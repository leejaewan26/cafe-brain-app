"""
YouTube Data API v3 — 카페·푸드 인플루언서 영상 트렌드.

쯔양·입짧은햇님 같은 한국 푸드 채널이 신메뉴 바이럴의 핵심 신호원.

API: https://developers.google.com/youtube/v3/docs/search/list
무료: 일 10,000 units (검색 1회 = 100 units → 일 100회)
"""
import os
from datetime import datetime, timedelta, timezone
from typing import Optional

import httpx

YT_SEARCH_URL = "https://www.googleapis.com/youtube/v3/search"
YT_VIDEOS_URL = "https://www.googleapis.com/youtube/v3/videos"


async def search_trending_videos(
    query: str,
    max_results: int = 10,
    region_code: str = "KR",
    days_back: int = 14,
) -> Optional[list[dict]]:
    """
    YouTube 검색 — 최근 N일 + 조회수 순 + 한국 지역.

    Args:
        query: 검색어 (예: '카페 신메뉴 트렌드')
        max_results: 1-50
        region_code: 'KR' (한국 지역 우선)
        days_back: 며칠 이내 영상

    Returns:
        [{"video_id", "title", "channel", "published_at", "view_count", "url"}] 또는 None
    """
    api_key = os.getenv("YOUTUBE_API_KEY", "")
    if not api_key or not query:
        return None

    published_after = (
        datetime.now(timezone.utc) - timedelta(days=days_back)
    ).strftime("%Y-%m-%dT%H:%M:%SZ")

    search_params = {
        "part": "snippet",
        "q": query,
        "type": "video",
        "order": "viewCount",
        "publishedAfter": published_after,
        "maxResults": min(50, max_results),
        "regionCode": region_code,
        "relevanceLanguage": "ko",
        "key": api_key,
    }

    try:
        async with httpx.AsyncClient(timeout=15) as client:
            r = await client.get(YT_SEARCH_URL, params=search_params)
            r.raise_for_status()
            search_items = r.json().get("items", [])
            if not search_items:
                return []

            # 영상 ID 모아서 통계 조회 (조회수)
            video_ids = [it["id"]["videoId"] for it in search_items if it.get("id", {}).get("videoId")]
            if not video_ids:
                return []

            stats_params = {
                "part": "statistics,snippet",
                "id": ",".join(video_ids),
                "key": api_key,
            }
            r2 = await client.get(YT_VIDEOS_URL, params=stats_params)
            r2.raise_for_status()
            stats_items = r2.json().get("items", [])

            results = []
            for it in stats_items:
                vid = it.get("id", "")
                snip = it.get("snippet", {})
                stats = it.get("statistics", {})
                results.append({
                    "video_id": vid,
                    "title": snip.get("title", ""),
                    "channel": snip.get("channelTitle", ""),
                    "published_at": snip.get("publishedAt", ""),
                    "view_count": int(stats.get("viewCount", 0)),
                    "like_count": int(stats.get("likeCount", 0)),
                    "url": f"https://www.youtube.com/watch?v={vid}",
                })

            results.sort(key=lambda x: x["view_count"], reverse=True)
            return results
    except Exception:
        return None
