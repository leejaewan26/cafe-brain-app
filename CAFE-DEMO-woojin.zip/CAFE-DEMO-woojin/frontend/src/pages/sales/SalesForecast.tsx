// 매출 예측 (Issue #2)
// 최근 4주 데이터를 요일별로 가중 평균 (최근 가중치 높음)
// 익일 예측 + 차주 7일 요일별 예측 차트
import { useMemo } from 'react'
import {
  LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip as RechartsTooltip,
  ResponsiveContainer, Bar, BarChart, ReferenceLine,
} from 'recharts'
import { TrendingUp, Calendar, AlertCircle } from 'lucide-react'
import type { SalesRecord } from '@/types/sales'
import { formatCurrency } from '@/lib/utils'

const DAY_LABELS = ['일', '월', '화', '수', '목', '금', '토']

interface SalesForecastProps {
  records: SalesRecord[]
}

export default function SalesForecast({ records }: SalesForecastProps) {
  // ─── 최근 4주 요일별 가중 회귀 ───
  const forecast = useMemo(() => {
    if (records.length === 0) return null

    const now = new Date()
    now.setHours(0, 0, 0, 0)

    // 최근 28일(4주) 필터
    const cutoff = new Date(now.getTime() - 28 * 24 * 3600 * 1000)
    const recent = records.filter((r) => new Date(r.sale_date) >= cutoff)

    if (recent.length < 14) {
      return { insufficient: true, daysOfData: recent.length }
    }

    // 주차·요일별로 집계 (최근 주일수록 높은 가중치)
    // 가중치: 최근 주 = 4, 2주전 = 3, 3주전 = 2, 4주전 = 1
    const dailyAggregates = new Map<string, { revenue: number }>()
    for (const r of recent) {
      const key = r.sale_date
      const prev = dailyAggregates.get(key) ?? { revenue: 0 }
      prev.revenue += r.revenue
      dailyAggregates.set(key, prev)
    }

    // 요일별 누적 (가중치 적용)
    const dowStats: Record<number, { weightedSum: number; weightTotal: number; samples: number }> =
      {}
    for (let d = 0; d < 7; d++) {
      dowStats[d] = { weightedSum: 0, weightTotal: 0, samples: 0 }
    }

    for (const [dateStr, { revenue }] of dailyAggregates) {
      const date = new Date(dateStr)
      const dow = date.getDay()
      const daysAgo = Math.floor((now.getTime() - date.getTime()) / (24 * 3600 * 1000))
      // 가중치: 0-6일(최근) = 4, 7-13일 = 3, 14-20일 = 2, 21-27일 = 1
      const weight = Math.max(1, 4 - Math.floor(daysAgo / 7))
      dowStats[dow].weightedSum += revenue * weight
      dowStats[dow].weightTotal += weight
      dowStats[dow].samples += 1
    }

    // 요일별 예측 값
    const dayForecasts = Array.from({ length: 7 }, (_, dow) => {
      const s = dowStats[dow]
      const predicted = s.weightTotal > 0 ? s.weightedSum / s.weightTotal : 0
      return {
        dow,
        label: DAY_LABELS[dow],
        predicted: Math.round(predicted),
        samples: s.samples,
        confidence: s.samples >= 3 ? 'high' : s.samples >= 1 ? 'medium' : 'low',
      }
    })

    // 내일 요일
    const tomorrow = new Date(now.getTime() + 24 * 3600 * 1000)
    const tomorrowDow = tomorrow.getDay()
    const tomorrowForecast = dayForecasts[tomorrowDow]

    // 차주 7일 예측 (내일부터 7일)
    const nextWeek = Array.from({ length: 7 }, (_, i) => {
      const d = new Date(now.getTime() + (i + 1) * 24 * 3600 * 1000)
      const dow = d.getDay()
      const f = dayForecasts[dow]
      return {
        date: `${d.getMonth() + 1}/${d.getDate()}`,
        day: DAY_LABELS[dow],
        predicted: f.predicted,
        confidence: f.confidence,
      }
    })

    // 최근 실제 매출 (비교용)
    const last14Days = Array.from(dailyAggregates.entries())
      .sort(([a], [b]) => a.localeCompare(b))
      .slice(-14)
      .map(([date, { revenue }]) => ({
        date: date.slice(5), // MM-DD
        actual: revenue,
      }))

    return {
      insufficient: false,
      tomorrowForecast,
      dayForecasts,
      nextWeek,
      last14Days,
      weeklyTotal: nextWeek.reduce((s, d) => s + d.predicted, 0),
    }
  }, [records])

  if (!forecast) {
    return (
      <div className="bg-white rounded-2xl p-8 border border-gray-100 shadow-sm text-center">
        <Calendar size={28} className="mx-auto mb-2 text-gray-300" />
        <p className="text-sm text-gray-400">매출 데이터가 없어요</p>
      </div>
    )
  }

  if (forecast.insufficient) {
    return (
      <div className="bg-amber-50 border border-amber-100 rounded-2xl p-4 flex items-start gap-3">
        <AlertCircle size={20} className="text-amber-500 shrink-0 mt-0.5" />
        <div>
          <p className="font-semibold text-amber-700 text-sm mb-1">데이터가 더 필요해요</p>
          <p className="text-xs text-amber-600 leading-relaxed">
            현재 {forecast.daysOfData ?? 0}일 분의 데이터가 있습니다. 매출 예측은 최근 14일 이상의 데이터가
            필요해요. 데이터가 더 쌓일수록 예측 정확도가 높아집니다.
          </p>
        </div>
      </div>
    )
  }

  // 타입 좁히기: insufficient=false면 모든 필드 존재
  const { tomorrowForecast, nextWeek, last14Days, weeklyTotal } = forecast as Required<typeof forecast>
  if (!tomorrowForecast || !nextWeek || !last14Days) return null

  return (
    <div className="space-y-4">
      {/* 내일 예측 하이라이트 */}
      <div className="bg-gradient-to-br from-[#2C1810] via-[#3d2418] to-[#2C1810] rounded-2xl p-5 text-white relative overflow-hidden">
        <div className="relative z-10">
          <div className="flex items-center gap-2 mb-2">
            <TrendingUp size={16} className="text-[#D4A574]" />
            <p className="text-[#D4A574] text-xs font-semibold">내일 매출 예측</p>
            <span className={`ml-auto text-[10px] font-bold px-2 py-0.5 rounded-full ${
              tomorrowForecast.confidence === 'high' ? 'bg-green-400/20 text-green-200'
              : tomorrowForecast.confidence === 'medium' ? 'bg-amber-400/20 text-amber-200'
              : 'bg-red-400/20 text-red-200'
            }`}>
              신뢰도 {tomorrowForecast.confidence === 'high' ? '높음'
                : tomorrowForecast.confidence === 'medium' ? '보통' : '낮음'}
            </span>
          </div>
          <p className="text-3xl font-bold mt-2">{formatCurrency(tomorrowForecast.predicted)}</p>
          <p className="text-white/60 text-xs mt-1">
            {tomorrowForecast.label}요일 기준 · 최근 {tomorrowForecast.samples}주 평균
          </p>
        </div>
        <div className="absolute right-4 top-1/2 -translate-y-1/2 text-6xl opacity-10 font-bold">
          {tomorrowForecast.label}
        </div>
      </div>

      {/* 차주 7일 예측 차트 */}
      <div className="bg-white rounded-2xl p-4 border border-gray-100 shadow-sm">
        <div className="flex items-center justify-between mb-3">
          <h3 className="text-sm font-bold text-[#2C1810]">📅 차주 7일 예측</h3>
          <span className="text-xs text-gray-500">
            합계 약 <strong className="text-[#D4A574]">{formatCurrency(weeklyTotal)}</strong>
          </span>
        </div>
        <ResponsiveContainer width="100%" height={240}>
          <BarChart data={nextWeek} margin={{ top: 10, right: 12, bottom: 30, left: 0 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="var(--border-hair)" vertical={false} />
            <XAxis
              dataKey="day"
              tick={{ fontSize: 11, fill: 'var(--text-mute)' }}
              interval={0}
              tickLine={false}
              axisLine={{ stroke: 'var(--border-hair)' }}
            />
            <YAxis
              tick={{ fontSize: 10, fill: 'var(--text-mute)' }}
              tickFormatter={(v) => `${(v / 10000).toFixed(0)}만`}
              width={45}
              tickLine={false}
              axisLine={false}
            />
            <RechartsTooltip
              formatter={(value) => formatCurrency(Number(value))}
              labelFormatter={(_label, payload) => {
                const d = payload?.[0]?.payload
                return d ? `${d.date} (${d.day}요일)` : ''
              }}
              cursor={{ fill: 'rgba(212,165,116,0.1)' }}
              contentStyle={{ background: 'var(--bg-card)', border: '1px solid var(--border-hair)', borderRadius: 12, fontSize: 12 }}
            />
            <Bar dataKey="predicted" name="예측 매출" fill="#D4A574" radius={[8, 8, 0, 0]} maxBarSize={50} />
          </BarChart>
        </ResponsiveContainer>
        <div className="grid grid-cols-7 gap-1 text-[10px] text-gray-400 text-center mt-1 px-1">
          {nextWeek.map((d, i) => (<span key={i}>{d.date}</span>))}
        </div>
      </div>

      {/* 최근 14일 실제 매출 추이 — tick 간격 자동 조정 */}
      <div className="bg-white dark:bg-gray-800 rounded-2xl p-4 border border-gray-100 dark:border-gray-700 shadow-sm">
        <h3 className="text-sm font-bold text-[#2C1810] dark:text-gray-100 mb-3">📈 최근 14일 실제 매출</h3>
        <ResponsiveContainer width="100%" height={200}>
          <LineChart data={last14Days} margin={{ top: 10, right: 12, bottom: 10, left: 0 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="var(--border-hair)" vertical={false} />
            <XAxis
              dataKey="date"
              tick={{ fontSize: 10, fill: 'var(--text-mute)' }}
              interval="preserveStartEnd"
              minTickGap={22}
              tickLine={false}
              axisLine={{ stroke: 'var(--border-hair)' }}
            />
            <YAxis
              tick={{ fontSize: 10, fill: 'var(--text-mute)' }}
              tickFormatter={(v) => `${(v / 10000).toFixed(0)}만`}
              width={45}
              tickLine={false}
              axisLine={false}
            />
            <RechartsTooltip
              formatter={(v) => formatCurrency(Number(v))}
              contentStyle={{ background: 'var(--bg-card)', border: '1px solid var(--border-hair)', borderRadius: 12, fontSize: 12 }}
            />
            <Line type="monotone" dataKey="actual" name="실제 매출" stroke="#2C1810"
              strokeWidth={2} dot={{ fill: '#2C1810', r: 3 }} activeDot={{ r: 5 }} />
            <ReferenceLine
              y={last14Days.reduce((s, d) => s + d.actual, 0) / last14Days.length}
              stroke="#D4A574" strokeDasharray="3 3"
              label={{ value: '평균', position: 'right', fill: '#D4A574', fontSize: 10 }}
            />
          </LineChart>
        </ResponsiveContainer>
      </div>

      {/* 안내 */}
      <div className="bg-blue-50/50 border border-blue-100 rounded-xl p-3 text-xs text-blue-700 flex items-start gap-2">
        <AlertCircle size={13} className="mt-0.5 shrink-0" />
        <div>
          <p className="font-semibold mb-1">예측 방식</p>
          <p className="leading-relaxed">
            최근 4주 요일별 매출을 가중 평균(최근 주일수록 가중치 ↑)합니다.
            데이터가 더 쌓일수록, 공휴일·시즌 이벤트를 고려할수록 정확도가 올라갑니다.
          </p>
        </div>
      </div>
    </div>
  )
}
