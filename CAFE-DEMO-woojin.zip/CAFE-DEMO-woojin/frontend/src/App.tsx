// 메인 라우터 — React.lazy 코드 스플리팅 + AppLayout 통합
// 4단계 최종 통합: 모든 보호 라우트를 AppLayout으로 래핑
import { lazy, Suspense } from 'react'
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom'
import { Toaster } from 'react-hot-toast'
import { Loader2 } from 'lucide-react'
import { ProtectedRoute, PublicOnlyRoute } from '@/components/guards/RouteGuard'
import AppLayout from '@/components/AppLayout'
import AiChat from '@/components/AiChat'

// ─── 코드 스플리팅: 동적 임포트로 초기 번들 최소화 ───
const LandingPage       = lazy(() => import('@/pages/landing/LandingPage'))
const LoginPage         = lazy(() => import('@/pages/auth/LoginPage'))
const OnboardingPage    = lazy(() => import('@/pages/auth/OnboardingPage'))
const ProfileSelectPage = lazy(() => import('@/pages/auth/ProfileSelectPage'))
const DashboardPage     = lazy(() => import('@/pages/DashboardPage'))
const SalesPage       = lazy(() => import('@/pages/sales/SalesPage'))
const SchedulePage    = lazy(() => import('@/pages/schedule/SchedulePage'))
const ReviewPage      = lazy(() => import('@/pages/reviews/ReviewPage'))
const MarketingPage   = lazy(() => import('@/pages/marketing/MarketingPage'))
const MenuPage        = lazy(() => import('@/pages/menu/MenuPage'))
const OrderPage       = lazy(() => import('@/pages/orders/OrderPage'))
const IngredientsPage = lazy(() => import('@/pages/ingredients/IngredientsPage'))
const AccountingPage  = lazy(() => import('@/pages/accounting/AccountingPage'))
const SupplierPage    = lazy(() => import('@/pages/supplier/SupplierPage'))
const SettingsPage    = lazy(() => import('@/pages/settings/SettingsPage'))
const BillingPage     = lazy(() => import('@/pages/billing/BillingPage'))
const TaxInvoicePage  = lazy(() => import('@/pages/billing/TaxInvoicePage'))
const FaqPage         = lazy(() => import('@/pages/faq/FaqPage'))
const ChatPage        = lazy(() => import('@/pages/chat/ChatPage'))
const TrendsPage      = lazy(() => import('@/pages/trends/TrendsPage'))
// Launch A2/A3: 법무 페이지 (공개 — 인증 X)
const PrivacyPage     = lazy(() => import('@/pages/legal/PrivacyPage'))
const TermsPage       = lazy(() => import('@/pages/legal/TermsPage'))
// F2~F5: 에이전트 고급 도구 (Plan, Compare, Memory Search, Audit)
const AgentToolsPage  = lazy(() => import('@/pages/agent/AgentToolsPage'))
// G6: 운영자 admin (X-Admin-Key 인증, 공개 라우트지만 키 없으면 차단)
const AdminPage       = lazy(() => import('@/pages/admin/AdminPage'))
// H2/H3/H5: 외부 연동 통합 페이지 (네이버/POS/Instagram/n8n)
const IntegrationsPage = lazy(() => import('@/pages/settings/IntegrationsPage'))
// J1/J2: 공개 변경이력 + 로드맵 (인증 X)
const ChangelogPage    = lazy(() => import('@/pages/public/ChangelogPage'))
const RoadmapPage      = lazy(() => import('@/pages/public/RoadmapPage'))
// J3~J6: 차별화 기능 (청결/퀴즈/음성/벤치마크)
const DifferentiationPage = lazy(() => import('@/pages/differentiation/DifferentiationPage'))

// ─── 페이지 로딩 fallback ───
function PageLoader() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-[#FAFAF8]">
      <div className="flex flex-col items-center gap-3">
        <Loader2 className="w-8 h-8 animate-spin text-[#D4A574]" />
        <p className="text-sm text-gray-400">불러오는 중...</p>
      </div>
    </div>
  )
}

function App() {
  return (
    <BrowserRouter>
      {/* 전역 토스트 알림 — WCAG AA 대비 4.5:1+ 보장 (Day 1-3) */}
      <Toaster
        position="top-right"
        toastOptions={{
          duration: 3000,
          style: {
            fontFamily: 'Pretendard, sans-serif',
            fontSize: '14px',
            padding: '12px 16px',
            borderRadius: '12px',
            boxShadow: '0 4px 12px rgba(0,0,0,0.12)',
          },
          // success: bg green-100 + text green-900 + border green-700 → 10.8:1 ✅
          success: {
            iconTheme: { primary: '#15803d', secondary: '#dcfce7' },
            style: {
              background: '#dcfce7',
              color: '#14532d',
              border: '2px solid #15803d',
              fontWeight: 600,
            },
            ariaProps: { role: 'status', 'aria-live': 'polite' },
          },
          // error: bg red-100 + text red-900 + border red-700 → 11.2:1 ✅
          error: {
            iconTheme: { primary: '#b91c1c', secondary: '#fee2e2' },
            style: {
              background: '#fee2e2',
              color: '#7f1d1d',
              border: '2px solid #b91c1c',
              fontWeight: 600,
            },
            ariaProps: { role: 'alert', 'aria-live': 'assertive' },
          },
        }}
      />

      <Suspense fallback={<PageLoader />}>
        <Routes>
          {/* 공개 랜딩 페이지 */}
          <Route path="/" element={<LandingPage />} />

          {/* Launch A2/A3: 법무 페이지 — 누구나 (인증 X) */}
          <Route path="/privacy" element={<PrivacyPage />} />
          <Route path="/terms" element={<TermsPage />} />
          {/* G6: 운영자 — Admin 키 인증 */}
          <Route path="/admin" element={<AdminPage />} />
          {/* J1/J2: 공개 페이지 (인증 X) */}
          <Route path="/changelog" element={<ChangelogPage />} />
          <Route path="/roadmap" element={<RoadmapPage />} />

          {/* 공개 라우트 */}
          <Route element={<PublicOnlyRoute />}>
            <Route path="/login" element={<LoginPage />} />
          </Route>

          {/* 온보딩 (인증 후, 공유 레이아웃 없음) */}
          <Route path="/onboarding" element={<OnboardingPage />} />

          {/* 프로필 선택 (Issue #5) — 인증 + 온보딩 완료 후 진입 */}
          <Route path="/profile-select" element={<ProfileSelectPage />} />

          {/* ✅ 보호된 라우트 — AppLayout으로 감싸기 */}
          <Route element={<ProtectedRoute />}>
            <Route element={<AppLayout />}>
              <Route path="/dashboard"   element={<DashboardPage />} />
              {/* 매출·운영 분석 */}
              <Route path="/sales/*"     element={<SalesPage />} />
              {/* 스마트 스케줄링 */}
              <Route path="/schedule/*"  element={<SchedulePage />} />
              {/* 리뷰 관리 */}
              <Route path="/reviews/*"   element={<ReviewPage />} />
              {/* 마케팅 콘텐츠 생성 */}
              <Route path="/marketing"   element={<MarketingPage />} />
              {/* 메뉴·레시피 & 교육 매뉴얼 */}
              <Route path="/menu/*"      element={<MenuPage />} />
              {/* 발주 관리 (Issue #8) */}
              <Route path="/orders"      element={<OrderPage />} />
              {/* 재료 원가 DB (Issue #18) */}
              <Route path="/ingredients" element={<IngredientsPage />} />
              {/* 회계·손익 (Issue #20) */}
              <Route path="/accounting"  element={<AccountingPage />} />
              {/* 공급처 절감 AI (Issue #9) */}
              <Route path="/supplier"    element={<SupplierPage />} />
              {/* 설정 (Wave 1 W1-A) */}
              <Route path="/settings"    element={<SettingsPage />} />
              {/* 결제·구독 (Day 3-1) */}
              <Route path="/billing"     element={<BillingPage />} />
              <Route path="/billing/success" element={<BillingPage />} />
              <Route path="/billing/fail"    element={<BillingPage />} />
              <Route path="/billing/tax-invoice" element={<TaxInvoicePage />} />
              {/* FAQ·고객지원 (Day 6-3) */}
              <Route path="/faq"         element={<FaqPage />} />
              {/* AI 어시스턴트 풀스크린 페이지 */}
              <Route path="/chat"        element={<ChatPage />} />
              {/* Phase 4: 시장 트렌드 분석 (7-source) */}
              <Route path="/trends"      element={<TrendsPage />} />
              {/* F2~F5: 에이전트 도구 모음 */}
              <Route path="/agent-tools" element={<AgentToolsPage />} />
              {/* H2/H3/H5: 외부 연동 (네이버, POS, Instagram, n8n) */}
              <Route path="/integrations" element={<IntegrationsPage />} />
              {/* J3~J6: 차별화 (청결/퀴즈/음성/벤치마크) */}
              <Route path="/lab" element={<DifferentiationPage />} />
            </Route>
          </Route>

          {/* 없는 경로 */}
          <Route path="*" element={<Navigate to="/dashboard" replace />} />
        </Routes>
      </Suspense>

      {/* ✅ AI 어시스턴트 플로팅 채팅 (모든 페이지 공통) */}
      <AiChat />
    </BrowserRouter>
  )
}

export default App
