"""
에이전트 게이트 미들웨어 (Phase 3) — Gemini 토큰 비용 폭발 방지

비싼 백그라운드 트리거(/api/agent/briefing, /distill, /learning/nudge-profile)에 게이트.

게이트 통과 조건 (둘 다 만족해야 실행):
1. 운영 시간: KST 기준 settings.agent_hour_open ~ agent_hour_close (기본 06~22시)
2. 인증된 호출:
   - Authorization: Bearer <jwt> (사용자 활성 세션) OR
   - X-Admin-Key: <key> (지정된 cron / 백그라운드 작업)

게이트 실패 시:
- 204 No Content + X-Agent-Skipped 헤더로 사유 표시
- 클라이언트(useAgentBriefing 등)는 이를 무시하고 정상 흐름 유지

왜 필요한가:
- useAgentBriefing 훅은 localStorage 마커로 일일 1회 보호하지만,
  새 디바이스/시크릿 모드/캐시 삭제 시 우회 가능
- 외부 모니터링·헬스체크가 /briefing 같은 경로 폴링하면 매번 Gemini 호출
- 영업 시간(밤·새벽) 밖에는 사장님이 안 볼 알림이라 토큰 가치 0
"""
import asyncio
from datetime import datetime, timedelta, timezone
from time import time as _now
from typing import Optional

from fastapi import Request
from fastapi.responses import Response
from starlette.middleware.base import BaseHTTPMiddleware

from app.config import settings


# 게이트 적용 경로 (Gemini 직접 호출하는 비싼 트리거)
GATED_PATHS = (
    "/api/agent/briefing",         # 능동 브리핑 (매번 Gemini)
    "/api/agent/distill",          # 메모리 → 프로필 증류 (Gemini, 무거움)
    "/api/learning/nudge-profile", # 위 distill을 wrapping
)

# Asia/Seoul 표준시
KST = timezone(timedelta(hours=9))

# Phase 3: 매장별 영업시간 5분 인메모리 캐시 (Supabase 부담 최소화)
_STORE_HOURS_TTL_SEC = 300
_store_hours_cache: dict[str, tuple[int, int, float]] = {}  # store_id → (open, close, expires_at)


async def _fetch_store_hours(store_id: str) -> Optional[tuple[int, int]]:
    """Supabase에서 매장 영업시간 조회. 실패 시 None."""
    try:
        from app.services.gemini_service import _get_supabase

        sb = _get_supabase()
        if sb is None:
            return None
        row = await asyncio.to_thread(
            lambda: sb.table("stores")
            .select("open_hour, close_hour")
            .eq("id", store_id)
            .limit(1)
            .execute()
        )
        if row.data:
            open_h = row.data[0].get("open_hour") or settings.agent_hour_open
            close_h = row.data[0].get("close_hour") or settings.agent_hour_close
            return int(open_h), int(close_h)
    except Exception:
        pass
    return None


async def get_operating_hours(store_id: Optional[str] = None) -> tuple[int, int]:
    """매장별 영업시간 조회 (5분 캐시). 없거나 실패 시 글로벌 기본값."""
    if not store_id:
        return settings.agent_hour_open, settings.agent_hour_close

    cached = _store_hours_cache.get(store_id)
    if cached:
        open_h, close_h, expires = cached
        if _now() < expires:
            return open_h, close_h

    fetched = await _fetch_store_hours(store_id)
    if fetched is None:
        return settings.agent_hour_open, settings.agent_hour_close

    open_h, close_h = fetched
    _store_hours_cache[store_id] = (open_h, close_h, _now() + _STORE_HOURS_TTL_SEC)
    return open_h, close_h


async def is_within_operating_hours(
    store_id: Optional[str] = None,
) -> tuple[bool, int, int, int]:
    """
    현재 KST 시각이 (매장별) 운영 시간 안인지 확인.

    Args:
        store_id: 매장 ID. 있으면 매장별 영업시간 사용, 없으면 글로벌 기본값(env).

    Returns:
        (within, now_h, open_h, close_h)
    """
    open_h, close_h = await get_operating_hours(store_id)
    now_h = datetime.now(KST).hour
    within = open_h <= now_h < close_h
    return within, now_h, open_h, close_h


def is_authenticated_call(request: Request) -> tuple[bool, str]:
    """
    호출자가 인증된 사용자거나 신뢰된 cron인지.

    Returns:
        (allowed, reason)
    """
    auth = request.headers.get("Authorization", "")
    if auth.startswith("Bearer "):
        return True, "user"

    admin = request.headers.get("X-Admin-Key", "")
    if settings.agent_admin_key and admin == settings.agent_admin_key:
        return True, "admin"

    return False, "no-active-session"


class AgentGateMiddleware(BaseHTTPMiddleware):
    """에이전트 비싼 호출 게이트 — 운영 시간 + 활성 세션 둘 다 통과해야 실행."""

    async def dispatch(self, request: Request, call_next):
        # 게이트 적용 대상이 아니면 즉시 통과
        if not request.url.path.startswith(GATED_PATHS):
            return await call_next(request)

        # 1) 운영 시간 체크 (가장 빠른 거부) — 매장별 영업시간 우선
        store_id = request.headers.get("X-Store-Id")
        within, now_h, open_h, close_h = await is_within_operating_hours(store_id)
        if not within:
            return Response(
                status_code=204,
                headers={
                    "X-Agent-Skipped": (
                        f"outside-operating-hours "
                        f"(KST {open_h:02d}:00–{close_h:02d}:00, now {now_h:02d}:xx)"
                    ),
                },
            )

        # 2) 활성 세션 / 인증 체크
        allowed, reason = is_authenticated_call(request)
        if not allowed:
            return Response(
                status_code=204,
                headers={"X-Agent-Skipped": reason},
            )

        return await call_next(request)
