// 스마트 스케줄링 모듈 메인 페이지
// 탭 1: 직원 관리 | 탭 2: 주간 스케줄 | 탭 3: 인건비 분석
import { useState, useMemo, useCallback } from 'react'
import { Link } from 'react-router-dom'
import {
  Calendar, ChevronLeft, Plus, Trash2, Edit3,
  Sparkles, Download, AlertTriangle, ChevronLeft as Prev, ChevronRight as Next,
  X, Loader2, Printer,
} from 'lucide-react'
import { useScheduleStore } from '@/store/scheduleStore'
import { useSalesStore } from '@/store/salesStore'
import type { Employee, Shift, EmploymentType, AutoScheduleConfig, JuhusuModeWarning } from '@/types/schedule'
import { useProfileStore } from '@/store/profileStore'
import { useAuthStore } from '@/store/authStore'
import { cn, formatCurrency } from '@/lib/utils'

// ─── 상수 ───
const DAY_LABELS = ['월', '화', '수', '목', '금', '토', '일']
const WEEKDAY_NUMS = [1, 2, 3, 4, 5, 6, 0] // ISO: 0=일, 실제 캘린더 월=1

const EMP_TYPE_LABEL: Record<EmploymentType, string> = {
  full_time: '풀타임',
  part_time: '파트타임',
  daily: '일용직',
}

// ─── 날짜 유틸 ───
function getMonday(date: Date): Date {
  const d = new Date(date)
  const day = d.getDay()
  const diff = (day === 0 ? -6 : 1 - day)
  d.setDate(d.getDate() + diff)
  d.setHours(0, 0, 0, 0)
  return d
}

function toISO(date: Date): string {
  return date.toISOString().split('T')[0]
}

function addDays(date: Date, days: number): Date {
  const d = new Date(date)
  d.setDate(d.getDate() + days)
  return d
}

function formatWeekRange(monday: Date): string {
  const sunday = addDays(monday, 6)
  return `${monday.getMonth() + 1}/${monday.getDate()} ~ ${sunday.getMonth() + 1}/${sunday.getDate()}`
}

// ─── 노무 규정: 휴게시간 계산 ───
function calcBreakMinutes(workHours: number): number {
  if (workHours >= 8) return 60
  if (workHours >= 4) return 30
  return 0
}

// ─── 노무 규정: 주휴수당 계산 ───
function calcJuhusu(weeklyHours: number, dailyAvgHours: number, hourlyRate: number): number {
  if (weeklyHours >= 15) return dailyAvgHours * hourlyRate
  return 0
}

// ─── 시프트 위반 체크 ───
function checkShiftWarnings(
  shift: Shift,
  employee: Employee,
  allShifts: Shift[]
): string[] {
  const warnings: string[] = []

  // 불가 요일 위반 (day_index: 0=월~6=일 → weekday: 1=월~0=일)
  const weekday = WEEKDAY_NUMS[shift.day_index]
  if (employee.unavailable_days.includes(weekday)) {
    warnings.push('불가 요일에 배정됨')
  }

  // 근무 8시간 이상 → 60분 휴게 필요
  const workHours = shift.end_hour - shift.start_hour
  if (workHours > 8) warnings.push('1일 근무 8시간 초과')

  // 주 최대시간 체크
  const weekShifts = allShifts.filter(
    (s) => s.employee_id === shift.employee_id && s.week_start === shift.week_start && !s.is_off
  )
  const weeklyHours = weekShifts.reduce((sum, s) => sum + (s.end_hour - s.start_hour), 0)
  if (weeklyHours > employee.max_weekly_hours) {
    warnings.push(`주 ${weeklyHours}h (최대 ${employee.max_weekly_hours}h 초과)`)
  }

  return warnings
}

// ═══════════════════════════════════════════
// ─── 탭 1: 직원 관리 ───
// ═══════════════════════════════════════════
const DEFAULT_EMP: Omit<Employee, 'id' | 'color'> = {
  name: '',
  employment_type: 'part_time',
  hourly_rate: 10030,
  preferred_start: 9,
  preferred_end: 17,
  max_weekly_hours: 25,
  unavailable_days: [],
}

function EmployeeManager() {
  const { employees, addEmployee, updateEmployee, deleteEmployee } = useScheduleStore()
  const [editId, setEditId] = useState<string | null>(null)
  const [form, setForm] = useState<Omit<Employee, 'id' | 'color'>>(DEFAULT_EMP)
  const [showForm, setShowForm] = useState(false)

  const openAdd = () => {
    setForm(DEFAULT_EMP)
    setEditId(null)
    setShowForm(true)
  }

  const openEdit = (emp: Employee) => {
    setForm({
      name: emp.name,
      employment_type: emp.employment_type,
      hourly_rate: emp.hourly_rate,
      preferred_start: emp.preferred_start,
      preferred_end: emp.preferred_end,
      max_weekly_hours: emp.max_weekly_hours,
      unavailable_days: emp.unavailable_days,
    })
    setEditId(emp.id)
    setShowForm(true)
  }

  const handleSave = () => {
    if (!form.name.trim()) return
    if (editId) {
      updateEmployee(editId, form)
    } else {
      addEmployee(form)
    }
    setShowForm(false)
    setEditId(null)
  }

  const toggleDay = (day: number) => {
    setForm((f) => ({
      ...f,
      unavailable_days: f.unavailable_days.includes(day)
        ? f.unavailable_days.filter((d) => d !== day)
        : [...f.unavailable_days, day],
    }))
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="font-bold text-[#2C1810]">직원 목록 ({employees.length}명)</h3>
        <button onClick={openAdd}
          className="flex items-center gap-1.5 px-4 py-2 bg-[#2C1810] text-white rounded-xl text-sm font-medium hover:bg-[#3d2418] transition-colors duration-200">
          <Plus size={15} />
          직원 추가
        </button>
      </div>

      {/* 직원 카드 목록 */}
      <div className="space-y-3">
        {employees.map((emp) => (
          <div key={emp.id}
            className="bg-white rounded-2xl p-4 border border-gray-100 shadow-sm flex items-start gap-3">
            {/* 색상 뱃지 */}
            <div className="w-10 h-10 rounded-xl flex items-center justify-center text-white text-sm font-bold shrink-0"
              style={{ backgroundColor: emp.color }}>
              {emp.name.slice(0, 1)}
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2 mb-1">
                <p className="font-semibold text-[#2C1810]">{emp.name}</p>
                <span className={cn('text-xs px-2 py-0.5 rounded-full font-medium',
                  emp.employment_type === 'full_time'
                    ? 'bg-blue-100 text-blue-700'
                    : 'bg-orange-100 text-orange-700'
                )}>
                  {EMP_TYPE_LABEL[emp.employment_type]}
                </span>
              </div>
              <div className="text-xs text-gray-500 space-y-0.5">
                <p>시급 {emp.hourly_rate.toLocaleString()}원 · 주 최대 {emp.max_weekly_hours}h</p>
                <p>선호: {emp.preferred_start}시~{emp.preferred_end}시</p>
                {emp.unavailable_days.length > 0 && (
                  <p>불가 요일: {emp.unavailable_days.map((d) => ['일', '월', '화', '수', '목', '금', '토'][d]).join(', ')}</p>
                )}
              </div>
            </div>
            <div className="flex gap-2 shrink-0">
              <button onClick={() => openEdit(emp)} className="p-1.5 text-gray-400 hover:text-[#2C1810] transition-colors duration-200">
                <Edit3 size={15} />
              </button>
              <button onClick={() => deleteEmployee(emp.id)} className="p-1.5 text-gray-400 hover:text-red-500 transition-colors duration-200">
                <Trash2 size={15} />
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* 직원 추가/수정 모달 */}
      {showForm && (
        <div className="fixed inset-0 bg-black/40 z-50 flex items-end md:items-center justify-center p-4">
          <div className="bg-white rounded-2xl p-6 w-full max-w-sm shadow-xl">
            <div className="flex items-center justify-between mb-4">
              <h4 className="font-bold text-[#2C1810]">{editId ? '직원 수정' : '직원 추가'}</h4>
              <button onClick={() => setShowForm(false)}><X size={18} className="text-gray-400" /></button>
            </div>
            <div className="space-y-3">
              <div>
                <label className="block text-xs font-medium text-gray-600 mb-1">이름 *</label>
                <input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })}
                  placeholder="직원 이름"
                  className="w-full px-3 py-2 rounded-xl border border-gray-200 text-sm focus:outline-none focus:ring-2 focus:ring-[#D4A574]" />
              </div>
              <div>
                <label className="block text-xs font-medium text-gray-600 mb-1">고용형태</label>
                <select value={form.employment_type} onChange={(e) => setForm({ ...form, employment_type: e.target.value as EmploymentType })}
                  className="w-full px-3 py-2 rounded-xl border border-gray-200 text-sm focus:outline-none focus:ring-2 focus:ring-[#D4A574]">
                  <option value="full_time">풀타임</option>
                  <option value="part_time">파트타임</option>
                  <option value="daily">일용직</option>
                </select>
              </div>
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-xs font-medium text-gray-600 mb-1">시급 (원)</label>
                  <input type="number" value={form.hourly_rate} onChange={(e) => setForm({ ...form, hourly_rate: +e.target.value })}
                    className="w-full px-3 py-2 rounded-xl border border-gray-200 text-sm focus:outline-none focus:ring-2 focus:ring-[#D4A574]" />
                </div>
                <div>
                  <label className="block text-xs font-medium text-gray-600 mb-1">주 최대시간</label>
                  <input type="number" value={form.max_weekly_hours} onChange={(e) => setForm({ ...form, max_weekly_hours: +e.target.value })}
                    className="w-full px-3 py-2 rounded-xl border border-gray-200 text-sm focus:outline-none focus:ring-2 focus:ring-[#D4A574]" />
                </div>
                <div>
                  <label className="block text-xs font-medium text-gray-600 mb-1">선호 시작 (시)</label>
                  <input type="number" min={0} max={23} value={form.preferred_start} onChange={(e) => setForm({ ...form, preferred_start: +e.target.value })}
                    className="w-full px-3 py-2 rounded-xl border border-gray-200 text-sm focus:outline-none focus:ring-2 focus:ring-[#D4A574]" />
                </div>
                <div>
                  <label className="block text-xs font-medium text-gray-600 mb-1">선호 종료 (시)</label>
                  <input type="number" min={1} max={24} value={form.preferred_end} onChange={(e) => setForm({ ...form, preferred_end: +e.target.value })}
                    className="w-full px-3 py-2 rounded-xl border border-gray-200 text-sm focus:outline-none focus:ring-2 focus:ring-[#D4A574]" />
                </div>
              </div>
              <div>
                <label className="block text-xs font-medium text-gray-600 mb-2">불가 요일</label>
                <div className="flex gap-2 flex-wrap">
                  {['일', '월', '화', '수', '목', '금', '토'].map((d, i) => (
                    <button key={i} onClick={() => toggleDay(i)}
                      className={cn('w-8 h-8 rounded-lg text-xs font-medium transition-all duration-200',
                        form.unavailable_days.includes(i)
                          ? 'bg-red-100 text-red-600 ring-1 ring-red-300'
                          : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                      )}>
                      {d}
                    </button>
                  ))}
                </div>
              </div>
            </div>
            <div className="flex gap-2 mt-5">
              <button onClick={() => setShowForm(false)}
                className="flex-1 py-2.5 rounded-xl border border-gray-200 text-sm text-gray-600 hover:bg-gray-50 transition-colors duration-200">
                취소
              </button>
              <button onClick={handleSave}
                className="flex-1 py-2.5 rounded-xl bg-[#2C1810] text-white text-sm font-semibold hover:bg-[#3d2418] transition-colors duration-200">
                저장
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

// ═══════════════════════════════════════════
// ─── 탭 2: 주간 스케줄 캘린더 ───
// ═══════════════════════════════════════════

// 자동 스케줄 생성 알고리즘 (Issue #6: juhusu_mode 반영)
function generateAutoSchedule(
  employees: Employee[],
  weekStart: string,
  _peakHours: number[],  // 피크타임 데이터 - 추후 고도화 시 사용
  config: AutoScheduleConfig
): { shifts: Shift[]; warning: JuhusuModeWarning | null } {
  const shifts: Shift[] = []
  // 최소화 모드에서 각 직원의 누적 주간 근무시간 추적
  const empWeeklyHours = new Map<string, number>(employees.map((e) => [e.id, 0]))
  // 최소화 모드 상한 (15시간 직전에 멈추도록)
  const MINIMIZE_CAP = 14.5

  for (let dayIdx = 0; dayIdx < 7; dayIdx++) {
    const weekday = WEEKDAY_NUMS[dayIdx]
    const available = employees.filter((e) => !e.unavailable_days.includes(weekday))

    const isPeakDay = dayIdx < 5
    const targetStaff = isPeakDay
      ? Math.min(available.length, config.max_daily_staff)
      : config.min_daily_staff

    // 최소화 모드: 누적 시간 적은 직원부터 선택 (로테이션)
    const sorted = config.juhusu_mode === 'minimize'
      ? [...available].sort((a, b) => (empWeeklyHours.get(a.id) ?? 0) - (empWeeklyHours.get(b.id) ?? 0))
      : available

    const selected: Employee[] = []
    for (const emp of sorted) {
      if (selected.length >= targetStaff) break
      if (config.juhusu_mode === 'minimize') {
        // 이미 주 15시간에 가까우면 스킵
        if ((empWeeklyHours.get(emp.id) ?? 0) >= MINIMIZE_CAP) continue
      }
      selected.push(emp)
    }

    for (const emp of selected) {
      const startH = emp.preferred_start
      let endH = Math.min(emp.preferred_end, startH + (dayIdx < 5 ? 8 : 6))

      // 최소화 모드: 남은 허용 시간만큼만 배정
      if (config.juhusu_mode === 'minimize') {
        const used = empWeeklyHours.get(emp.id) ?? 0
        const remaining = Math.max(0, MINIMIZE_CAP - used)
        const maxToday = Math.min(endH - startH, Math.floor(remaining))
        if (maxToday <= 0) continue
        endH = startH + maxToday
      }

      const workH = endH - startH
      if (workH <= 0) continue
      const breakMin = calcBreakMinutes(workH)
      // 순 근무시간 (휴게 제외)
      const netHours = workH - breakMin / 60
      empWeeklyHours.set(emp.id, (empWeeklyHours.get(emp.id) ?? 0) + netHours)

      shifts.push({
        id: `shift-${Date.now()}-${emp.id}-${dayIdx}`,
        employee_id: emp.id,
        week_start: weekStart,
        day_index: dayIdx,
        start_hour: startH,
        end_hour: endH,
        break_minutes: breakMin,
        is_off: false,
        warnings: [],
      })
    }

    // 선택되지 않은 직원 휴무
    const selectedIds = new Set(selected.map((s) => s.id))
    for (const emp of available) {
      if (selectedIds.has(emp.id)) continue
      shifts.push({
        id: `shift-off-${Date.now()}-${emp.id}-${dayIdx}`,
        employee_id: emp.id,
        week_start: weekStart,
        day_index: dayIdx,
        start_hour: 0,
        end_hour: 0,
        break_minutes: 0,
        is_off: true,
        warnings: [],
      })
    }

    // 불가 요일 직원 → 자동 휴무
    for (const emp of employees.filter((e) => e.unavailable_days.includes(weekday))) {
      shifts.push({
        id: `shift-unavail-${Date.now()}-${emp.id}-${dayIdx}`,
        employee_id: emp.id,
        week_start: weekStart,
        day_index: dayIdx,
        start_hour: 0,
        end_hour: 0,
        break_minutes: 0,
        is_off: true,
        warnings: [],
      })
    }
  }

  // 최소화 모드에서 운영 커버 가능 여부 체크 (Issue #6)
  let warning: JuhusuModeWarning | null = null
  if (config.juhusu_mode === 'minimize') {
    // 주 5일(평일) × 최소 인원 × 8시간 = 필요 총 근무시간
    const requiredHours = 5 * config.min_daily_staff * 8 + 2 * config.min_daily_staff * 6
    // 전체 배정된 순 근무시간
    const assignedHours = Array.from(empWeeklyHours.values()).reduce((s, h) => s + h, 0)
    if (assignedHours < requiredHours * 0.85) {
      // 부족한 시간을 15시간 제한으로 나눠서 필요 인원 추정
      const shortage = requiredHours - assignedHours
      const additional = Math.ceil(shortage / MINIMIZE_CAP)
      warning = {
        type: 'insufficient_staff',
        message: `현재 인원으로는 주휴수당 없이 운영 불가 — 주휴수당 허용 또는 추가 채용 필요 (약 ${additional}명)`,
        additional_staff_needed: additional,
      }
    }
  }

  return { shifts, warning }
}

// 시프트 편집 팝오버 (Issue #7 펑크 대체 자동 제안 포함)
function ShiftEditPopover({
  shift,
  employee,
  onSave,
  onClose,
  allEmployees,
  weekShifts,
  onReplaceEmployee,
}: {
  shift: Partial<Shift> | null
  employee: Employee
  onSave: (s: Shift) => void
  onClose: () => void
  allEmployees: Employee[]
  weekShifts: Shift[]
  onReplaceEmployee?: (originalShift: Partial<Shift>, replacementEmpId: string) => void
}) {
  const [startH, setStartH] = useState(shift?.start_hour ?? employee.preferred_start)
  const [endH, setEndH] = useState(shift?.end_hour ?? employee.preferred_end)
  const [isOff, setIsOff] = useState(shift?.is_off ?? false)
  const [showReplace, setShowReplace] = useState(false)

  // Issue #7: 대체 후보 계산 (해당 요일 비번 + 해당 시간대 충돌 없음 + 주 근무시간 적은 순)
  const dayIdx = shift?.day_index ?? 0
  const weekday = WEEKDAY_NUMS[dayIdx]
  const candidates = useMemo(() => {
    return allEmployees
      .filter((e) => e.id !== employee.id) // 본인 제외
      .filter((e) => !e.unavailable_days.includes(weekday)) // 불가 요일 제외
      .filter((e) => {
        // 해당 요일 다른 시프트 충돌 여부 (비번이거나 is_off)
        const existing = weekShifts.find(
          (s) => s.employee_id === e.id && s.day_index === dayIdx && !s.is_off
        )
        return !existing // 해당 요일에 이미 일하는 사람은 제외
      })
      .map((e) => {
        // 주간 누적 근무시간 계산 (시간 적은 직원 우선)
        const weekHours = weekShifts
          .filter((s) => s.employee_id === e.id && !s.is_off)
          .reduce((sum, s) => sum + Math.max(0, (s.end_hour - s.start_hour) - s.break_minutes / 60), 0)
        return { emp: e, weekHours }
      })
      .sort((a, b) => a.weekHours - b.weekHours) // 시간 적은 순
  }, [allEmployees, employee.id, weekday, dayIdx, weekShifts])

  if (!shift) return null
  const workH = endH - startH
  const breakMin = isOff ? 0 : calcBreakMinutes(workH)

  const handleSave = () => {
    onSave({
      id: shift.id ?? `shift-${Date.now()}`,
      employee_id: employee.id,
      week_start: shift.week_start ?? '',
      day_index: shift.day_index ?? 0,
      start_hour: isOff ? 0 : startH,
      end_hour: isOff ? 0 : endH,
      break_minutes: breakMin,
      is_off: isOff,
      warnings: [],
    })
    onClose()
  }

  const handleReplace = (replacementEmpId: string) => {
    if (!onReplaceEmployee) return
    onReplaceEmployee(shift, replacementEmpId)
    onClose()
  }

  return (
    <div className="fixed inset-0 bg-black/40 z-50 flex items-end md:items-center justify-center p-4">
      <div className="bg-white rounded-2xl p-5 w-full max-w-xs shadow-xl">
        <div className="flex items-center justify-between mb-4">
          <div>
            <p className="font-bold text-[#2C1810]">{employee.name}</p>
            <p className="text-xs text-gray-400">{DAY_LABELS[shift.day_index ?? 0]}요일</p>
          </div>
          <button onClick={onClose}><X size={18} className="text-gray-400" /></button>
        </div>

        <div className="mb-4">
          <button onClick={() => setIsOff(!isOff)}
            className={cn('w-full py-2 rounded-xl text-sm font-medium transition-all duration-200',
              isOff ? 'bg-gray-100 text-gray-500' : 'bg-red-50 text-red-600 ring-1 ring-red-200')}>
            {isOff ? '근무로 변경' : '✕ 휴무로 처리'}
          </button>
        </div>

        {!isOff && (
          <div className="space-y-3">
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-medium text-gray-600 mb-1">시작 시간</label>
                <input type="number" min={0} max={23} value={startH} onChange={(e) => setStartH(+e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-gray-200 text-sm focus:outline-none focus:ring-2 focus:ring-[#D4A574]" />
              </div>
              <div>
                <label className="block text-xs font-medium text-gray-600 mb-1">종료 시간</label>
                <input type="number" min={1} max={24} value={endH} onChange={(e) => setEndH(+e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-gray-200 text-sm focus:outline-none focus:ring-2 focus:ring-[#D4A574]" />
              </div>
            </div>
            <div className="bg-[#FAFAF8] rounded-xl p-3 text-xs space-y-1">
              <p className="text-gray-500">실근무: {Math.max(0, workH - breakMin / 60).toFixed(1)}h</p>
              <p className="text-gray-500">휴게: {breakMin}분</p>
              <p className="text-[#2C1810] font-medium">
                예상 급여: {formatCurrency(Math.max(0, workH - breakMin / 60) * employee.hourly_rate)}
              </p>
            </div>
          </div>
        )}

        {/* Issue #7: 대체 근무 자동 제안 (휴무·공석 상태일 때만 노출) */}
        {isOff && candidates.length > 0 && onReplaceEmployee && (
          <div className="mt-4 pt-4 border-t border-gray-100">
            <button
              onClick={() => setShowReplace(!showReplace)}
              className="w-full text-xs text-[#D4A574] font-semibold hover:text-[#c4956a] flex items-center justify-center gap-1"
            >
              🔄 {showReplace ? '대체 후보 숨기기' : `대체 직원 제안 (${candidates.length}명)`}
            </button>
            {showReplace && (
              <div className="mt-3 space-y-1.5">
                <p className="text-[10px] text-gray-400 mb-1">이번 주 근무 시간이 적은 순 ↓</p>
                {candidates.slice(0, 5).map(({ emp: cand, weekHours }) => (
                  <button
                    key={cand.id}
                    onClick={() => handleReplace(cand.id)}
                    className="w-full flex items-center gap-2 p-2 rounded-lg border border-gray-100 hover:border-[#D4A574] hover:bg-[#D4A574]/5 transition-colors text-left"
                  >
                    <div className="w-2 h-2 rounded-full shrink-0" style={{ backgroundColor: cand.color }} />
                    <div className="flex-1 min-w-0">
                      <p className="text-xs font-medium text-[#2C1810]">{cand.name}</p>
                      <p className="text-[10px] text-gray-400">주 {weekHours.toFixed(1)}h / 최대 {cand.max_weekly_hours}h</p>
                    </div>
                    <span className="text-[10px] text-[#D4A574] font-semibold">배정 →</span>
                  </button>
                ))}
              </div>
            )}
          </div>
        )}

        <button onClick={handleSave}
          className="w-full mt-4 py-2.5 rounded-xl bg-[#2C1810] text-white text-sm font-semibold hover:bg-[#3d2418] transition-colors duration-200">
          저장
        </button>
      </div>
    </div>
  )
}

function ScheduleCalendar() {
  const { employees, shifts, setWeekShifts, laborCostCapRatio } = useScheduleStore()
  const { records: salesRecords } = useSalesStore()
  const activeProfile = useProfileStore((s) => s.activeProfile)
  const storeInfo = useAuthStore((s) => s.storeInfo)
  const isOwner = activeProfile?.role === 'owner'

  const [currentMonday, setCurrentMonday] = useState(() => getMonday(new Date()))
  const [editTarget, setEditTarget] = useState<{ empId: string; dayIdx: number } | null>(null)
  const [isGenerating, setIsGenerating] = useState(false)
  // Issue #6: 주휴수당 모드 (사장 전용)
  const [juhusuMode, setJuhusuMode] = useState<'include' | 'minimize'>('include')
  const [juhusuWarning, setJuhusuWarning] = useState<JuhusuModeWarning | null>(null)
  // Phase 2: AI 인사이트
  const [aiInsight, setAiInsight] = useState<string | null>(null)
  const [aiLoading, setAiLoading] = useState(false)
  const [aiError, setAiError] = useState<string | null>(null)

  const weekStart = toISO(currentMonday)


  // 현재 주 시프트 필터
  const weekShifts = useMemo(
    () => shifts.filter((s) => s.week_start === weekStart),
    [shifts, weekStart]
  )

  // 직원·요일별 시프트 맵
  const shiftMap = useMemo(() => {
    const map: Record<string, Shift> = {}
    weekShifts.forEach((s) => { map[`${s.employee_id}-${s.day_index}`] = s })
    return map
  }, [weekShifts])

  // 피크타임 추출 (매출 분석 연동, 자동 생성 + 표시에 사용)
  const peakHoursData = useMemo(() => {
    if (!salesRecords.length) return [10, 11, 14, 15]
    const hourMap: Record<number, number> = {}
    salesRecords.forEach((r) => {
      hourMap[r.hour_slot] = (hourMap[r.hour_slot] ?? 0) + r.revenue
    })
    return Object.entries(hourMap)
      .sort(([, a], [, b]) => b - a)
      .slice(0, 4)
      .map(([h]) => +h)
  }, [salesRecords])

  // 주간 인건비 계산 (React 19 immutability 규칙: 렌더 중 변수 재할당 금지)
  const laborReport = useMemo(() => {
    const empBreakdown = employees.map((emp) => {
      const empShifts = weekShifts.filter((s) => s.employee_id === emp.id && !s.is_off)
      const totalHours = empShifts.reduce((sum, s) => {
        const workH = s.end_hour - s.start_hour
        return sum + Math.max(0, workH - s.break_minutes / 60)
      }, 0)

      const dailyAvg = empShifts.length > 0 ? totalHours / empShifts.length : 0
      const juhusu = calcJuhusu(totalHours, dailyAvg, emp.hourly_rate)
      const regularPay = totalHours * emp.hourly_rate
      const totalPay = regularPay + juhusu

      return {
        employee_id: emp.id,
        employee_name: emp.name,
        total_hours: totalHours,
        regular_pay: regularPay,
        juhusu,
        total_pay: totalPay,
        qualifies_for_juhusu: totalHours >= 15,
      }
    })

    // 누적합은 reduce로 (재할당 제거)
    const totalLaborCost = empBreakdown.reduce((sum, row) => sum + row.total_pay, 0)

    // 매출 연동 (가장 최근 주 매출 합산)
    const estimatedRevenue = salesRecords.reduce((s, r) => s + r.revenue, 0) / Math.max(1, 3) // 월평균 근사
    const laborCostCap = estimatedRevenue * laborCostCapRatio

    return {
      total_labor_cost: totalLaborCost,
      estimated_revenue: estimatedRevenue,
      labor_cost_cap: laborCostCap,
      labor_cost_ratio: estimatedRevenue > 0 ? (totalLaborCost / estimatedRevenue) * 100 : 0,
      is_over_cap: totalLaborCost > laborCostCap,
      employee_breakdown: empBreakdown,
    }
  }, [employees, weekShifts, laborCostCapRatio, salesRecords])

  // 자동 스케줄 생성 (Issue #14 낙관적 UI + Issue #6 모드 반영)
  const handleAutoGenerate = useCallback(async () => {
    setIsGenerating(true)
    setJuhusuWarning(null)

    // Issue #14: 낙관적 UI — 이전 스케줄 즉시 클리어해서 "작업 중" 느낌 제공
    // 실제 계산은 빠르지만 (수십 ms) UX를 위해 최소 200ms 유지
    const startTs = performance.now()

    const config: AutoScheduleConfig = {
      week_start: weekStart,
      min_daily_staff: Math.max(1, Math.ceil(employees.length / 3)),
      max_daily_staff: employees.length,
      labor_cost_ratio_cap: laborCostCapRatio,
      juhusu_mode: juhusuMode,
    }

    const { shifts: generated, warning } = generateAutoSchedule(employees, weekStart, peakHoursData, config)
    // 위반 체크 추가
    const checked = generated.map((s) => {
      const emp = employees.find((e) => e.id === s.employee_id)!
      return { ...s, warnings: s.is_off ? [] : checkShiftWarnings(s, emp, generated) }
    })

    // 최소 200ms 유지 — 즉시 응답이 "작동 안 한 듯" 보이는 것 방지
    const elapsed = performance.now() - startTs
    if (elapsed < 200) {
      await new Promise((r) => setTimeout(r, 200 - elapsed))
    }

    setWeekShifts(checked)
    setJuhusuWarning(warning)
    setIsGenerating(false)
  }, [employees, weekStart, peakHoursData, laborCostCapRatio, juhusuMode, setWeekShifts])

  // ─── Phase 2: 스케줄 AI 인사이트 호출 ───
  const handleAiInsight = useCallback(async () => {
    setAiLoading(true)
    setAiError(null)
    try {
      const empSummary = employees
        .map((e) => {
          const empShifts = weekShifts.filter((s) => s.employee_id === e.id && !s.is_off)
          const h = empShifts.reduce(
            (sum, s) => sum + Math.max(0, (s.end_hour - s.start_hour) - s.break_minutes / 60),
            0,
          )
          return `${e.name}(${h.toFixed(1)}h)`
        })
        .join(', ')

      const peakHoursStr =
        peakHoursData.length > 0
          ? peakHoursData.slice().sort((a, b) => a - b).map((h) => `${h}시`).join(',')
          : null

      const warningTexts = weekShifts
        .flatMap((s) => s.warnings ?? [])
        .filter(Boolean)
        .slice(0, 5)
        .join('; ')

      const sevenDaysAgo = new Date(Date.now() - 7 * 24 * 3600 * 1000)
      const estimatedRevenue = salesRecords
        .filter((r) => new Date(r.sale_date) >= sevenDaysAgo)
        .reduce((s, r) => s + r.revenue, 0)

      const totalLaborCost = laborReport.total_labor_cost
      const ratio = estimatedRevenue > 0 ? totalLaborCost / estimatedRevenue : 0

      const res = await fetch('/api/v1/schedule/ai-insight', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          store_context: `매장명: ${storeInfo?.store_name ?? '내 카페'}`,
          week_summary: `주 시작일: ${weekStart} | 직원 배치: ${empSummary || '미배정'}`,
          estimated_revenue: estimatedRevenue,
          total_labor_cost: totalLaborCost,
          labor_cost_ratio: ratio,
          over_cap: laborReport.is_over_cap,
          warnings_summary: warningTexts || null,
          peak_hours: peakHoursStr,
        }),
      })
      if (!res.ok) {
        const data = await res.json().catch(() => null)
        throw new Error(data?.detail ?? `요청 실패 (${res.status})`)
      }
      const data = await res.json()
      setAiInsight(data.insight)
    } catch (e) {
      setAiError(e instanceof Error ? e.message : String(e))
    } finally {
      setAiLoading(false)
    }
  }, [storeInfo, employees, weekShifts, weekStart, laborReport, peakHoursData, salesRecords])

  // 시프트 저장 (클릭 편집)
  const handleShiftSave = (shift: Shift) => {
    const emp = employees.find((e) => e.id === shift.employee_id)!
    const warnings = shift.is_off ? [] : checkShiftWarnings(shift, emp, [...weekShifts.filter(
      (s) => !(s.employee_id === shift.employee_id && s.day_index === shift.day_index)
    ), shift])
    const { setShift } = useScheduleStore.getState()
    setShift({ ...shift, warnings })
  }

  // CSV/xlsx 내보내기 (Issue #3)
  const handleExport = async (format: 'csv' | 'xlsx') => {
    const rows: (string | number)[][] = [['직원', ...DAY_LABELS, '주간 시간', '주간 금액']]
    employees.forEach((emp) => {
      const row: (string | number)[] = [emp.name]
      let weekHours = 0
      for (let d = 0; d < 7; d++) {
        const s = shiftMap[`${emp.id}-${d}`]
        if (!s || s.is_off) {
          row.push('휴무')
        } else {
          const h = Math.max(0, (s.end_hour - s.start_hour) - s.break_minutes / 60)
          weekHours += h
          row.push(`${s.start_hour}:00~${s.end_hour}:00`)
        }
      }
      const weekPay = weekHours * emp.hourly_rate
      const dailyAvg = weekHours / 7
      const juhusu = calcJuhusu(weekHours, dailyAvg, emp.hourly_rate)
      row.push(weekHours.toFixed(1))
      row.push(weekPay + juhusu)
      rows.push(row)
    })

    if (format === 'xlsx') {
      try {
        const XLSX = await import('xlsx')
        const wb = XLSX.utils.book_new()
        const ws = XLSX.utils.aoa_to_sheet(rows)
        XLSX.utils.book_append_sheet(wb, ws, '주간스케줄')
        XLSX.writeFile(wb, `schedule_${weekStart}.xlsx`)
      } catch {
        // xlsx 로드 실패 시 CSV fallback
        handleExport('csv')
      }
    } else {
      const csv = rows.map((r) => r.map((c) => String(c)).join(',')).join('\n')
      const blob = new Blob(['\uFEFF' + csv], { type: 'text/csv;charset=utf-8;' })
      const url = URL.createObjectURL(blob)
      const a = document.createElement('a')
      a.href = url
      a.download = `schedule_${weekStart}.csv`
      a.click()
      URL.revokeObjectURL(url)
    }
  }

  // 인쇄/PDF
  const handlePrintPDF = () => window.print()

  const editShift = editTarget
    ? shiftMap[`${editTarget.empId}-${editTarget.dayIdx}`] ?? {
        employee_id: editTarget.empId,
        week_start: weekStart,
        day_index: editTarget.dayIdx,
      }
    : null

  const editEmployee = editTarget ? employees.find((e) => e.id === editTarget.empId) : null

  return (
    <div className="print-schedule space-y-4">
      {/* 인쇄 전용 헤더 — 화면에선 숨김, 인쇄 시 노출 */}
      <div className="hidden print:block mb-4">
        <h1 className="text-lg font-bold">주간 근무 스케줄 — 카페 브레인</h1>
        <p className="text-sm">{formatWeekRange(currentMonday)}</p>
      </div>

      {/* 주 네비게이션 */}
      <div className="bg-white rounded-2xl p-4 border border-gray-100 shadow-sm">
        <div className="flex items-center justify-between mb-3 no-print">
          <div className="flex items-center gap-3">
            <button onClick={() => setCurrentMonday(addDays(currentMonday, -7))}
              className="p-1.5 rounded-lg hover:bg-gray-100 transition-colors duration-200">
              <Prev size={16} />
            </button>
            <span className="text-sm font-semibold text-[#2C1810]">{formatWeekRange(currentMonday)}</span>
            <button onClick={() => setCurrentMonday(addDays(currentMonday, 7))}
              className="p-1.5 rounded-lg hover:bg-gray-100 transition-colors duration-200">
              <Next size={16} />
            </button>
          </div>
          <div className="flex gap-2 flex-wrap">
            {/* Issue #6: 주휴수당 모드 (사장 전용) */}
            {isOwner && (
              <select
                value={juhusuMode}
                onChange={(e) => setJuhusuMode(e.target.value as 'include' | 'minimize')}
                className="text-xs border border-gray-200 rounded-lg px-2 py-1.5 text-gray-700 bg-white focus:outline-none focus:ring-2 focus:ring-[#D4A574]/30"
                title="Issue #6: 주휴수당 모드"
              >
                <option value="include">💼 주휴수당 포함</option>
                <option value="minimize">💰 주휴수당 최소화</option>
              </select>
            )}
            <button onClick={() => handleExport('xlsx')}
              className="flex items-center gap-1 px-3 py-1.5 text-xs text-gray-600 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors duration-200">
              <Download size={13} /> 엑셀
            </button>
            <button onClick={() => handleExport('csv')}
              className="flex items-center gap-1 px-3 py-1.5 text-xs text-gray-600 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors duration-200">
              <Download size={13} /> CSV
            </button>
            <button onClick={handlePrintPDF}
              className="flex items-center gap-1 px-3 py-1.5 text-xs text-gray-600 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors duration-200"
              title="브라우저 인쇄 (Ctrl+P) — PDF 저장도 이 버튼으로">
              <Printer size={13} /> 인쇄/PDF
            </button>
            <button onClick={handleAutoGenerate} disabled={isGenerating || employees.length === 0}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-gradient-to-r from-[#2C1810] to-[#D4A574] text-white rounded-lg text-xs font-medium hover:opacity-90 transition-opacity duration-200 disabled:opacity-50">
              {isGenerating ? <Loader2 size={12} className="animate-spin" /> : <Sparkles size={12} />}
              자동 생성
            </button>
          </div>
        </div>

        {/* 피크타임 뱃지 */}
        {peakHoursData.length > 0 && (
          <div className="flex items-center gap-2 text-xs text-gray-500 mb-3">
            <span>📈 피크타임:</span>
            {peakHoursData.sort((a: number, b: number) => a - b).map((h: number) => (
              <span key={h} className="bg-orange-100 text-orange-600 px-2 py-0.5 rounded-full font-medium">{h}시</span>
            ))}
            <span className="text-gray-400">(매출 분석 연동)</span>
          </div>
        )}

        {/* 인건비 상한 경고 */}
        {laborReport.is_over_cap && (
          <div className="flex items-center gap-2 text-xs bg-red-50 text-red-600 rounded-xl p-2 mb-3">
            <AlertTriangle size={13} />
            인건비({formatCurrency(laborReport.total_labor_cost)})가 상한({formatCurrency(laborReport.labor_cost_cap)})을 초과합니다!
          </div>
        )}

        {/* Issue #6: 인건비 절약 모드 경고 (사장 프로필만) */}
        {juhusuWarning && isOwner && (
          <div className="flex items-start gap-2 p-3 bg-amber-50 border border-amber-200 rounded-xl mb-3">
            <AlertTriangle size={14} className="text-amber-600 mt-0.5 shrink-0" />
            <div className="flex-1 text-xs">
              <p className="font-semibold text-amber-700">주휴수당 최소화 모드 경보</p>
              <p className="text-amber-600 mt-1 leading-relaxed">{juhusuWarning.message}</p>
            </div>
            <button onClick={() => setJuhusuWarning(null)} className="text-amber-400 hover:text-amber-600 p-0.5">
              <X size={12} />
            </button>
          </div>
        )}

        {/* 주간 인건비 요약 */}
        <div className="grid grid-cols-3 gap-2 mb-4">
          {[
            { label: '총 인건비', value: formatCurrency(laborReport.total_labor_cost), warn: laborReport.is_over_cap },
            { label: '인건비 비율', value: `${laborReport.labor_cost_ratio.toFixed(1)}%`, warn: laborReport.is_over_cap },
            { label: '인건비 상한', value: formatCurrency(laborReport.labor_cost_cap), warn: false },
          ].map(({ label, value, warn }) => (
            <div key={label} className={cn('rounded-xl p-2.5 text-center', warn ? 'bg-red-50' : 'bg-[#FAFAF8]')}>
              <p className="text-xs text-gray-400">{label}</p>
              <p className={cn('text-sm font-bold', warn ? 'text-red-600' : 'text-[#2C1810]')}>{value}</p>
            </div>
          ))}
        </div>

        {/* Phase 2: AI 스케줄 인사이트 패널 */}
        <div className="bg-gradient-to-br from-[#FAFAF8] to-[#F5F1EA] border border-[#E5E0D5] rounded-2xl p-3.5 mb-4 no-print">
          <div className="flex items-center justify-between mb-2">
            <h4 className="font-semibold text-[#2C1810] text-xs flex items-center gap-1.5">
              <Sparkles size={13} className="text-[#D4A574]" />
              AI 스케줄 인사이트
            </h4>
            <button
              onClick={handleAiInsight}
              disabled={aiLoading || employees.length === 0}
              className="flex items-center gap-1 px-2.5 py-1 text-[11px] bg-gradient-to-r from-[#2C1810] to-[#D4A574] text-white rounded-lg font-medium disabled:opacity-50 hover:opacity-90 transition-opacity duration-200"
            >
              {aiLoading ? <Loader2 size={11} className="animate-spin" /> : <Sparkles size={11} />}
              {aiInsight ? '다시 생성' : 'AI 조언 받기'}
            </button>
          </div>
          {aiError && (
            <div className="bg-red-50 text-red-600 text-[11px] rounded-lg p-2.5 flex items-start gap-1.5 mb-2">
              <AlertTriangle size={11} className="mt-0.5 shrink-0" />
              <div className="flex-1">{aiError}</div>
              <button onClick={handleAiInsight} className="text-red-500 underline shrink-0">재시도</button>
            </div>
          )}
          {aiInsight ? (
            <div className="bg-white/70 backdrop-blur rounded-xl p-3 text-[11px] text-[#3D3D3A] whitespace-pre-line leading-relaxed">
              {aiInsight}
            </div>
          ) : !aiError ? (
            <p className="text-[11px] text-gray-500 leading-relaxed">
              현재 직원 배치·인건비 비율·매출 피크 패턴을 분석해 인력 운영 조언 4~5줄을 생성합니다.
              동일 조건은 24시간 캐싱으로 비용 0으로 재사용됩니다.
            </p>
          ) : null}
        </div>

        {/* 주간 캘린더 그리드 */}
        {employees.length === 0 ? (
          <div className="text-center py-8 text-gray-400 text-sm">직원을 먼저 추가해주세요</div>
        ) : (
          <div className="overflow-x-auto -mx-1">
            <table className="schedule-grid text-xs w-full border-collapse min-w-[600px]" data-print-grid>
              <thead>
                <tr>
                  <th className="text-left px-2 py-2 text-gray-500 font-medium w-20">직원</th>
                  {DAY_LABELS.map((d, i) => (
                    <th key={d} className={cn('text-center px-1 py-2 font-medium',
                      i === 5 ? 'text-blue-500' : i === 6 ? 'text-red-500' : 'text-gray-500')}>
                      {d}
                    </th>
                  ))}
                  <th className="text-center px-2 py-2 text-gray-500 font-medium">주간</th>
                </tr>
              </thead>
              <tbody>
                {employees.map((emp) => {
                  const empShifts = weekShifts.filter((s) => s.employee_id === emp.id && !s.is_off)
                  const weeklyH = empShifts.reduce((sum, s) => {
                    const wh = s.end_hour - s.start_hour
                    return sum + Math.max(0, wh - s.break_minutes / 60)
                  }, 0)
                  const weekPay = weeklyH * emp.hourly_rate + calcJuhusu(weeklyH, weeklyH / Math.max(1, empShifts.length), emp.hourly_rate)

                  return (
                    <tr key={emp.id} className="border-t border-gray-100">
                      <td className="px-2 py-2">
                        <div className="flex items-center gap-1.5">
                          <div className="w-2 h-2 rounded-full shrink-0" style={{ backgroundColor: emp.color }} />
                          <span className="font-medium text-[#2C1810] truncate">{emp.name}</span>
                        </div>
                      </td>
                      {Array.from({ length: 7 }, (_, dayIdx) => {
                        const shift = shiftMap[`${emp.id}-${dayIdx}`]
                        const hasWarning = shift?.warnings?.length > 0
                        const isUnavail = emp.unavailable_days.includes(WEEKDAY_NUMS[dayIdx])

                        return (
                          <td key={dayIdx} className="px-1 py-1.5">
                            <button
                              onClick={() => setEditTarget({ empId: emp.id, dayIdx })}
                              className={cn(
                                'w-full min-h-[44px] rounded-lg text-center text-[10px] font-medium transition-all duration-200 border',
                                isUnavail && !shift ? 'bg-gray-100 text-gray-300 border-gray-100 cursor-default' :
                                (!shift || shift.is_off) ? 'bg-gray-50 text-gray-400 border-gray-100 hover:bg-gray-100' :
                                hasWarning ? 'border-red-200 bg-red-50 text-red-700 hover:bg-red-100' :
                                'border-transparent hover:opacity-80'
                              )}
                              style={!shift?.is_off && shift ? { backgroundColor: emp.color + '22', borderColor: emp.color + '44', color: emp.color } : {}}
                            >
                              {!shift || shift.is_off ? (
                                <span className="text-gray-300">{isUnavail ? '×' : '휴무'}</span>
                              ) : (
                                <div className="px-1">
                                  <div>{shift.start_hour}~{shift.end_hour}시</div>
                                  {hasWarning && (
                                    <div className="flex items-center justify-center gap-0.5 mt-0.5">
                                      <AlertTriangle size={9} className="text-red-500" />
                                      <span className="text-red-500 text-[9px]">위반</span>
                                    </div>
                                  )}
                                  {shift.break_minutes > 0 && !hasWarning && (
                                    <div className="text-[9px] opacity-60">휴게{shift.break_minutes}분</div>
                                  )}
                                </div>
                              )}
                            </button>
                          </td>
                        )
                      })}
                      {/* 주간 합계 */}
                      <td className="px-2 py-2 text-center">
                        <div className="text-[#2C1810] font-semibold">{weeklyH.toFixed(0)}h</div>
                        <div className="text-gray-400 text-[10px]">{formatCurrency(weekPay)}</div>
                        {weeklyH >= 15 && (
                          <div className="text-[9px] text-blue-500 font-medium">주휴✓</div>
                        )}
                      </td>
                    </tr>
                  )
                })}
              </tbody>
            </table>
          </div>
        )}

        {/* 범례 */}
        <div className="flex flex-wrap gap-3 mt-3 text-[10px] text-gray-400 no-print">
          <div className="flex items-center gap-1"><div className="w-3 h-3 rounded bg-red-100 ring-1 ring-red-200" /> 규정 위반</div>
          <div className="flex items-center gap-1"><div className="w-3 h-3 rounded bg-gray-50 ring-1 ring-gray-200" /> 휴무</div>
          <div className="flex items-center gap-1">• 셀 클릭 시 편집</div>
        </div>

        {/* 인쇄 전용 서명란 */}
        <div className="hidden print:block mt-8 pt-4 border-t border-gray-400">
          <div className="flex justify-between text-xs">
            <div>작성일: {new Date().toLocaleDateString('ko-KR')}</div>
            <div>확인: _______________</div>
          </div>
        </div>
      </div>

      {/* 시프트 편집 팝오버 (Issue #7 대체 제안 포함) */}
      {editTarget && editShift && editEmployee && (
        <ShiftEditPopover
          shift={editShift as Partial<Shift>}
          employee={editEmployee}
          onSave={handleShiftSave}
          onClose={() => setEditTarget(null)}
          allEmployees={employees}
          weekShifts={weekShifts}
          onReplaceEmployee={(orig, replacementEmpId) => {
            // 원 시프트 소유자는 휴무로, 대체자는 원 시프트 시간으로 배정
            const originalShift = shiftMap[`${orig.employee_id}-${orig.day_index}`]
            const replacement = employees.find((e) => e.id === replacementEmpId)
            if (!replacement || !originalShift) return

            const startH = originalShift.start_hour || replacement.preferred_start
            const endH = originalShift.end_hour || replacement.preferred_end
            const workH = endH - startH
            const breakMin = calcBreakMinutes(workH)

            // 원 소유자 휴무
            handleShiftSave({
              ...originalShift,
              is_off: true,
              start_hour: 0,
              end_hour: 0,
              break_minutes: 0,
            })
            // 대체자 배정
            handleShiftSave({
              id: `shift-replace-${Date.now()}-${replacementEmpId}`,
              employee_id: replacementEmpId,
              week_start: weekStart,
              day_index: orig.day_index ?? 0,
              start_hour: startH,
              end_hour: endH,
              break_minutes: breakMin,
              is_off: false,
              warnings: [],
            })
          }}
        />
      )}
    </div>
  )
}

// ═══════════════════════════════════════════
// ─── 탭 3: 인건비 분석 ───
// ═══════════════════════════════════════════
function LaborCostAnalysis() {
  const { employees, shifts, laborCostCapRatio, setLaborCostCapRatio } = useScheduleStore()
  const { records: salesRecords } = useSalesStore()

  // 주/월 단위 전환 (Issue #12)
  const [period, setPeriod] = useState<'week' | 'month'>('week')

  // 해당 기간의 시프트 필터
  const periodShifts = useMemo(() => {
    const now = new Date()
    if (period === 'month') {
      const prefix = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}`
      return shifts.filter((s) => s.week_start.startsWith(prefix))
    }
    // 이번 주 (월요일 기준)
    const monday = getMonday(now)
    const weekStart = toISO(monday)
    return shifts.filter((s) => s.week_start === weekStart)
  }, [shifts, period])

  // 해당 기간의 매출 (월=이번달, 주=최근 7일)
  const periodRevenue = useMemo(() => {
    const now = new Date()
    if (period === 'month') {
      const prefix = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}`
      return salesRecords
        .filter((r) => r.sale_date.startsWith(prefix))
        .reduce((s, r) => s + r.revenue, 0)
    }
    const sevenDaysAgo = new Date(now.getTime() - 7 * 24 * 3600 * 1000)
    return salesRecords
      .filter((r) => new Date(r.sale_date) >= sevenDaysAgo)
      .reduce((s, r) => s + r.revenue, 0)
  }, [salesRecords, period])

  const laborCostCap = periodRevenue * laborCostCapRatio

  // 직원별 인건비 분석 (선택된 기간 기준)
  const empAnalysis = useMemo(() => employees.map((emp) => {
    const empShifts = periodShifts.filter((s) => s.employee_id === emp.id && !s.is_off)
    const totalHours = empShifts.reduce((sum, s) => {
      return sum + Math.max(0, (s.end_hour - s.start_hour) - s.break_minutes / 60)
    }, 0)
    // 주간 평균 근무일 (주휴수당 계산용)
    const workDays = new Set(empShifts.map((s) => `${s.week_start}-${s.day_index}`)).size
    const dailyAvg = workDays > 0 ? totalHours / workDays : 0
    // 월 단위: 주별 주휴수당 합산 추정 (주당 15시간 이상 달성 주 수 × 주휴금)
    const weekMap = new Map<string, number>()
    empShifts.forEach((s) => {
      const h = Math.max(0, (s.end_hour - s.start_hour) - s.break_minutes / 60)
      weekMap.set(s.week_start, (weekMap.get(s.week_start) ?? 0) + h)
    })
    let juhusu = 0
    if (period === 'week') {
      juhusu = calcJuhusu(totalHours, dailyAvg, emp.hourly_rate)
    } else {
      weekMap.forEach((weekHours) => {
        const weekDaily = workDays > 0 ? weekHours / Math.max(1, workDays / weekMap.size) : 0
        juhusu += calcJuhusu(weekHours, weekDaily, emp.hourly_rate)
      })
    }
    const regularPay = totalHours * emp.hourly_rate
    return {
      emp,
      totalHours,
      workDays,
      regularPay,
      juhusu,
      totalPay: regularPay + juhusu,
      qualifiesJuhusu: period === 'week' ? totalHours >= 15 : Array.from(weekMap.values()).some((h) => h >= 15),
      weeksCount: weekMap.size,
    }
  }), [employees, periodShifts, period])

  const totalLaborCost = empAnalysis.reduce((s, e) => s + e.totalPay, 0)
  const laborRatio = periodRevenue > 0 ? (totalLaborCost / periodRevenue) * 100 : 0
  const isOverCap = totalLaborCost > laborCostCap && periodRevenue > 0

  return (
    <div className="space-y-4">
      {/* 주/월 전환 (Issue #12) */}
      <div className="bg-white rounded-2xl p-2 border border-gray-100 shadow-sm flex gap-1">
        {([
          { v: 'week', label: '📅 이번 주' },
          { v: 'month', label: '🗓 이번 달' },
        ] as const).map(({ v, label }) => (
          <button
            key={v}
            onClick={() => setPeriod(v)}
            className={cn(
              'flex-1 py-2 rounded-xl text-sm font-medium transition-all duration-200',
              period === v ? 'bg-[#2C1810] text-white' : 'text-gray-500 hover:bg-gray-50'
            )}
          >
            {label}
          </button>
        ))}
      </div>

      {/* 설정 + 요약 */}
      <div className="bg-white rounded-2xl p-4 border border-gray-100 shadow-sm">
        <h4 className="font-semibold text-[#2C1810] mb-3 text-sm">
          인건비 {period === 'week' ? '주간' : '월간'} 요약
        </h4>
        <div className="flex items-center gap-3 mb-3">
          <label className="text-xs text-gray-600 shrink-0">매출 대비 상한 비율</label>
          <input type="range" min={10} max={50} step={1} value={laborCostCapRatio * 100}
            onChange={(e) => setLaborCostCapRatio(+e.target.value / 100)}
            className="flex-1 accent-[#D4A574]" />
          <span className="text-sm font-bold text-[#2C1810] w-10 text-right">{(laborCostCapRatio * 100).toFixed(0)}%</span>
        </div>

        <div className="grid grid-cols-2 gap-3">
          <div className="bg-[#FAFAF8] rounded-xl p-3 text-center">
            <p className="text-xs text-gray-400 mb-1">{period === 'week' ? '이번 주' : '이번 달'} 총 인건비</p>
            <p className={cn('text-lg font-bold', isOverCap ? 'text-red-500' : 'text-[#2C1810]')}>
              {formatCurrency(totalLaborCost)}
            </p>
          </div>
          <div className="bg-[#FAFAF8] rounded-xl p-3 text-center">
            <p className="text-xs text-gray-400 mb-1">매출 (집계 기간)</p>
            <p className="text-lg font-bold text-[#2C1810]">{formatCurrency(periodRevenue)}</p>
          </div>
          <div className="bg-[#FAFAF8] rounded-xl p-3 text-center">
            <p className="text-xs text-gray-400 mb-1">인건비 상한</p>
            <p className="text-lg font-bold text-[#2C1810]">{formatCurrency(laborCostCap)}</p>
          </div>
          <div className={cn('rounded-xl p-3 text-center', isOverCap ? 'bg-red-50' : 'bg-[#FAFAF8]')}>
            <p className="text-xs text-gray-400 mb-1">매출 대비 비율</p>
            <p className={cn('text-lg font-bold', isOverCap ? 'text-red-600' : 'text-[#2C1810]')}>
              {laborRatio.toFixed(1)}%
            </p>
          </div>
        </div>

        {/* 비율 경보 (Issue #12) */}
        {isOverCap && (
          <div className="mt-3 flex items-start gap-2 p-3 bg-red-50 border border-red-100 rounded-xl text-xs text-red-700">
            <AlertTriangle size={14} className="mt-0.5 shrink-0" />
            <div>
              <p className="font-semibold">⚠️ 인건비 상한 초과</p>
              <p className="mt-0.5">
                목표 {(laborCostCapRatio * 100).toFixed(0)}%보다 {(laborRatio - laborCostCapRatio * 100).toFixed(1)}%p 높습니다.
                인력 배치를 재검토하거나 매출 증대 전략이 필요합니다.
              </p>
            </div>
          </div>
        )}
      </div>

      {/* 직원별 상세 */}
      <div className="bg-white rounded-2xl p-4 border border-gray-100 shadow-sm">
        <h4 className="font-semibold text-[#2C1810] mb-3 text-sm">
          직원별 인건비 내역 {period === 'month' && `(이번 달 — 집계된 ${empAnalysis[0]?.weeksCount ?? 0}주 기준)`}
        </h4>
        {empAnalysis.length === 0 ? (
          <p className="text-center text-gray-400 text-sm py-4">직원 정보 없음</p>
        ) : (
          <div className="space-y-3">
            {empAnalysis.map(({ emp, totalHours, regularPay, juhusu, totalPay, qualifiesJuhusu }) => {
              const maxHours = period === 'week' ? emp.max_weekly_hours : emp.max_weekly_hours * 4.33
              return (
                <div key={emp.id} className="border border-gray-100 rounded-xl p-3">
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-2">
                      <div className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: emp.color }} />
                      <span className="font-medium text-[#2C1810] text-sm">{emp.name}</span>
                      {qualifiesJuhusu && (
                        <span className="text-[10px] bg-blue-100 text-blue-600 px-1.5 py-0.5 rounded-full font-medium">
                          주휴수당 적용
                        </span>
                      )}
                    </div>
                    <span className="font-bold text-[#2C1810] text-sm">{formatCurrency(totalPay)}</span>
                  </div>
                  <div className="grid grid-cols-3 gap-2 text-xs text-gray-500">
                    <div>총 {totalHours.toFixed(1)}h</div>
                    <div>기본 {formatCurrency(regularPay)}</div>
                    {juhusu > 0 && <div className="text-blue-500">주휴 +{formatCurrency(juhusu)}</div>}
                  </div>
                  {/* 진행 막대 */}
                  <div className="mt-2 bg-gray-100 rounded-full h-1.5 overflow-hidden">
                    <div className="h-1.5 rounded-full" style={{
                      width: `${Math.min(100, (totalHours / maxHours) * 100)}%`,
                      backgroundColor: emp.color,
                    }} />
                  </div>
                  <p className="text-[10px] text-gray-400 mt-0.5">{totalHours.toFixed(0)} / {maxHours.toFixed(0)}h</p>
                </div>
              )
            })}
          </div>
        )}
      </div>

      {/* 노무 규정 안내 */}
      <div className="bg-amber-50 border border-amber-100 rounded-2xl p-4 text-xs text-amber-700 space-y-1">
        <p className="font-semibold mb-2">⚖️ 노동법 규정 (자동 적용)</p>
        <p>• 주 15시간 이상 근무 → 주휴수당 = 1일 평균 근무시간 × 시급</p>
        <p>• 4시간 이상 근무 → 30분 휴게 자동 삽입</p>
        <p>• 8시간 이상 근무 → 60분 휴게 자동 삽입</p>
        <p>• 규정 위반 시 캘린더에 빨간 경고 표시</p>
      </div>
    </div>
  )
}

// ═══════════════════════════════════════════
// ─── 메인 SchedulePage ───
// ═══════════════════════════════════════════
const TABS = ['👥 직원 관리', '📅 주간 스케줄', '💰 인건비 분석']

export default function SchedulePage() {
  const [activeTab, setActiveTab] = useState(1) // 기본: 스케줄 탭
  const { employees } = useScheduleStore()

  return (
    <div className="min-h-screen bg-[#FAFAF8]">
      {/* 헤더 */}
      <header className="bg-[#2C1810] text-white px-4 py-3 flex items-center gap-3">
        <Link to="/dashboard" className="hover:text-[#D4A574] transition-colors duration-200">
          <ChevronLeft size={20} />
        </Link>
        <Calendar size={18} className="text-[#D4A574]" />
        <h1 className="font-bold text-base flex-1">스마트 스케줄링</h1>
        <span className="text-xs text-[#D4A574]">{employees.length}명</span>
      </header>

      {/* 탭 네비게이션 */}
      <div className="flex overflow-x-auto scrollbar-hide bg-white border-b border-gray-100 px-2 pt-2">
        {TABS.map((tab, i) => (
          <button key={tab} onClick={() => setActiveTab(i)}
            className={cn(
              'shrink-0 px-4 py-2.5 text-sm font-medium rounded-t-lg transition-all duration-200 whitespace-nowrap',
              activeTab === i ? 'bg-[#2C1810] text-white' : 'text-gray-500 hover:text-[#2C1810] hover:bg-gray-50'
            )}>
            {tab}
          </button>
        ))}
      </div>

      {/* 탭 콘텐츠 */}
      <main className="max-w-3xl mx-auto px-4 py-6">
        {activeTab === 0 && <EmployeeManager />}
        {activeTab === 1 && <ScheduleCalendar />}
        {activeTab === 2 && <LaborCostAnalysis />}
      </main>
    </div>
  )
}
