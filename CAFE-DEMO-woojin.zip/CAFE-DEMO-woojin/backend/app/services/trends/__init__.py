"""
Phase 4: 트렌드 분석 서비스 패키지

7개 데이터 소스 모듈 + 1개 aggregator:
  1. naver_datalab     — 한국 검색량 정량 (Naver 키)
  2. naver_news        — 한국 미디어 (Naver 키)
  3. google_trends     — pytrends 한국 vs 글로벌 비교 (키 X)
  4. youtube           — YouTube Data API v3 (YouTube 키)
  5. newsapi           — NewsAPI.org 글로벌 영문 뉴스 (NewsAPI 키)
  6. google_news_rss   — Google News RSS 파싱 (키 X)
  7. gemini_grounding  — Gemini Search Grounding 실시간 웹 (Gemini 키 재사용)
  → aggregator         — 7개 raw → Gemini 전략 보고서

graceful degradation: 키 없는 소스는 자동 비활성, 다른 소스만 사용.
"""
from app.services.trends.collector import collect_all_sources
from app.services.trends.aggregator import synthesize_strategic_report

__all__ = ["collect_all_sources", "synthesize_strategic_report"]
