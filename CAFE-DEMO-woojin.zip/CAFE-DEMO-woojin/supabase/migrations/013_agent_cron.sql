-- Phase 5: 에이전트 자동 cron 스케줄 (Supabase 대시보드 호환 버전)
--
-- Supabase SQL Editor가 함수 내부 변수명을 테이블로 오인해 RLS 코드를 끼워넣는
-- 버그를 회피하기 위해:
--   1) 모든 PL/pgSQL 변수에 v_ prefix
--   2) dollar-quote를 명명형 ($func$ ... $func$) 사용
--   3) 함수 정의와 cron.schedule 호출을 명확히 분리
--
-- 적용 전:
--   1. Supabase 대시보드 → Database → Extensions → pg_cron 활성화
--   2. SQL Editor에서 이 파일을 한 번에 실행 (또는 4개 블록 따로)

-- ══════════════════════════════════════════════════════════
-- 0. pg_cron 확장 (이미 활성이면 noop)
-- ══════════════════════════════════════════════════════════
CREATE EXTENSION IF NOT EXISTS pg_cron;


-- ══════════════════════════════════════════════════════════
-- 1. 매일 23:00 KST — 모든 매장 매출 이상 + BEP 감지
-- ══════════════════════════════════════════════════════════
CREATE OR REPLACE FUNCTION public.cron_run_daily_capture()
RETURNS void AS $func$
DECLARE
  v_store RECORD;
BEGIN
  FOR v_store IN
    SELECT id FROM public.stores WHERE agent_learning_enabled = true
  LOOP
    PERFORM public.detect_sales_anomaly(v_store.id);
    PERFORM public.detect_bep_milestone(v_store.id);
  END LOOP;
END;
$func$ LANGUAGE plpgsql SECURITY DEFINER;


-- ══════════════════════════════════════════════════════════
-- 2. 매일 03:00 KST — 90일 이상 미사용 메모리 archived 처리
-- ══════════════════════════════════════════════════════════
CREATE OR REPLACE FUNCTION public.cron_archive_stale_memories()
RETURNS int AS $func$
DECLARE
  v_arch_count int;
BEGIN
  UPDATE public.agent_memory
    SET archived_at = now()
  WHERE archived_at IS NULL
    AND (
      (last_used_at IS NULL AND created_at < now() - interval '90 days' AND importance <= 5)
      OR (last_used_at < now() - interval '90 days' AND importance <= 5)
      OR (expires_at IS NOT NULL AND expires_at < now())
    );
  GET DIAGNOSTICS v_arch_count = ROW_COUNT;
  RETURN v_arch_count;
END;
$func$ LANGUAGE plpgsql SECURITY DEFINER;


-- ══════════════════════════════════════════════════════════
-- 3. 매주 월 04:00 KST — distill 필요 매장 플래그 (백엔드 후처리)
-- ══════════════════════════════════════════════════════════
CREATE OR REPLACE FUNCTION public.cron_distill_profiles_weekly()
RETURNS int AS $func$
DECLARE
  v_store RECORD;
  v_mem_cnt int;
  v_last_at timestamptz;
  v_processed int := 0;
BEGIN
  FOR v_store IN
    SELECT id, agent_profile FROM public.stores WHERE agent_learning_enabled = true
  LOOP
    SELECT count(*) INTO v_mem_cnt
      FROM public.agent_memory
      WHERE store_id = v_store.id AND archived_at IS NULL;

    IF v_mem_cnt < 20 THEN CONTINUE; END IF;

    v_last_at := (v_store.agent_profile->>'_distilled_at')::timestamptz;
    IF v_last_at IS NOT NULL AND v_last_at > now() - interval '7 days' THEN
      CONTINUE;
    END IF;

    UPDATE public.stores
      SET agent_profile = jsonb_set(
        COALESCE(agent_profile, '{}'::jsonb),
        '{_distill_pending}',
        'true'::jsonb
      )
      WHERE id = v_store.id;

    v_processed := v_processed + 1;
  END LOOP;

  RETURN v_processed;
END;
$func$ LANGUAGE plpgsql SECURITY DEFINER;


-- ══════════════════════════════════════════════════════════
-- 4. 매일 02:00 UTC — 만료 7일 지난 ai_cache 삭제
-- ══════════════════════════════════════════════════════════
CREATE OR REPLACE FUNCTION public.cron_cleanup_ai_cache()
RETURNS int AS $func$
DECLARE
  v_del_count int;
BEGIN
  DELETE FROM public.ai_cache WHERE expires_at < now() - interval '7 days';
  GET DIAGNOSTICS v_del_count = ROW_COUNT;
  RETURN v_del_count;
END;
$func$ LANGUAGE plpgsql SECURITY DEFINER;


-- ══════════════════════════════════════════════════════════
-- 5. 스케줄 등록 (idempotent — 기존 등록은 unschedule 후 재등록)
-- ══════════════════════════════════════════════════════════

-- 기존 잡 제거 (있을 때만)
DO $cleanup$
BEGIN
  IF EXISTS (SELECT 1 FROM cron.job WHERE jobname = 'agent_daily_capture') THEN
    PERFORM cron.unschedule('agent_daily_capture');
  END IF;
  IF EXISTS (SELECT 1 FROM cron.job WHERE jobname = 'agent_archive_stale') THEN
    PERFORM cron.unschedule('agent_archive_stale');
  END IF;
  IF EXISTS (SELECT 1 FROM cron.job WHERE jobname = 'agent_distill_weekly') THEN
    PERFORM cron.unschedule('agent_distill_weekly');
  END IF;
  IF EXISTS (SELECT 1 FROM cron.job WHERE jobname = 'agent_cache_cleanup') THEN
    PERFORM cron.unschedule('agent_cache_cleanup');
  END IF;
END;
$cleanup$;

-- 신규 등록
SELECT cron.schedule('agent_daily_capture',  '0 14 * * *', 'SELECT public.cron_run_daily_capture()');
SELECT cron.schedule('agent_archive_stale',  '0 18 * * *', 'SELECT public.cron_archive_stale_memories()');
SELECT cron.schedule('agent_distill_weekly', '0 19 * * 0', 'SELECT public.cron_distill_profiles_weekly()');
SELECT cron.schedule('agent_cache_cleanup',  '0 2 * * *',  'SELECT public.cron_cleanup_ai_cache()');


-- ══════════════════════════════════════════════════════════
-- 코멘트
-- ══════════════════════════════════════════════════════════
COMMENT ON FUNCTION public.cron_run_daily_capture IS
  'Phase 5: 매일 23시 KST 모든 매장 매출 이상·BEP 자동 감지';
COMMENT ON FUNCTION public.cron_archive_stale_memories IS
  'Phase 5: 매일 03시 KST 노후 메모리 archived';
COMMENT ON FUNCTION public.cron_distill_profiles_weekly IS
  'Phase 5: 매주 월 04시 KST distill 필요 매장 플래그';
COMMENT ON FUNCTION public.cron_cleanup_ai_cache IS
  'Phase 5: 매일 02시 UTC 만료 캐시 정리';
