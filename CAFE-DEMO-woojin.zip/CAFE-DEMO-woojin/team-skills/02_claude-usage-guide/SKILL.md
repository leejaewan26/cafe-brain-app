---
name: claude-usage-guide
description: This skill should be used when the user asks how to use Claude Code features, how to set up slash commands, how to use memory across conversations, how to configure hooks, how to use subagents, how to work with MCP servers, how to create plugins, or how to automate workflows with Claude Code. Activates on phrases like "Claude Code 사용법", "slash command", "메모리 설정", "hooks", "서브에이전트", "MCP", "플러그인", "자동화", "how does Claude Code work", "CLAUDE.md".
version: 1.0.0
---

# Claude Code Usage Guide Skill

Progressive guide for mastering Claude Code — from basics to automated pipelines combining slash commands, memory, subagents, hooks, and MCP.

> Based on: https://github.com/luongnv89/claude-howto

## When This Skill Applies

Activate when the user asks about:
- How any Claude Code feature works
- Setting up their Claude Code environment
- Combining multiple features into workflows
- Troubleshooting Claude Code behavior
- Creating slash commands, skills, hooks, or plugins

---

## Module 1: Slash Commands

User-invoked commands in Claude Code. Stored as markdown files.

### Location
```
~/.claude/commands/           # Global commands (all projects)
.claude/commands/             # Project-local commands
```

### File Format
```markdown
# Command Name

Your prompt template here. You can reference $ARGUMENTS for user input.

Example: "Analyze the function $ARGUMENTS and suggest improvements."
```

### Usage
```
/command-name argument here
```

### Example: Code Review Command
```markdown
# review

Perform a thorough code review of $ARGUMENTS.

Check for:
- Logic errors and edge cases
- Security vulnerabilities (OWASP top 10)
- Performance issues
- Code style consistency
- Missing error handling

Provide specific line-by-line feedback.
```

---

## Module 2: Memory System

Persistent notes that carry across conversations.

### Memory File Locations
```
~/.claude/projects/{project-path}/memory/   # Project-scoped memory
~/.claude/memory/                            # Global memory
```

### Memory Index (MEMORY.md)
Always loaded into context. Keep under 200 lines.
```markdown
# Memory Index

- [Project Context](project.md) — What this project does
- [User Preferences](preferences.md) — How the user likes to work
- [Architecture Decisions](decisions.md) — Key technical choices
```

### Memory Types
| Type | When to use |
|------|-------------|
| `user` | User's role, expertise, preferences |
| `feedback` | Corrections and confirmed approaches |
| `project` | Goals, deadlines, architecture decisions |
| `reference` | Where to find things (Linear, Slack, docs) |

### Memory File Format
```markdown
---
name: memory-name
description: One-line hook — used to decide relevance
type: user | feedback | project | reference
---

Content here. For feedback/project:
**Why:** reason this matters
**How to apply:** when this guidance kicks in
```

---

## Module 3: Skills

Model-invoked capabilities — Claude automatically uses them based on context.

### Location
```
~/.claude/skills/{skill-name}/SKILL.md     # Global skills
.claude/skills/{skill-name}/SKILL.md       # Project-local skills
```

### SKILL.md Format
```markdown
---
name: skill-name
description: When Claude should use this skill. Include trigger phrases.
version: 1.0.0
---

# Skill Title

## When This Skill Applies
[conditions]

## Guidance
[structured content Claude uses when this skill is active]
```

### Key: The Description Field
This is how Claude decides to invoke the skill. Be specific:
```yaml
description: Use when user asks to "write tests", mentions "TDD",
  discusses "pytest", "jest", or "unit testing".
```

---

## Module 4: Hooks

Shell commands that run automatically on Claude Code events.

### Configuration: `~/.claude/settings.json`
```json
{
  "hooks": {
    "PreToolUse": [
      {
        "matcher": "Bash",
        "hooks": [
          {
            "type": "command",
            "command": "echo 'Running bash command' >> ~/.claude/audit.log"
          }
        ]
      }
    ],
    "PostToolUse": [...],
    "Stop": [...],
    "Notification": [...]
  }
}
```

### Hook Events
| Event | When it fires |
|-------|--------------|
| `PreToolUse` | Before any tool call |
| `PostToolUse` | After any tool call |
| `Stop` | When Claude finishes a response |
| `Notification` | When Claude needs user attention |

### Hook Matchers
- `"Bash"` — matches Bash tool calls
- `"Write"` — matches file writes
- `"Edit"` — matches file edits
- `""` — matches all tools

### Practical Hook Examples

**Block dangerous commands:**
```bash
#!/bin/bash
# ~/.claude/hooks/block-rm-rf.sh
if echo "$CLAUDE_TOOL_INPUT" | grep -q "rm -rf /"; then
  echo "BLOCKED: rm -rf / is not allowed" >&2
  exit 1
fi
```

**Log all file writes:**
```json
{
  "matcher": "Write",
  "hooks": [{
    "type": "command",
    "command": "echo \"$(date): Write to $CLAUDE_TOOL_INPUT_FILE_PATH\" >> ~/.claude/writes.log"
  }]
}
```

---

## Module 5: Subagents

Claude spawning specialized Claude instances for parallel or isolated work.

### When to Use Subagents
- Research that shouldn't pollute main context
- Parallel independent tasks (run simultaneously)
- Specialized expertise (Explore agent, Plan agent)
- Isolated code execution (worktree isolation)

### Agent Types Available
| Agent | Use for |
|-------|---------|
| `general-purpose` | Complex multi-step research |
| `Explore` | Codebase exploration, file finding |
| `Plan` | Architecture and implementation planning |
| `claude-code-guide` | Questions about Claude Code features |
| `statusline-setup` | Configure Claude Code status line |

### Parallel Subagents Pattern
```
Launch multiple agents in a single message (no dependencies between them):
- Research agent 1: investigate X
- Research agent 2: investigate Y
→ Both run simultaneously, results returned together
```

---

## Module 6: MCP Servers

Model Context Protocol — extend Claude with external data and tools.

### Install an MCP Server
```bash
# Via Claude Code
claude mcp add server-name -- npx -y @package/mcp-server

# Or edit settings.json directly
```

### Settings Location
`~/.claude/settings.json`:
```json
{
  "mcpServers": {
    "filesystem": {
      "command": "npx",
      "args": ["-y", "@modelcontextprotocol/server-filesystem", "/allowed/path"]
    },
    "github": {
      "command": "npx",
      "args": ["-y", "@modelcontextprotocol/server-github"],
      "env": {
        "GITHUB_TOKEN": "your-token"
      }
    }
  }
}
```

### Popular MCP Servers
| Server | Purpose |
|--------|---------|
| `@modelcontextprotocol/server-filesystem` | Read/write files beyond project |
| `@modelcontextprotocol/server-github` | GitHub issues, PRs, repos |
| `@modelcontextprotocol/server-slack` | Slack messages |
| `@notionhq/notion-mcp-server` | Notion pages and databases |
| `@modelcontextprotocol/server-postgres` | PostgreSQL queries |

---

## Module 7: CLAUDE.md

Project instructions that are always loaded for this project.

### Location
`.claude/CLAUDE.md` or `CLAUDE.md` in project root

### Effective Structure
```markdown
# Project: [Name]

## Tech Stack
[Languages, frameworks, key libraries]

## Architecture
[Brief description of how components fit together]

## Development Guidelines
- [Rule 1]
- [Rule 2]

## Testing
[How to run tests, what to test]

## Important Patterns
[Code patterns specific to this project]

## Out of Scope
[What NOT to change or touch]
```

---

## Combining Features: Automated Workflows

### Code Review Pipeline
```
Slash command /review $PR_NUMBER
  → Hook: log review start
  → Subagent: fetch PR diff (Explore agent)
  → Subagent: check test coverage
  → Main: synthesize review + post comment
  → Hook: log review complete
```

### Documentation Generation
```
Hook: PostToolUse on Write to *.py files
  → Trigger: check if docstrings present
  → If missing: Claude generates docstrings
  → Write: update file
```

### Security Audit
```
Slash command /security-audit
  → Skill: security-patterns activated
  → Explore agent: scan all files for patterns
  → Plan agent: prioritize findings
  → Main: produce report with fix suggestions
```

---

## Quick Reference

| Feature | Invocation | Location |
|---------|-----------|----------|
| Slash commands | `/command-name arg` | `~/.claude/commands/` or `.claude/commands/` |
| Skills | Automatic (model-invoked) | `~/.claude/skills/` or `.claude/skills/` |
| Memory | Automatic (loaded at start) | `~/.claude/projects/*/memory/` |
| Hooks | Automatic (event-driven) | `~/.claude/settings.json` |
| Subagents | Claude spawns them | N/A (built-in) |
| MCP | Available as tools | `~/.claude/settings.json` |
| CLAUDE.md | Loaded every session | `CLAUDE.md` in project root |
