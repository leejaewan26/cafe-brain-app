"""
메뉴·레시피 & 교육 매뉴얼 라우터
- 레시피 문서 자동 생성 (AI)
- 시그니처 메뉴 3종 추천 (AI)
- 교육 매뉴얼 5종 생성 (AI)
"""
from fastapi import APIRouter
from pydantic import BaseModel
from typing import List, Optional
from app.services.gemini_service import generate_insight_cached, build_cache_key

router = APIRouter()


# ─── 스키마 ───

class RecipeRequest(BaseModel):
    """레시피 문서 생성 요청"""
    menu_name: str
    category: str
    ingredients: List[str]  # ["에스프레소 18g", "우유 200ml"] 형태
    notes: Optional[str] = ""
    store_name: str


class RecipeResponse(BaseModel):
    recipe: str


class RecommendRequest(BaseModel):
    """시그니처 메뉴 추천 요청"""
    store_name: str
    district_type: str
    ambiance: str
    menu_count: int


class RecommendResponse(BaseModel):
    recommendations: str


class ManualRequest(BaseModel):
    """교육 매뉴얼 생성 요청"""
    manual_type: str    # open_checklist, close_checklist, barista_guide, customer_scenario, machine_trouble
    output_format: str  # checklist, table, step_guide
    store_name: str
    machine_brand: Optional[str] = "라마르조코"
    milk_location: Optional[str] = "냉장고 2번 칸"
    extra_info: Optional[str] = ""


class ManualResponse(BaseModel):
    content: str


# ─── 프롬프트 빌더 ───


def build_format_note(output_format: str) -> str:
    if output_format == "checklist":
        return "체크박스(☐) 목록 형태로 작성하세요."
    if output_format == "table":
        return "마크다운 표(| 열1 | 열2 |) 형태로 작성하세요."
    return "번호를 매긴 단계별 가이드 형태로 작성하세요."


# ─── 엔드포인트 ───

@router.post("/recipe", response_model=RecipeResponse)
async def generate_recipe(req: RecipeRequest):
    """
    등록된 재료·용량 기반으로 단계별 레시피 카드 생성
    누구나 따라할 수 있는 자연스러운 문장으로 정리
    """
    ingredients_str = "\n".join(f"- {ing}" for ing in req.ingredients)
    prompt = f"""
'{req.menu_name}' ({req.category}) 레시피 문서를 작성해주세요.
매장명: {req.store_name}
메모: {req.notes}

재료:
{ingredients_str}

작성 규칙:
- 대상: 처음 배우는 신입 직원
- 톤: 친근하고 명확한 설명
- 구조: [재료 준비] → [도구 준비] → [Step 1~5 단계별 조리법] → [서빙 가이드] → [바리스타 팁]
- 각 Step에 온도, 시간, 주의사항 포함
- 이모지 적절히 활용

레시피 문서 전체 작성:"""

    cache_key = build_cache_key(
        store_id=req.store_name,
        template="menu_recipe",
        params={
            "menu": req.menu_name,
            "category": req.category,
            "ingredients": "|".join(sorted(req.ingredients)),
            "notes": (req.notes or "")[:200],
        },
    )
    recipe = await generate_insight_cached(prompt, cache_key=cache_key)
    return RecipeResponse(recipe=recipe)


@router.post("/recommend", response_model=RecommendResponse)
async def recommend_menus(req: RecommendRequest):
    """
    매장 분위기·상권 기반 시그니처 메뉴 3종 추천
    논커피 포함, 이름·재료·가격대 제안
    """
    prompt = f"""
'{req.store_name}' 카페를 위한 시그니처 신메뉴 3가지를 추천해주세요.

매장 정보:
- 상권: {req.district_type}
- 분위기: {req.ambiance}
- 현재 메뉴 수: {req.menu_count}개

추천 기준:
- 3가지 중 최소 1가지는 논커피 메뉴
- 상권 특성을 반영한 차별화 메뉴
- 계절감 또는 트렌드 반영

각 메뉴별 형식:
1. [메뉴명]
   - 컨셉: (한 줄 설명)
   - 핵심 재료: (3~5가지)
   - 추천 가격: (원)
   - 예상 원가비중: (%)
   - 차별화 포인트: (경쟁 메뉴 대비)

구체적이고 실현 가능한 메뉴로 추천해주세요:"""

    cache_key = build_cache_key(
        store_id=req.store_name,
        template="menu_recommend",
        params={
            "district": req.district_type,
            "ambiance": req.ambiance,
            "count": req.menu_count,
        },
    )
    recommendations = await generate_insight_cached(prompt, cache_key=cache_key)
    return RecommendResponse(recommendations=recommendations)


@router.post("/manual", response_model=ManualResponse)
async def generate_manual(req: ManualRequest):
    """
    교육 매뉴얼 5종 생성
    - 오픈/마감 체크리스트
    - 신입 바리스타 교육 가이드
    - 고객 응대 시나리오
    - 머신 트러블슈팅
    """
    format_note = build_format_note(req.output_format)

    base_prompts = {
        "open_checklist": f"""'{req.store_name}' 오픈 체크리스트를 작성해주세요. {format_note}
머신: {req.machine_brand}, 우유 위치: {req.milk_location}
추가사항: {req.extra_info}
항목: 기기 점검, 재료 확인, 청결, POS, 조명·음악, 최종 확인 (총 25~30개 항목)""",

        "close_checklist": f"""'{req.store_name}' 마감 체크리스트를 작성해주세요. {format_note}
머신: {req.machine_brand}
추가사항: {req.extra_info}
항목: 기기 세척, 재료 정리, 바 청소, 쓰레기 처리, POS 마감, 잠금 확인 (총 25~30개 항목)""",

        "barista_guide": f"""'{req.store_name}' 신입 바리스타 첫 주 교육 가이드를 작성해주세요. {format_note}
머신: {req.machine_brand}, 우유 위치: {req.milk_location}
추가사항: {req.extra_info}
5일 커리큘럼 (에스프레소 → 스팀밀크 → 라떼아트 순서로 진행)""",

        "customer_scenario": f"""'{req.store_name}' 고객 응대 시나리오를 작성해주세요. {format_note}
추가사항: {req.extra_info}
상황: 주문 실수, 환불 요구, 대기 불만, 알레르기 문의, 자리 부족, 매장 이용 규칙""",

        "machine_trouble": f"""'{req.store_name}' {req.machine_brand} 트러블슈팅 가이드를 작성해주세요. {format_note}
추가사항: {req.extra_info}
문제: 추출 속도 이상, 스팀봉 문제, 그라인더 조절, 압력 이상, 필터 홀더, 보일러 경고""",
    }

    prompt = base_prompts.get(req.manual_type, f"'{req.store_name}' 카페 교육 매뉴얼을 작성해주세요.")
    cache_key = build_cache_key(
        store_id=req.store_name,
        template=f"menu_manual_{req.manual_type}",
        params={
            "format": req.output_format,
            "machine": req.machine_brand or "",
            "milk": req.milk_location or "",
            "extra": (req.extra_info or "")[:200],
        },
    )
    content = await generate_insight_cached(prompt, cache_key=cache_key)
    return ManualResponse(content=content)
