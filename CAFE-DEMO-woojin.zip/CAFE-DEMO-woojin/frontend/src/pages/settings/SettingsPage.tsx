// 설정 페이지 (Wave 1 W1-A) — 탭 컨테이너
// Wave 2-4의 #5 멀티프로필·#19 알림 등도 여기 추가될 예정
import { useState } from 'react'
import { Link } from 'react-router-dom'
import { ChevronLeft, Settings, User, Sparkles, Moon, Shield, Bell, Users, Brain } from 'lucide-react'
import { cn } from '@/lib/utils'
import { useTheme } from '@/hooks/useTheme'
import { useProfileStore } from '@/store/profileStore'
import StoreTab from './tabs/StoreTab'
import AiTab from './tabs/AiTab'
import ThemeTab from './tabs/ThemeTab'
import AccountTab from './tabs/AccountTab'
import NotifyTab from './tabs/NotifyTab'
import ProfilesTab from './tabs/ProfilesTab'
import AgentTab from './tabs/AgentTab'

type TabId = 'store' | 'ai' | 'agent' | 'notify' | 'profiles' | 'theme' | 'account'

const BASE_TABS: { id: TabId; label: string; icon: React.ElementType; ownerOnly?: boolean }[] = [
  { id: 'store', label: '매장 정보', icon: User },
  { id: 'ai', label: 'AI 설정', icon: Sparkles },
  { id: 'agent', label: 'AI 학습', icon: Brain },
  { id: 'notify', label: '알림', icon: Bell },
  { id: 'profiles', label: '프로필 관리', icon: Users, ownerOnly: true },
  { id: 'theme', label: '화면', icon: Moon },
  { id: 'account', label: '계정', icon: Shield },
]

export default function SettingsPage() {
  // 페이지 진입 시 테마 구독 (OS 변경 실시간 반영)
  useTheme()
  const activeProfile = useProfileStore((s) => s.activeProfile)
  const isOwner = activeProfile?.role === 'owner'
  const [activeTab, setActiveTab] = useState<TabId>('store')

  // 권한별 탭 필터링 (사장만 프로필 관리 탭 노출)
  const TABS = BASE_TABS.filter((t) => !t.ownerOnly || isOwner)

  return (
    <div className="min-h-screen bg-[#FAFAF8]">
      {/* 헤더 */}
      <header className="bg-[#2C1810] text-white px-4 py-3 flex items-center gap-3 sticky top-0 z-20">
        <Link to="/dashboard" className="hover:text-[#D4A574] transition-colors duration-200">
          <ChevronLeft size={20} />
        </Link>
        <Settings size={18} className="text-[#D4A574]" />
        <h1 className="font-bold text-base flex-1">설정</h1>
      </header>

      {/* 탭 네비게이션 */}
      <div className="flex overflow-x-auto scrollbar-hide bg-white border-b border-gray-100 px-2 pt-2 sticky top-[52px] z-10">
        {TABS.map(({ id, label, icon: Icon }) => (
          <button
            key={id}
            onClick={() => setActiveTab(id)}
            className={cn(
              'shrink-0 flex items-center gap-1.5 px-4 py-2.5 text-sm font-medium rounded-t-lg transition-all duration-200 whitespace-nowrap',
              activeTab === id
                ? 'bg-[#2C1810] text-white'
                : 'text-gray-500 hover:text-[#2C1810] hover:bg-gray-50'
            )}
          >
            <Icon size={14} />
            {label}
          </button>
        ))}
      </div>

      <main className="max-w-2xl mx-auto px-4 py-6 pb-24">
        {activeTab === 'store' && <StoreTab />}
        {activeTab === 'ai' && <AiTab />}
        {activeTab === 'agent' && <AgentTab />}
        {activeTab === 'notify' && <NotifyTab />}
        {activeTab === 'profiles' && <ProfilesTab />}
        {activeTab === 'theme' && <ThemeTab />}
        {activeTab === 'account' && <AccountTab />}
      </main>
    </div>
  )
}
