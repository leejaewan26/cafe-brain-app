// 이벤트 추적 유틸리티 (Day 7-1)
// /ultrareview VC·PM Critical: PMF 신호 측정 기반 확보
//
// 설계:
//   - 프로바이더 추상화 (PostHog/Amplitude/GA4 모두 주입 가능)
//   - DSN·API 키 없으면 no-op (개발 환경 무마찰)
//   - PII 없는 이벤트만 전송 (매장 ID는 sha256 해시)
//
// 런칭 시 import.meta.env.VITE_POSTHOG_KEY 설정하면 자동 활성

type EventName =
  // 가입 깔때기
  | 'landing_view'
  | 'login_click'
  | 'signup_success'
  | 'onboarding_start'
  | 'onboarding_quick_start'
  | 'onboarding_complete'
  // 핵심 기능 사용
  | 'sales_upload_csv'
  | 'sales_upload_ocr'
  | 'sales_ai_insight'
  | 'review_ai_reply'
  | 'marketing_generate'
  | 'marketing_canva_export'
  | 'schedule_generate'
  | 'bep_view'
  // AI 학습 루프
  | 'agent_briefing_view'
  | 'agent_feedback'
  | 'memory_extracted'
  // 결제 깔때기
  | 'pricing_view'
  | 'trial_banner_click'
  | 'checkout_start'
  | 'checkout_success'
  | 'checkout_fail'
  // 리텐션
  | 'app_install_pwa'
  | 'push_subscribe'
  | 'export_csv'
  | 'export_excel'
  | 'export_pdf'
  // 이탈 신호
  | 'error_occurred'
  | 'rate_limit_hit'

interface EventProps {
  [key: string]: string | number | boolean | null | undefined
}

// ─── 구성 ───
const POSTHOG_KEY = import.meta.env.VITE_POSTHOG_KEY as string | undefined
const POSTHOG_HOST = (import.meta.env.VITE_POSTHOG_HOST as string | undefined) ?? 'https://app.posthog.com'
const ENABLED = Boolean(POSTHOG_KEY)

// 매장 ID를 FNV-1a 32비트로 해시 (PII 제거) — 간단하고 결정적
function hashStoreId(id: string): string {
  let h = 2166136261
  for (let i = 0; i < id.length; i++) {
    h ^= id.charCodeAt(i)
    h = Math.imul(h, 16777619)
  }
  return (h >>> 0).toString(36)
}

// PostHog 런타임 타입 (npm 미설치 환경에서도 빌드 통과)
interface PostHogLite {
  init: (key: string, config: Record<string, unknown>) => void
  capture: (event: string, props?: Record<string, unknown>) => void
  identify: (id: string, props?: Record<string, unknown>) => void
  reset: () => void
}

// PostHog 지연 로드 (초기 번들 최소화)
// @vite-ignore로 TS 컴파일 타임 의존성 체크 회피 — 런타임은 ENABLED 체크로 안전
let posthogPromise: Promise<PostHogLite | null> | null = null
async function getPostHog(): Promise<PostHogLite | null> {
  if (!ENABLED) return null
  if (!posthogPromise) {
    posthogPromise = (async () => {
      try {
        // @ts-ignore — posthog-js는 환경에 따라 type 없을 수 있는 optional dep
        const m = await import(/* @vite-ignore */ 'posthog-js')
        const ph = (m.default ?? m) as PostHogLite
        ph.init(POSTHOG_KEY!, {
          api_host: POSTHOG_HOST,
          persistence: 'localStorage+cookie',
          autocapture: false,
          capture_pageview: true,
          capture_pageleave: true,
          disable_session_recording: true,
          respect_dnt: true,
        })
        return ph
      } catch {
        return null
      }
    })()
  }
  return posthogPromise
}

/**
 * 이벤트 트래킹.
 * ENABLED가 false면 no-op (개발 환경에서도 콘솔만 찍고 끝).
 */
export function track(event: EventName, props: EventProps = {}): void {
  if (!ENABLED) {
    if (import.meta.env.DEV) {
      // 개발 환경: 콘솔로만 찍어 디버깅
      console.debug('[analytics]', event, props)
    }
    return
  }

  // 매장 ID가 있으면 해시화
  const safe: EventProps = { ...props }
  if (typeof safe.store_id === 'string' && safe.store_id) {
    safe.store_id_hash = hashStoreId(safe.store_id)
    delete safe.store_id
  }

  void getPostHog().then((ph) => {
    ph?.capture(event, safe)
  }).catch(() => { /* 조용히 실패 */ })
}

/**
 * 사용자 식별 (로그인 후 호출).
 * store_id는 해시만 저장되어 Amplitude·PostHog 대시보드에서도 PII 노출 X.
 */
export function identify(storeId: string, props: EventProps = {}): void {
  if (!ENABLED) return
  const distinctId = hashStoreId(storeId)
  void getPostHog().then((ph) => {
    ph?.identify(distinctId, { ...props })
  }).catch(() => { /* 조용히 실패 */ })
}

/**
 * 사용자 로그아웃 시 호출.
 */
export function reset(): void {
  if (!ENABLED) return
  void getPostHog().then((ph) => {
    ph?.reset()
  }).catch(() => { /* 조용히 실패 */ })
}

/**
 * 페이지뷰 — React Router와 연동하려면 useLocation 훅 사용.
 */
export function pageView(path: string): void {
  track('landing_view' as EventName, { path })
}
