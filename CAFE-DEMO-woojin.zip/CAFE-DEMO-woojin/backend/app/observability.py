"""
관측성(Observability) 설정 — Sentry + 심화 헬스체크 (Day 2-2)

설계 원칙:
  - Sentry DSN 없으면 자동 비활성화 (로컬 개발 무마찰)
  - PII 필터와 일관성: before_send 훅에서 민감정보 마스킹
  - /health/deep: DB·Gemini·Supabase 3종 핵심 의존성 점검
"""
import asyncio
import logging
import time
from typing import Any, Optional

from app.config import settings

logger = logging.getLogger("observability")


def init_sentry() -> bool:
    """
    Sentry 초기화. DSN 비어 있으면 no-op.
    Returns: 활성화 여부
    """
    if not settings.sentry_dsn:
        logger.info("Sentry 비활성화 (SENTRY_DSN 환경변수 없음)")
        return False

    try:
        import sentry_sdk
        from sentry_sdk.integrations.fastapi import FastApiIntegration
        from sentry_sdk.integrations.starlette import StarletteIntegration

        sentry_sdk.init(
            dsn=settings.sentry_dsn,
            environment=settings.sentry_environment,
            release=f"cafe-brain@{settings.app_version}",
            sample_rate=settings.sentry_sample_rate,
            traces_sample_rate=settings.sentry_traces_sample_rate,
            integrations=[
                StarletteIntegration(transaction_style="endpoint"),
                FastApiIntegration(transaction_style="endpoint"),
            ],
            # PII 보호: 민감정보 마스킹 후 전송
            send_default_pii=False,
            before_send=_scrub_sentry_event,
        )
        logger.info(
            "Sentry 활성화 | env=%s | release=cafe-brain@%s",
            settings.sentry_environment,
            settings.app_version,
        )
        return True
    except ImportError:
        logger.warning("sentry_sdk 미설치 — `pip install sentry-sdk[fastapi]` 필요")
        return False
    except Exception as e:
        logger.error("Sentry 초기화 실패: %s", e)
        return False


def _scrub_sentry_event(event: dict, hint: dict) -> Optional[dict]:
    """
    Sentry 전송 전 PII·시크릿 마스킹.
    """
    # Authorization 헤더 제거
    request = event.get("request", {})
    headers = request.get("headers", {})
    if isinstance(headers, dict):
        for k in list(headers.keys()):
            if k.lower() in ("authorization", "cookie", "x-store-id"):
                headers[k] = "[REDACTED]"

    # 요청 바디에서 Gemini 키·base64 이미지 제거
    data = request.get("data")
    if isinstance(data, dict):
        for k in ("image_base64", "image", "gemini_api_key", "supabase_service_key"):
            if k in data:
                data[k] = "[REDACTED]"

    return event


# ═══════════════════════════════════════════════════════
# 심화 헬스체크 — DB·Gemini·Supabase
# ═══════════════════════════════════════════════════════


async def _check_gemini() -> tuple[str, float, Optional[str]]:
    """Gemini 연결성 확인 (키 유효성만 검증 — 실제 호출 비용 발생 없음)."""
    t0 = time.time()
    if not settings.gemini_api_key:
        return ("skip", 0.0, "GEMINI_API_KEY 미설정")
    try:
        import google.generativeai as genai
        genai.configure(api_key=settings.gemini_api_key)
        # list_models()는 저비용 메타데이터 호출
        def _list():
            return list(genai.list_models())
        models = await asyncio.wait_for(
            asyncio.to_thread(_list), timeout=5.0
        )
        elapsed = (time.time() - t0) * 1000
        return ("ok", elapsed, f"{len(models)} 모델 접근 가능")
    except asyncio.TimeoutError:
        return ("timeout", (time.time() - t0) * 1000, "5초 초과")
    except Exception as e:
        return ("error", (time.time() - t0) * 1000, str(e)[:120])


async def _check_supabase() -> tuple[str, float, Optional[str]]:
    """Supabase 연결성 확인 — 간단한 SELECT."""
    t0 = time.time()
    if not settings.supabase_url or not settings.supabase_service_key:
        return ("skip", 0.0, "Supabase 환경변수 미설정")
    try:
        from supabase import create_client
        sb = create_client(settings.supabase_url, settings.supabase_service_key)

        def _probe():
            # ai_cache 1건 조회 (비용 거의 0, 결과 개수 중요 X)
            return sb.table("ai_cache").select("cache_key").limit(1).execute()

        await asyncio.wait_for(asyncio.to_thread(_probe), timeout=5.0)
        elapsed = (time.time() - t0) * 1000
        return ("ok", elapsed, None)
    except asyncio.TimeoutError:
        return ("timeout", (time.time() - t0) * 1000, "5초 초과")
    except Exception as e:
        return ("error", (time.time() - t0) * 1000, str(e)[:120])


async def _check_memory() -> tuple[str, float, Optional[str]]:
    """프로세스 메모리 사용률 (psutil 있으면)."""
    t0 = time.time()
    try:
        import psutil
        mem = psutil.virtual_memory()
        elapsed = (time.time() - t0) * 1000
        status = "warn" if mem.percent > 85 else "ok"
        return (status, elapsed, f"{mem.percent:.1f}% 사용 중")
    except ImportError:
        return ("skip", 0.0, "psutil 미설치")
    except Exception as e:
        return ("error", (time.time() - t0) * 1000, str(e)[:120])


async def run_deep_healthcheck() -> dict[str, Any]:
    """
    DB·Gemini·Supabase·메모리 동시 점검.
    각 체크는 타임아웃 5초, 전체 병렬 실행.
    """
    started = time.time()

    results = await asyncio.gather(
        _check_gemini(),
        _check_supabase(),
        _check_memory(),
        return_exceptions=True,
    )

    checks = {}
    for name, result in zip(["gemini", "supabase", "memory"], results):
        if isinstance(result, Exception):
            checks[name] = {
                "status": "exception",
                "latency_ms": 0,
                "detail": str(result)[:120],
            }
        else:
            status, latency_ms, detail = result
            checks[name] = {
                "status": status,
                "latency_ms": round(latency_ms, 1),
                "detail": detail,
            }

    # 캐시 통계 병합
    try:
        from app.services.gemini_service import get_cache_stats
        checks["ai_cache"] = {"status": "ok", **get_cache_stats()}
    except Exception:
        pass

    # 전체 상태 집계: 하나라도 error/timeout이면 degraded
    statuses = [c.get("status") for c in checks.values() if c.get("status") not in ("skip", "ok")]
    if not statuses:
        overall = "ok"
    elif any(s in ("error", "exception", "timeout") for s in statuses):
        overall = "degraded"
    else:
        overall = "warn"

    return {
        "status": overall,
        "service": "cafe-brain-api",
        "version": settings.app_version,
        "environment": settings.sentry_environment,
        "total_latency_ms": round((time.time() - started) * 1000, 1),
        "checks": checks,
    }
