"""
Bonus E2 — Citation 헬퍼 검증.
"""
from app.services.gemini_service import (
    attach_citations,
    derive_citations_from_tool_calls,
)


def test_attach_citations_appends_footnote():
    text = "오늘 매출이 평일 평균 대비 +15% 증가했습니다."
    cites = [
        {"label": "2024-12-15 매출 데이터", "kind": "sales"},
        {"label": "고객 패턴 메모리", "kind": "memory"},
    ]
    out = attach_citations(text, cites)
    assert "📎" in out
    assert "📊 2024-12-15 매출 데이터" in out
    assert "🧠 고객 패턴 메모리" in out


def test_attach_citations_dedup():
    text = "answer"
    cites = [
        {"label": "동일", "kind": "sales"},
        {"label": "동일", "kind": "sales"},
    ]
    out = attach_citations(text, cites)
    assert out.count("동일") == 1


def test_attach_citations_empty_returns_text_unchanged():
    text = "그대로"
    assert attach_citations(text, []) == text


def test_derive_citations_from_tool_calls():
    tool_calls = [
        {"name": "get_sales_summary", "args": {"today": "2024-12-15"}, "result": {}},
        {"name": "search_memories", "args": {"query": "주말 매출"}, "result": {}},
        {"name": "get_trend_snapshot", "args": {}, "result": {}},
    ]
    cites = derive_citations_from_tool_calls(tool_calls)
    assert len(cites) == 3
    assert cites[0]["kind"] == "sales"
    assert "2024-12-15" in cites[0]["label"]
    assert cites[1]["kind"] == "memory"
    assert cites[2]["kind"] == "trend"
