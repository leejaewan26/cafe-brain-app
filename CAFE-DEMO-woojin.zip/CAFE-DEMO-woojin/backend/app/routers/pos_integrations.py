"""
H3 — POS 시스템 연동

어댑터 패턴: 각 POS 벤더별 클라이언트 모듈을 plug-in으로 추가.

지원 POS (단계별):
  - toss_pos: 토스 POS (REST API + 웹훅)
  - kis: 한국정보시스템 (REST + 폴링)
  - smart_bro: 스마트브로 (CSV export + 폴링)
  - tablen: 테블엔 (REST)
  - generic: CSV 업로드 (모든 POS 호환)

플로우 1 (실시간 웹훅):
  POS → /api/pos/webhook/{vendor}/{store_id}  (vendor가 push)
  웹훅에서 매출 row를 sales_records에 INSERT (멱등)

플로우 2 (폴링):
  cron이 /api/pos/sync/{store_id} 호출 (5분마다)
  마지막 동기화 timestamp 이후 매출만 fetch

플로우 3 (수동):
  POST /api/pos/upload-csv  (이미 sales.py에 있음)
"""
import asyncio
import logging
import uuid
from datetime import datetime, timezone
from typing import Any, Literal, Optional

import httpx
from fastapi import APIRouter, BackgroundTasks, Header, HTTPException, Request
from pydantic import BaseModel, Field

from app.config import settings
from app.services.gemini_service import _get_supabase

logger = logging.getLogger("pos")
router = APIRouter()

VendorId = Literal["toss_pos", "kis", "smart_bro", "tablen", "generic"]


class POSConnection(BaseModel):
    store_id: str
    vendor: VendorId
    api_key: Optional[str] = None
    api_secret: Optional[str] = None
    business_no: Optional[str] = None  # 사업자번호
    last_sync_at: Optional[str] = None


# ─── 1) 연결 관리 ──────────────────────────────────────────────


class ConnectRequest(BaseModel):
    store_id: str = Field(..., min_length=1)
    vendor: VendorId
    api_key: Optional[str] = None
    api_secret: Optional[str] = None
    business_no: Optional[str] = None


@router.post("/connect")
async def connect_pos(req: ConnectRequest):
    """매장에 POS 연동 키 저장. 키는 service_role 컬럼 — 본인은 마스킹된 view만 read."""
    sb = _get_supabase()
    if sb is None:
        raise HTTPException(503, "Supabase 미설정")

    row = {
        "store_id": req.store_id,
        "vendor": req.vendor,
        "api_key": req.api_key,
        "api_secret": req.api_secret,
        "business_no": req.business_no,
        "connected_at": datetime.now(timezone.utc).isoformat(),
        "is_active": True,
    }
    # upsert (store_id + vendor PK)
    await asyncio.to_thread(
        lambda: sb.table("pos_connections").upsert(row, on_conflict="store_id,vendor").execute()
    )
    return {"connected": True, "vendor": req.vendor}


@router.delete("/connect/{store_id}/{vendor}")
async def disconnect_pos(store_id: str, vendor: VendorId):
    sb = _get_supabase()
    if sb is None:
        raise HTTPException(503, "Supabase 미설정")
    await asyncio.to_thread(
        lambda: sb.table("pos_connections")
        .update({"is_active": False})
        .eq("store_id", store_id)
        .eq("vendor", vendor)
        .execute()
    )
    return {"disconnected": True}


@router.get("/connections/{store_id}")
async def list_connections(store_id: str):
    sb = _get_supabase()
    if sb is None:
        return {"connections": []}
    res = await asyncio.to_thread(
        lambda: sb.table("pos_connections")
        .select("vendor, business_no, last_sync_at, connected_at, is_active")
        .eq("store_id", store_id)
        .execute()
    )
    return {"connections": res.data or []}


# ─── 2) 웹훅 수신 (실시간) ────────────────────────────────────


@router.post("/webhook/{vendor}/{store_id}")
async def pos_webhook(
    vendor: VendorId,
    store_id: str,
    request: Request,
    bg: BackgroundTasks,
    signature: str = Header(default="", alias="X-POS-Signature"),
):
    """
    POS 벤더가 매출 발생 즉시 호출.

    예: 토스 POS는 결제 완료 시:
      POST /api/pos/webhook/toss_pos/{store_id}
      { paymentKey, totalAmount, items: [{name, quantity, price}], approvedAt }
    """
    raw = await request.body()
    payload = await request.json()

    bg.add_task(_handle_pos_event, vendor, store_id, payload, signature, raw)
    return {"received": True}


async def _handle_pos_event(
    vendor: VendorId,
    store_id: str,
    payload: dict[str, Any],
    signature: str,
    raw: bytes,
) -> None:
    """벤더별 페이로드 → sales_records 정규화 INSERT."""
    sb = _get_supabase()
    if sb is None:
        return

    try:
        normalized = _normalize_pos_payload(vendor, payload)
        if not normalized:
            logger.warning("POS payload 정규화 실패 vendor=%s", vendor)
            return

        # 멱등성: idempotency_key (vendor + payment_id)
        idem_key = f"{vendor}:{normalized.get('payment_id') or normalized.get('order_id', uuid.uuid4().hex)}"

        for item in normalized["items"]:
            row = {
                "store_id": store_id,
                "sale_date": normalized["sale_date"],
                "menu_name": item["menu_name"],
                "quantity": item["quantity"],
                "revenue": item["revenue"],
                "cost": item.get("cost", 0),
                "hour_slot": normalized.get("hour_slot"),
                "discount": item.get("discount", 0),
                "source": vendor,
                "idempotency_key": f"{idem_key}:{item['menu_name']}",
            }
            try:
                await asyncio.to_thread(lambda r=row: sb.table("sales_records").insert(r).execute())
            except Exception:
                pass  # idempotency UNIQUE 충돌 — 이미 처리됨, 무시

        # last_sync_at 갱신
        await asyncio.to_thread(
            lambda: sb.table("pos_connections")
            .update({"last_sync_at": datetime.now(timezone.utc).isoformat()})
            .eq("store_id", store_id)
            .eq("vendor", vendor)
            .execute()
        )
    except Exception as e:
        logger.error("POS webhook 처리 실패 vendor=%s: %s", vendor, e)


def _normalize_pos_payload(vendor: VendorId, payload: dict[str, Any]) -> Optional[dict[str, Any]]:
    """벤더별 페이로드 → 공통 스키마."""
    if vendor == "toss_pos":
        # https://docs.tosspayments.com/reference#결제-완료-콜백
        approved_at = payload.get("approvedAt") or datetime.now(timezone.utc).isoformat()
        sale_date = approved_at[:10]
        hour_slot = int(approved_at[11:13]) if len(approved_at) >= 13 else None
        items = []
        for it in payload.get("items", []):
            items.append({
                "menu_name": it.get("name", "Unknown"),
                "quantity": int(it.get("quantity", 1)),
                "revenue": int(it.get("totalPrice", it.get("price", 0))),
                "discount": int(it.get("discount", 0)),
            })
        return {
            "payment_id": payload.get("paymentKey"),
            "order_id": payload.get("orderId"),
            "sale_date": sale_date,
            "hour_slot": hour_slot,
            "items": items,
        }

    if vendor == "kis":
        # KIS POS는 trDt(거래일) trTm(거래시간) menuList
        tr_dt = payload.get("trDt", "")
        tr_tm = payload.get("trTm", "")
        sale_date = f"{tr_dt[:4]}-{tr_dt[4:6]}-{tr_dt[6:8]}" if len(tr_dt) == 8 else datetime.now(timezone.utc).date().isoformat()
        hour = int(tr_tm[:2]) if len(tr_tm) >= 2 else None
        items = []
        for m in payload.get("menuList", []):
            items.append({
                "menu_name": m.get("menuNm", "Unknown"),
                "quantity": int(m.get("qty", 1)),
                "revenue": int(m.get("amt", 0)),
            })
        return {
            "payment_id": payload.get("trNo"),
            "sale_date": sale_date,
            "hour_slot": hour,
            "items": items,
        }

    if vendor == "smart_bro":
        # smart_bro (스마트브로) 표준 webhook
        tx = payload.get("transaction", {})
        sale_date = tx.get("date") or datetime.now(timezone.utc).date().isoformat()
        hour = tx.get("hour")
        items = []
        for it in payload.get("items", []):
            items.append({
                "menu_name": it.get("name", "Unknown"),
                "quantity": it.get("qty", 1),
                "revenue": it.get("price", 0) * it.get("qty", 1),
            })
        return {
            "payment_id": tx.get("id"),
            "sale_date": sale_date,
            "hour_slot": hour,
            "items": items,
        }

    if vendor == "generic":
        # 사용자 정의 — 그대로 사용
        return payload

    return None


# ─── 3) 폴링 sync (cron이 호출) ─────────────────────────────────


@router.post("/sync/{store_id}")
async def sync_pos(
    store_id: str,
    cron_key: str = Header(default="", alias="X-Cron-Key"),
):
    """
    매장의 모든 active POS 연결에 대해 마지막 동기화 이후 매출 폴링.
    cron이 5분마다 호출.
    """
    expected = settings.agent_admin_key or ""
    if cron_key != expected:
        raise HTTPException(403, "권한 없음")

    sb = _get_supabase()
    if sb is None:
        raise HTTPException(503, "Supabase 미설정")

    res = await asyncio.to_thread(
        lambda: sb.table("pos_connections")
        .select("*")
        .eq("store_id", store_id)
        .eq("is_active", True)
        .execute()
    )
    conns = res.data or []
    total_synced = 0

    for conn in conns:
        synced = await _poll_vendor(store_id, conn)
        total_synced += synced

    return {"synced": total_synced, "connections_processed": len(conns)}


async def _poll_vendor(store_id: str, conn: dict) -> int:
    """벤더별 폴링 — API 호출 + 정규화 + INSERT. 미구현 벤더는 0 반환."""
    vendor = conn["vendor"]
    api_key = conn.get("api_key")
    if not api_key:
        return 0

    last_sync = conn.get("last_sync_at") or "1970-01-01T00:00:00Z"

    # 벤더별 분기
    if vendor == "toss_pos":
        try:
            async with httpx.AsyncClient(timeout=10.0) as client:
                r = await client.get(
                    "https://api.tosspayments.com/v1/payments",
                    params={"startDate": last_sync, "endDate": datetime.now(timezone.utc).isoformat()},
                    headers={"Authorization": f"Basic {api_key}"},
                )
                if r.status_code != 200:
                    logger.warning("Toss POS 폴링 실패 %s", r.status_code)
                    return 0
                data = r.json()
                count = 0
                for p in data.get("payments", []):
                    await _handle_pos_event(vendor, store_id, p, "", b"")
                    count += 1
                return count
        except Exception as e:
            logger.warning("Toss POS 폴링 예외: %s", e)
            return 0

    # smart_bro — 자체 REST API (가상 — 실제 엔드포인트는 벤더 SDK 문서 참고)
    if vendor == "smart_bro":
        try:
            async with httpx.AsyncClient(timeout=10.0) as client:
                r = await client.get(
                    "https://api.smartbro.kr/v1/transactions",
                    params={"since": last_sync, "limit": 200},
                    headers={"X-API-Key": api_key},
                )
                if r.status_code != 200:
                    return 0
                data = r.json()
                count = 0
                for tx in data.get("transactions", []):
                    await _handle_pos_event(vendor, store_id, {"transaction": tx, "items": tx.get("items", [])}, "", b"")
                    count += 1
                return count
        except Exception as e:
            logger.warning("smart_bro 폴링 예외: %s", e)
            return 0

    # tablen — REST API
    if vendor == "tablen":
        try:
            async with httpx.AsyncClient(timeout=10.0) as client:
                r = await client.get(
                    "https://openapi.tablen.co.kr/v1/sales",
                    params={"startAt": last_sync},
                    headers={"Authorization": f"Bearer {api_key}"},
                )
                if r.status_code != 200:
                    return 0
                data = r.json()
                count = 0
                for sale in data.get("sales", []):
                    # tablen 페이로드를 generic으로 정규화
                    payload = {
                        "items": [{"name": s.get("menu_name", "Unknown"), "qty": s.get("count", 1), "price": s.get("price", 0)} for s in sale.get("lines", [])],
                        "transaction": {
                            "id": sale.get("orderId"),
                            "date": (sale.get("approvedAt") or "")[:10],
                            "hour": int((sale.get("approvedAt") or "00:00:00")[11:13]) if len(sale.get("approvedAt", "")) >= 13 else None,
                        },
                    }
                    # generic 어댑터로 처리
                    await _handle_pos_event("smart_bro", store_id, payload, "", b"")
                    count += 1
                return count
        except Exception as e:
            logger.warning("tablen 폴링 예외: %s", e)
            return 0

    # generic — CSV 업로드 등 외부 의존, 폴링 없음
    return 0
