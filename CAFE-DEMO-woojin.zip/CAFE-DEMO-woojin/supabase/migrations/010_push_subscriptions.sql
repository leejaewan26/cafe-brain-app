-- Issue #19: Web Push 구독 저장
-- 사용자가 여러 기기에서 구독 가능 → 1:N

CREATE TABLE IF NOT EXISTS public.push_subscriptions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  store_id uuid NOT NULL REFERENCES public.stores(id) ON DELETE CASCADE,
  profile_id uuid REFERENCES public.profiles(id) ON DELETE CASCADE,

  -- Web Push 프로토콜 구독 정보
  endpoint text NOT NULL,
  p256dh_key text NOT NULL,   -- 공개키
  auth_key text NOT NULL,     -- 인증 비밀

  -- 디바이스 식별 (UA 요약)
  user_agent text,

  -- 알림 항목별 on/off
  enabled_channels jsonb NOT NULL DEFAULT '{
    "sales_anomaly": true,
    "new_review": true,
    "order_pending": true,
    "bep_reached": true,
    "daily_briefing": true
  }'::jsonb,

  created_at timestamptz NOT NULL DEFAULT now(),
  last_active_at timestamptz NOT NULL DEFAULT now()
);

CREATE UNIQUE INDEX IF NOT EXISTS idx_push_subs_endpoint
  ON public.push_subscriptions(endpoint);

CREATE INDEX IF NOT EXISTS idx_push_subs_store
  ON public.push_subscriptions(store_id);

ALTER TABLE public.push_subscriptions ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "push_subs: 본인 매장" ON public.push_subscriptions;
CREATE POLICY "push_subs: 본인 매장" ON public.push_subscriptions
  FOR ALL USING (store_id = auth.uid());
