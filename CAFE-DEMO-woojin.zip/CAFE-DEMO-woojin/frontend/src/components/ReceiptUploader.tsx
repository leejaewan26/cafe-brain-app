// 영수증·매출 전표 사진 OCR 업로더 (Wave 5G)
// CSV를 모르는 사장님도 사진 한 장으로 매출 입력
// - 카메라 직접 촬영 / 갤러리 선택 / 드래그앤드롭
// - 이미지 클라이언트 리사이징 (Gemini 토큰 절약)
// - 추출 결과 검토·수정 → 저장
import { useRef, useState } from 'react'
import {
  Camera, Upload, Image as ImageIcon, Loader2, Check, X, AlertCircle,
  Trash2, Edit3, Sparkles, ScanLine,
} from 'lucide-react'
import toast from 'react-hot-toast'
import type { SalesRecord } from '@/types/sales'
import { useStoreContext } from '@/hooks/useStoreContext'
import { cn, formatCurrency } from '@/lib/utils'
import { track } from '@/lib/analytics'

interface ExtractedRow {
  sale_date: string
  menu_name: string
  quantity: number
  revenue: number
  cost: number
  hour_slot: number
  discount: number
  confidence: number
}

interface ReceiptUploaderProps {
  onImport: (records: SalesRecord[]) => void
}

// 이미지 리사이징 (긴 변 1024px, JPEG 0.85 품질)
const MAX_DIMENSION = 1024

async function optimizeImage(file: File): Promise<{ base64: string; mime: string }> {
  const isSvg = file.type === 'image/svg+xml'
  if (isSvg) {
    // SVG는 base64 그대로
    const buf = await file.arrayBuffer()
    const b64 = btoa(String.fromCharCode(...new Uint8Array(buf)))
    return { base64: b64, mime: 'image/svg+xml' }
  }

  const img = await new Promise<HTMLImageElement>((resolve, reject) => {
    const i = new Image()
    i.onload = () => resolve(i)
    i.onerror = reject
    i.src = URL.createObjectURL(file)
  })

  const longer = Math.max(img.width, img.height)
  const scale = longer > MAX_DIMENSION ? MAX_DIMENSION / longer : 1
  const canvas = document.createElement('canvas')
  canvas.width = Math.round(img.width * scale)
  canvas.height = Math.round(img.height * scale)
  const ctx = canvas.getContext('2d')!
  ctx.drawImage(img, 0, 0, canvas.width, canvas.height)
  URL.revokeObjectURL(img.src)

  // JPEG이 파일 크기 효율 가장 좋음
  const dataUrl = canvas.toDataURL('image/jpeg', 0.85)
  return { base64: dataUrl, mime: 'image/jpeg' }
}

export default function ReceiptUploader({ onImport }: ReceiptUploaderProps) {
  const { buildPromptContext } = useStoreContext()
  const cameraRef = useRef<HTMLInputElement>(null)
  const fileRef = useRef<HTMLInputElement>(null)
  const [preview, setPreview] = useState<string | null>(null)
  const [processing, setProcessing] = useState(false)
  const [rows, setRows] = useState<ExtractedRow[]>([])
  const [warnings, setWarnings] = useState<string[]>([])
  const [receiptType, setReceiptType] = useState<string>('')
  const [rawText, setRawText] = useState('')
  const [editingIdx, setEditingIdx] = useState<number | null>(null)
  const [dragOver, setDragOver] = useState(false)

  const processImage = async (file: File) => {
    if (!file.type.startsWith('image/')) {
      toast.error('이미지 파일만 업로드 가능해요')
      return
    }
    if (file.size > 20 * 1024 * 1024) {
      toast.error('파일이 너무 커요 (20MB 이하)')
      return
    }

    setProcessing(true)
    setRows([])
    setWarnings([])
    setRawText('')

    try {
      // 클라이언트 리사이징
      const { base64, mime } = await optimizeImage(file)
      setPreview(base64)

      // 백엔드 OCR 호출
      const today = new Date().toISOString().split('T')[0]
      const res = await fetch('/api/v1/sales/ocr-receipt', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          image_base64: base64,
          mime_type: mime,
          store_context: buildPromptContext(),
          receipt_date_hint: today,
        }),
      })

      if (res.status === 429) {
        const d = await res.json().catch(() => ({}))
        throw new Error(d.detail ?? 'AI 호출 한도 초과 (1분 후 재시도)')
      }
      if (!res.ok) throw new Error(`서버 오류 ${res.status}`)

      const data = await res.json()
      setRows(data.rows ?? [])
      setWarnings(data.warnings ?? [])
      setReceiptType(data.receipt_type ?? 'unknown')
      setRawText(data.raw_text ?? '')

      if (data.rows?.length > 0) {
        toast.success(`${data.rows.length}개 항목 추출 완료 — 검토 후 저장하세요`)
        // Day 7-1: OCR 성공 이벤트 — 핵심 차별화 기능이라 측정 중요
        track('sales_upload_ocr', {
          row_count: data.rows.length,
          receipt_type: data.receipt_type,
          warnings: data.warnings?.length ?? 0,
        })
      } else {
        toast.error('추출된 항목이 없어요')
        track('sales_upload_ocr', { row_count: 0, failed: true })
      }
    } catch (e) {
      const msg = e instanceof Error ? e.message : 'OCR 실패'
      toast.error(msg)
    } finally {
      setProcessing(false)
    }
  }

  const handleFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) void processImage(file)
  }

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault()
    setDragOver(false)
    const file = e.dataTransfer.files?.[0]
    if (file) void processImage(file)
  }

  const updateRow = (idx: number, patch: Partial<ExtractedRow>) => {
    setRows(rows.map((r, i) => i === idx ? { ...r, ...patch } : r))
  }

  const deleteRow = (idx: number) => {
    setRows(rows.filter((_, i) => i !== idx))
  }

  const handleImport = () => {
    if (rows.length === 0) return
    const records: SalesRecord[] = rows.map((r, i) => ({
      id: `ocr-${Date.now()}-${i}`,
      sale_date: r.sale_date,
      menu_name: r.menu_name,
      quantity: r.quantity,
      revenue: r.revenue,
      cost: r.cost,
      hour_slot: r.hour_slot,
      discount: r.discount,
      day_of_week: new Date(r.sale_date).getDay(),
    }))
    onImport(records)
    toast.success(`${rows.length}건 저장됐어요!`)
    // 초기화
    setPreview(null)
    setRows([])
    setWarnings([])
    setRawText('')
    if (cameraRef.current) cameraRef.current.value = ''
    if (fileRef.current) fileRef.current.value = ''
  }

  const total = rows.reduce((s, r) => s + r.revenue, 0)

  return (
    <div className="bg-white dark:bg-gray-800 rounded-2xl p-5 border border-gray-100 dark:border-gray-700 shadow-sm">
      <div className="flex items-center gap-2 mb-1">
        <ScanLine size={18} className="text-[#D4A574]" />
        <h3 className="font-bold text-[#2C1810] dark:text-gray-100">📸 사진으로 매출 입력 (AI OCR)</h3>
        <span className="text-[10px] bg-amber-100 text-amber-700 px-2 py-0.5 rounded-full font-bold">NEW</span>
      </div>
      <p className="text-xs text-gray-500 dark:text-gray-400 mb-4 leading-relaxed">
        영수증·POS 전표·마감 보고서를 카메라로 찍거나 올리면 AI가 자동으로 매출 데이터를 추출합니다.
        CSV를 모르셔도 괜찮아요.
      </p>

      {/* 업로드 영역 */}
      {!preview && (
        <div
          onDragOver={(e) => { e.preventDefault(); setDragOver(true) }}
          onDragLeave={() => setDragOver(false)}
          onDrop={handleDrop}
          className={cn(
            'border-2 border-dashed rounded-2xl p-6 transition-colors duration-200',
            dragOver
              ? 'border-[#D4A574] bg-[#D4A574]/10'
              : 'border-[#D4A574]/40 hover:border-[#D4A574] hover:bg-[#D4A574]/5'
          )}
        >
          <ImageIcon className="w-8 h-8 text-[#D4A574] mx-auto mb-3" />
          <div className="grid grid-cols-2 gap-2">
            <button
              onClick={() => cameraRef.current?.click()}
              className="flex flex-col items-center gap-1 py-3 bg-[#2C1810] text-white rounded-xl text-xs font-semibold hover:bg-[#3d2418] transition-colors"
            >
              <Camera size={18} />
              <span>카메라 촬영</span>
              <span className="text-[9px] text-white/60">(모바일)</span>
            </button>
            <button
              onClick={() => fileRef.current?.click()}
              className="flex flex-col items-center gap-1 py-3 bg-[#D4A574] text-[#2C1810] rounded-xl text-xs font-semibold hover:bg-[#c4956a] transition-colors"
            >
              <Upload size={18} />
              <span>사진 선택</span>
              <span className="text-[9px] opacity-70">(갤러리/파일)</span>
            </button>
          </div>
          <p className="text-[10px] text-gray-400 text-center mt-3">
            또는 사진을 여기로 드래그하세요 · JPG · PNG · WEBP · 최대 20MB
          </p>
          <input
            ref={cameraRef}
            type="file"
            accept="image/*"
            capture="environment"
            className="hidden"
            onChange={handleFile}
          />
          <input
            ref={fileRef}
            type="file"
            accept="image/*"
            className="hidden"
            onChange={handleFile}
          />
        </div>
      )}

      {/* 처리 중 */}
      {processing && (
        <div className="flex flex-col items-center justify-center py-10 gap-3">
          <div className="relative">
            <Loader2 className="w-10 h-10 animate-spin text-[#D4A574]" />
            <Sparkles size={16} className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 text-[#2C1810]" />
          </div>
          <p className="text-sm text-gray-600 dark:text-gray-300 font-medium">AI가 영수증을 읽고 있어요...</p>
          <p className="text-xs text-gray-400">보통 3-8초 걸립니다</p>
        </div>
      )}

      {/* 프리뷰 + 결과 */}
      {preview && !processing && (
        <div className="space-y-4">
          {/* 이미지 + 요약 */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            <div className="relative bg-[#FAFAF8] dark:bg-gray-900 rounded-xl overflow-hidden border border-gray-100 dark:border-gray-700">
              <img src={preview} alt="영수증" className="w-full h-48 object-contain" />
              <button
                onClick={() => { setPreview(null); setRows([]); setWarnings([]) }}
                className="absolute top-2 right-2 bg-black/60 text-white p-1.5 rounded-full hover:bg-black/80"
                aria-label="다시 업로드"
              >
                <X size={14} />
              </button>
            </div>

            <div className="bg-[#FAFAF8] dark:bg-gray-900 rounded-xl p-4 space-y-2 text-sm">
              <div className="flex items-center gap-2">
                <Check size={14} className="text-green-600" />
                <span className="font-semibold text-[#2C1810] dark:text-gray-100">{rows.length}개 항목</span>
                <span className="text-xs text-gray-400">({receiptTypeLabel(receiptType)})</span>
              </div>
              <div>
                <span className="text-xs text-gray-400">예상 합계</span>
                <p className="text-lg font-bold text-[#D4A574]">{formatCurrency(total)}</p>
              </div>
              {warnings.length > 0 && (
                <div className="flex items-start gap-1.5 text-xs text-amber-700 bg-amber-50 rounded-lg p-2">
                  <AlertCircle size={12} className="mt-0.5 shrink-0" />
                  <ul className="space-y-0.5">
                    {warnings.map((w, i) => <li key={i}>{w}</li>)}
                  </ul>
                </div>
              )}
            </div>
          </div>

          {/* 추출 항목 테이블 */}
          {rows.length > 0 && (
            <div className="rounded-xl border border-gray-100 dark:border-gray-700 overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full text-xs">
                  <thead className="bg-gray-50 dark:bg-gray-900">
                    <tr>
                      <th className="px-2 py-2 text-left text-gray-500 font-medium w-20">날짜</th>
                      <th className="px-2 py-2 text-left text-gray-500 font-medium">메뉴</th>
                      <th className="px-2 py-2 text-right text-gray-500 font-medium w-12">수량</th>
                      <th className="px-2 py-2 text-right text-gray-500 font-medium w-20">금액</th>
                      <th className="px-2 py-2 text-center text-gray-500 font-medium w-14">시간</th>
                      <th className="px-2 py-2 text-center text-gray-500 font-medium w-14">신뢰도</th>
                      <th className="px-2 py-2 w-8"></th>
                    </tr>
                  </thead>
                  <tbody>
                    {rows.map((r, i) => (
                      <RowEditor
                        key={i}
                        row={r}
                        editing={editingIdx === i}
                        onEdit={() => setEditingIdx(editingIdx === i ? null : i)}
                        onUpdate={(patch) => updateRow(i, patch)}
                        onDelete={() => deleteRow(i)}
                      />
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* 액션 */}
          <div className="flex gap-2">
            <button
              onClick={() => { setPreview(null); setRows([]); setWarnings([]) }}
              className="flex-1 py-2.5 border border-gray-200 dark:border-gray-600 rounded-xl text-sm text-gray-600 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700"
            >
              다시 촬영
            </button>
            <button
              onClick={handleImport}
              disabled={rows.length === 0}
              className="flex-[2] py-2.5 bg-gradient-to-r from-[#2C1810] to-[#D4A574] text-white rounded-xl text-sm font-semibold hover:opacity-90 disabled:opacity-40 flex items-center justify-center gap-2"
            >
              <Check size={14} />
              {rows.length}건 매출 저장
            </button>
          </div>

          {/* AI 원문 (디버깅용) */}
          {rawText && (
            <details className="text-xs">
              <summary className="cursor-pointer text-gray-400 hover:text-gray-600">
                AI가 읽은 원문 보기
              </summary>
              <pre className="mt-2 p-3 bg-gray-50 dark:bg-gray-900 rounded-lg whitespace-pre-wrap max-h-40 overflow-y-auto text-gray-600 dark:text-gray-300">
                {rawText}
              </pre>
            </details>
          )}
        </div>
      )}
    </div>
  )
}

// ─── 개별 행 편집기 ───
function RowEditor({
  row,
  editing,
  onEdit,
  onUpdate,
  onDelete,
}: {
  row: ExtractedRow
  editing: boolean
  onEdit: () => void
  onUpdate: (patch: Partial<ExtractedRow>) => void
  onDelete: () => void
}) {
  const conf = row.confidence
  const confColor = conf >= 0.8 ? 'text-green-600' : conf >= 0.5 ? 'text-amber-600' : 'text-red-500'
  const confLabel = conf >= 0.8 ? '높음' : conf >= 0.5 ? '보통' : '낮음'

  if (!editing) {
    return (
      <tr className="border-t border-gray-100 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-900">
        <td className="px-2 py-2 text-gray-600 dark:text-gray-300">{row.sale_date.slice(5)}</td>
        <td className="px-2 py-2 font-medium text-[#2C1810] dark:text-gray-100">{row.menu_name}</td>
        <td className="px-2 py-2 text-right">×{row.quantity}</td>
        <td className="px-2 py-2 text-right font-semibold">{formatCurrency(row.revenue)}</td>
        <td className="px-2 py-2 text-center text-gray-500">{row.hour_slot}시</td>
        <td className={`px-2 py-2 text-center text-[10px] font-bold ${confColor}`}>{confLabel}</td>
        <td className="px-2 py-2">
          <div className="flex gap-0.5">
            <button onClick={onEdit} className="p-1 text-gray-400 hover:text-[#2C1810] dark:hover:text-gray-200"
              aria-label="편집">
              <Edit3 size={11} />
            </button>
            <button onClick={onDelete} className="p-1 text-red-400 hover:bg-red-50 rounded"
              aria-label="삭제">
              <Trash2 size={11} />
            </button>
          </div>
        </td>
      </tr>
    )
  }

  return (
    <tr className="border-t-2 border-[#D4A574] bg-[#D4A574]/5">
      <td className="px-2 py-2">
        <input type="date" value={row.sale_date}
          onChange={(e) => onUpdate({ sale_date: e.target.value })}
          className="w-full px-1 py-0.5 rounded border border-gray-200 text-[11px] bg-white dark:bg-gray-700" />
      </td>
      <td className="px-2 py-2">
        <input value={row.menu_name}
          onChange={(e) => onUpdate({ menu_name: e.target.value })}
          className="w-full px-1 py-0.5 rounded border border-gray-200 text-[11px] bg-white dark:bg-gray-700" />
      </td>
      <td className="px-2 py-2">
        <input type="number" value={row.quantity} min={1}
          onChange={(e) => onUpdate({ quantity: Number(e.target.value) || 1 })}
          className="w-full px-1 py-0.5 rounded border border-gray-200 text-[11px] text-right bg-white dark:bg-gray-700" />
      </td>
      <td className="px-2 py-2">
        <input type="number" value={row.revenue} min={0}
          onChange={(e) => onUpdate({ revenue: Number(e.target.value) || 0 })}
          className="w-full px-1 py-0.5 rounded border border-gray-200 text-[11px] text-right bg-white dark:bg-gray-700" />
      </td>
      <td className="px-2 py-2">
        <input type="number" value={row.hour_slot} min={0} max={23}
          onChange={(e) => onUpdate({ hour_slot: Math.max(0, Math.min(23, Number(e.target.value) || 0)) })}
          className="w-full px-1 py-0.5 rounded border border-gray-200 text-[11px] text-center bg-white dark:bg-gray-700" />
      </td>
      <td className={`px-2 py-2 text-center text-[10px] font-bold ${confColor}`}>{confLabel}</td>
      <td className="px-2 py-2">
        <button onClick={onEdit} className="p-1 text-green-600 hover:bg-green-50 rounded"
          aria-label="완료">
          <Check size={12} />
        </button>
      </td>
    </tr>
  )
}

function receiptTypeLabel(type: string): string {
  const map: Record<string, string> = {
    pos_receipt: 'POS 영수증',
    daily_summary: '일일 마감',
    handwritten: '손글씨 장부',
    unknown: '유형 미확인',
  }
  return map[type] ?? type
}
