"""
Google Trends (pytrends) — 한국 vs 글로벌 비교.

핵심 가치: "해외에서 떠오르는데 한국엔 아직 없는" 키워드 발견 → 선점 기회.

키 X. pytrends 라이브러리만 있으면 동작 (rate limit 주의).
"""
import asyncio
from typing import Optional


async def fetch_compare_korea_vs_global(
    keywords: list[str],
    timeframe: str = "now 7-d",
) -> Optional[dict]:
    """
    같은 키워드 셋에 대해 한국(geo='KR')과 글로벌(geo='') 트렌드 동시 조회.

    Args:
        keywords: 비교할 키워드 (최대 5개 — pytrends 제한)
        timeframe: pytrends 형식 (예: 'now 7-d', 'today 1-m', 'today 3-m')

    Returns:
        {
          "korea":  [{"date", "키워드1": int, ...}, ...],
          "global": [{"date", "키워드1": int, ...}, ...],
          "comparison": [
            {"keyword", "global_score", "korea_score", "gap", "label"}
          ]
        }
        또는 None.

    label:
      - "선점기회"   글로벌 high (>=50) + 한국 low (<=20)
      - "성장중"     글로벌 high + 한국 mid (20-50)
      - "정착"       양쪽 high
      - "끝물"       양쪽 low + 둘 다 하락 트렌드
      - "한국선도"   한국 high + 글로벌 low (한국발 트렌드)
    """
    if not keywords:
        return None

    def _sync_fetch():
        try:
            from pytrends.request import TrendReq
        except ImportError:
            return None

        result = {"korea": [], "global": [], "comparison": []}

        try:
            kw_top5 = keywords[:5]

            # 글로벌
            pt_g = TrendReq(hl="en-US", tz=0, retries=2, backoff_factor=0.5)
            pt_g.build_payload(kw_top5, timeframe=timeframe, geo="")
            df_g = pt_g.interest_over_time()

            # 한국
            pt_kr = TrendReq(hl="ko", tz=540, retries=2, backoff_factor=0.5)
            pt_kr.build_payload(kw_top5, timeframe=timeframe, geo="KR")
            df_kr = pt_kr.interest_over_time()

            def _df_to_records(df) -> list[dict]:
                if df is None or df.empty:
                    return []
                df = df.drop(columns=["isPartial"], errors="ignore").reset_index()
                return [
                    {**{"date": str(row["date"])[:10]},
                     **{k: int(row[k]) for k in df.columns if k != "date"}}
                    for _, row in df.iterrows()
                ]

            result["global"] = _df_to_records(df_g)
            result["korea"] = _df_to_records(df_kr)

            # 비교 분석
            for kw in kw_top5:
                global_avg = (
                    sum(r.get(kw, 0) for r in result["global"]) / len(result["global"])
                    if result["global"] else 0
                )
                korea_avg = (
                    sum(r.get(kw, 0) for r in result["korea"]) / len(result["korea"])
                    if result["korea"] else 0
                )

                gap = global_avg - korea_avg

                if global_avg >= 50 and korea_avg <= 20:
                    label = "선점기회"  # 해외 뜨는데 한국 미진입
                elif global_avg >= 50 and 20 < korea_avg < 50:
                    label = "성장중"
                elif global_avg >= 40 and korea_avg >= 40:
                    label = "정착"
                elif korea_avg >= 50 and global_avg <= 20:
                    label = "한국선도"
                elif global_avg <= 15 and korea_avg <= 15:
                    label = "끝물"
                else:
                    label = "보통"

                result["comparison"].append({
                    "keyword": kw,
                    "global_score": round(global_avg, 1),
                    "korea_score": round(korea_avg, 1),
                    "gap": round(gap, 1),
                    "label": label,
                })

            # 선점기회 우선 정렬
            label_priority = {"선점기회": 0, "성장중": 1, "한국선도": 2, "정착": 3, "보통": 4, "끝물": 5}
            result["comparison"].sort(
                key=lambda x: (label_priority.get(x["label"], 9), -x["global_score"])
            )

            return result
        except Exception:
            return None

    return await asyncio.to_thread(_sync_fetch)
