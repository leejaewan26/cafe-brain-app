"""
에이전트 메모리·피드백 API (Issue #10 Foundation)

엔드포인트:
- POST /api/agent/feedback: AI 제안에 대한 사용자 반응 기록
- POST /api/agent/memory: 수동 메모리 추가 (디버깅용)
- GET  /api/agent/memory: 메모리 조회 (투명성 — "AI가 뭘 알고 있나?")
- DELETE /api/agent/memory/{id}: 메모리 삭제 (망각권)
"""
from fastapi import APIRouter, HTTPException, Header, Request
from pydantic import BaseModel, Field
from typing import Any, Literal, Optional

from app.services import memory_service
from app.services.memory_service import (
    FeedbackReaction,
    MemoryCategory,
)
from app.services.gemini_service import get_token_stats, get_cache_stats
from app.services import audit_service, slo_service, anomaly_evaluator

router = APIRouter()


def _client_ctx(request) -> dict[str, str]:
    """request에서 ip/ua 추출 (audit log용)."""
    ip = request.client.host if request.client else ""
    ua = request.headers.get("user-agent", "")[:200]
    return {"ip": ip, "user_agent": ua}


# ═══════════════════════════════════════════════════════
# 스키마
# ═══════════════════════════════════════════════════════


class FeedbackRequest(BaseModel):
    """AI 제안 피드백 기록 요청"""

    store_id: str = Field(..., description="매장 UUID")
    source_type: str = Field(..., description="피드백 대상 유형")
    source_ref: str = Field(..., description="피드백 대상 식별자")
    reaction: Literal["helpful", "irrelevant", "applied", "muted"]
    note: Optional[str] = None


class FeedbackResponse(BaseModel):
    feedback_id: Optional[str]
    learning_signal: str


class MemoryItem(BaseModel):
    """메모리 조회 결과 아이템"""

    id: str
    category: str
    content: str
    importance: int
    confidence: float
    created_at: str


class MemoryListResponse(BaseModel):
    memories: list[MemoryItem]
    total: int


class CreateMemoryRequest(BaseModel):
    store_id: str
    category: Literal[
        "business_pattern",
        "customer_insight",
        "decision_history",
        "preference",
        "event",
        "goal",
        "accepted_suggestion",
        "rejected_suggestion",
    ]
    content: str = Field(..., max_length=990)
    importance: int = Field(default=5, ge=1, le=10)
    confidence: float = Field(default=0.7, ge=0, le=1)
    source_type: Optional[str] = None


# ═══════════════════════════════════════════════════════
# 피드백 기록 (가장 많이 쓰일 엔드포인트)
# ═══════════════════════════════════════════════════════


@router.post("/feedback", response_model=FeedbackResponse)
async def submit_feedback(req: FeedbackRequest):
    """
    AI 제안에 대한 사용자 반응 기록.
    학습 루프의 핵심 신호 — 어떤 제안이 효과적이었는지 축적.
    """
    feedback_id = await memory_service.record_feedback(
        store_id=req.store_id,
        source_type=req.source_type,
        source_ref=req.source_ref,
        reaction=req.reaction,
        note=req.note,
    )

    # 학습 신호 설명 (UI에 표시 가능)
    signal_map = {
        "helpful": "이런 유형 제안을 앞으로 더 자주 드릴게요 👍",
        "applied": "실제 적용 확인! 효과를 추적해서 학습에 반영합니다 ✨",
        "irrelevant": "이런 제안은 덜 보여드릴게요",
        "muted": "이 유형 제안은 앞으로 드리지 않겠습니다 🔇",
    }

    return FeedbackResponse(
        feedback_id=feedback_id,
        learning_signal=signal_map.get(req.reaction, ""),
    )


# ═══════════════════════════════════════════════════════
# 메모리 조회 (투명성 — "AI가 뭘 알고 있나?")
# ═══════════════════════════════════════════════════════


@router.get("/memory", response_model=MemoryListResponse)
async def list_memories(
    store_id: str,
    category: Optional[str] = None,
    limit: int = 20,
):
    """
    매장의 학습된 메모리 조회.
    사용자가 자기 매장에 대해 AI가 무엇을 알고 있는지 볼 수 있어야 함 (투명성).
    """
    categories = [category] if category else None  # type: ignore[list-item]
    memories = await memory_service.search_memories(
        store_id=store_id, categories=categories, limit=limit
    )
    return MemoryListResponse(
        memories=[MemoryItem(**m) for m in memories],
        total=len(memories),
    )


# ═══════════════════════════════════════════════════════
# 메모리 수동 추가 (테스트·디버깅)
# ═══════════════════════════════════════════════════════


@router.post("/memory", response_model=dict)
async def create_memory(req: CreateMemoryRequest):
    """수동으로 메모리 추가 (주로 디버깅·테스트용)."""
    memory_id = await memory_service.insert_memory(
        store_id=req.store_id,
        category=req.category,  # type: ignore[arg-type]
        content=req.content,
        importance=req.importance,
        confidence=req.confidence,
        source_type=req.source_type or "manual",
    )
    if memory_id is None:
        raise HTTPException(status_code=503, detail="메모리 저장 실패")
    return {"memory_id": memory_id}


# ═══════════════════════════════════════════════════════
# 메모리 삭제 (망각권)
# ═══════════════════════════════════════════════════════


@router.get("/usage")
async def get_agent_usage():
    """
    Phase 6: AI 사용량 + 비용 추정 (인메모리, 프로세스 수명).

    제공:
      - 캐시 히트율·절감액 추정
      - 모듈별 토큰 사용량 + 추정 비용 (KRW)
    """
    return {
        "cache": get_cache_stats(),
        "tokens": get_token_stats(),
    }


# ═══════════════════════════════════════════════════════
# Phase 6 #6: Multi-step Plan — 복잡 질문 분해 + 단계별 분석 + 통합
# ═══════════════════════════════════════════════════════


class PlanRequest(BaseModel):
    """복잡한 질문을 multi-step으로 분해해서 답변"""
    store_id: str = Field(..., description="매장 UUID")
    goal: str = Field(..., min_length=5, max_length=500, description="사용자 목표 (예: '다음 분기 전략')")
    store_context: str = Field(..., description="매장 기본 정보")


class PlanStep(BaseModel):
    step: int
    title: str
    analysis: str


class PlanResponse(BaseModel):
    plan: list[PlanStep]
    final_recommendation: str
    sources: list[str]  # 어느 도구/데이터 소스 활용


@router.post("/plan", response_model=PlanResponse)
async def agent_plan(req: PlanRequest):
    """
    복잡한 목표를 4-5단계로 분해해서 각 단계 분석 + 통합 권고안 작성.

    예: "다음 분기 전략 짜줘"
      → Step 1: 매출 트렌드 분석
      → Step 2: 카페 시장 트렌드 (메모리 검색)
      → Step 3: 인력 비용 검토
      → Step 4: 메뉴 라인업 점검
      → 통합: 전략 보고서

    내부적으로 Gemini가 "단계별로 분석 + 마지막에 통합" 형식 강제로
    multi-step 효과 (실제 도구 호출은 V2에서, 지금은 단일 LLM 추론).
    """
    from app.services.gemini_service import generate_insight, build_cache_key
    from app.services import memory_service
    from datetime import date

    # 매장 메모리 컨텍스트
    memories = await memory_service.search_memories(req.store_id, limit=5)
    mem_text = "\n".join(
        f"  - [{m['category']}] {m['content']}" for m in memories
    ) if memories else "  - (학습된 메모리 없음)"

    prompt = f"""
당신은 한국 카페 경영 전략 컨설턴트입니다.
사장님의 다음 목표에 대해 **multi-step 분석 보고서**를 작성하세요.

[목표]
{req.goal}

[매장 컨텍스트]
{req.store_context}

[학습된 매장 메모리 Top 5]
{mem_text}

[작성 형식 — 정확히 이 JSON 구조 출력 (코드블록 X)]
{{
  "plan": [
    {{"step": 1, "title": "단계 제목", "analysis": "이 단계에서 무엇을 검토했고 어떤 결론"}},
    {{"step": 2, "title": "...", "analysis": "..."}},
    {{"step": 3, "title": "...", "analysis": "..."}},
    {{"step": 4, "title": "...", "analysis": "..."}}
  ],
  "final_recommendation": "통합 전략 권고 5~8문장. 구체적 수치·실행 방안 포함",
  "sources": ["sales", "memory", "trend", "ambiance"]
}}

규칙:
- 4~5단계로 분해 (매출, 트렌드, 인력, 메뉴, 마케팅 등 매장 컨텍스트 활용)
- 각 step.analysis는 3~5문장
- 일반론 금지 — 매장 컨텍스트와 메모리에 기반한 구체적 분석
- 한국어 출력
""".strip()

    cache_key = build_cache_key(
        store_id=req.store_id,
        template="agent_plan",
        params={"goal": req.goal[:200], "date": date.today().isoformat()},
    )

    try:
        raw = await generate_insight(prompt, cache_key=cache_key)
        raw = raw.replace("\n\nⓘ AI가 생성한 콘텐츠입니다.", "").strip()
        if "```" in raw:
            import re
            match = re.search(r"\{[\s\S]*\}", raw)
            if match:
                raw = match.group()
        import json as _json
        data = _json.loads(raw)
        return PlanResponse(
            plan=[PlanStep(**s) for s in data.get("plan", [])],
            final_recommendation=data.get("final_recommendation", ""),
            sources=data.get("sources", []),
        )
    except Exception as e:
        raise HTTPException(status_code=503, detail=f"Plan 생성 실패: {str(e)[:120]}")


# ═══════════════════════════════════════════════════════
# Phase 6 #9: A/B 비교 — 두 옵션 데이터 기반 추천
# ═══════════════════════════════════════════════════════


class CompareRequest(BaseModel):
    """A/B 두 옵션 비교 요청"""
    store_id: str = Field(..., description="매장 UUID")
    question: str = Field(..., description="비교 질문 (예: '50% 할인 vs 1+1 어느 게 효과?')")
    option_a: str = Field(..., description="옵션 A 설명")
    option_b: str = Field(..., description="옵션 B 설명")
    store_context: str = ""


class CompareScore(BaseModel):
    option: str  # "A" or "B"
    score: int   # 0-100
    pros: list[str]
    cons: list[str]


class CompareResponse(BaseModel):
    scores: list[CompareScore]
    winner: str       # "A" | "B" | "draw"
    reasoning: str    # 추천 이유


@router.post("/compare", response_model=CompareResponse)
async def agent_compare(req: CompareRequest):
    """
    두 옵션을 매장 데이터·메모리·일반 카페 패턴 기반으로 비교 → 추천.
    """
    from app.services.gemini_service import generate_insight, build_cache_key
    from app.services import memory_service
    from datetime import date

    memories = await memory_service.search_memories(req.store_id, limit=5)
    mem_text = "\n".join(
        f"  - {m['content']}" for m in memories
    ) if memories else "  - (학습된 메모리 없음)"

    prompt = f"""
당신은 한국 카페 마케팅·운영 전문가입니다.
사장님의 A/B 비교 질문에 데이터 기반으로 답하세요.

[질문]
{req.question}

[옵션 A] {req.option_a}
[옵션 B] {req.option_b}

[매장 컨텍스트]
{req.store_context}

[학습된 매장 메모리]
{mem_text}

[출력 — JSON만 (코드블록 X)]
{{
  "scores": [
    {{"option": "A", "score": 0-100, "pros": ["...", "..."], "cons": ["...", "..."]}},
    {{"option": "B", "score": 0-100, "pros": ["..."], "cons": ["..."]}}
  ],
  "winner": "A" | "B" | "draw",
  "reasoning": "데이터 기반 추천 이유 4~6문장. 매장 컨텍스트 직접 인용"
}}

규칙:
- 일반론 금지 — 이 매장에 특화한 분석
- pros/cons 각 2~3개
- score는 종합 추천도 (호환성·기대 효과·리스크 종합)
- 한국어
""".strip()

    cache_key = build_cache_key(
        store_id=req.store_id,
        template="agent_compare",
        params={
            "q": req.question[:100],
            "a": req.option_a[:50],
            "b": req.option_b[:50],
            "date": date.today().isoformat(),
        },
    )

    try:
        raw = await generate_insight(prompt, cache_key=cache_key)
        raw = raw.replace("\n\nⓘ AI가 생성한 콘텐츠입니다.", "").strip()
        if "```" in raw:
            import re
            match = re.search(r"\{[\s\S]*\}", raw)
            if match:
                raw = match.group()
        import json as _json
        data = _json.loads(raw)
        return CompareResponse(
            scores=[CompareScore(**s) for s in data.get("scores", [])],
            winner=data.get("winner", "draw"),
            reasoning=data.get("reasoning", ""),
        )
    except Exception as e:
        raise HTTPException(status_code=503, detail=f"Compare 생성 실패: {str(e)[:120]}")


@router.delete("/memory/{memory_id}")
async def archive_memory(
    memory_id: str,
    request: Request,
    store_id: str = Header(..., alias="X-Store-Id"),
):
    """
    메모리를 archived_at=now로 설정 (soft delete).
    사용자 GDPR 망각권 대응. 감사 로그 자동 기록.
    """
    import asyncio
    from datetime import datetime, timezone
    from app.services.gemini_service import _get_supabase

    sb = _get_supabase()
    if sb is None:
        raise HTTPException(status_code=503, detail="Supabase 미설정")

    try:
        # 삭제 전 본문 확보 (audit before)
        before = await asyncio.to_thread(
            lambda: sb.table("agent_memory")
            .select("category, content, importance")
            .eq("id", memory_id)
            .eq("store_id", store_id)
            .limit(1)
            .execute()
        )
        before_data = before.data[0] if before.data else None

        result = await asyncio.to_thread(
            lambda: sb.table("agent_memory")
            .update({"archived_at": datetime.now(timezone.utc).isoformat()})
            .eq("id", memory_id)
            .eq("store_id", store_id)
            .execute()
        )
        if not result.data:
            raise HTTPException(status_code=404, detail="메모리 없음 또는 권한 없음")

        # Phase 6 #11: 감사 로그 (fire-and-forget)
        ctx = _client_ctx(request)
        asyncio.create_task(audit_service.log_action(
            store_id=store_id,
            action="memory_delete",
            target_type="memory",
            target_id=memory_id,
            before=before_data,
            ip=ctx["ip"],
            user_agent=ctx["user_agent"],
        ))

        return {"archived": True}
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


# ═══════════════════════════════════════════════════════
# Phase 6 #11: 감사 로그 조회
# ═══════════════════════════════════════════════════════


class AuditLogItem(BaseModel):
    id: str
    action: str
    actor_role: Optional[str] = None
    target_type: Optional[str] = None
    target_id: Optional[str] = None
    before: Optional[dict] = None
    after: Optional[dict] = None
    created_at: str


@router.get("/audit", response_model=list[AuditLogItem])
async def list_audit(
    store_id: str,
    action: Optional[str] = None,
    limit: int = 50,
):
    """매장 감사 로그 조회 — 누가 언제 무엇을 했는가."""
    rows = await audit_service.list_audit_logs(store_id, action=action, limit=limit)
    return [AuditLogItem(**r) for r in rows]


# ═══════════════════════════════════════════════════════
# Phase 6 #13: SLO 응답시간 통계
# ═══════════════════════════════════════════════════════


class SLOStat(BaseModel):
    endpoint: str
    total_calls: int
    cache_hit_rate: float
    p50_ms: float
    p95_ms: float
    p99_ms: float
    total_cost_krw: float


@router.get("/slo", response_model=list[SLOStat])
async def get_slo(
    store_id: Optional[str] = None,
    endpoint: Optional[str] = None,
    window_days: int = 7,
):
    """엔드포인트별 응답시간 백분위 + 캐시 적중률 + 비용."""
    rows = await slo_service.compute_percentiles(
        store_id=store_id, endpoint=endpoint, window_days=window_days,
    )
    return [
        SLOStat(
            endpoint=r["endpoint"],
            total_calls=int(r["total_calls"]),
            cache_hit_rate=float(r.get("cache_hit_rate") or 0),
            p50_ms=float(r["p50_ms"]),
            p95_ms=float(r["p95_ms"]),
            p99_ms=float(r["p99_ms"]),
            total_cost_krw=float(r.get("total_cost_krw") or 0),
        )
        for r in rows
    ]


# ═══════════════════════════════════════════════════════
# Phase 6 #14: 사용자 정의 이상치 룰 CRUD + 평가
# ═══════════════════════════════════════════════════════


class AnomalyRuleIn(BaseModel):
    name: str = Field(..., min_length=1, max_length=100)
    metric: Literal["sales", "orders", "review_score", "menu_sales"]
    metric_param: Optional[str] = None
    comparator: Literal["pct_change", "abs_lt", "abs_gt"] = "pct_change"
    threshold: float
    window_type: Literal["today_vs_week_avg", "week_vs_prev_week", "today_abs"] = "today_vs_week_avg"
    enabled: bool = True
    channel: Literal["briefing", "push", "both"] = "briefing"
    cooldown_h: int = 24


class AnomalyRuleOut(AnomalyRuleIn):
    id: str
    last_fired_at: Optional[str] = None
    created_at: str


@router.get("/rules", response_model=list[AnomalyRuleOut])
async def list_rules_endpoint(store_id: str, enabled_only: bool = False):
    rows = await anomaly_evaluator.list_rules(store_id, enabled_only=enabled_only)
    out: list[AnomalyRuleOut] = []
    for r in rows:
        try:
            out.append(AnomalyRuleOut(
                id=r["id"],
                name=r["name"],
                metric=r["metric"],
                metric_param=r.get("metric_param"),
                comparator=r["comparator"],
                threshold=float(r["threshold"]),
                window_type=r["window_type"],
                enabled=bool(r["enabled"]),
                channel=r["channel"],
                cooldown_h=int(r["cooldown_h"]),
                last_fired_at=r.get("last_fired_at"),
                created_at=r["created_at"],
            ))
        except Exception:
            continue
    return out


@router.post("/rules")
async def create_rule(
    request: Request,
    rule: AnomalyRuleIn,
    store_id: str = Header(..., alias="X-Store-Id"),
):
    rule_id = await anomaly_evaluator.upsert_rule(
        store_id=store_id,
        name=rule.name,
        metric=rule.metric,
        threshold=rule.threshold,
        comparator=rule.comparator,
        window_type=rule.window_type,
        metric_param=rule.metric_param,
        enabled=rule.enabled,
        channel=rule.channel,
        cooldown_h=rule.cooldown_h,
    )
    if rule_id is None:
        raise HTTPException(status_code=503, detail="룰 저장 실패")

    ctx = _client_ctx(request)
    import asyncio as _a
    _a.create_task(audit_service.log_action(
        store_id=store_id,
        action="anomaly_rule_create",
        target_type="rule",
        target_id=rule_id,
        after=rule.model_dump(),
        ip=ctx["ip"],
        user_agent=ctx["user_agent"],
    ))
    return {"id": rule_id}


@router.put("/rules/{rule_id}")
async def update_rule(
    rule_id: str,
    request: Request,
    rule: AnomalyRuleIn,
    store_id: str = Header(..., alias="X-Store-Id"),
):
    updated_id = await anomaly_evaluator.upsert_rule(
        store_id=store_id,
        rule_id=rule_id,
        name=rule.name,
        metric=rule.metric,
        threshold=rule.threshold,
        comparator=rule.comparator,
        window_type=rule.window_type,
        metric_param=rule.metric_param,
        enabled=rule.enabled,
        channel=rule.channel,
        cooldown_h=rule.cooldown_h,
    )
    if updated_id is None:
        raise HTTPException(status_code=404, detail="룰 없음 또는 권한 없음")

    ctx = _client_ctx(request)
    import asyncio as _a
    _a.create_task(audit_service.log_action(
        store_id=store_id,
        action="anomaly_rule_update",
        target_type="rule",
        target_id=rule_id,
        after=rule.model_dump(),
        ip=ctx["ip"],
        user_agent=ctx["user_agent"],
    ))
    return {"id": updated_id}


@router.delete("/rules/{rule_id}")
async def delete_rule_endpoint(
    rule_id: str,
    request: Request,
    store_id: str = Header(..., alias="X-Store-Id"),
):
    ok = await anomaly_evaluator.delete_rule(store_id, rule_id)
    if not ok:
        raise HTTPException(status_code=404, detail="룰 없음 또는 권한 없음")

    ctx = _client_ctx(request)
    import asyncio as _a
    _a.create_task(audit_service.log_action(
        store_id=store_id,
        action="anomaly_rule_delete",
        target_type="rule",
        target_id=rule_id,
        ip=ctx["ip"],
        user_agent=ctx["user_agent"],
    ))
    return {"deleted": True}


@router.post("/rules/evaluate")
async def evaluate_rules_now(store_id: str = Header(..., alias="X-Store-Id")):
    """수동 평가 — 모든 활성 룰 즉시 평가 후 트리거된 것 반환."""
    triggered = await anomaly_evaluator.evaluate_store_rules(store_id)
    return {"triggered": triggered, "count": len(triggered)}


# ═══════════════════════════════════════════════════════
# F4 — 의미적 메모리 검색 endpoint (UI 노출용)
# ═══════════════════════════════════════════════════════


class MemorySearchRequest(BaseModel):
    query: str = Field(..., min_length=1, max_length=200)
    limit: int = Field(default=10, ge=1, le=50)
    min_similarity: float = Field(default=0.5, ge=0, le=1)


@router.post("/memory/search")
async def semantic_memory_search(
    req: MemorySearchRequest,
    store_id: str = Header(..., alias="X-Store-Id"),
):
    """
    pgvector 기반 의미 검색. 임베딩 또는 pgvector 미설정 시 키워드 fallback.
    """
    results = await memory_service.search_memories_semantic(
        store_id=store_id,
        query=req.query,
        limit=req.limit,
        min_similarity=req.min_similarity,
    )
    if results:
        return {"memories": results, "method": "semantic"}

    # Fallback — 키워드 기반
    all_mems = await memory_service.search_memories(store_id, limit=50)
    keyword = req.query.lower()
    filtered = [
        m for m in all_mems
        if keyword in (m.get("content") or "").lower()
    ][: req.limit]
    return {"memories": filtered, "method": "keyword_fallback"}
