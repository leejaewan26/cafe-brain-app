-- ═══════════════════════════════════════════════════════════════
-- 019 — J 배치 차별화 기능
-- ═══════════════════════════════════════════════════════════════

-- ─── J2 — 로드맵 투표 ────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS roadmap_votes (
  feature_id  TEXT NOT NULL,
  store_id    UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  voted_at    TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  PRIMARY KEY (feature_id, store_id)
);
CREATE INDEX IF NOT EXISTS idx_roadmap_votes_feature ON roadmap_votes(feature_id);

ALTER TABLE roadmap_votes ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "roadmap_votes_owner" ON roadmap_votes;
CREATE POLICY "roadmap_votes_owner" ON roadmap_votes
  FOR ALL USING (auth.uid() = store_id);

-- ─── I5 — feature_flags ──────────────────────────────────────────
CREATE TABLE IF NOT EXISTS feature_flags (
  flag_key    TEXT PRIMARY KEY,
  enabled     BOOLEAN NOT NULL DEFAULT FALSE,
  description TEXT,
  updated_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS store_feature_flags (
  store_id   UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  flag_key   TEXT NOT NULL,
  enabled    BOOLEAN NOT NULL,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  PRIMARY KEY (store_id, flag_key)
);

ALTER TABLE store_feature_flags ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "store_flags_owner" ON store_feature_flags;
CREATE POLICY "store_flags_owner" ON store_feature_flags
  FOR ALL USING (auth.uid() = store_id);

-- ─── J6 — 분위수 RPC ─────────────────────────────────────────────
CREATE OR REPLACE FUNCTION revenue_per_day_quartiles(p_days INT)
RETURNS TABLE(
  p25 NUMERIC,
  p50 NUMERIC,
  p75 NUMERIC,
  sample_size BIGINT
)
LANGUAGE SQL
SECURITY DEFINER
AS $$
  WITH per_store AS (
    SELECT
      store_id,
      SUM(revenue)::NUMERIC / GREATEST(p_days, 1) AS avg_per_day
    FROM sales_records
    WHERE sale_date >= (CURRENT_DATE - p_days)
    GROUP BY store_id
    HAVING COUNT(*) >= 5  -- 최소 5건 매출 있는 매장만
  )
  SELECT
    PERCENTILE_CONT(0.25) WITHIN GROUP (ORDER BY avg_per_day) AS p25,
    PERCENTILE_CONT(0.50) WITHIN GROUP (ORDER BY avg_per_day) AS p50,
    PERCENTILE_CONT(0.75) WITHIN GROUP (ORDER BY avg_per_day) AS p75,
    COUNT(*)::BIGINT AS sample_size
  FROM per_store;
$$;

COMMENT ON FUNCTION revenue_per_day_quartiles IS 'J6 — 동종업계 익명 벤치마크 (k-anonymity: 표본 < 10이면 호출자가 차단)';

-- ─── 메뉴 테이블 컬럼 (퀴즈용) ───────────────────────────────────
ALTER TABLE menus
  ADD COLUMN IF NOT EXISTS recipe TEXT,
  ADD COLUMN IF NOT EXISTS allergens TEXT;
