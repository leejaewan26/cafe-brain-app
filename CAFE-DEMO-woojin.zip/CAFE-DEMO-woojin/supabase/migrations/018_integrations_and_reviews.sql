-- ═══════════════════════════════════════════════════════════════
-- 018 — H2/H3/H5 외부 연동 (Naver / POS / Social) + reviews 컬럼 보강
-- ═══════════════════════════════════════════════════════════════

-- ─── reviews 컬럼 보강 ──────────────────────────────────────────
ALTER TABLE reviews
  ADD COLUMN IF NOT EXISTS source TEXT DEFAULT 'manual'
    CHECK (source IN ('manual', 'naver_api', 'naver_url', 'kakao', 'google', 'baemin', 'yogiyo')),
  ADD COLUMN IF NOT EXISTS naver_review_id TEXT,
  ADD COLUMN IF NOT EXISTS source_url TEXT;

CREATE UNIQUE INDEX IF NOT EXISTS uq_reviews_naver_id
  ON reviews(store_id, naver_review_id)
  WHERE naver_review_id IS NOT NULL;

-- ─── stores 외부 매장 ID ────────────────────────────────────────
ALTER TABLE stores
  ADD COLUMN IF NOT EXISTS naver_place_id TEXT,
  ADD COLUMN IF NOT EXISTS naver_business_id TEXT,
  ADD COLUMN IF NOT EXISTS naver_place_name TEXT;

-- ─── pos_connections (H3) ──────────────────────────────────────
CREATE TABLE IF NOT EXISTS pos_connections (
  store_id        UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  vendor          TEXT NOT NULL CHECK (vendor IN ('toss_pos','kis','smart_bro','tablen','generic')),
  api_key         TEXT,
  api_secret      TEXT,
  business_no     TEXT,
  last_sync_at    TIMESTAMPTZ,
  is_active       BOOLEAN NOT NULL DEFAULT TRUE,
  connected_at    TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  PRIMARY KEY (store_id, vendor)
);

ALTER TABLE pos_connections ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "pos_owner_read" ON pos_connections;
CREATE POLICY "pos_owner_read" ON pos_connections
  FOR SELECT USING (auth.uid() = store_id);
DROP POLICY IF EXISTS "pos_service_write" ON pos_connections;
CREATE POLICY "pos_service_write" ON pos_connections
  FOR ALL USING (auth.role() = 'service_role');

-- ─── sales_records 멱등 컬럼 ────────────────────────────────────
ALTER TABLE sales_records
  ADD COLUMN IF NOT EXISTS source TEXT DEFAULT 'manual',
  ADD COLUMN IF NOT EXISTS idempotency_key TEXT;

CREATE UNIQUE INDEX IF NOT EXISTS uq_sales_idem
  ON sales_records(store_id, idempotency_key)
  WHERE idempotency_key IS NOT NULL;

-- ─── social_connections (H5) ────────────────────────────────────
CREATE TABLE IF NOT EXISTS social_connections (
  store_id      UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  channel       TEXT NOT NULL CHECK (channel IN ('instagram','threads','facebook','x')),
  external_id   TEXT NOT NULL,
  external_name TEXT,
  access_token  TEXT NOT NULL,
  page_id       TEXT,
  is_active     BOOLEAN NOT NULL DEFAULT TRUE,
  connected_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  expires_at    TIMESTAMPTZ,
  PRIMARY KEY (store_id, channel)
);

ALTER TABLE social_connections ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "social_owner_read" ON social_connections;
CREATE POLICY "social_owner_read" ON social_connections
  FOR SELECT USING (auth.uid() = store_id);
DROP POLICY IF EXISTS "social_service_write" ON social_connections;
CREATE POLICY "social_service_write" ON social_connections
  FOR ALL USING (auth.role() = 'service_role');

-- ─── social_posts (게시 이력) ────────────────────────────────────
CREATE TABLE IF NOT EXISTS social_posts (
  id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  store_id      UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  channel       TEXT NOT NULL,
  external_id   TEXT,
  caption       TEXT,
  image_url     TEXT,
  published_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  metrics       JSONB
);
CREATE INDEX IF NOT EXISTS idx_social_posts_store_published
  ON social_posts(store_id, published_at DESC);

ALTER TABLE social_posts ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "social_posts_owner" ON social_posts;
CREATE POLICY "social_posts_owner" ON social_posts
  FOR ALL USING (auth.uid() = store_id);

COMMENT ON TABLE pos_connections IS 'POS 벤더 연동 키 (H3)';
COMMENT ON TABLE social_connections IS '소셜 채널 연결 + 토큰 (H5)';
COMMENT ON TABLE social_posts IS '소셜 게시 이력';
