"""
Naver DataLab Search Trends API 래퍼.

API: https://developers.naver.com/docs/serviceapi/datalab/search/search.md
- 키워드 그룹별 검색량 추이 (date/week/month)
- 한국 시장의 정량 시그널 (검색의 ~70%가 Naver)
- 무료 티어: 일 25,000건 (충분)

키 없으면 None 반환 (graceful degradation).
"""
import os
from typing import Optional

import httpx

DATALAB_URL = "https://openapi.naver.com/v1/datalab/search"


async def fetch_search_trends(
    keywords: list[str],
    start_date: str,
    end_date: str,
    time_unit: str = "date",
) -> Optional[dict]:
    """
    Naver DataLab Search Trends 호출.

    Args:
        keywords: 비교할 키워드 리스트 (최대 5개, 더 많으면 5개로 절단)
        start_date: 'YYYY-MM-DD' (최대 1년 전)
        end_date: 'YYYY-MM-DD'
        time_unit: 'date' | 'week' | 'month'

    Returns:
        {"results": [{"title", "keywords", "data": [{"period", "ratio"}]}]} 또는 None
    """
    cid = os.getenv("NAVER_CLIENT_ID", "")
    csec = os.getenv("NAVER_CLIENT_SECRET", "")
    if not cid or not csec or not keywords:
        return None

    body = {
        "startDate": start_date,
        "endDate": end_date,
        "timeUnit": time_unit,
        "keywordGroups": [
            {"groupName": kw, "keywords": [kw]} for kw in keywords[:5]
        ],
    }
    headers = {
        "X-Naver-Client-Id": cid,
        "X-Naver-Client-Secret": csec,
        "Content-Type": "application/json",
    }

    try:
        async with httpx.AsyncClient(timeout=15) as client:
            r = await client.post(DATALAB_URL, json=body, headers=headers)
            r.raise_for_status()
            return r.json()
    except Exception:
        return None


def compute_keyword_momentum(datalab_result: dict) -> list[dict]:
    """
    DataLab 응답에서 키워드별 7일 모멘텀 계산.

    Returns:
        [{"keyword", "current_avg", "prev_avg", "change_pct", "trend"}]
        trend: "rising" (>=20%) | "stable" (-10~+10) | "falling" (<=-20%) | "mild_*"
    """
    summary = []
    if not datalab_result or "results" not in datalab_result:
        return summary

    for group in datalab_result["results"]:
        data = group.get("data", [])
        if len(data) < 14:
            continue
        recent = [d["ratio"] for d in data[-7:]]
        prev = [d["ratio"] for d in data[-14:-7]]
        cur_avg = sum(recent) / len(recent) if recent else 0
        prev_avg = sum(prev) / len(prev) if prev else 0
        change = ((cur_avg - prev_avg) / prev_avg * 100) if prev_avg > 0 else 0

        if change >= 20:
            trend = "rising"
        elif change >= 5:
            trend = "mild_rising"
        elif change <= -20:
            trend = "falling"
        elif change <= -5:
            trend = "mild_falling"
        else:
            trend = "stable"

        summary.append({
            "keyword": group.get("title", ""),
            "current_avg": round(cur_avg, 2),
            "prev_avg": round(prev_avg, 2),
            "change_pct": round(change, 1),
            "trend": trend,
        })

    return sorted(summary, key=lambda x: x["change_pct"], reverse=True)
