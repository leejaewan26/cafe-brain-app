"""
에이전트 메모리 서비스 (Issue #10 Foundation)

구조화된 장기 기억 CRUD + 검색 + 사용자 반응 기록.
Batch 4의 능동형 에이전트가 여기서 메모리를 읽고 쓴다.

철학: "이 사장님에 대해 무엇을 알아야 60일 후 더 개인화된 응답을 할 수 있는가?"
"""
import asyncio
from datetime import datetime, timezone
from typing import Any, Literal, Optional

from app.services.gemini_service import _get_supabase

# ═══════════════════════════════════════════════════════
# 타입
# ═══════════════════════════════════════════════════════

MemoryCategory = Literal[
    "business_pattern",
    "customer_insight",
    "decision_history",
    "preference",
    "event",
    "goal",
    "accepted_suggestion",
    "rejected_suggestion",
]

FeedbackReaction = Literal["helpful", "irrelevant", "applied", "muted"]

BriefingTrigger = Literal[
    "daily_briefing",
    "sales_anomaly",
    "bep_milestone",
    "review_surge",
    "reorder_reminder",
    "manual",
]


# ═══════════════════════════════════════════════════════
# 메모리 저장
# ═══════════════════════════════════════════════════════


async def insert_memory(
    store_id: str,
    category: MemoryCategory,
    content: str,
    importance: int = 5,
    confidence: float = 0.7,
    source_type: Optional[str] = None,
    source_ref: Optional[str] = None,
    expires_at: Optional[datetime] = None,
    skip_embedding: bool = False,  # Phase 6 #4: 임베딩 생성 스킵 (테스트·대량 import용)
    profile_role: Optional[str] = None,  # Phase 6 #7: 'owner' | 'manager' | None(전체)
) -> Optional[str]:
    """
    새 메모리 저장. 반환: 생성된 메모리 id (실패 시 None).

    중복 메모리 방지: 동일 store_id + category + content[:100] 일치하면
    기존 레코드를 강화(importance +1, last_reinforced_at=now)만 수행.
    """
    sb = _get_supabase()
    if sb is None:
        return None

    # 컨텐츠 자르기 (DB CHECK: 1000자)
    content = content[:990]

    try:
        # 1) 유사 메모리 중복 체크 (같은 카테고리 + 내용 접두사 일치)
        existing = await asyncio.to_thread(
            lambda: sb.table("agent_memory")
            .select("id, importance")
            .eq("store_id", store_id)
            .eq("category", category)
            .is_("archived_at", "null")
            .ilike("content", f"{content[:80]}%")
            .limit(1)
            .execute()
        )

        if existing.data:
            # 강화 (중복 INSERT 대신 기존 메모리 신뢰도 UP)
            row = existing.data[0]
            new_importance = min(10, row["importance"] + 1)
            await asyncio.to_thread(
                lambda: sb.table("agent_memory")
                .update(
                    {
                        "importance": new_importance,
                        "last_reinforced_at": datetime.now(timezone.utc).isoformat(),
                    }
                )
                .eq("id", row["id"])
                .execute()
            )
            return row["id"]

        # 2) 신규 INSERT
        payload: dict[str, Any] = {
            "store_id": store_id,
            "category": category,
            "content": content,
            "importance": importance,
            "confidence": confidence,
            "source_type": source_type,
            "source_ref": source_ref,
        }
        if expires_at:
            payload["expires_at"] = expires_at.isoformat()
        # Phase 6 #7: 권한별 가시성 (None이면 전체 공개)
        if profile_role in ("owner", "manager"):
            payload["profile_role"] = profile_role

        # Phase 6 #4: Gemini 임베딩 자동 생성 (실패 시 NULL — 키워드 검색만 가능)
        if not skip_embedding:
            try:
                from app.services.embeddings import generate_embedding
                emb = await generate_embedding(content)
                if emb is not None:
                    payload["embedding"] = emb
            except Exception:
                pass  # 임베딩 실패가 INSERT를 막으면 안 됨

        result = await asyncio.to_thread(
            lambda: sb.table("agent_memory").insert(payload).execute()
        )
        if result.data:
            return result.data[0]["id"]
    except Exception:
        # 메모리 저장 실패가 주요 기능을 막으면 안 됨
        pass
    return None


# ═══════════════════════════════════════════════════════
# 메모리 검색 (에이전트 프롬프트 주입용)
# ═══════════════════════════════════════════════════════


async def search_memories(
    store_id: str,
    categories: Optional[list[MemoryCategory]] = None,
    limit: int = 10,
    active_role: str = "owner",  # Phase 6 #7: 활성 프로필 역할 (owner|manager)
) -> list[dict[str, Any]]:
    """
    현재 상황에 관련성 높은 메모리 Top-N 반환.
    랭킹: importance × confidence × recency

    Phase 6 #7: active_role에 따른 권한 필터
      - 'owner': 전체 메모리 가시
      - 'manager': profile_role IS NULL OR 'manager' 만

    Returns:
        [{id, category, content, importance, confidence, created_at}, ...]
    """
    sb = _get_supabase()
    if sb is None:
        return []

    # 1) v2 (권한 필터) 우선 시도
    try:
        result = await asyncio.to_thread(
            lambda: sb.rpc(
                "search_relevant_memories_v2",
                {
                    "p_store_id": store_id,
                    "p_active_role": active_role,
                    "p_categories": categories,
                    "p_limit": limit,
                },
            ).execute()
        )
        return result.data or []
    except Exception:
        pass

    # 2) v2 미배포 환경 fallback — 기존 v1
    try:
        result = await asyncio.to_thread(
            lambda: sb.rpc(
                "search_relevant_memories",
                {
                    "p_store_id": store_id,
                    "p_categories": categories,
                    "p_limit": limit,
                },
            ).execute()
        )
        return result.data or []
    except Exception:
        return []


async def search_memories_semantic(
    store_id: str,
    query: str,
    categories: Optional[list[MemoryCategory]] = None,
    limit: int = 8,
    min_similarity: float = 0.5,
) -> list[dict[str, Any]]:
    """
    Phase 6 #4: 의미적 메모리 검색 (cosine similarity).

    예: "고객 불만" 으로 검색 → "민원" "컴플레인" 메모리도 매칭

    Args:
        query: 자연어 검색 쿼리
        min_similarity: 최소 유사도 (0~1, 낮을수록 더 많이 반환)

    Returns:
        [{id, category, content, importance, confidence, similarity, created_at}, ...]
        embedding 또는 pgvector 미설정 시 빈 리스트.
    """
    sb = _get_supabase()
    if sb is None or not query.strip():
        return []

    # 1) 쿼리 임베딩
    try:
        from app.services.embeddings import generate_query_embedding
        query_emb = await generate_query_embedding(query)
    except Exception:
        return []

    if query_emb is None:
        return []

    # 2) pg 함수 호출
    try:
        result = await asyncio.to_thread(
            lambda: sb.rpc(
                "search_memories_semantic",
                {
                    "p_store_id": store_id,
                    "p_query_embedding": query_emb,
                    "p_categories": categories,
                    "p_limit": limit,
                    "p_min_similarity": min_similarity,
                },
            ).execute()
        )
        return result.data or []
    except Exception:
        # pgvector 미설정 또는 컬럼 없음 → 빈 결과
        return []


async def mark_memories_used(memory_ids: list[str]) -> None:
    """에이전트 발화 후 사용한 메모리들 use_count 증가."""
    if not memory_ids:
        return
    sb = _get_supabase()
    if sb is None:
        return
    try:
        await asyncio.to_thread(
            lambda: sb.rpc(
                "mark_memories_used", {"p_memory_ids": memory_ids}
            ).execute()
        )
    except Exception:
        pass


# ═══════════════════════════════════════════════════════
# 사용자 피드백 (학습 루프)
# ═══════════════════════════════════════════════════════


async def record_feedback(
    store_id: str,
    source_type: str,
    source_ref: str,
    reaction: FeedbackReaction,
    note: Optional[str] = None,
) -> Optional[str]:
    """
    AI 제안에 대한 사용자 반응 기록. 학습 신호.
    - applied: 실제 적용됨 → 해당 카테고리 선호도 강화
    - muted: 다시는 이런 거 주지 마 → rejected_suggestion 메모리 생성
    """
    sb = _get_supabase()
    if sb is None:
        return None

    try:
        result = await asyncio.to_thread(
            lambda: sb.table("agent_feedback")
            .insert(
                {
                    "store_id": store_id,
                    "source_type": source_type,
                    "source_ref": source_ref,
                    "reaction": reaction,
                    "note": note,
                }
            )
            .execute()
        )

        # muted 반응은 자동으로 rejected_suggestion 메모리 생성
        if reaction == "muted":
            await insert_memory(
                store_id=store_id,
                category="rejected_suggestion",
                content=f"[{source_type}] 유형 제안 거부: {note or '이유 미지정'}",
                importance=6,
                confidence=0.9,
                source_type="user_feedback",
                source_ref=source_ref,
            )

        if result.data:
            return result.data[0]["id"]
    except Exception:
        pass
    return None


# ═══════════════════════════════════════════════════════
# 매장 프로필 (빠른 컨텍스트 주입)
# ═══════════════════════════════════════════════════════


async def get_store_agent_profile(store_id: str) -> dict[str, Any]:
    """
    stores.agent_profile 조회. Batch 4에서 메모리 → 프로필 증류 예정.
    현재는 빈 dict 반환 가능 (정상).
    """
    sb = _get_supabase()
    if sb is None:
        return {}

    try:
        result = await asyncio.to_thread(
            lambda: sb.table("stores")
            .select("agent_profile, agent_learning_enabled")
            .eq("id", store_id)
            .limit(1)
            .execute()
        )
        if result.data:
            row = result.data[0]
            if not row.get("agent_learning_enabled", True):
                return {}  # 학습 꺼둔 매장은 빈 프로필
            return row.get("agent_profile") or {}
    except Exception:
        pass
    return {}


# ═══════════════════════════════════════════════════════
# 능동 브리핑 로그
# ═══════════════════════════════════════════════════════


async def log_briefing(
    store_id: str,
    trigger_type: BriefingTrigger,
    response: str,
    context_memory_ids: Optional[list[str]] = None,
    prompt_snapshot: Optional[str] = None,
) -> Optional[str]:
    """에이전트가 능동 발화했을 때 로그. 나중에 feedback과 매칭."""
    sb = _get_supabase()
    if sb is None:
        return None

    try:
        result = await asyncio.to_thread(
            lambda: sb.table("agent_briefing_log")
            .insert(
                {
                    "store_id": store_id,
                    "trigger_type": trigger_type,
                    "response": response,
                    "context_memories": context_memory_ids or [],
                    "prompt_snapshot": prompt_snapshot,
                }
            )
            .execute()
        )
        if result.data:
            return result.data[0]["id"]
    except Exception:
        pass
    return None
