// I8 — 풀-투-리프레시 시각화 인디케이터
import { Loader2, ArrowDown } from 'lucide-react'

interface Props {
  pullDistance: number
  refreshing: boolean
  threshold?: number
}

export default function PullToRefreshIndicator({
  pullDistance,
  refreshing,
  threshold = 80,
}: Props) {
  if (pullDistance === 0 && !refreshing) return null

  const progress = Math.min(1, pullDistance / threshold)
  const triggered = pullDistance >= threshold

  return (
    <div
      className="fixed top-0 left-0 right-0 z-40 flex justify-center pointer-events-none transition-transform"
      style={{
        transform: `translateY(${refreshing ? 16 : pullDistance - 40}px)`,
      }}
    >
      <div className="bg-white rounded-full shadow-md px-4 py-2 flex items-center gap-2 text-xs text-[#2C1810] font-semibold">
        {refreshing ? (
          <>
            <Loader2 size={14} className="animate-spin text-[#D4A574]" />
            새로고침 중…
          </>
        ) : (
          <>
            <ArrowDown
              size={14}
              className="transition-transform"
              style={{ transform: `rotate(${triggered ? 180 : 0}deg)`, opacity: progress }}
            />
            {triggered ? '놓으면 새로고침' : '아래로 당겨주세요'}
          </>
        )}
      </div>
    </div>
  )
}
