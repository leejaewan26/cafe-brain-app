// QA 시나리오 1: 신규 가입 → 온보딩 → 대시보드
// 검증: 5단계 온보딩 완료 후 BEP 게이지·홈 위젯 정상 표시
import { test, expect } from '@playwright/test'
import { setupApiMocks } from './fixtures/apiMock'
import { MOCK_SESSION, MOCK_STORE } from './fixtures/mockData'

test.describe('시나리오 1 — 온보딩 + 대시보드', () => {
  test('신규 로그인 후 /login → 로그인 UI 노출', async ({ page }) => {
    await setupApiMocks(page)
    await page.goto('/login')
    await expect(page).toHaveURL(/.*\/login/)
    // 로고 또는 헤딩
    await expect(page.locator('body')).toContainText(/카페 브레인|Cafe Brain|로그인|이메일/)
  })

  test('로그인 완료 후 온보딩 미완이면 /onboarding 리다이렉트', async ({ page }) => {
    await setupApiMocks(page)
    // 인증만 되고 온보딩 미완 상태 주입
    await page.addInitScript(({ session }) => {
      localStorage.setItem(
        'cafe-brain-auth',
        JSON.stringify({ state: { storeInfo: null, isOnboarded: false }, version: 0 }),
      )
      localStorage.setItem(
        `sb-${location.hostname}-auth-token`,
        JSON.stringify(session),
      )
    }, { session: MOCK_SESSION })

    await page.goto('/')
    // 가드에 의해 /onboarding 으로 튕기는지
    await page.waitForURL(/.*\/(onboarding|login|profile-select)/, { timeout: 5000 })
  })

  test('온보딩 + 프로필 완료 후 대시보드에 BEP 게이지·인사말 표시', async ({ page }) => {
    await setupApiMocks(page)
    // 온보딩·프로필 완료 상태 주입
    await page.addInitScript(({ session, store }) => {
      localStorage.setItem(
        'cafe-brain-auth',
        JSON.stringify({ state: { storeInfo: store, isOnboarded: true }, version: 0 }),
      )
      localStorage.setItem(
        'cafe-brain-profile',
        JSON.stringify({
          state: {
            activeProfile: {
              id: 'p1', store_id: store.id, name: store.owner_name,
              role: 'owner', avatar_emoji: '👨‍💼', avatar_color: '#D4A574',
              active: true, permissions: {}, created_at: new Date().toISOString(),
            },
          },
          version: 0,
        }),
      )
      localStorage.setItem(
        `sb-${location.hostname}-auth-token`,
        JSON.stringify(session),
      )
    }, { session: MOCK_SESSION, store: MOCK_STORE })

    await page.goto('/dashboard')

    // 대시보드 핵심 요소
    await expect(page.locator('body')).toContainText(/안녕하세요|좋은 아침|수고하셨어요/)
    await expect(page.locator('body')).toContainText(MOCK_STORE.store_name)
    // BEP 섹션 — '이번 달 목표' 또는 BEP 관련 텍스트
    await expect(page.locator('body')).toContainText(/이번 달|BEP/)
  })
})
