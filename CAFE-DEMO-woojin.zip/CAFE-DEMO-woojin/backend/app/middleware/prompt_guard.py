"""
프롬프트 인젝션 가드 미들웨어 (E05 Critical — /ultrareview Day 1)

사용자 입력이 Gemini 시스템 프롬프트에 concat될 때 악의적 탈취를 차단한다.
공격 유형:
  1. Role override: ignore previous instructions / you are now / 시스템:
  2. Delimiter injection: 트리플 따옴표나 ### 뒤에 역할 지시문
  3. Prompt leak: print your instructions / 시스템 프롬프트 출력
  4. Jailbreak: DAN, 역할극 유도

전략:
  - HIGH 위험 패턴(명백한 탈취) -> 400 BAD REQUEST + 차단 로그
  - MEDIUM 위험 패턴(애매) -> 경고 헤더 + 통과 (사장님이 우연히 쓸 수도 있음)
  - JSON 바디의 문자열 필드만 검사 (이미지 base64·숫자는 스킵)

설계 원칙:
  - False Positive 최소화 (진짜 사장님의 평범한 문장은 통과)
  - 한국어·영어 패턴 모두 커버
  - 로그로 시도 통계 축적 (향후 튜닝용)
"""
import json
import logging
import re
from typing import Optional

from fastapi import Request
from fastapi.responses import JSONResponse
from starlette.middleware.base import BaseHTTPMiddleware

logger = logging.getLogger("prompt_guard")

# 가드 적용 대상 — AI가 사용자 텍스트를 프롬프트에 섞는 엔드포인트만
GUARDED_ENDPOINTS = (
    "/api/sales/ai-insight",
    "/api/reviews/reply",
    "/api/marketing/generate",
    "/api/marketing/seo",
    "/api/menu/recipe",
    "/api/menu/recommend",
    "/api/menu/manual",
    "/api/chat/message",
    "/api/agent/briefing",
    "/api/agent/distill",
    "/api/supplier/cost-savings",
    # OCR은 이미지 검증이라 텍스트 인젝션 무관 → 제외
)

# HIGH — 명백한 탈취 의도 (즉시 차단)
HIGH_RISK_PATTERNS: list[re.Pattern] = [
    # 역할 덮어쓰기
    re.compile(r"ignore\s+(all\s+)?(previous|prior|above|earlier)\s+(instructions?|prompts?|rules?)", re.I),
    re.compile(r"disregard\s+(all\s+)?(previous|above|prior)\s+(instructions?|rules?)", re.I),
    re.compile(r"forget\s+(everything|all|previous)\s+(above|before|instructions?)", re.I),
    re.compile(r"이전\s*(지시|규칙|프롬프트|명령)[을는를이가]?\s*(무시|잊)", re.I),
    re.compile(r"지금까지의?\s*(지시|규칙|프롬프트)[을는를이가]?\s*(무시|잊)", re.I),
    re.compile(r"위\s*(지시|규칙|프롬프트|명령)[을는를]?\s*(무시|잊)", re.I),
    # 시스템 프롬프트 위조 (구분자 + 역할)
    re.compile(r"(^|\n)\s*(system|시스템|assistant|어시스턴트)\s*[:：]", re.I | re.M),
    re.compile(r"(\"{3}|```|---|\#{3,}).{0,40}(system|시스템|new\s+instruction|새\s*지시)", re.I | re.S),
    # 역할 전환 유도
    re.compile(r"you\s+are\s+(now|no\s+longer)\s+", re.I),
    re.compile(r"act\s+as\s+(a|an)\s+(unrestricted|uncensored|jailbroken|dan)", re.I),
    re.compile(r"(dan\s+mode|developer\s+mode|jailbreak\s+mode)\s+(on|enabled|activated)", re.I),
    # 프롬프트 유출
    re.compile(r"(print|show|reveal|display|출력|보여|알려)\s+(your|the|너의|당신의)?\s*(system\s+)?(prompt|instructions?|prompts?|프롬프트|지시|규칙)", re.I),
    re.compile(r"what\s+(are|were)\s+your\s+(original|initial|system)\s+(instructions?|prompts?)", re.I),
]

# MEDIUM — 애매한 패턴 (로그만, 통과)
MEDIUM_RISK_PATTERNS: list[re.Pattern] = [
    re.compile(r"jailbreak", re.I),
    re.compile(r"bypass\s+(safety|filter|restriction)", re.I),
    re.compile(r"(\"{3}|```)\s*new\s+", re.I),
]

# 검사 대상 필드 최대 길이 (이 이상은 앞/뒤 샘플만)
MAX_SCAN_CHARS = 4000


def _iter_strings(obj, path="") -> list[tuple[str, str]]:
    """JSON 트리에서 문자열 값만 뽑아낸다 (field path, value). base64·숫자 제외."""
    results: list[tuple[str, str]] = []
    if isinstance(obj, dict):
        for k, v in obj.items():
            # base64 이미지·binary는 스킵
            if k in ("image_base64", "image", "file_base64"):
                continue
            results.extend(_iter_strings(v, f"{path}.{k}" if path else k))
    elif isinstance(obj, list):
        for i, v in enumerate(obj):
            results.extend(_iter_strings(v, f"{path}[{i}]"))
    elif isinstance(obj, str) and len(obj) > 0:
        # 너무 길면 앞 2000 + 뒤 2000만
        if len(obj) > MAX_SCAN_CHARS:
            obj = obj[:2000] + "\n" + obj[-2000:]
        results.append((path, obj))
    return results


def scan_prompt_injection(body_str: str) -> tuple[str, Optional[str]]:
    """
    JSON 문자열 바디에서 프롬프트 인젝션 시도를 탐지.

    Returns:
        (risk_level, matched_pattern)
        risk_level: "clean" | "medium" | "high"
        matched_pattern: HIGH 때 매칭된 패턴 설명 (로그용)
    """
    try:
        payload = json.loads(body_str)
    except (json.JSONDecodeError, ValueError):
        # JSON 아니면 검사 스킵 (raw text 엔드포인트 없음)
        return ("clean", None)

    risk = "clean"
    matched: Optional[str] = None

    for field_path, text in _iter_strings(payload):
        for pat in HIGH_RISK_PATTERNS:
            m = pat.search(text)
            if m:
                return ("high", f"field={field_path} pattern={pat.pattern[:60]} match={m.group(0)[:60]}")
        if risk == "clean":
            for pat in MEDIUM_RISK_PATTERNS:
                if pat.search(text):
                    risk = "medium"
                    matched = f"field={field_path} pattern={pat.pattern[:40]}"
                    break

    return (risk, matched)


class PromptInjectionGuardMiddleware(BaseHTTPMiddleware):
    """
    AI 엔드포인트에 프롬프트 인젝션 가드 적용.
    HIGH 위험 → 400 차단, MEDIUM → X-Prompt-Risk: medium 헤더만 추가.
    """

    async def dispatch(self, request: Request, call_next):
        if not request.url.path.startswith(GUARDED_ENDPOINTS):
            return await call_next(request)

        # POST/PUT만 검사 (GET은 바디 없음)
        if request.method not in ("POST", "PUT", "PATCH"):
            return await call_next(request)

        body_bytes = await request.body()
        if not body_bytes:
            return await call_next(request)

        try:
            body_str = body_bytes.decode("utf-8", errors="replace")
        except Exception:
            # 디코딩 실패 시 통과 (다른 미들웨어·핸들러가 400 반환)
            request._body = body_bytes
            return await call_next(request)

        risk, matched = scan_prompt_injection(body_str)

        # 바디 복원 (starlette 특성상 한 번 읽으면 재읽기 불가)
        request._body = body_bytes

        if risk == "high":
            logger.warning(
                "Prompt injection BLOCKED | path=%s | ip=%s | %s",
                request.url.path,
                request.client.host if request.client else "?",
                matched,
            )
            return JSONResponse(
                status_code=400,
                content={
                    "detail": (
                        "요청에 AI 시스템 지시를 탈취하려는 문구가 감지되었습니다. "
                        "정상 사용 중 이 오류가 반복되면 문의 부탁드립니다."
                    ),
                    "risk": "prompt_injection",
                },
                headers={"X-Prompt-Risk": "high"},
            )

        response = await call_next(request)
        if risk == "medium":
            logger.info(
                "Prompt injection MEDIUM | path=%s | %s",
                request.url.path,
                matched,
            )
            response.headers["X-Prompt-Risk"] = "medium"
        return response
