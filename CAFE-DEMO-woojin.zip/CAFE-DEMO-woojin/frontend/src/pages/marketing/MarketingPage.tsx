// 마케팅 콘텐츠 생성 모듈
// 기능: 플랫폼 선택 → 입력 폼 → Gemini AI 시안 3개 생성 → 편집/복사
//      SEO 블로그 전용 모드: 키워드 → 2,000자 초안 → 에세이 리라이트 → SEO 점수
import { useState, useRef, useEffect } from 'react'
import { Link } from 'react-router-dom'
import {
  ChevronLeft, Sparkles, Copy, Check, Loader2, AlertCircle,
  Megaphone, FileText, RotateCcw, Edit3, Search,
  Bell, TrendingUp, Zap, Download, BookOpen, Eye,
} from 'lucide-react'
import { useStoreContext } from '@/hooks/useStoreContext'
import { cn } from '@/lib/utils'
import AiFeedback from '@/components/AiFeedback'
import CanvaExport from '@/components/CanvaExport'
import { BrandIcons } from '@/components/BrandIcons'

// Day 6-1: Canva 딥링크는 CanvaExport 컴포넌트로 이관 (lib/canva.ts)

// ─── 타입 ───
interface DraftItem {
  content: string
  hashtags: string[]
  char_count: number
}

interface SeoScore {
  keywordDensity: Record<string, number>
  hasTitle: boolean
  hasSections: boolean
  charCount: number
  overallScore: number
}

// ─── 플랫폼 설정 (브랜드 정확 SVG 아이콘) ───
const PLATFORMS = [
  {
    id: 'instagram_feed',
    label: '인스타 게시물',
    BrandIcon: BrandIcons.Instagram,
    color: 'from-purple-500 to-pink-500',
    badge: 'bg-purple-100 text-purple-700',
    hint: 'MZ 감성 + 이모지 + 해시태그 10개 · 피드 미리보기 지원',
    featured: true,
  },
  {
    id: 'poster',
    label: '홍보 포스터',
    BrandIcon: BrandIcons.Poster,
    color: 'from-[#D4A574] to-[#A87844]',
    badge: 'bg-amber-100 text-amber-700',
    hint: '오프라인/온라인 겸용 포스터 · 제목·부제·본문·CTA 구조',
    featured: true,
  },
  {
    id: 'instagram_story',
    label: '인스타 스토리',
    BrandIcon: BrandIcons.InstagramStory,
    color: 'from-[#FEDA77] via-[#DD2A7B] to-[#8134AF]',
    badge: 'bg-orange-100 text-orange-700',
    hint: '1~2문장 + 강렬한 임팩트',
    featured: false,
  },
  {
    id: 'threads',
    label: '스레드',
    BrandIcon: BrandIcons.Threads,
    color: 'from-gray-800 to-black',
    badge: 'bg-gray-100 text-gray-700',
    hint: '3줄 이내 솔직/위트, 일상 공유',
    featured: false,
  },
  {
    id: 'naver_blog',
    label: '네이버 블로그',
    BrandIcon: BrandIcons.NaverBlog,
    color: 'from-[#03C75A] to-[#02A347]',
    badge: 'bg-green-100 text-green-700',
    hint: 'SEO 키워드 삽입, 2,000자 구조화',
    featured: false,
  },
  {
    id: 'kakao',
    label: '카카오톡 공지',
    BrandIcon: BrandIcons.Kakao,
    color: 'from-[#FEE500] to-[#FFC900]',
    badge: 'bg-yellow-100 text-yellow-700',
    hint: '간결한 공지 형태, 핵심 정보 위주',
    featured: false,
  },
]

// 추후 지원 예정 플랫폼
const COMING_SOON = [
  { id: 'video_shorts', label: '유튜브 쇼츠 / 릴스', BrandIcon: BrandIcons.YouTubeShorts },
]

const PROMOTION_TARGETS = [
  { id: 'new_menu', label: '신메뉴 홍보', emoji: '🍰' },
  { id: 'event', label: '이벤트 안내', emoji: '🎉' },
  { id: 'season', label: '시즌 프로모션', emoji: '🌸' },
  { id: 'daily', label: '일상 기록', emoji: '☕' },
  { id: 'intro', label: '매장 소개', emoji: '🏠' },
]

const TONES = [
  { id: 'emotional', label: '감성', emoji: '🌸' },
  { id: 'humor', label: '유머', emoji: '😄' },
  { id: 'informative', label: '정보 전달', emoji: '📊' },
  { id: 'casual', label: '담백한 일상', emoji: '☕' },
]

const TARGETS = [
  { id: 'mz_women', label: '2030 여성', emoji: '👩' },
  { id: 'office', label: '직장인', emoji: '💼' },
  { id: 'student', label: '학생', emoji: '🎓' },
  { id: 'family', label: '가족', emoji: '👨‍👩‍👧' },
  { id: 'general', label: '범용', emoji: '👥' },
]

// ─── 복사 버튼 ───
function CopyButton({ text, small }: { text: string; small?: boolean }) {
  const [copied, setCopied] = useState(false)
  const handleCopy = async () => {
    await navigator.clipboard.writeText(text)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }
  return (
    <button
      onClick={handleCopy}
      className={cn(
        'flex items-center gap-1 bg-[#2C1810] text-white rounded-lg hover:bg-[#3d2418] transition-all duration-200',
        small ? 'px-2 py-1 text-xs' : 'px-3 py-1.5 text-sm'
      )}
    >
      {copied ? <><Check size={12} /> 복사됨</> : <><Copy size={12} /> 복사</>}
    </button>
  )
}

// Day 6-1: 기존 CanvaButton 제거 — CanvaExport 컴포넌트로 교체 (3 템플릿 선택 지원)

// ──────────────────────────────────────────────────────
// ─── 인스타그램 피드 미리보기 컴포넌트 ───
// ──────────────────────────────────────────────────────
function InstagramPreview({ content, hashtags, storeName }: {
  content: string
  hashtags: string[]
  storeName: string
}) {
  return (
    <div className="bg-white rounded-2xl border border-gray-200 overflow-hidden max-w-xs mx-auto shadow-lg">
      {/* 헤더 */}
      <div className="flex items-center gap-2 px-3 py-2 border-b border-gray-100">
        <div className="w-8 h-8 rounded-full bg-gradient-to-br from-[#D4A574] to-[#2C1810] flex items-center justify-center text-white text-xs font-bold">
          {storeName.charAt(0)}
        </div>
        <div>
          <p className="text-xs font-semibold text-gray-800">{storeName}</p>
          <p className="text-xs text-gray-400">방금 전</p>
        </div>
        <div className="ml-auto">
          <div className="w-1 h-1 bg-gray-400 rounded-full inline-block mx-0.5" />
          <div className="w-1 h-1 bg-gray-400 rounded-full inline-block mx-0.5" />
          <div className="w-1 h-1 bg-gray-400 rounded-full inline-block mx-0.5" />
        </div>
      </div>
      {/* 이미지 플레이스홀더 */}
      <div className="aspect-square bg-gradient-to-br from-[#D4A574]/20 via-[#FAFAF8] to-[#2C1810]/10 flex items-center justify-center">
        <div className="text-center">
          <BrandIcons.Instagram size={48} className="mx-auto mb-2 opacity-70" />
          <p className="text-xs text-gray-400">이미지 영역</p>
        </div>
      </div>
      {/* 좋아요/댓글 아이콘 (인스타 진짜 아이콘 — 가는 라인 스타일) */}
      <div className="px-3 py-2">
        <div className="flex items-center gap-3 mb-2 text-gray-800">
          <svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-label="좋아요">
            <path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78Z" />
          </svg>
          <svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-label="댓글">
            <path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z" />
          </svg>
          <svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-label="공유">
            <line x1="22" y1="2" x2="11" y2="13" />
            <polygon points="22 2 15 22 11 13 2 9 22 2" />
          </svg>
          <svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" className="ml-auto" aria-label="저장">
            <path d="M19 21l-7-5-7 5V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z" />
          </svg>
        </div>
        {/* 캡션 */}
        <p className="text-xs font-semibold text-gray-800 mb-0.5">{storeName}</p>
        <p className="text-xs text-gray-700 leading-relaxed line-clamp-4 whitespace-pre-line">
          {content}
        </p>
        {hashtags.length > 0 && (
          <p className="text-xs text-blue-500 mt-1 leading-relaxed">
            {hashtags.join(' ')}
          </p>
        )}
      </div>
    </div>
  )
}

// ──────────────────────────────────────────────────────
// ─── 포스터 Canvas 다운로드 유틸 ───
// ──────────────────────────────────────────────────────
function downloadPosterCanvas(
  title: string, subtitle: string, body: string, cta: string,
  storeName: string, index: number
) {
  const W = 600, H = 800, R = 24, DPR = 2
  const canvas = document.createElement('canvas')
  canvas.width = W * DPR
  canvas.height = H * DPR
  const ctx = canvas.getContext('2d')!
  ctx.scale(DPR, DPR)

  // 테마 색상
  const themeColors = [
    { from: '#2C1810', to: '#5a3420', accent: '#D4A574', text: '#ffffff', sub: 'rgba(255,255,255,0.7)' },
    { from: '#1a1a2e', to: '#16213e', accent: '#D4A574', text: '#ffffff', sub: 'rgba(255,255,255,0.7)' },
    { from: '#f5f0eb', to: '#ede4d9', accent: '#2C1810', text: '#2C1810', sub: '#7a5c4a' },
  ]
  const t = themeColors[index % themeColors.length]

  // 배경 그라디언트
  const grad = ctx.createLinearGradient(0, 0, W, H)
  grad.addColorStop(0, t.from)
  grad.addColorStop(1, t.to)

  // 둥근 사각형 클리핑
  ctx.beginPath()
  ctx.moveTo(R, 0)
  ctx.lineTo(W - R, 0)
  ctx.arcTo(W, 0, W, R, R)
  ctx.lineTo(W, H - R)
  ctx.arcTo(W, H, W - R, H, R)
  ctx.lineTo(R, H)
  ctx.arcTo(0, H, 0, H - R, R)
  ctx.lineTo(0, R)
  ctx.arcTo(0, 0, R, 0, R)
  ctx.closePath()
  ctx.fillStyle = grad
  ctx.fill()
  ctx.save()
  ctx.clip()

  // 브랜드 원
  const circleCx = 32, circleCy = 36
  ctx.beginPath()
  ctx.arc(circleCx, circleCy, 16, 0, Math.PI * 2)
  ctx.fillStyle = t.accent
  ctx.fill()
  ctx.fillStyle = t.from === '#f5f0eb' ? '#ffffff' : '#2C1810'
  ctx.font = 'bold 14px sans-serif'
  ctx.textAlign = 'center'
  ctx.textBaseline = 'middle'
  ctx.fillText(storeName.charAt(0), circleCx, circleCy)

  // 매장명
  ctx.textAlign = 'left'
  ctx.textBaseline = 'middle'
  ctx.fillStyle = t.sub
  ctx.font = '12px sans-serif'
  ctx.fillText(storeName, 54, 36)

  // 이미지 플레이스홀더
  const imgX = 24, imgY = 64, imgW = W - 48, imgH = 280
  ctx.fillStyle = 'rgba(255,255,255,0.08)'
  ctx.beginPath()
  ctx.roundRect(imgX, imgY, imgW, imgH, 16)
  ctx.fill()
  ctx.font = '40px sans-serif'
  ctx.textAlign = 'center'
  ctx.textBaseline = 'middle'
  ctx.fillText('☕', W / 2, imgY + imgH / 2 - 12)
  ctx.font = '12px sans-serif'
  ctx.fillStyle = t.sub
  ctx.fillText('이미지 영역', W / 2, imgY + imgH / 2 + 28)

  // 텍스트 영역
  let y = imgY + imgH + 28
  const wrapText = (text: string, maxW: number, lineH: number, fStyle: string, color: string) => {
    ctx.font = fStyle
    ctx.fillStyle = color
    ctx.textAlign = 'left'
    ctx.textBaseline = 'top'
    const words = text.split('')
    let line = ''
    for (const ch of words) {
      const test = line + ch
      if (ctx.measureText(test).width > maxW && line) {
        ctx.fillText(line, 24, y)
        y += lineH
        line = ch
      } else {
        line = test
      }
    }
    if (line) { ctx.fillText(line, 24, y); y += lineH }
  }

  if (title) {
    wrapText(title, W - 48, 36, 'bold 28px sans-serif', t.accent)
    y += 4
  }
  if (subtitle) {
    wrapText(subtitle, W - 48, 24, '600 16px sans-serif', t.text)
    y += 4
  }
  if (body) {
    wrapText(body, W - 48, 20, '14px sans-serif', t.sub)
    y += 8
  }
  if (cta) {
    // 구분선
    ctx.strokeStyle = 'rgba(255,255,255,0.15)'
    ctx.lineWidth = 1
    ctx.beginPath()
    ctx.moveTo(24, y)
    ctx.lineTo(W - 24, y)
    ctx.stroke()
    y += 12
    wrapText(cta, W - 48, 20, 'bold 13px sans-serif', t.accent)
  }

  ctx.restore()

  // 다운로드
  canvas.toBlob(blob => {
    if (!blob) return
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `poster-${['A','B','C'][index]}-${Date.now()}.png`
    a.click()
    URL.revokeObjectURL(url)
  }, 'image/png')
}

// ──────────────────────────────────────────────────────
// ─── 포스터 미리보기 컴포넌트 ───
// ──────────────────────────────────────────────────────
function PosterPreview({ content, storeName, index }: {
  content: string
  storeName: string
  index: number
}) {
  // [제목] / [부제] / [본문] / [CTA] 파싱
  const extract = (tag: string): string => {
    const match = content.match(new RegExp(`\\[${tag}\\]\\s*([^\\[]+)`))
    return match ? match[1].trim() : ''
  }

  const title = extract('제목') || content.split('\n')[0]
  const subtitle = extract('부제')
  const body = extract('본문')
  const cta = extract('CTA')

  // 시안별 포스터 색상 테마
  const themes = [
    { bg: 'from-[#2C1810] to-[#5a3420]', accent: '#D4A574', text: 'white', subtleText: 'rgba(255,255,255,0.7)' },
    { bg: 'from-[#1a1a2e] to-[#16213e]',  accent: '#D4A574', text: 'white', subtleText: 'rgba(255,255,255,0.7)' },
    { bg: 'from-[#f5f0eb] to-[#ede4d9]',  accent: '#2C1810', text: '#2C1810', subtleText: '#7a5c4a' },
  ]
  const theme = themes[index % themes.length]

  return (
    <div className={`rounded-2xl overflow-hidden shadow-xl bg-gradient-to-br ${theme.bg} mx-auto max-w-xs`}
      style={{ aspectRatio: '3/4', display: 'flex', flexDirection: 'column' }}>
      {/* 상단 브랜드 */}
      <div className="px-5 pt-5 pb-2 flex items-center gap-2">
        <div className="w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold"
          style={{ backgroundColor: theme.accent, color: theme.bg.includes('f5f0eb') ? 'white' : '#2C1810' }}>
          {storeName.charAt(0)}
        </div>
        <p className="text-xs font-semibold" style={{ color: theme.subtleText }}>{storeName}</p>
      </div>

      {/* 이미지 플레이스홀더 */}
      <div className="mx-5 rounded-xl overflow-hidden flex-1 flex items-center justify-center"
        style={{ backgroundColor: 'rgba(255,255,255,0.08)', minHeight: 80 }}>
        <div className="text-center">
          <div className="text-3xl mb-1">☕</div>
          <p className="text-xs" style={{ color: theme.subtleText }}>이미지 영역</p>
        </div>
      </div>

      {/* 텍스트 */}
      <div className="px-5 py-4 space-y-2">
        {title && (
          <p className="text-xl font-black leading-tight" style={{ color: theme.accent }}>
            {title}
          </p>
        )}
        {subtitle && (
          <p className="text-sm font-medium" style={{ color: theme.text }}>
            {subtitle}
          </p>
        )}
        {body && (
          <p className="text-xs leading-relaxed whitespace-pre-line" style={{ color: theme.subtleText }}>
            {body}
          </p>
        )}
        {cta && (
          <div className="mt-3 pt-3 border-t" style={{ borderColor: 'rgba(255,255,255,0.15)' }}>
            <p className="text-xs font-bold" style={{ color: theme.accent }}>{cta}</p>
          </div>
        )}
      </div>
    </div>
  )
}

// ──────────────────────────────────────────────────────
// ─── 시안 카드 ───
// ──────────────────────────────────────────────────────
function DraftCard({
  draft,
  index,
  platform,
  storeName,
  isSelected,
  onSelect,
}: {
  draft: DraftItem
  index: number
  platform: string
  storeName: string
  isSelected: boolean
  onSelect: () => void
}) {
  const [isEditing, setIsEditing] = useState(false)
  const [editContent, setEditContent] = useState(draft.content)
  const [showPreview, setShowPreview] = useState(platform === 'poster') // 포스터는 기본 미리보기

  const labels = ['시안 A', '시안 B', '시안 C']
  const colors = [
    'border-purple-200 bg-purple-50',
    'border-blue-200 bg-blue-50',
    'border-emerald-200 bg-emerald-50',
  ]
  const badgeColors = [
    'bg-purple-100 text-purple-700',
    'bg-blue-100 text-blue-700',
    'bg-emerald-100 text-emerald-700',
  ]

  return (
    <div
      className={cn(
        'rounded-2xl border-2 p-4 transition-all duration-200 cursor-pointer',
        isSelected
          ? 'border-[#D4A574] ring-2 ring-[#D4A574]/30 bg-[#D4A574]/5'
          : `${colors[index]} hover:scale-[1.01]`
      )}
      onClick={!isEditing ? onSelect : undefined}
    >
      {/* 헤더 */}
      <div className="flex items-center justify-between mb-3">
        <span className={cn('text-xs font-bold px-2 py-0.5 rounded-full', badgeColors[index])}>
          {labels[index]}
        </span>
        <div className="flex items-center gap-2" onClick={(e) => e.stopPropagation()}>
          <span className="text-xs text-gray-400">{editContent.length}자</span>
          {(platform === 'instagram_feed' || platform === 'poster') && (
            <button
              onClick={() => setShowPreview(!showPreview)}
              className={cn(
                'flex items-center gap-1 px-2 py-1 rounded-lg text-xs transition-colors duration-200',
                showPreview
                  ? platform === 'poster' ? 'bg-amber-500 text-white' : 'bg-purple-500 text-white'
                  : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
              )}
            >
              <Eye size={11} /> {showPreview ? '텍스트' : '미리보기'}
            </button>
          )}
          <button
            onClick={() => { setIsEditing(!isEditing); setEditContent(draft.content) }}
            className="flex items-center gap-1 px-2 py-1 bg-gray-100 text-gray-600 rounded-lg text-xs hover:bg-gray-200 transition-colors duration-200"
          >
            <Edit3 size={11} /> {isEditing ? '취소' : '편집'}
          </button>
          <CopyButton
            text={editContent + (draft.hashtags.length ? '\n\n' + draft.hashtags.join(' ') : '')}
            small
          />
          {/* Day 6-1: 3 템플릿 Canva 딥링크 (인스타 피드/스토리/가로 배너) */}
          <CanvaExport
            text={editContent + (draft.hashtags.length ? '\n\n' + draft.hashtags.join(' ') : '')}
            brandName={storeName}
            size="sm"
          />
        </div>
      </div>

      {/* 편집 모드 */}
      {isEditing ? (
        <div onClick={(e) => e.stopPropagation()}>
          <textarea
            value={editContent}
            onChange={(e) => setEditContent(e.target.value)}
            rows={6}
            className="w-full px-3 py-2 rounded-xl border border-gray-200 text-sm focus:outline-none focus:ring-2 focus:ring-[#D4A574] resize-none bg-white"
            autoFocus
          />
          <button
            onClick={() => setIsEditing(false)}
            className="mt-2 px-4 py-1.5 bg-[#D4A574] text-white rounded-xl text-xs font-medium hover:bg-[#c4956a] transition-colors duration-200"
          >
            저장
          </button>
        </div>
      ) : (
        <p className="text-sm text-gray-700 leading-relaxed whitespace-pre-line">
          {editContent}
        </p>
      )}

      {/* 해시태그 */}
      {draft.hashtags.length > 0 && !isEditing && (
        <div className="mt-3 flex flex-wrap gap-1">
          {draft.hashtags.map((tag) => (
            <span key={tag} className="text-xs text-blue-500 bg-blue-50 px-1.5 py-0.5 rounded-full">
              {tag}
            </span>
          ))}
        </div>
      )}

      {/* 플랫폼별 미리보기 */}
      {showPreview && platform === 'instagram_feed' && (
        <div className="mt-4" onClick={(e) => e.stopPropagation()}>
          <InstagramPreview content={editContent} hashtags={draft.hashtags} storeName={storeName} />
        </div>
      )}
      {showPreview && platform === 'poster' && (
        <div className="mt-4" onClick={(e) => e.stopPropagation()}>
          <PosterPreview content={editContent} storeName={storeName} index={index} />
          <div className="flex items-center justify-between mt-2 px-1">
            <p className="text-xs text-gray-400">💡 실제 포스터에는 이미지를 삽입하세요</p>
            <button
              onClick={() => {
                const extract = (tag: string) => {
                  const m = editContent.match(new RegExp(`\\[${tag}\\]\\s*([^\\[]+)`))
                  return m ? m[1].trim() : ''
                }
                downloadPosterCanvas(
                  extract('제목') || editContent.split('\n')[0],
                  extract('부제'), extract('본문'), extract('CTA'),
                  storeName, index
                )
              }}
              className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-amber-500 text-white text-xs font-medium hover:bg-amber-600 transition-colors duration-200"
            >
              <Download size={11} /> PNG 저장
            </button>
          </div>
        </div>
      )}

      {/* AI 배지 + 피드백 수집 */}
      <div className="mt-3 flex items-center justify-between gap-2 flex-wrap">
        <p className="text-xs text-gray-400 italic">ⓘ AI가 생성한 콘텐츠입니다</p>
        <AiFeedback
          sourceType="marketing_draft"
          sourceRef={`marketing-${platform}-${index}-${draft.char_count}`}
          compact
        />
      </div>
    </div>
  )
}

// ──────────────────────────────────────────────────────
// ─── SEO 점수 패널 ───
// ──────────────────────────────────────────────────────
function SeoScorePanel({ score }: { score: SeoScore }) {
  const checks = [
    { label: '제목 태그 포함', ok: score.hasTitle },
    { label: '소제목(##) 사용', ok: score.hasSections },
    { label: '2,000자 이상', ok: score.charCount >= 1800 },
    { label: '키워드 3회 이상 반복', ok: Object.values(score.keywordDensity).some((v) => v >= 3) },
  ]

  return (
    <div className="bg-white rounded-2xl border border-gray-100 p-4 shadow-sm">
      <div className="flex items-center gap-2 mb-4">
        <Search size={16} className="text-[#D4A574]" />
        <h3 className="font-bold text-[#2C1810] text-sm">SEO 점수 분석</h3>
        <div className="ml-auto">
          <span
            className={cn(
              'text-lg font-black',
              score.overallScore >= 80
                ? 'text-green-500'
                : score.overallScore >= 60
                ? 'text-amber-500'
                : 'text-red-400'
            )}
          >
            {score.overallScore}점
          </span>
          <span className="text-xs text-gray-400">/100</span>
        </div>
      </div>

      {/* 체크리스트 */}
      <div className="space-y-2 mb-4">
        {checks.map((c) => (
          <div key={c.label} className="flex items-center gap-2">
            <span className={c.ok ? 'text-green-500' : 'text-gray-300'}>
              {c.ok ? '✅' : '⬜'}
            </span>
            <span className={cn('text-xs', c.ok ? 'text-gray-700' : 'text-gray-400')}>
              {c.label}
            </span>
          </div>
        ))}
      </div>

      {/* 키워드 밀도 */}
      <div>
        <p className="text-xs font-semibold text-gray-600 mb-2">키워드 등장 횟수</p>
        <div className="space-y-1.5">
          {Object.entries(score.keywordDensity).map(([kw, count]) => (
            <div key={kw} className="flex items-center gap-2">
              <span className="text-xs text-gray-600 w-24 truncate">{kw}</span>
              <div className="flex-1 bg-gray-100 rounded-full h-1.5 overflow-hidden">
                <div
                  className={cn(
                    'h-1.5 rounded-full transition-all duration-500',
                    count >= 3 ? 'bg-green-400' : count >= 1 ? 'bg-amber-400' : 'bg-gray-300'
                  )}
                  style={{ width: `${Math.min(100, (count / 5) * 100)}%` }}
                />
              </div>
              <span className={cn('text-xs w-6 text-right', count >= 3 ? 'text-green-600' : 'text-amber-500')}>
                {count}회
              </span>
            </div>
          ))}
        </div>
      </div>

      <p className="text-xs text-gray-400 mt-3 italic">ⓘ AI가 생성한 콘텐츠입니다</p>
    </div>
  )
}

// ══════════════════════════════════════════════════════
// ─── 메인 MarketingPage ───
// ══════════════════════════════════════════════════════
export default function MarketingPage() {
  const { storeInfo } = useStoreContext()
  const storeName = storeInfo?.store_name ?? '우리 카페'
  const menuList = ['아이스 아메리카노', '카라멜 마키아토', '딸기 케이크', '바닐라 라떼', '콜드브루']

  // ─── 일반 생성 모드 상태 ───
  const [mode, setMode] = useState<'generate' | 'seo'>('generate')
  const [selectedPlatform, setSelectedPlatform] = useState('instagram_feed')
  const [promotionTarget, setPromotionTarget] = useState('new_menu')
  const [description, setDescription] = useState('')
  const [tone, setTone] = useState('emotional')
  const [targetAudience, setTargetAudience] = useState('mz_women')

  const [drafts, setDrafts] = useState<DraftItem[]>([])
  const [selectedDraft, setSelectedDraft] = useState<number | null>(null)
  const [isGenerating, setIsGenerating] = useState(false)
  const [genError, setGenError] = useState('')

  // ─── 트렌드 벤치마킹 상태 ───
  const [useTrend, setUseTrend] = useState(false)
  const [trendKeywords, setTrendKeywords] = useState<string[]>([])
  const [trendLoading, setTrendLoading] = useState(false)

  // 트렌드 토글 시 키워드 자동 로드
  useEffect(() => {
    if (!useTrend || trendKeywords.length > 0 || !storeInfo) return
    setTrendLoading(true)
    fetch('/api/v1/trends/briefing', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        store_name: storeInfo.store_name,
        district_type: storeInfo.district_type,
        ambiance_keywords: storeInfo.ambiance_keywords ?? [],
        top_menus: [],
      }),
    })
      .then(r => r.ok ? r.json() : null)
      .then(data => {
        if (data?.keywords) setTrendKeywords(data.keywords.map((k: { keyword: string }) => k.keyword))
      })
      .catch(() => {})
      .finally(() => setTrendLoading(false))
  }, [useTrend, storeInfo]) // eslint-disable-line react-hooks/exhaustive-deps

  // ─── SEO 모드 상태 ───
  const [seoKeywords, setSeoKeywords] = useState<string[]>(['', '', '', '', ''])
  const [seoDesc, setSeoDesc] = useState('')
  const [seoContent, setSeoContent] = useState('')
  const [seoScore, setSeoScore] = useState<SeoScore | null>(null)
  const [isSeoLoading, setIsSeoLoading] = useState(false)
  const [isRewriting, setIsRewriting] = useState(false)
  const [seoError, setSeoError] = useState('')
  const seoTextRef = useRef<HTMLTextAreaElement>(null)

  // ─── 시안 생성 ───
  const handleGenerate = async () => {
    if (!description.trim()) { setGenError('상세 설명을 입력해주세요'); return }
    setIsGenerating(true)
    setGenError('')
    setDrafts([])
    setSelectedDraft(null)
    try {
      const res = await fetch('/api/v1/marketing/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          platform: selectedPlatform,
          promotion_target: promotionTarget,
          description,
          tone,
          target_audience: targetAudience,
          store_name: storeName,
          menu_list: menuList,
          use_trend: useTrend,
          trend_keywords: trendKeywords,
        }),
      })
      if (!res.ok) throw new Error(`서버 오류: ${res.status}`)
      const data = await res.json()
      setDrafts(data.drafts)
    } catch (e) {
      const msg = e instanceof Error ? e.message : '오류'
      setGenError(msg.includes('Failed to fetch') ? '백엔드 서버를 먼저 시작해주세요 (uvicorn app.main:app)' : msg)
    } finally {
      setIsGenerating(false)
    }
  }

  // ─── SEO 초안 생성 ───
  const handleSeoGenerate = async (rewriteStyle?: 'essay') => {
    const validKeywords = seoKeywords.filter(Boolean)
    if (validKeywords.length < 2) { setSeoError('키워드를 최소 2개 입력해주세요'); return }
    if (!seoDesc.trim()) { setSeoError('주제 설명을 입력해주세요'); return }

    if (rewriteStyle) setIsRewriting(true)
    else setIsSeoLoading(true)
    setSeoError('')

    try {
      const res = await fetch('/api/v1/marketing/seo', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          keywords: validKeywords,
          description: rewriteStyle ? seoContent : seoDesc,
          store_name: storeName,
          rewrite_style: rewriteStyle ?? null,
        }),
      })
      if (!res.ok) throw new Error(`서버 오류: ${res.status}`)
      const data = await res.json()
      setSeoContent(data.content)

      // SEO 점수 계산
      const score: SeoScore = {
        keywordDensity: data.keyword_hits,
        hasTitle: data.content.includes('제목') || data.content.split('\n')[0].length > 10,
        hasSections: data.content.includes('##'),
        charCount: data.char_count,
        overallScore: Math.min(
          100,
          (data.char_count >= 1800 ? 25 : 0) +
          (data.content.includes('##') ? 25 : 0) +
          (Object.values(data.keyword_hits as Record<string, number>).some((v) => v >= 3) ? 30 : 10) +
          (data.content.split('\n')[0].length > 10 ? 20 : 0)
        ),
      }
      setSeoScore(score)
    } catch (e) {
      const msg = e instanceof Error ? e.message : '오류'
      setSeoError(msg.includes('Failed to fetch') ? '백엔드 서버를 먼저 시작해주세요' : msg)
    } finally {
      setIsSeoLoading(false)
      setIsRewriting(false)
    }
  }

  const platformInfo = PLATFORMS.find((p) => p.id === selectedPlatform)!

  return (
    <div className="min-h-screen bg-[#FAFAF8]">
      {/* 헤더 */}
      <header className="bg-[#2C1810] text-white px-4 py-3 flex items-center gap-3">
        <Link to="/dashboard" className="hover:text-[#D4A574] transition-colors duration-200">
          <ChevronLeft size={20} />
        </Link>
        <Megaphone size={18} className="text-[#D4A574]" />
        <h1 className="font-bold text-base flex-1">마케팅 콘텐츠 생성</h1>
        {/* 모드 토글 */}
        <div className="flex items-center gap-1 bg-[#3d2418] rounded-xl p-1">
          <button
            onClick={() => setMode('generate')}
            className={cn(
              'px-3 py-1 rounded-lg text-xs font-medium transition-all duration-200',
              mode === 'generate' ? 'bg-[#D4A574] text-white' : 'text-gray-300 hover:text-white'
            )}
          >
            <Megaphone size={11} className="inline mr-1" />콘텐츠
          </button>
          <button
            onClick={() => setMode('seo')}
            className={cn(
              'px-3 py-1 rounded-lg text-xs font-medium transition-all duration-200',
              mode === 'seo' ? 'bg-[#D4A574] text-white' : 'text-gray-300 hover:text-white'
            )}
          >
            <Search size={11} className="inline mr-1" />SEO
          </button>
        </div>
      </header>

      <main className="max-w-4xl mx-auto px-4 py-5 space-y-5">

        {/* ══════════ 일반 콘텐츠 생성 모드 ══════════ */}
        {mode === 'generate' && (
          <>
            {/* 플랫폼 선택 */}
            <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-4 space-y-3">
              <h2 className="text-sm font-bold text-[#2C1810] flex items-center gap-2">
                <Bell size={15} className="text-[#D4A574]" /> 플랫폼 선택
              </h2>

              {/* 주요 플랫폼 (인스타 게시물 + 포스터) */}
              <div>
                <p className="text-[10px] font-bold text-gray-400 uppercase tracking-wider mb-2">⭐ 주요 기능</p>
                <div className="grid grid-cols-2 gap-2">
                  {PLATFORMS.filter(p => p.featured).map((p) => {
                    const BrandIcon = p.BrandIcon
                    const selected = selectedPlatform === p.id
                    return (
                      <button
                        key={p.id}
                        onClick={() => setSelectedPlatform(p.id)}
                        className={cn(
                          'flex flex-col items-start gap-2 p-3.5 rounded-xl border-2 text-xs font-medium transition-all duration-200 text-left',
                          selected
                            ? `border-transparent bg-gradient-to-br ${p.color} text-white shadow-md`
                            : 'border-gray-100 text-gray-600 hover:border-gray-200 hover:bg-gray-50'
                        )}
                      >
                        {/* 브랜드 아이콘: 선택되면 흰 배지 위에 띄움 (브랜드 컬러 보존) */}
                        <span className={cn(
                          'inline-flex items-center justify-center rounded-xl transition-all',
                          selected
                            ? 'w-10 h-10 bg-white/95 shadow-sm'
                            : 'w-10 h-10 bg-white border border-gray-100'
                        )}>
                          <BrandIcon size={26} />
                        </span>
                        <span className="font-bold">{p.label}</span>
                        <span className={cn('text-[10px] leading-tight', selected ? 'text-white/85' : 'text-gray-400')}>
                          {p.hint}
                        </span>
                      </button>
                    )
                  })}
                </div>
              </div>

              {/* 추가 채널 */}
              <div>
                <p className="text-[10px] font-bold text-gray-400 uppercase tracking-wider mb-2">추가 채널</p>
                <div className="grid grid-cols-3 md:grid-cols-4 gap-2">
                  {PLATFORMS.filter(p => !p.featured).map((p) => {
                    const BrandIcon = p.BrandIcon
                    const selected = selectedPlatform === p.id
                    return (
                      <button
                        key={p.id}
                        onClick={() => setSelectedPlatform(p.id)}
                        className={cn(
                          'flex flex-col items-center gap-1.5 p-2.5 rounded-xl border-2 text-xs font-medium transition-all duration-200',
                          selected
                            ? `border-transparent bg-gradient-to-br ${p.color} text-white shadow-md`
                            : 'border-gray-100 text-gray-500 hover:border-gray-200 hover:bg-gray-50'
                        )}
                      >
                        <span className={cn(
                          'inline-flex items-center justify-center rounded-lg transition-all',
                          selected
                            ? 'w-8 h-8 bg-white/95 shadow-sm'
                            : 'w-8 h-8 bg-white border border-gray-100'
                        )}>
                          <BrandIcon size={20} />
                        </span>
                        <span className="text-center leading-tight text-[10px]">{p.label}</span>
                      </button>
                    )
                  })}

                  {/* 추후 지원 예정 */}
                  {COMING_SOON.map((p) => {
                    const BrandIcon = p.BrandIcon
                    return (
                      <div
                        key={p.id}
                        className="flex flex-col items-center gap-1.5 p-2.5 rounded-xl border-2 border-dashed border-gray-200 text-xs opacity-60 cursor-not-allowed relative"
                      >
                        <span className="inline-flex items-center justify-center w-8 h-8 bg-white border border-gray-100 rounded-lg">
                          <BrandIcon size={20} className="grayscale-[40%]" />
                        </span>
                        <span className="text-center leading-tight text-[10px] text-gray-400">{p.label}</span>
                        <span className="absolute -top-1.5 left-1/2 -translate-x-1/2 text-[8px] bg-gray-200 text-gray-500 px-1.5 py-0.5 rounded-full whitespace-nowrap font-bold">
                          예정
                        </span>
                      </div>
                    )
                  })}
                </div>
              </div>

              {platformInfo && (
                <p className="text-xs text-gray-400 text-center bg-gray-50 rounded-xl py-2">
                  💡 {platformInfo.hint}
                </p>
              )}
            </div>

            {/* 입력 폼 */}
            <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-4 space-y-4">
              <h2 className="text-sm font-bold text-[#2C1810] flex items-center gap-2">
                <FileText size={15} className="text-[#D4A574]" /> 콘텐츠 정보 입력
              </h2>

              {/* 홍보 대상 */}
              <div>
                <label className="block text-xs font-semibold text-gray-600 mb-2">홍보 대상</label>
                <div className="flex flex-wrap gap-2">
                  {PROMOTION_TARGETS.map((t) => (
                    <button
                      key={t.id}
                      onClick={() => setPromotionTarget(t.id)}
                      className={cn(
                        'flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-medium border transition-all duration-200',
                        promotionTarget === t.id
                          ? 'bg-[#2C1810] text-white border-[#2C1810]'
                          : 'border-gray-200 text-gray-600 hover:border-gray-300'
                      )}
                    >
                      {t.emoji} {t.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* 상세 설명 */}
              <div>
                <label className="block text-xs font-semibold text-gray-600 mb-2">
                  상세 설명 <span className="text-red-400">*</span>
                </label>
                <textarea
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="예) 오늘 신메뉴 딸기 케이크 출시! 국내산 딸기 100% 사용, 3/20부터 판매 시작, 가격 7,500원"
                  rows={3}
                  className="w-full px-3 py-2.5 rounded-xl border border-gray-200 text-sm focus:outline-none focus:ring-2 focus:ring-[#D4A574] resize-none placeholder:text-gray-300"
                />
              </div>

              {/* 톤 선택 */}
              <div>
                <label className="block text-xs font-semibold text-gray-600 mb-2">톤 선택</label>
                <div className="flex flex-wrap gap-2">
                  {TONES.map((t) => (
                    <button
                      key={t.id}
                      onClick={() => setTone(t.id)}
                      className={cn(
                        'flex items-center gap-1 px-3 py-1.5 rounded-full text-xs font-medium border transition-all duration-200',
                        tone === t.id
                          ? 'bg-[#D4A574] text-white border-[#D4A574]'
                          : 'border-gray-200 text-gray-600 hover:border-gray-300'
                      )}
                    >
                      {t.emoji} {t.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* 타깃 */}
              <div>
                <label className="block text-xs font-semibold text-gray-600 mb-2">타깃 고객층</label>
                <div className="flex flex-wrap gap-2">
                  {TARGETS.map((t) => (
                    <button
                      key={t.id}
                      onClick={() => setTargetAudience(t.id)}
                      className={cn(
                        'flex items-center gap-1 px-3 py-1.5 rounded-full text-xs font-medium border transition-all duration-200',
                        targetAudience === t.id
                          ? 'bg-[#2C1810] text-white border-[#2C1810]'
                          : 'border-gray-200 text-gray-600 hover:border-gray-300'
                      )}
                    >
                      {t.emoji} {t.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* 트렌드 벤치마킹 토글 */}
              <div className={cn(
                'flex items-center justify-between p-3 rounded-xl border-2 transition-all duration-200 cursor-pointer',
                useTrend ? 'border-orange-300 bg-orange-50' : 'border-gray-100 bg-gray-50'
              )} onClick={() => setUseTrend(!useTrend)}>
                <div className="flex items-center gap-2">
                  <div className={cn('w-8 h-8 rounded-xl flex items-center justify-center', useTrend ? 'bg-orange-500' : 'bg-gray-300')}>
                    <TrendingUp size={14} className="text-white" />
                  </div>
                  <div>
                    <p className={cn('text-xs font-bold', useTrend ? 'text-orange-700' : 'text-gray-600')}>
                      트렌드 벤치마킹
                    </p>
                    <p className="text-[10px] text-gray-400">SNS·유튜브 바이럴 형식 참고</p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  {trendLoading && <Loader2 size={12} className="animate-spin text-orange-500" />}
                  {useTrend && trendKeywords.length > 0 && (
                    <div className="flex gap-1 flex-wrap justify-end max-w-32">
                      {trendKeywords.slice(0, 3).map(kw => (
                        <span key={kw} className="text-[9px] bg-orange-100 text-orange-700 px-1.5 py-0.5 rounded-full">{kw}</span>
                      ))}
                    </div>
                  )}
                  <div className={cn(
                    'w-10 h-5 rounded-full transition-all duration-200 relative shrink-0',
                    useTrend ? 'bg-orange-500' : 'bg-gray-300'
                  )}>
                    <div className={cn(
                      'absolute top-0.5 w-4 h-4 bg-white rounded-full shadow transition-all duration-200',
                      useTrend ? 'left-5' : 'left-0.5'
                    )} />
                  </div>
                </div>
              </div>

              {/* 생성 버튼 */}
              {genError && (
                <div className="flex items-center gap-2 p-3 bg-orange-50 border border-orange-200 rounded-xl text-sm text-orange-700">
                  <AlertCircle size={15} />
                  <span>{genError}</span>
                  <button onClick={() => setGenError('')} className="ml-auto text-orange-400 hover:text-orange-600">✕</button>
                </div>
              )}
              <button
                onClick={handleGenerate}
                disabled={isGenerating}
                className={cn(
                  'w-full py-3 text-white rounded-xl font-semibold text-sm hover:opacity-90 transition-all duration-200 disabled:opacity-50 flex items-center justify-center gap-2 shadow-md',
                  useTrend
                    ? 'bg-gradient-to-r from-orange-600 to-amber-500'
                    : 'bg-gradient-to-r from-[#2C1810] to-[#D4A574]'
                )}
              >
                {isGenerating
                  ? <><Loader2 size={16} className="animate-spin" /> 시안 3개 생성 중...</>
                  : useTrend
                    ? <><Zap size={16} /> 트렌드 반영 시안 3개 생성</>
                    : <><Sparkles size={16} /> AI 시안 3개 생성</>}
              </button>
            </div>

            {/* 생성 중 스켈레톤 */}
            {isGenerating && (
              <div>
                <p className="text-xs text-gray-400 mb-3 flex items-center gap-2">
                  <Loader2 size={12} className="animate-spin text-[#D4A574]" />
                  AI가 시안 3개를 동시 생성 중입니다...
                </p>
                <div className="grid gap-4 md:grid-cols-3 grid-cols-1">
                  {[0, 1, 2].map(i => (
                    <div key={i} className="bg-white rounded-2xl border border-gray-100 p-4 space-y-3 animate-pulse">
                      <div className="h-3 bg-gray-100 rounded w-16" />
                      <div className="space-y-2">
                        <div className="h-2 bg-gray-100 rounded" />
                        <div className="h-2 bg-gray-100 rounded w-5/6" />
                        <div className="h-2 bg-gray-100 rounded w-4/6" />
                        <div className="h-2 bg-gray-100 rounded w-5/6" />
                      </div>
                      <div className="flex gap-1 flex-wrap pt-1">
                        {[60, 80, 70].map((w, j) => (
                          <div key={j} className="h-5 bg-gray-100 rounded-full" style={{ width: `${w}px` }} />
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* 시안 카드 그리드 */}
            {drafts.length > 0 && !isGenerating && (
              <div>
                <div className="flex items-center gap-2 mb-3">
                  <h2 className="text-sm font-bold text-[#2C1810]">생성된 시안 3개</h2>
                  {(() => {
                    const PlatformBrandIcon = platformInfo.BrandIcon
                    return (
                      <span className={cn('inline-flex items-center gap-1.5 text-xs px-2 py-0.5 rounded-full', platformInfo.badge)}>
                        <PlatformBrandIcon size={14} />
                        {platformInfo.label}
                      </span>
                    )
                  })()}
                  <button
                    onClick={handleGenerate}
                    className="ml-auto flex items-center gap-1 text-xs text-gray-400 hover:text-[#D4A574] transition-colors duration-200"
                  >
                    <RotateCcw size={12} /> 재생성
                  </button>
                </div>
                <div className={cn(
                  'grid gap-4',
                  selectedPlatform === 'naver_blog' ? 'grid-cols-1' : 'md:grid-cols-3 grid-cols-1'
                )}>
                  {drafts.map((draft, i) => (
                    <DraftCard
                      key={i}
                      draft={draft}
                      index={i}
                      platform={selectedPlatform}
                      storeName={storeName}
                      isSelected={selectedDraft === i}
                      onSelect={() => setSelectedDraft(selectedDraft === i ? null : i)}
                    />
                  ))}
                </div>

                {/* 선택된 시안 전체 복사 */}
                {selectedDraft !== null && (
                  <div className="mt-4 p-4 bg-[#2C1810] rounded-2xl flex items-center gap-3">
                    <div className="flex-1">
                      <p className="text-white text-sm font-semibold">
                        시안 {['A', 'B', 'C'][selectedDraft]} 선택됨
                      </p>
                      <p className="text-gray-300 text-xs">바로 복사하여 SNS에 붙여넣기하세요</p>
                    </div>
                    <CopyButton
                      text={
                        drafts[selectedDraft].content +
                        (drafts[selectedDraft].hashtags.length
                          ? '\n\n' + drafts[selectedDraft].hashtags.join(' ')
                          : '')
                      }
                    />
                  </div>
                )}
              </div>
            )}
          </>
        )}

        {/* ══════════ SEO 블로그 모드 ══════════ */}
        {mode === 'seo' && (
          <>
            <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-4 space-y-4">
              <div className="flex items-center gap-2 mb-1">
                <Search size={16} className="text-[#D4A574]" />
                <h2 className="text-sm font-bold text-[#2C1810]">SEO 소개글 전용 모드</h2>
                <span className="text-xs px-2 py-0.5 rounded-full bg-green-100 text-green-700">
                  네이버 블로그 최적화
                </span>
              </div>
              <p className="text-xs text-gray-400">
                키워드 5개 입력 → 2,000자 블로그 초안 생성 → 에세이 스타일로 리라이트
              </p>

              {/* 키워드 입력 */}
              <div>
                <label className="block text-xs font-semibold text-gray-600 mb-2">
                  SEO 핵심 키워드 (최대 5개)
                </label>
                <div className="grid grid-cols-2 md:grid-cols-5 gap-2">
                  {seoKeywords.map((kw, i) => (
                    <input
                      key={i}
                      value={kw}
                      onChange={(e) => {
                        const newKws = [...seoKeywords]
                        newKws[i] = e.target.value
                        setSeoKeywords(newKws)
                      }}
                      placeholder={['카페', '커피', '에스프레소', '핸드드립', '분위기'][i]}
                      className="px-3 py-2 rounded-xl border border-gray-200 text-sm focus:outline-none focus:ring-2 focus:ring-[#D4A574] placeholder:text-gray-200"
                    />
                  ))}
                </div>
              </div>

              {/* 주제 설명 */}
              <div>
                <label className="block text-xs font-semibold text-gray-600 mb-2">
                  블로그 주제 설명 <span className="text-red-400">*</span>
                </label>
                <textarea
                  value={seoDesc}
                  onChange={(e) => setSeoDesc(e.target.value)}
                  placeholder="예) 서울 연남동에 위치한 코지한 카페. 핸드드립 커피와 국내산 딸기를 활용한 시즌 케이크가 시그니처."
                  rows={3}
                  className="w-full px-3 py-2.5 rounded-xl border border-gray-200 text-sm focus:outline-none focus:ring-2 focus:ring-[#D4A574] resize-none placeholder:text-gray-300"
                />
              </div>

              {/* 오류 */}
              {seoError && (
                <div className="flex items-center gap-2 p-3 bg-orange-50 border border-orange-200 rounded-xl text-sm text-orange-700">
                  <AlertCircle size={15} />
                  <span>{seoError}</span>
                  <button onClick={() => setSeoError('')} className="ml-auto text-orange-400">✕</button>
                </div>
              )}

              {/* 생성 버튼 */}
              <button
                onClick={() => handleSeoGenerate()}
                disabled={isSeoLoading || isRewriting}
                className="w-full py-3 bg-gradient-to-r from-green-600 to-emerald-600 text-white rounded-xl font-semibold text-sm hover:opacity-90 transition-opacity duration-200 disabled:opacity-50 flex items-center justify-center gap-2 shadow-md"
              >
                {isSeoLoading
                  ? <><Loader2 size={16} className="animate-spin" /> SEO 블로그 초안 생성 중...</>
                  : <><BookOpen size={16} /> SEO 블로그 초안 생성</>}
              </button>
            </div>

            {/* SEO 결과 */}
            {seoContent && (
              <>
                <div className="grid md:grid-cols-3 gap-4">
                  {/* 블로그 본문 */}
                  <div className="md:col-span-2 bg-white rounded-2xl border border-gray-100 shadow-sm p-4">
                    <div className="flex items-center justify-between mb-3">
                      <h3 className="font-bold text-[#2C1810] text-sm flex items-center gap-2">
                        <BookOpen size={14} className="text-green-500" />
                        SEO 블로그 초안
                        <span className="text-xs text-gray-400 font-normal">({seoContent.length}자)</span>
                      </h3>
                      <div className="flex items-center gap-2">
                        <button
                          onClick={() => handleSeoGenerate('essay')}
                          disabled={isRewriting || isSeoLoading}
                          className="flex items-center gap-1.5 px-3 py-1.5 bg-purple-600 text-white rounded-lg text-xs font-medium hover:bg-purple-700 transition-colors duration-200 disabled:opacity-50"
                        >
                          {isRewriting
                            ? <><Loader2 size={11} className="animate-spin" /> 리라이트 중...</>
                            : <><Edit3 size={11} /> 작가 스타일로 다듬기</>}
                        </button>
                        <CopyButton text={seoContent} small />
                      </div>
                    </div>
                    <textarea
                      ref={seoTextRef}
                      value={seoContent}
                      onChange={(e) => setSeoContent(e.target.value)}
                      rows={20}
                      className="w-full px-3 py-2.5 rounded-xl border border-gray-200 text-sm focus:outline-none focus:ring-2 focus:ring-[#D4A574] resize-none font-mono leading-relaxed"
                    />
                    <p className="text-xs text-gray-400 mt-2 italic">ⓘ AI가 생성한 콘텐츠입니다</p>
                  </div>

                  {/* SEO 점수 */}
                  {seoScore && <SeoScorePanel score={seoScore} />}
                </div>
              </>
            )}
          </>
        )}
      </main>
    </div>
  )
}
