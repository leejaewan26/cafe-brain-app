"""
Launch A7 헬스 프로브 검증.
liveness/readiness 분리가 잘 동작하는지.
"""


def test_liveness_returns_200(client):
    r = client.get("/liveness")
    assert r.status_code == 200
    assert r.json()["status"] == "alive"


def test_health_returns_200(client):
    r = client.get("/health")
    assert r.status_code == 200
    body = r.json()
    assert body["status"] == "ok"
    assert body["service"] == "cafe-brain-api"


def test_readiness_503_when_no_gemini_key(client):
    """GEMINI_API_KEY 없으면 readiness=503 (conftest.py가 빈 키 세팅함)."""
    r = client.get("/readiness")
    assert r.status_code == 503
    body = r.json()
    assert body["status"] == "not_ready"
    assert "GEMINI_API_KEY" in body["missing_config"]


def test_health_deep_no_external_calls(client):
    """deep healthcheck는 외부 호출이 skip 처리되어도 200을 반환해야."""
    r = client.get("/health/deep")
    assert r.status_code == 200
    body = r.json()
    assert "checks" in body
    # gemini·supabase 둘 다 키 없으니 skip 상태
    assert body["checks"]["gemini"]["status"] == "skip"
    assert body["checks"]["supabase"]["status"] == "skip"
