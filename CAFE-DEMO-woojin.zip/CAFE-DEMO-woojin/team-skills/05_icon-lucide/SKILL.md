---
name: icon-lucide
description: This skill should be used when the user asks to add icons to a UI, find the right icon name, use Lucide icons in React/Vue/Svelte/Angular, replace icon libraries, pick icons for buttons or navigation, or when building any UI component that needs icons. Activates on phrases like "아이콘", "icon", "lucide", "lucide-react", "svg icon", "버튼 아이콘", "네비게이션 아이콘".
version: 1.0.0
---

# Lucide Icon Library Skill

1000+ open-source SVG icons, beautifully consistent, for React, Vue, Svelte, Angular, and vanilla JS/TS.

> Based on: https://github.com/lucide-icons/lucide

## When This Skill Applies

Activate when the user needs to:
- Add icons to any UI component
- Find the correct Lucide icon name for a use case
- Install or configure lucide for their framework
- Replace other icon libraries (Font Awesome, Heroicons, etc.)
- Use icons in Figma (via Lucide Figma plugin)

---

## Installation by Framework

```bash
# React
npm install lucide-react

# Vue 3
npm install lucide-vue-next

# Svelte
npm install lucide-svelte

# Angular
npm install lucide-angular

# Solid
npm install lucide-solid

# Vanilla JS
npm install lucide
```

---

## Usage

### React
```tsx
import { Home, Settings, Bell, Search, X, ChevronRight } from 'lucide-react'

// Basic usage
<Home />

// With props
<Home size={24} color="#6366f1" strokeWidth={1.5} />

// As button icon
<button className="flex items-center gap-2">
  <Settings size={16} />
  Settings
</button>
```

### Vue 3
```vue
<script setup>
import { Home, Settings } from 'lucide-vue-next'
</script>

<template>
  <Home :size="24" color="#6366f1" />
</template>
```

### Svelte
```svelte
<script>
  import { Home } from 'lucide-svelte'
</script>

<Home size={24} />
```

---

## Icon Props

| Prop | Type | Default | Description |
|------|------|---------|-------------|
| `size` | number \| string | 24 | Width and height in px |
| `color` | string | currentColor | Stroke color (CSS color or `currentColor`) |
| `strokeWidth` | number | 2 | SVG stroke width |
| `absoluteStrokeWidth` | boolean | false | Keep stroke width consistent regardless of size |
| `className` | string | — | CSS class (React) |

> Tip: Use `color="currentColor"` (default) to inherit text color from parent — great for theming.

---

## Common Icon Reference

### Navigation & UI
| Use Case | Icon Name |
|----------|-----------|
| Home | `Home` |
| Back | `ArrowLeft`, `ChevronLeft` |
| Forward | `ArrowRight`, `ChevronRight` |
| Menu (hamburger) | `Menu` |
| Close / X | `X` |
| Search | `Search` |
| Settings | `Settings`, `SlidersHorizontal` |
| More options | `MoreHorizontal`, `MoreVertical` |
| Expand | `ChevronDown`, `ChevronsUpDown` |
| External link | `ExternalLink` |

### Actions
| Use Case | Icon Name |
|----------|-----------|
| Add / New | `Plus`, `PlusCircle` |
| Delete | `Trash2`, `Trash` |
| Edit | `Pencil`, `Edit2` |
| Save | `Save` |
| Copy | `Copy` |
| Download | `Download` |
| Upload | `Upload` |
| Share | `Share2` |
| Refresh | `RefreshCw`, `RotateCcw` |
| Filter | `Filter`, `ListFilter` |
| Sort | `ArrowUpDown` |

### Status & Feedback
| Use Case | Icon Name |
|----------|-----------|
| Success | `CheckCircle2`, `Check` |
| Error | `XCircle`, `AlertCircle` |
| Warning | `AlertTriangle`, `OctagonAlert` |
| Info | `Info` |
| Loading | `Loader`, `Loader2` |
| Notification | `Bell`, `BellRing` |

### Files & Data
| Use Case | Icon Name |
|----------|-----------|
| File | `File`, `FileText` |
| Folder | `Folder`, `FolderOpen` |
| Image | `Image`, `ImagePlus` |
| Video | `Video` |
| Code | `Code`, `Code2` |
| Database | `Database` |
| Chart | `BarChart2`, `LineChart`, `PieChart` |

### Communication
| Use Case | Icon Name |
|----------|-----------|
| Email | `Mail` |
| Message | `MessageSquare`, `MessageCircle` |
| Phone | `Phone` |
| User | `User`, `UserCircle` |
| Users (group) | `Users` |

### E-commerce
| Use Case | Icon Name |
|----------|-----------|
| Cart | `ShoppingCart` |
| Bag | `ShoppingBag` |
| Payment | `CreditCard` |
| Tag/Price | `Tag`, `Tags` |
| Star/Rating | `Star` |
| Heart/Wishlist | `Heart` |

### Tech & Dev
| Use Case | Icon Name |
|----------|-----------|
| GitHub | `Github` |
| Terminal | `Terminal` |
| CPU | `Cpu` |
| Server | `Server` |
| Globe/Web | `Globe` |
| Lock/Security | `Lock`, `ShieldCheck` |
| Key | `Key` |
| API/Webhook | `Webhook` |
| Bug | `Bug` |

---

## Search Tips

Can't find the right icon? Search at https://lucide.dev/icons

- Search by concept: "arrow", "check", "circle", "alert"
- Search by use case: "camera", "map", "calendar", "clock"
- Browse by category on the website

---

## Styling with Tailwind CSS

```tsx
// Size via className
<Search className="w-4 h-4" />
<Search className="w-6 h-6" />

// Color via text color
<CheckCircle2 className="text-green-500" />
<AlertCircle className="text-red-500" />
<Info className="text-blue-400" />

// Stroke width
<Home strokeWidth={1} />   // thin
<Home strokeWidth={2} />   // default
<Home strokeWidth={2.5} /> // bold
```

---

## Creating an Icon Button Component (React)

```tsx
import { LucideIcon } from 'lucide-react'

interface IconButtonProps {
  icon: LucideIcon
  label: string
  onClick?: () => void
  variant?: 'ghost' | 'solid'
  size?: 'sm' | 'md' | 'lg'
}

const sizeMap = { sm: 14, md: 16, lg: 20 }

export function IconButton({ icon: Icon, label, onClick, variant = 'ghost', size = 'md' }: IconButtonProps) {
  return (
    <button
      onClick={onClick}
      aria-label={label}
      className={`inline-flex items-center justify-center rounded-md p-1.5
        ${variant === 'ghost' ? 'hover:bg-gray-100' : 'bg-gray-900 text-white hover:bg-gray-700'}`}
    >
      <Icon size={sizeMap[size]} />
    </button>
  )
}
```

---

## Dynamic Icons

```tsx
import * as icons from 'lucide-react'

// Render icon by string name
function DynamicIcon({ name, ...props }: { name: string } & LucideProps) {
  const Icon = (icons as Record<string, LucideIcon>)[name]
  if (!Icon) return null
  return <Icon {...props} />
}

// Usage
<DynamicIcon name="Home" size={24} />
<DynamicIcon name="Settings" size={24} color="red" />
```
