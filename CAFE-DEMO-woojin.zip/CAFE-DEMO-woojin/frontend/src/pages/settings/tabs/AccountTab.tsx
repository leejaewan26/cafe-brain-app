// 설정 > 계정 탭
import { useState } from 'react'
import { LogOut, Trash2, Mail, Shield, AlertTriangle, Download, Loader2 } from 'lucide-react'
import toast from 'react-hot-toast'
import { useAuth } from '@/hooks/useAuth'
import { supabase } from '@/lib/supabase'
import { useAuthStore } from '@/store/authStore'

export default function AccountTab() {
  const { user, signOut } = useAuth()
  const reset = useAuthStore((s) => s.reset)
  const [deleting, setDeleting] = useState(false)
  const [exporting, setExporting] = useState(false)

  // F6 — 본인 데이터 ZIP 다운로드 (GDPR/PIPA 데이터 이동권)
  const handleExport = async () => {
    if (!user) return
    setExporting(true)
    try {
      const r = await fetch('/api/v1/data/export', {
        headers: { 'X-Store-Id': user.id },
      })
      if (!r.ok) throw new Error('export 실패')
      const blob = await r.blob()
      const url = URL.createObjectURL(blob)
      const a = document.createElement('a')
      a.href = url
      a.download = `cafe-brain-data-${new Date().toISOString().slice(0, 10)}.zip`
      a.click()
      URL.revokeObjectURL(url)
      toast.success('데이터 ZIP 다운로드 완료 ✨')
    } catch (e) {
      toast.error(e instanceof Error ? e.message : '내보내기 실패')
    } finally {
      setExporting(false)
    }
  }

  const handleDelete = async () => {
    if (!user) return
    const confirmText = '삭제'
    const input = prompt(
      `⚠️ 계정 삭제 안내\n\n` +
      `1단계: 매장·리뷰·매출 등 서비스 데이터가 즉시 영구 삭제됩니다.\n` +
      `2단계: 이메일 계정 자체는 보안상 Supabase Auth에서 직접 삭제되지 않습니다.\n` +
      `     → 완전 삭제를 원하시면 서비스 운영진에 요청해주세요.\n\n` +
      `서비스 데이터만 즉시 삭제하려면 "${confirmText}"를 입력하세요:`
    )
    if (input !== confirmText) return

    setDeleting(true)
    try {
      // Supabase Auth user 삭제는 service_role 키가 필요하므로 백엔드 RPC 또는
      // 관리자 작업으로 분리. 여기선 서비스 데이터 제거 + 세션 파기.
      const { error: dbError } = await supabase.from('stores').delete().eq('id', user.id)
      if (dbError) throw dbError

      await supabase.auth.signOut()
      reset()
      toast.success(
        '서비스 데이터가 삭제되었어요. 이메일 계정 완전 삭제는 고객센터에 요청해주세요.',
        { duration: 6000 }
      )
      window.location.href = '/login'
    } catch (e) {
      const msg = e instanceof Error ? e.message : '삭제 실패'
      toast.error(`계정 삭제 실패: ${msg}`)
    } finally {
      setDeleting(false)
    }
  }

  return (
    <div className="space-y-6">
      {/* 계정 정보 */}
      <section className="bg-white rounded-2xl p-5 border border-gray-100 shadow-sm">
        <h3 className="font-bold text-[#2C1810] mb-4 flex items-center gap-2">
          <Shield size={16} className="text-[#D4A574]" />
          계정 정보
        </h3>
        <div className="space-y-3">
          <div className="flex items-center gap-3 p-3 bg-[#FAFAF8] rounded-xl">
            <Mail size={15} className="text-gray-400" />
            <div className="flex-1 min-w-0">
              <p className="text-xs text-gray-400">이메일</p>
              <p className="text-sm font-medium text-[#2C1810] truncate">
                {user?.email ?? '—'}
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* 로그아웃 */}
      <section className="bg-white rounded-2xl p-5 border border-gray-100 shadow-sm">
        <button
          onClick={signOut}
          className="w-full flex items-center justify-center gap-2 py-2.5 border border-gray-200 rounded-xl text-sm font-medium text-gray-600 hover:bg-gray-50 transition-colors duration-200"
        >
          <LogOut size={14} /> 로그아웃
        </button>
      </section>

      {/* F6: 데이터 내보내기 (GDPR 데이터 이동권) */}
      <section className="bg-white rounded-2xl p-5 border border-gray-100 shadow-sm">
        <div className="flex items-start gap-2 mb-3">
          <Download size={16} className="text-[#4A90A4] mt-0.5" />
          <div>
            <h3 className="font-bold text-[#2C1810] text-sm">내 데이터 다운로드</h3>
            <p className="text-xs text-gray-500 mt-0.5 leading-relaxed">
              매장·매출·메모리·리뷰·감사로그 등 본인 데이터 전체를 ZIP으로 받아갑니다 (PIPA 데이터 이동권).
            </p>
          </div>
        </div>
        <button
          onClick={handleExport}
          disabled={exporting}
          className="w-full flex items-center justify-center gap-2 py-2.5 bg-[#4A90A4] text-white rounded-xl text-sm font-semibold hover:bg-[#3A7A8A] transition-colors disabled:opacity-50"
        >
          {exporting ? <><Loader2 size={14} className="animate-spin" /> 압축 중…</> : <><Download size={14} /> ZIP 다운로드</>}
        </button>
      </section>

      {/* 위험 구역 */}
      <section className="bg-red-50/50 rounded-2xl p-5 border border-red-100">
        <div className="flex items-start gap-2 mb-3">
          <AlertTriangle size={16} className="text-red-500 mt-0.5 shrink-0" />
          <div>
            <h3 className="font-bold text-red-600 text-sm">계정 삭제</h3>
            <p className="text-xs text-red-500 mt-0.5">
              매장 정보, 직원, 리뷰, 매출 등 모든 데이터가 영구 삭제됩니다. 복구할 수 없습니다.
            </p>
          </div>
        </div>
        <button
          onClick={handleDelete}
          disabled={deleting}
          className="w-full flex items-center justify-center gap-2 py-2.5 border border-red-200 rounded-xl text-sm font-medium text-red-600 hover:bg-red-100 transition-colors duration-200 disabled:opacity-50"
        >
          <Trash2 size={14} /> {deleting ? '삭제 중...' : '계정 삭제'}
        </button>
      </section>
    </div>
  )
}
