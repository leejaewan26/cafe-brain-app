-- ══════════════════════════════════════════════════════════════════════
-- Phase 6 Round 3 — 운영·보안 인프라
-- #11 Agent action audit log
-- #13 Response time SLO 추적
-- #14 사용자 정의 이상치 감지 룰
-- ══════════════════════════════════════════════════════════════════════

-- ──────────────────────────────────────────────────────────
-- #11. agent_audit_log — 누가, 언제, 무엇을 했는가
-- ──────────────────────────────────────────────────────────
-- 기록 대상:
--   memory_delete    — 메모리 삭제 (망각권)
--   memory_create    — 수동 메모리 추가
--   feedback         — AI 제안에 대한 반응
--   learning_toggle  — 학습 on/off 변경
--   profile_switch   — owner ↔ manager 전환
--   anomaly_rule_*   — 룰 추가·수정·삭제
CREATE TABLE IF NOT EXISTS public.agent_audit_log (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  store_id    uuid NOT NULL REFERENCES public.stores(id) ON DELETE CASCADE,
  actor_id    uuid,                    -- auth.users.id (NULL=시스템)
  actor_role  text,                    -- 'owner' | 'manager' | 'system'
  action      text NOT NULL,           -- memory_delete, learning_toggle 등
  target_type text,                    -- 'memory' | 'rule' | 'setting'
  target_id   text,                    -- 대상 식별자 (uuid 또는 키)
  before      jsonb,                   -- 변경 전 상태 (삭제된 메모리 본문 등)
  after       jsonb,                   -- 변경 후 상태
  ip          text,                    -- 요청 IP
  user_agent  text,                    -- UA 첫 200자
  created_at  timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_audit_store_time
  ON public.agent_audit_log(store_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_audit_action
  ON public.agent_audit_log(store_id, action, created_at DESC);

ALTER TABLE public.agent_audit_log ENABLE ROW LEVEL SECURITY;

-- 매장 소속 사용자만 자기 매장 로그 SELECT (다른 매장은 가려짐)
DROP POLICY IF EXISTS "audit_select_own_store" ON public.agent_audit_log;
CREATE POLICY "audit_select_own_store"
  ON public.agent_audit_log FOR SELECT
  USING (
    store_id IN (
      SELECT id FROM public.stores WHERE user_id = auth.uid()
    )
  );

-- INSERT는 service_role(서버)만 — 클라이언트 직접 INSERT 차단
DROP POLICY IF EXISTS "audit_insert_service" ON public.agent_audit_log;
CREATE POLICY "audit_insert_service"
  ON public.agent_audit_log FOR INSERT
  WITH CHECK (auth.role() = 'service_role');

COMMENT ON TABLE public.agent_audit_log IS
  'Phase 6 #11: 에이전트 관련 사용자/시스템 행위 감사 로그 (GDPR·내부 감사)';


-- ──────────────────────────────────────────────────────────
-- #13. agent_latency_log — 응답시간 SLO 추적
-- ──────────────────────────────────────────────────────────
-- 모든 AI 엔드포인트의 응답시간을 기록 → 일별 p50/p95/p99 집계 가능
CREATE TABLE IF NOT EXISTS public.agent_latency_log (
  id          bigserial PRIMARY KEY,
  store_id    uuid REFERENCES public.stores(id) ON DELETE SET NULL,
  endpoint    text NOT NULL,           -- 예: '/api/agent/briefing'
  method      text NOT NULL DEFAULT 'POST',
  duration_ms int NOT NULL,            -- 처리 시간 (밀리초)
  status_code int,
  cache_hit   boolean DEFAULT false,
  cost_krw    numeric(10, 4),          -- 이 요청 추정 비용 (선택)
  created_at  timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_latency_endpoint_time
  ON public.agent_latency_log(endpoint, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_latency_store_time
  ON public.agent_latency_log(store_id, created_at DESC)
  WHERE store_id IS NOT NULL;

-- 30일 이상 된 latency 로그 자동 정리 (별도 cron에서 호출)
CREATE OR REPLACE FUNCTION public.cleanup_old_latency_logs()
RETURNS int AS $cleanup$
DECLARE
  v_deleted int;
BEGIN
  DELETE FROM public.agent_latency_log
  WHERE created_at < now() - interval '30 days';
  GET DIAGNOSTICS v_deleted = ROW_COUNT;
  RETURN v_deleted;
END;
$cleanup$ LANGUAGE plpgsql;

ALTER TABLE public.agent_latency_log ENABLE ROW LEVEL SECURITY;

-- 본인 매장 latency 만 조회
DROP POLICY IF EXISTS "latency_select_own_store" ON public.agent_latency_log;
CREATE POLICY "latency_select_own_store"
  ON public.agent_latency_log FOR SELECT
  USING (
    store_id IS NULL
    OR store_id IN (SELECT id FROM public.stores WHERE user_id = auth.uid())
  );

DROP POLICY IF EXISTS "latency_insert_service" ON public.agent_latency_log;
CREATE POLICY "latency_insert_service"
  ON public.agent_latency_log FOR INSERT
  WITH CHECK (auth.role() = 'service_role');


-- SLO 집계 RPC — 최근 7일/30일 p50/p95/p99
CREATE OR REPLACE FUNCTION public.compute_slo_percentiles(
  p_store_id uuid DEFAULT NULL,
  p_endpoint text DEFAULT NULL,
  p_window_days int DEFAULT 7
)
RETURNS TABLE (
  endpoint text,
  total_calls bigint,
  cache_hit_rate numeric,
  p50_ms numeric,
  p95_ms numeric,
  p99_ms numeric,
  total_cost_krw numeric
) AS $func$
BEGIN
  RETURN QUERY
  SELECT
    l.endpoint,
    count(*)::bigint AS total_calls,
    (count(*) FILTER (WHERE l.cache_hit))::numeric / NULLIF(count(*), 0) AS cache_hit_rate,
    percentile_cont(0.50) WITHIN GROUP (ORDER BY l.duration_ms)::numeric AS p50_ms,
    percentile_cont(0.95) WITHIN GROUP (ORDER BY l.duration_ms)::numeric AS p95_ms,
    percentile_cont(0.99) WITHIN GROUP (ORDER BY l.duration_ms)::numeric AS p99_ms,
    coalesce(sum(l.cost_krw), 0)::numeric AS total_cost_krw
  FROM public.agent_latency_log l
  WHERE l.created_at > now() - (p_window_days || ' days')::interval
    AND (p_store_id IS NULL OR l.store_id = p_store_id)
    AND (p_endpoint IS NULL OR l.endpoint = p_endpoint)
  GROUP BY l.endpoint
  ORDER BY total_calls DESC;
END;
$func$ LANGUAGE plpgsql STABLE SECURITY DEFINER;

COMMENT ON FUNCTION public.compute_slo_percentiles IS
  'Phase 6 #13: 엔드포인트별 응답시간 백분위 + 캐시 적중률 집계';


-- ──────────────────────────────────────────────────────────
-- #14. agent_anomaly_rules — 사용자 정의 이상치 룰
-- ──────────────────────────────────────────────────────────
-- 기존 하드코딩된 -20% 매출 감소 트리거를 사장님이 직접 정의 가능하게.
-- 예시 룰:
--   "주말 매출이 평일 평균 대비 -30%면 알림"
--   "리뷰 평점이 4.0 이하로 떨어지면 알림"
--   "특정 메뉴 판매가 전주 대비 -50%면 알림"
CREATE TABLE IF NOT EXISTS public.agent_anomaly_rules (
  id           uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  store_id     uuid NOT NULL REFERENCES public.stores(id) ON DELETE CASCADE,
  name         text NOT NULL,                 -- "주말 매출 급감"
  metric       text NOT NULL,                 -- 'sales' | 'orders' | 'review_score' | 'menu_sales'
  metric_param text,                          -- menu_sales일 경우 메뉴ID
  comparator   text NOT NULL DEFAULT 'pct_change',  -- 'pct_change' | 'abs_lt' | 'abs_gt'
  threshold    numeric NOT NULL,              -- -30 (== -30%) 또는 4.0
  window_type  text NOT NULL DEFAULT 'today_vs_week_avg',
  -- 'today_vs_week_avg' | 'week_vs_prev_week' | 'today_abs'
  enabled      boolean NOT NULL DEFAULT true,
  channel      text NOT NULL DEFAULT 'briefing',  -- 'briefing' | 'push' | 'both'
  cooldown_h   int NOT NULL DEFAULT 24,       -- 같은 룰 재발화 최소 간격
  last_fired_at timestamptz,
  created_by   uuid,                          -- auth.users.id
  created_at   timestamptz NOT NULL DEFAULT now(),
  updated_at   timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT chk_metric CHECK (metric IN ('sales', 'orders', 'review_score', 'menu_sales')),
  CONSTRAINT chk_comparator CHECK (comparator IN ('pct_change', 'abs_lt', 'abs_gt')),
  CONSTRAINT chk_channel CHECK (channel IN ('briefing', 'push', 'both'))
);

CREATE INDEX IF NOT EXISTS idx_anomaly_store_enabled
  ON public.agent_anomaly_rules(store_id)
  WHERE enabled = true;

ALTER TABLE public.agent_anomaly_rules ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anomaly_rules_owner" ON public.agent_anomaly_rules;
CREATE POLICY "anomaly_rules_owner"
  ON public.agent_anomaly_rules FOR ALL
  USING (
    store_id IN (SELECT id FROM public.stores WHERE user_id = auth.uid())
  )
  WITH CHECK (
    store_id IN (SELECT id FROM public.stores WHERE user_id = auth.uid())
  );

-- updated_at 자동 갱신 트리거
CREATE OR REPLACE FUNCTION public._touch_anomaly_rules_updated_at()
RETURNS trigger AS $trg$
BEGIN
  NEW.updated_at := now();
  RETURN NEW;
END;
$trg$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_anomaly_rules_updated_at ON public.agent_anomaly_rules;
CREATE TRIGGER trg_anomaly_rules_updated_at
  BEFORE UPDATE ON public.agent_anomaly_rules
  FOR EACH ROW EXECUTE FUNCTION public._touch_anomaly_rules_updated_at();

COMMENT ON TABLE public.agent_anomaly_rules IS
  'Phase 6 #14: 사장님이 직접 정의하는 매장 이상치 감지 룰. anomaly_evaluator가 주기적으로 평가';
