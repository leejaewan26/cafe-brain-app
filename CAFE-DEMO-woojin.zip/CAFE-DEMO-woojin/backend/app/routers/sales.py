"""
매출 분석 AI 인사이트 라우터
- POST /api/sales/ai-insight: 매출 요약 텍스트 → Gemini 경영 조언
- 24시간 캐싱 적용 (동일 매출 요약은 하루 동안 동일 응답)
"""
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from app.services.gemini_service import (
    generate_insight_cached,
    build_cache_key,
    generate_with_review,  # I10
)
from app.services.feature_flags import is_enabled as flag_enabled

router = APIRouter()


class SalesInsightRequest(BaseModel):
    """매출 AI 인사이트 요청 스키마"""
    store_context: str   # 매장 기본 정보 (useStoreContext에서 생성)
    stats_summary: str   # 매출 집계 요약 텍스트
    top_menu: str        # 최고 매출 메뉴명
    low_day: str         # 가장 매출이 낮은 요일


class SalesInsightResponse(BaseModel):
    """매출 AI 인사이트 응답 스키마"""
    insight: str


@router.post("/ai-insight", response_model=SalesInsightResponse)
async def get_sales_insight(req: SalesInsightRequest):
    """
    매출 데이터 기반 Gemini 경영 조언 생성
    - 민감정보는 PII 미들웨어가 사전 마스킹
    - 24시간 캐싱: 동일 매장/통계 조합은 캐시 히트
    """
    prompt = f"""
당신은 10년 경력의 카페 경영 전문가입니다.
아래 매장 정보와 매출 데이터를 분석하여 실질적인 경영 조언 3~5줄을 한국어로 작성해주세요.

{req.store_context}

[매출 분석 요약]
{req.stats_summary}
- 최고 인기 메뉴: {req.top_menu}
- 매출이 가장 낮은 요일: {req.low_day}

조언은 구체적이고 실행 가능해야 합니다. 예를 들어:
- 특정 시간대 프로모션 제안
- 저마진 메뉴 개선 방안
- 휴무일 및 인력 배치 최적화
- 월별 매출 트렌드에 대한 해석

형식: 불릿(•) 없이 자연스러운 문장 3~5개.
""".strip()

    # 캐시 키: 매장 컨텍스트 + 통계 요약 해시
    cache_key = build_cache_key(
        store_id=req.store_context[:100],  # 앞 100자로 매장 식별자 근사
        template="sales_insight",
        params={
            "stats": req.stats_summary,
            "top_menu": req.top_menu,
            "low_day": req.low_day,
        },
    )

    try:
        # I10 — Self-correction 적용 (flag 활성 시)
        if await flag_enabled("agent_self_correction"):
            question = f"매출 통계: {req.stats_summary}, top: {req.top_menu}, low: {req.low_day}"
            text, _meta = await generate_with_review(
                prompt,
                question_for_review=question,
            )
            return SalesInsightResponse(insight=text)
        insight = await generate_insight_cached(prompt, cache_key=cache_key)
        return SalesInsightResponse(insight=insight)
    except RuntimeError as e:
        raise HTTPException(status_code=503, detail=str(e))
