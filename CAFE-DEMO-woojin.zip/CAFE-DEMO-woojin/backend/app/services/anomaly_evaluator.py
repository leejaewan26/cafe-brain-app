"""
Phase 6 #14 — 사용자 정의 이상치 룰 평가기.

agent_anomaly_rules의 각 룰을 평가:
  metric: sales | orders | review_score | menu_sales
  comparator: pct_change | abs_lt | abs_gt
  window_type: today_vs_week_avg | week_vs_prev_week | today_abs

평가 결과 트리거된 룰은 cooldown 후 다시 발화 가능.
브리핑/푸시 채널로 알림 (channel 컬럼).
"""
import asyncio
from datetime import date, datetime, timedelta, timezone
from typing import Any, Optional

from app.services.gemini_service import _get_supabase


async def list_rules(store_id: str, enabled_only: bool = True) -> list[dict[str, Any]]:
    """매장의 룰 목록."""
    sb = _get_supabase()
    if sb is None:
        return []

    try:
        query = (
            sb.table("agent_anomaly_rules")
            .select("*")
            .eq("store_id", store_id)
            .order("created_at", desc=True)
        )
        if enabled_only:
            query = query.eq("enabled", True)
        result = await asyncio.to_thread(lambda: query.execute())
        return result.data or []
    except Exception:
        return []


async def upsert_rule(
    store_id: str,
    name: str,
    metric: str,
    threshold: float,
    rule_id: Optional[str] = None,
    comparator: str = "pct_change",
    window_type: str = "today_vs_week_avg",
    metric_param: Optional[str] = None,
    enabled: bool = True,
    channel: str = "briefing",
    cooldown_h: int = 24,
    created_by: Optional[str] = None,
) -> Optional[str]:
    """룰 INSERT or UPDATE. 반환: 룰 id."""
    sb = _get_supabase()
    if sb is None:
        return None

    payload: dict[str, Any] = {
        "store_id": store_id,
        "name": name[:100],
        "metric": metric,
        "threshold": float(threshold),
        "comparator": comparator,
        "window_type": window_type,
        "metric_param": metric_param,
        "enabled": enabled,
        "channel": channel,
        "cooldown_h": int(max(1, cooldown_h)),
    }
    if created_by:
        payload["created_by"] = created_by

    try:
        if rule_id:
            result = await asyncio.to_thread(
                lambda: sb.table("agent_anomaly_rules")
                .update(payload)
                .eq("id", rule_id)
                .eq("store_id", store_id)  # 다른 매장 룰 수정 방지
                .execute()
            )
        else:
            result = await asyncio.to_thread(
                lambda: sb.table("agent_anomaly_rules").insert(payload).execute()
            )
        if result.data:
            return result.data[0]["id"]
    except Exception:
        pass
    return None


async def delete_rule(store_id: str, rule_id: str) -> bool:
    sb = _get_supabase()
    if sb is None:
        return False
    try:
        result = await asyncio.to_thread(
            lambda: sb.table("agent_anomaly_rules")
            .delete()
            .eq("id", rule_id)
            .eq("store_id", store_id)
            .execute()
        )
        return bool(result.data)
    except Exception:
        return False


# ════════════════════════════════════════════════════
# 평가 — 룰별 현재값 계산 + 트리거 여부 판단
# ════════════════════════════════════════════════════


async def _fetch_metric_value(
    store_id: str, metric: str, window_type: str, metric_param: Optional[str] = None
) -> tuple[Optional[float], Optional[float]]:
    """
    (현재값, 비교 기준값) 반환. 비교 기준이 없으면 (현재값, None).
    """
    sb = _get_supabase()
    if sb is None:
        return None, None

    today = date.today()
    today_iso = today.isoformat()

    try:
        if metric == "sales":
            # 매출액 합계 (sales_records 테이블 가정 — 없으면 None)
            today_sum = await _sum_field(
                sb, "sales_records", "amount", store_id, today_iso, today_iso
            )
            if window_type == "today_vs_week_avg":
                start = (today - timedelta(days=7)).isoformat()
                end = (today - timedelta(days=1)).isoformat()
                week_sum = await _sum_field(
                    sb, "sales_records", "amount", store_id, start, end
                )
                avg = (week_sum / 7) if week_sum else None
                return today_sum, avg
            if window_type == "week_vs_prev_week":
                this_start = (today - timedelta(days=6)).isoformat()
                prev_start = (today - timedelta(days=13)).isoformat()
                prev_end = (today - timedelta(days=7)).isoformat()
                this_sum = await _sum_field(
                    sb, "sales_records", "amount", store_id, this_start, today_iso
                )
                prev_sum = await _sum_field(
                    sb, "sales_records", "amount", store_id, prev_start, prev_end
                )
                return this_sum, prev_sum
            return today_sum, None

        if metric == "orders":
            # 주문 건수 (orders 테이블 가정)
            today_count = await _count_rows(
                sb, "orders", store_id, today_iso, today_iso
            )
            if window_type == "today_vs_week_avg":
                start = (today - timedelta(days=7)).isoformat()
                end = (today - timedelta(days=1)).isoformat()
                week_count = await _count_rows(sb, "orders", store_id, start, end)
                avg = (week_count / 7) if week_count else None
                return float(today_count), avg
            return float(today_count), None

        if metric == "review_score":
            # 최근 30일 리뷰 평점
            since = (today - timedelta(days=30)).isoformat()
            res = await asyncio.to_thread(
                lambda: sb.table("reviews")
                .select("rating")
                .eq("store_id", store_id)
                .gte("created_at", since)
                .execute()
            )
            rows = res.data or []
            if not rows:
                return None, None
            avg = sum(r.get("rating", 0) for r in rows) / len(rows)
            return float(avg), None

        if metric == "menu_sales" and metric_param:
            # 특정 메뉴 판매량 (sales_records.menu_id가 있다고 가정)
            today_count = await _count_rows(
                sb, "sales_records", store_id, today_iso, today_iso,
                extra_filter=("menu_id", metric_param),
            )
            if window_type == "week_vs_prev_week":
                this_start = (today - timedelta(days=6)).isoformat()
                prev_start = (today - timedelta(days=13)).isoformat()
                prev_end = (today - timedelta(days=7)).isoformat()
                this_count = await _count_rows(
                    sb, "sales_records", store_id, this_start, today_iso,
                    extra_filter=("menu_id", metric_param),
                )
                prev_count = await _count_rows(
                    sb, "sales_records", store_id, prev_start, prev_end,
                    extra_filter=("menu_id", metric_param),
                )
                return float(this_count), float(prev_count)
            return float(today_count), None
    except Exception:
        return None, None

    return None, None


async def _sum_field(sb, table: str, field: str, store_id: str, start: str, end: str) -> Optional[float]:
    try:
        res = await asyncio.to_thread(
            lambda: sb.table(table)
            .select(field)
            .eq("store_id", store_id)
            .gte("date", start)
            .lte("date", end)
            .execute()
        )
        rows = res.data or []
        return float(sum(r.get(field, 0) for r in rows))
    except Exception:
        return None


async def _count_rows(
    sb, table: str, store_id: str, start: str, end: str,
    extra_filter: Optional[tuple[str, str]] = None,
) -> int:
    try:
        query = (
            sb.table(table)
            .select("id", count="exact")
            .eq("store_id", store_id)
            .gte("date", start)
            .lte("date", end)
        )
        if extra_filter:
            query = query.eq(extra_filter[0], extra_filter[1])
        res = await asyncio.to_thread(lambda: query.execute())
        return int(res.count or 0)
    except Exception:
        return 0


def _evaluate_threshold(
    current: Optional[float], baseline: Optional[float],
    comparator: str, threshold: float,
) -> tuple[bool, Optional[float]]:
    """
    (트리거 여부, 평가값) 반환.
    """
    if current is None:
        return False, None

    if comparator == "abs_lt":
        return current < threshold, current
    if comparator == "abs_gt":
        return current > threshold, current
    if comparator == "pct_change":
        if baseline is None or baseline == 0:
            return False, None
        pct = (current - baseline) / baseline * 100
        # threshold가 음수면 "이만큼 떨어지면 트리거"
        if threshold < 0:
            return pct <= threshold, pct
        return pct >= threshold, pct
    return False, current


async def evaluate_store_rules(store_id: str) -> list[dict[str, Any]]:
    """
    매장의 활성 룰들을 모두 평가. 트리거된 것만 반환.
    cooldown 통과한 룰만 평가 (재발화 방지).
    """
    rules = await list_rules(store_id, enabled_only=True)
    triggered: list[dict[str, Any]] = []

    now = datetime.now(timezone.utc)

    for rule in rules:
        cooldown_h = int(rule.get("cooldown_h") or 24)
        last_fired = rule.get("last_fired_at")
        if last_fired:
            try:
                lf = datetime.fromisoformat(last_fired.replace("Z", "+00:00"))
                if now - lf < timedelta(hours=cooldown_h):
                    continue  # 쿨다운 중
            except Exception:
                pass

        current, baseline = await _fetch_metric_value(
            store_id=store_id,
            metric=rule["metric"],
            window_type=rule["window_type"],
            metric_param=rule.get("metric_param"),
        )

        fired, value = _evaluate_threshold(
            current=current,
            baseline=baseline,
            comparator=rule["comparator"],
            threshold=float(rule["threshold"]),
        )

        if fired:
            # last_fired_at 업데이트
            sb = _get_supabase()
            if sb:
                try:
                    await asyncio.to_thread(
                        lambda r=rule: sb.table("agent_anomaly_rules")
                        .update({"last_fired_at": now.isoformat()})
                        .eq("id", r["id"])
                        .execute()
                    )
                except Exception:
                    pass

            triggered.append({
                "rule_id": rule["id"],
                "name": rule["name"],
                "metric": rule["metric"],
                "current_value": current,
                "baseline": baseline,
                "evaluated": value,
                "threshold": float(rule["threshold"]),
                "channel": rule.get("channel", "briefing"),
            })

    return triggered
