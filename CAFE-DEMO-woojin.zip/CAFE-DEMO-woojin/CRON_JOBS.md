# Cron Jobs — 외부 스케줄러 등록 가이드

코드는 다 만들었지만 **호출하는 cron은 외부 스케줄러에서 직접 등록**해야 합니다.

권장: **Render Cron Jobs** (무료 tier 있음) 또는 **GitHub Actions** (개인 repo 무료).

## 인증

모든 cron endpoint은 `X-Cron-Key` 헤더 검증.
환경변수에 `CRON_SECRET` 또는 `AGENT_ADMIN_KEY`를 동일 값으로 설정.

## 등록할 작업

| 작업 | endpoint | 주기 | 우선순위 |
|------|----------|------|---------|
| **결제 정기 갱신** | `POST /api/v1/billing/cron/charge` | 매일 04:00 KST | 🔴 critical |
| **체험 만료 알림** | `POST /api/v1/notification-cron/trial-expiring` | 매일 02:00 KST | 🟡 high |
| **Instagram 토큰 갱신** | `POST /api/v1/social/cron/refresh-tokens` | 매일 03:00 KST | 🟡 high |
| **POS 폴링** | `POST /api/v1/pos/sync/{store_id}` | 5분마다 | 🟢 medium (실시간 매출) |
| **데이터 보관 sweep** | `POST /api/v1/retention/sweep` | 매주 일 04:00 | 🟢 medium |
| **이상치 룰 평가** | `POST /api/v1/agent/rules/cron-evaluate` | 매시간 정각 | 🟢 medium |

## GitHub Actions 예시

`.github/workflows/cron.yml`:
```yaml
name: Cron Jobs
on:
  schedule:
    - cron: '0 19 * * *'  # 매일 04:00 KST = 19:00 UTC (전일)
jobs:
  charge:
    runs-on: ubuntu-latest
    steps:
      - run: |
          curl -X POST "${{ secrets.API_BASE_URL }}/api/v1/billing/cron/charge" \
            -H "X-Cron-Key: ${{ secrets.CRON_SECRET }}"
```

## Render Cron Job 예시

Service Type: Cron Job
Schedule: `0 19 * * *`
Build Command: (없음)
Start Command:
```bash
curl -X POST "$API_BASE_URL/api/v1/billing/cron/charge" -H "X-Cron-Key: $CRON_SECRET"
```

## Supabase pg_cron (대안)

`pg_net` extension 활성화 후:
```sql
SELECT cron.schedule(
  'cafe-brain-billing-charge',
  '0 19 * * *',
  $$ SELECT net.http_post(
    url := 'https://api.cafe-brain.app/api/v1/billing/cron/charge',
    headers := '{"X-Cron-Key": "YOUR_SECRET"}'::jsonb
  ); $$
);
```
