-- Wave 1 마이그레이션
-- 1) stores 테이블에 Issue #15·#1 필드 추가
-- 2) store-logos 스토리지 버킷 + RLS 정책

-- ─── stores 테이블 확장 ───
ALTER TABLE public.stores
  ADD COLUMN IF NOT EXISTS logo_url text;

ALTER TABLE public.stores
  ADD COLUMN IF NOT EXISTS monthly_fixed_cost numeric DEFAULT 3000000
    CHECK (monthly_fixed_cost >= 0);

COMMENT ON COLUMN public.stores.logo_url IS 'Issue #15: 매장 로고 (Supabase Storage public URL)';
COMMENT ON COLUMN public.stores.monthly_fixed_cost IS 'Issue #1: BEP 계산용 월 고정비 (임대료+인건비+관리비)';

-- ─── Storage 버킷 생성 (공개 읽기, 본인만 쓰기) ───
INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES (
  'store-logos',
  'store-logos',
  true,
  2097152,  -- 2MB
  ARRAY['image/png', 'image/jpeg', 'image/jpg', 'image/webp', 'image/svg+xml']
)
ON CONFLICT (id) DO UPDATE SET
  public = EXCLUDED.public,
  file_size_limit = EXCLUDED.file_size_limit,
  allowed_mime_types = EXCLUDED.allowed_mime_types;

-- ─── Storage RLS 정책 ───
-- 경로 규칙: {user_id}/logo_{timestamp}.{ext}
-- storage.foldername(name)[1] = 최상위 폴더명 = user_id

-- 공개 읽기 (누구나 로고 볼 수 있음)
DROP POLICY IF EXISTS "store-logos 공개 읽기" ON storage.objects;
CREATE POLICY "store-logos 공개 읽기"
  ON storage.objects FOR SELECT
  USING (bucket_id = 'store-logos');

-- 본인 폴더에만 업로드
DROP POLICY IF EXISTS "store-logos 본인 업로드" ON storage.objects;
CREATE POLICY "store-logos 본인 업로드"
  ON storage.objects FOR INSERT
  WITH CHECK (
    bucket_id = 'store-logos'
    AND auth.uid()::text = (storage.foldername(name))[1]
  );

-- 본인 파일만 교체
DROP POLICY IF EXISTS "store-logos 본인 업데이트" ON storage.objects;
CREATE POLICY "store-logos 본인 업데이트"
  ON storage.objects FOR UPDATE
  USING (
    bucket_id = 'store-logos'
    AND auth.uid()::text = (storage.foldername(name))[1]
  );

-- 본인 파일만 삭제
DROP POLICY IF EXISTS "store-logos 본인 삭제" ON storage.objects;
CREATE POLICY "store-logos 본인 삭제"
  ON storage.objects FOR DELETE
  USING (
    bucket_id = 'store-logos'
    AND auth.uid()::text = (storage.foldername(name))[1]
  );
