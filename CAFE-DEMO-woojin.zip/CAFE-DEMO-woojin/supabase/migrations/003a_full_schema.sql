-- ========================================================
-- 003_full_schema.sql - 메뉴, 리뷰, 스케줄 테이블 추가
-- ========================================================

-- ── 메뉴 테이블 ──
CREATE TABLE IF NOT EXISTS public.menus (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  store_id uuid NOT NULL REFERENCES public.stores(id) ON DELETE CASCADE,
  name text NOT NULL,
  category text NOT NULL DEFAULT 'etc',
  ingredients text[] NOT NULL DEFAULT '{}',
  total_cost numeric NOT NULL DEFAULT 0,
  sale_price numeric NOT NULL DEFAULT 0,
  recipe text NOT NULL DEFAULT '',
  photo_url text NOT NULL DEFAULT '',
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.menus ENABLE ROW LEVEL SECURITY;
CREATE POLICY "menus: 본인 매장만" ON public.menus
  FOR ALL USING (store_id = auth.uid());

CREATE INDEX IF NOT EXISTS idx_menus_store ON public.menus(store_id);

-- ── 리뷰 테이블 ──
CREATE TABLE IF NOT EXISTS public.reviews (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  store_id uuid NOT NULL REFERENCES public.stores(id) ON DELETE CASCADE,
  nickname text NOT NULL DEFAULT '',
  rating integer NOT NULL DEFAULT 5 CHECK (rating BETWEEN 1 AND 5),
  date date NOT NULL DEFAULT CURRENT_DATE,
  platform text NOT NULL DEFAULT '기타',
  content text NOT NULL DEFAULT '',
  ai_reply text NOT NULL DEFAULT '',
  reply_status text NOT NULL DEFAULT 'pending' CHECK (reply_status IN ('pending','generated','sent')),
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.reviews ENABLE ROW LEVEL SECURITY;
CREATE POLICY "reviews: 본인 매장만" ON public.reviews
  FOR ALL USING (store_id = auth.uid());

CREATE INDEX IF NOT EXISTS idx_reviews_store ON public.reviews(store_id, date DESC);

-- ── 직원 테이블 ──
CREATE TABLE IF NOT EXISTS public.employees (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  store_id uuid NOT NULL REFERENCES public.stores(id) ON DELETE CASCADE,
  name text NOT NULL,
  employment_type text NOT NULL DEFAULT 'part_time',
  hourly_rate numeric NOT NULL DEFAULT 9860,
  max_weekly_hours integer NOT NULL DEFAULT 40,
  unavailable_days integer[] NOT NULL DEFAULT '{}',
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.employees ENABLE ROW LEVEL SECURITY;
CREATE POLICY "employees: 본인 매장만" ON public.employees
  FOR ALL USING (store_id = auth.uid());

-- ── 주간 스케줄 테이블 ──
CREATE TABLE IF NOT EXISTS public.schedules (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  store_id uuid NOT NULL REFERENCES public.stores(id) ON DELETE CASCADE,
  week_start date NOT NULL,
  employee_id uuid NOT NULL REFERENCES public.employees(id) ON DELETE CASCADE,
  day_index integer NOT NULL CHECK (day_index BETWEEN 0 AND 6),
  start_hour integer NOT NULL CHECK (start_hour BETWEEN 0 AND 23),
  end_hour integer NOT NULL CHECK (end_hour BETWEEN 1 AND 24),
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.schedules ENABLE ROW LEVEL SECURITY;
CREATE POLICY "schedules: 본인 매장만" ON public.schedules
  FOR ALL USING (store_id = auth.uid());

CREATE INDEX IF NOT EXISTS idx_schedules_store_week ON public.schedules(store_id, week_start);

-- ── 트렌드 캐시 테이블 ──
CREATE TABLE IF NOT EXISTS public.trend_cache (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  region text NOT NULL DEFAULT 'KR',
  category text NOT NULL DEFAULT 'cafe',
  keywords jsonb NOT NULL DEFAULT '[]',
  insight text NOT NULL DEFAULT '',
  generated_at timestamptz NOT NULL DEFAULT now(),
  expires_at timestamptz NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_trend_cache_expires ON public.trend_cache(expires_at);
