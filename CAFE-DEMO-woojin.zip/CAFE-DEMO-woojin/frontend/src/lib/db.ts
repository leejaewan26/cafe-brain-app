/**
 * Supabase DB 동기화 레이어
 * 모든 CRUD는 이 파일을 통해 Supabase와 통신
 * Zustand 스토어의 데이터를 Supabase에 영속화
 */
import { supabase } from './supabase'
import type { SalesRecord } from '@/types/sales'
import type { Review } from '@/types/review'
import type { MenuItem } from '@/types/menu'

// ═══════════════════ 매출 ═══════════════════

export async function fetchSalesRecords(storeId: string): Promise<SalesRecord[]> {
  const { data, error } = await supabase
    .from('sales_records')
    .select('*')
    .eq('store_id', storeId)
    .order('sale_date', { ascending: false })
  if (error) throw error
  return (data ?? []).map(r => ({
    id: r.id,
    sale_date: r.sale_date,
    hour_slot: r.hour_slot,
    day_of_week: r.day_of_week,
    menu_name: r.menu_name,
    quantity: r.quantity,
    revenue: Number(r.revenue),
    cost: Number(r.cost),
    discount: Number(r.discount),
  }))
}

export async function upsertSalesRecords(storeId: string, records: SalesRecord[]): Promise<void> {
  if (!records.length) return
  const rows = records.map(r => ({
    id: r.id.startsWith('csv-') || r.id.startsWith('manual-') || r.id.startsWith('ocr-') ? undefined : r.id,
    store_id: storeId,
    sale_date: r.sale_date,
    hour_slot: r.hour_slot,
    day_of_week: r.day_of_week,
    menu_name: r.menu_name,
    quantity: r.quantity,
    revenue: r.revenue,
    cost: r.cost,
    discount: r.discount,
  }))
  const { error } = await supabase.from('sales_records').upsert(rows, { onConflict: 'id', ignoreDuplicates: true })
  if (error) throw error
}

export async function deleteSalesRecord(id: string): Promise<void> {
  await supabase.from('sales_records').delete().eq('id', id)
}

// ═══════════════════ 리뷰 ═══════════════════

export async function fetchReviews(storeId: string): Promise<Review[]> {
  const { data, error } = await supabase
    .from('reviews')
    .select('*')
    .eq('store_id', storeId)
    .order('date', { ascending: false })
  if (error) throw error
  return (data ?? []).map(r => ({
    id: r.id,
    nickname: r.nickname,
    rating: r.rating,
    date: r.date,
    platform: r.platform,
    content: r.content,
    ai_reply: r.ai_reply,
    reply_status: r.reply_status as Review['reply_status'],
    is_selected: false,
  }))
}

export async function upsertReviews(storeId: string, reviews: Review[]): Promise<void> {
  if (!reviews.length) return
  const rows = reviews
    .filter(r => !r.id.startsWith('rv-'))  // 샘플 데이터 제외
    .map(r => ({
      id: r.id.startsWith('rv-import-') ? undefined : r.id,
      store_id: storeId,
      nickname: r.nickname,
      rating: r.rating,
      date: r.date,
      platform: r.platform,
      content: r.content,
      ai_reply: r.ai_reply,
      reply_status: r.reply_status,
    }))
  if (!rows.length) return
  const { error } = await supabase.from('reviews').upsert(rows, { onConflict: 'id', ignoreDuplicates: false })
  if (error) throw error
}

export async function updateReviewReply(id: string, reply: string): Promise<void> {
  await supabase.from('reviews').update({ ai_reply: reply, reply_status: 'generated' }).eq('id', id)
}

// ═══════════════════ 메뉴 ═══════════════════

export async function fetchMenus(storeId: string): Promise<MenuItem[]> {
  const { data, error } = await supabase
    .from('menus')
    .select('*')
    .eq('store_id', storeId)
    .order('created_at', { ascending: true })
  if (error) throw error
  return (data ?? []).map(m => ({
    id: m.id,
    name: m.name,
    category: m.category,
    ingredients: m.ingredients,
    totalCost: Number(m.total_cost),
    salePrice: Number(m.sale_price),
    recipe: m.recipe,
    photoUrl: m.photo_url,
    createdAt: m.created_at ?? new Date().toISOString(),
  }))
}

export async function upsertMenu(storeId: string, menu: MenuItem): Promise<string> {
  const row = {
    id: menu.id.startsWith('menu-') ? undefined : menu.id,
    store_id: storeId,
    name: menu.name,
    category: menu.category,
    ingredients: menu.ingredients,
    total_cost: menu.totalCost,
    sale_price: menu.salePrice,
    recipe: menu.recipe,
    photo_url: menu.photoUrl,
  }
  const { data, error } = await supabase.from('menus').upsert(row, { onConflict: 'id' }).select('id').single()
  if (error) throw error
  return data.id
}

export async function deleteMenu(id: string): Promise<void> {
  await supabase.from('menus').delete().eq('id', id)
}
