"""
Rate Limiting 미들웨어 — 사용자(매장)당 분당 AI 호출 제한
Rule 3: AI 호출 분당 10회 제한 (API 비용·남용 방지)

MVP는 인메모리 토큰 버킷 방식 (단일 인스턴스 전제).
프로덕션 다중 인스턴스 전환 시 Redis 기반으로 교체 예정.
"""
import hashlib
from collections import defaultdict
from time import time
from fastapi import Request
from fastapi.responses import JSONResponse
from starlette.middleware.base import BaseHTTPMiddleware

# Rate Limit 적용 대상 경로 (AI 호출이 일어나는 모든 엔드포인트)
AI_ENDPOINTS = (
    "/api/sales/ai-insight",
    "/api/schedule/ai-insight",
    "/api/reviews/reply",
    "/api/marketing/generate",
    "/api/marketing/seo",
    "/api/menu/recipe",
    "/api/menu/recommend",
    "/api/menu/manual",
    "/api/chat/message",
    "/api/agent/briefing",
    "/api/agent/distill",
    "/api/supplier/cost-savings",
    "/api/sales/ocr-receipt",
)


class RateLimiter:
    """슬라이딩 윈도우 Rate Limiter (인메모리, 단일 인스턴스용)"""

    def __init__(self, max_calls: int = 10, window_seconds: int = 60):
        self.calls: dict[str, list[float]] = defaultdict(list)
        self.max_calls = max_calls
        self.window = window_seconds

    def check(self, client_id: str, max_calls: int | None = None) -> tuple[bool, int, float]:
        """
        호출 가능 여부 확인 및 카운트 증가.

        Args:
            client_id: 식별자 (token / ip / store)
            max_calls: 매장별 커스텀 한도 (None이면 self.max_calls 사용)

        Returns:
            (허용 여부, 남은 호출 수, 리셋까지 남은 초)
        """
        now = time()
        limit = max_calls if max_calls is not None else self.max_calls

        # 윈도우 밖의 오래된 호출 기록 제거
        recent = [t for t in self.calls[client_id] if now - t < self.window]
        self.calls[client_id] = recent

        if len(recent) >= limit:
            # 가장 오래된 호출 기준으로 리셋 시간 계산
            retry_after = self.window - (now - recent[0])
            return False, 0, max(1.0, retry_after)

        recent.append(now)
        return True, limit - len(recent), float(self.window)


# 모듈 전역 Limiter 인스턴스 (분당 10회 — 매장별로 override 가능)
limiter = RateLimiter(max_calls=10, window_seconds=60)


# Phase 6 #12 — 매장별 커스텀 한도 (stores.agent_settings.rate_limit_per_min 으로 override).
# 인메모리 캐시 (TTL 5분) — DB 조회 비용 최소화.
_STORE_LIMIT_CACHE: dict[str, tuple[int, float]] = {}
_STORE_LIMIT_TTL = 300.0  # 5분


def _get_store_limit(store_hint: str) -> int | None:
    """
    매장별 커스텀 한도 조회 (캐시).
    Returns None이면 기본 limiter.max_calls 사용.
    """
    if not store_hint:
        return None
    now = time()
    cached = _STORE_LIMIT_CACHE.get(store_hint)
    if cached and now - cached[1] < _STORE_LIMIT_TTL:
        return cached[0] if cached[0] > 0 else None

    # DB 조회 (실패 시 None — 기본값 사용)
    try:
        from app.services.gemini_service import _get_supabase
        sb = _get_supabase()
        if sb is None:
            return None
        result = sb.table("stores").select("agent_settings").eq("id", store_hint).limit(1).execute()
        if result.data:
            settings = result.data[0].get("agent_settings") or {}
            limit = settings.get("rate_limit_per_min")
            if isinstance(limit, int) and 1 <= limit <= 1000:
                _STORE_LIMIT_CACHE[store_hint] = (limit, now)
                return limit
        # 매장은 있지만 커스텀 없음 — 기본값 사용 (캐시에 0 저장)
        _STORE_LIMIT_CACHE[store_hint] = (0, now)
    except Exception:
        pass
    return None


def _hash_token(token: str) -> str:
    """토큰의 결정적 해시 (Critical C5: hash() 세션 비결정성 제거)."""
    return hashlib.sha256(token.encode("utf-8")).hexdigest()[:16]


def _get_client_id(request: Request) -> str:
    """
    요청자 식별 — 보안 강화 (Critical C4).
    우선순위:
      1. Authorization Bearer 토큰 (가장 신뢰: 서버가 검증 가능)
      2. IP 주소 (위조 어려움)
      3. X-Store-Id 헤더 (편의용 fallback, 단독 신뢰 X)
      4. anonymous

    기존 X-Store-Id 단독 신뢰는 위조 가능하므로, 토큰/IP 우선.
    """
    auth = request.headers.get("Authorization", "")
    if auth.startswith("Bearer "):
        token = auth[7:]
        return f"token:{_hash_token(token)}"

    if request.client:
        # IP + X-Store-Id 힌트 조합 (같은 네트워크 여러 매장 지원)
        ip = request.client.host
        store_hint = request.headers.get("X-Store-Id", "")
        if store_hint:
            # IP로 본인 인증, store_hint는 버킷 분리만 (위조해도 본인 쿼터만 나눌 뿐)
            return f"ip:{ip}:store:{_hash_token(store_hint)[:8]}"
        return f"ip:{ip}"

    return "anonymous"


class RateLimitMiddleware(BaseHTTPMiddleware):
    """
    AI 엔드포인트에 Rate Limit 적용하는 미들웨어.
    초과 시 429 반환 + Retry-After 헤더.
    """

    async def dispatch(self, request: Request, call_next):
        # AI 엔드포인트가 아니면 바로 통과
        if not request.url.path.startswith(AI_ENDPOINTS):
            return await call_next(request)

        client_id = _get_client_id(request)

        # Phase 6 #12: 매장별 커스텀 한도 적용 (X-Store-Id 있으면 DB 조회)
        store_hint = request.headers.get("X-Store-Id", "")
        custom_limit = _get_store_limit(store_hint) if store_hint else None
        effective_limit = custom_limit if custom_limit is not None else limiter.max_calls

        allowed, remaining, retry_after = limiter.check(client_id, max_calls=effective_limit)

        if not allowed:
            return JSONResponse(
                status_code=429,
                content={
                    "detail": (
                        f"AI 호출 한도 초과 (분당 {effective_limit}회). "
                        f"{int(retry_after)}초 후 다시 시도해주세요."
                    ),
                    "retry_after_seconds": int(retry_after),
                },
                headers={
                    "Retry-After": str(int(retry_after)),
                    "X-RateLimit-Limit": str(effective_limit),
                    "X-RateLimit-Remaining": "0",
                },
            )

        response = await call_next(request)
        response.headers["X-RateLimit-Limit"] = str(effective_limit)
        response.headers["X-RateLimit-Remaining"] = str(remaining)
        return response
