"""
H5 — 소셜 자동 게시 (Instagram + n8n 우회)

레이어:
  L1. Instagram Graph API 직접 호출 (FB 페이지 + IG Business 계정 + Long-lived token)
       사장님이 본인 IG에 직접 연결. 메타 비즈니스 검토 X (개별 사용자 토큰)
  L2. n8n webhook 우회 — 마케팅 콘텐츠를 N8N_WEBHOOK_URL로 POST →
       n8n 워크플로우가 IG/Threads/Facebook/X에 분배
       (n8n 자체 호스팅·무료, 사장님 OAuth는 한 번만)

L1 플로우:
  1) 사장님이 /settings/integrations 에서 [Instagram 연결]
  2) Facebook OAuth → 페이지 ID + IG Business ID + 장기 토큰 받음
  3) /api/social/publish 호출:
     - 미디어 컨테이너 생성: POST /{ig-user-id}/media
     - 게시: POST /{ig-user-id}/media_publish
"""
import asyncio
import logging
from datetime import datetime, timedelta, timezone  # noqa
from typing import Literal, Optional

import httpx
from fastapi import APIRouter, Header, HTTPException
from pydantic import BaseModel, Field, HttpUrl

from app.config import settings
from app.services.gemini_service import _get_supabase

logger = logging.getLogger("social_publish")
router = APIRouter()

ChannelId = Literal["instagram", "threads", "facebook", "x", "n8n"]


# ─── 연결 관리 ────────────────────────────────────────────────


class ConnectInstagramRequest(BaseModel):
    store_id: str = Field(..., min_length=1)
    ig_user_id: str  # Instagram Business 계정 ID
    access_token: str  # Long-lived token (60일 유효)
    page_id: Optional[str] = None
    page_name: Optional[str] = None


@router.post("/connect/instagram")
async def connect_instagram(req: ConnectInstagramRequest):
    """매장에 Instagram 연결. 토큰은 service_role 영역."""
    sb = _get_supabase()
    if sb is None:
        raise HTTPException(503, "Supabase 미설정")

    # 토큰 유효성 검사 — Graph API ping
    try:
        async with httpx.AsyncClient(timeout=10.0) as client:
            r = await client.get(
                f"https://graph.facebook.com/v18.0/{req.ig_user_id}",
                params={"fields": "username,name", "access_token": req.access_token},
            )
            if r.status_code != 200:
                raise HTTPException(400, f"토큰 검증 실패: {r.text[:200]}")
            ig_info = r.json()
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(500, f"검증 호출 실패: {str(e)[:100]}")

    row = {
        "store_id": req.store_id,
        "channel": "instagram",
        "external_id": req.ig_user_id,
        "external_name": ig_info.get("username") or ig_info.get("name"),
        "access_token": req.access_token,
        "page_id": req.page_id,
        "connected_at": datetime.now(timezone.utc).isoformat(),
        "is_active": True,
    }
    await asyncio.to_thread(
        lambda: sb.table("social_connections")
        .upsert(row, on_conflict="store_id,channel")
        .execute()
    )
    return {"connected": True, "username": ig_info.get("username")}


@router.get("/connections/{store_id}")
async def list_social_connections(store_id: str):
    sb = _get_supabase()
    if sb is None:
        return {"connections": []}
    res = await asyncio.to_thread(
        lambda: sb.table("social_connections")
        .select("channel, external_name, connected_at, is_active")
        .eq("store_id", store_id)
        .execute()
    )
    return {"connections": res.data or []}


# ─── L1: Instagram 게시 (Graph API) ──────────────────────────


class InstagramPublishRequest(BaseModel):
    store_id: str
    image_url: HttpUrl  # 공개 접근 가능한 이미지 URL (Supabase Storage 등)
    caption: str = Field(..., min_length=1, max_length=2200)


@router.post("/publish/instagram")
async def publish_to_instagram(req: InstagramPublishRequest):
    """
    Instagram Business 계정에 단일 이미지 + 캡션 게시.

    플로우:
      1) POST /{ig-user-id}/media (image_url + caption) → creation_id
      2) POST /{ig-user-id}/media_publish (creation_id) → media_id
    """
    sb = _get_supabase()
    if sb is None:
        raise HTTPException(503, "Supabase 미설정")

    res = await asyncio.to_thread(
        lambda: sb.table("social_connections")
        .select("external_id, access_token")
        .eq("store_id", req.store_id)
        .eq("channel", "instagram")
        .eq("is_active", True)
        .single()
        .execute()
    )
    conn = res.data
    if not conn:
        raise HTTPException(400, "Instagram 미연결")

    ig_user_id = conn["external_id"]
    token = conn["access_token"]

    try:
        async with httpx.AsyncClient(timeout=30.0) as client:
            # 1) 미디어 컨테이너
            r1 = await client.post(
                f"https://graph.facebook.com/v18.0/{ig_user_id}/media",
                data={
                    "image_url": str(req.image_url),
                    "caption": req.caption,
                    "access_token": token,
                },
            )
            if r1.status_code != 200:
                raise HTTPException(r1.status_code, f"컨테이너 생성 실패: {r1.text[:200]}")
            creation_id = r1.json()["id"]

            # 2) 게시
            r2 = await client.post(
                f"https://graph.facebook.com/v18.0/{ig_user_id}/media_publish",
                data={
                    "creation_id": creation_id,
                    "access_token": token,
                },
            )
            if r2.status_code != 200:
                raise HTTPException(r2.status_code, f"게시 실패: {r2.text[:200]}")
            media_id = r2.json()["id"]
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(500, f"Graph API 호출 실패: {str(e)[:100]}")

    # 게시 이력 저장
    try:
        await asyncio.to_thread(
            lambda: sb.table("social_posts").insert({
                "store_id": req.store_id,
                "channel": "instagram",
                "external_id": media_id,
                "caption": req.caption[:500],
                "image_url": str(req.image_url),
                "published_at": datetime.now(timezone.utc).isoformat(),
            }).execute()
        )
    except Exception:
        pass

    return {
        "published": True,
        "media_id": media_id,
        "permalink": f"https://www.instagram.com/p/{media_id}/",
    }


# ─── L2: n8n webhook 우회 (한 번에 다 채널 분배) ─────────────


class N8nPublishRequest(BaseModel):
    store_id: str
    channels: list[ChannelId]  # ["instagram", "threads", "facebook"]
    caption: str
    image_url: Optional[HttpUrl] = None
    schedule_at: Optional[str] = None  # ISO datetime — 예약 게시


# ─── L6: 다중 이미지 carousel + 영상 ──────────────────────────


class CarouselPublishRequest(BaseModel):
    store_id: str
    image_urls: list[HttpUrl] = Field(..., min_length=2, max_length=10)
    caption: str = Field(..., min_length=1, max_length=2200)


@router.post("/publish/instagram-carousel")
async def publish_carousel(req: CarouselPublishRequest):
    """
    Instagram 다중 이미지 게시 (2~10장).

    플로우:
      1) 각 이미지마다 단일 미디어 컨테이너 (is_carousel_item=true)
      2) carousel 컨테이너 생성 (children=[id1,id2,...])
      3) media_publish (carousel id)
    """
    sb = _get_supabase()
    if sb is None:
        raise HTTPException(503, "Supabase 미설정")

    res = await asyncio.to_thread(
        lambda: sb.table("social_connections")
        .select("external_id, access_token")
        .eq("store_id", req.store_id)
        .eq("channel", "instagram")
        .eq("is_active", True)
        .single()
        .execute()
    )
    conn = res.data
    if not conn:
        raise HTTPException(400, "Instagram 미연결")

    ig_user_id = conn["external_id"]
    token = conn["access_token"]

    try:
        async with httpx.AsyncClient(timeout=60.0) as client:
            # 1) 각 이미지를 carousel item으로 등록
            child_ids = []
            for url in req.image_urls:
                r = await client.post(
                    f"https://graph.facebook.com/v18.0/{ig_user_id}/media",
                    data={
                        "image_url": str(url),
                        "is_carousel_item": "true",
                        "access_token": token,
                    },
                )
                if r.status_code != 200:
                    raise HTTPException(r.status_code, f"이미지 #{len(child_ids)+1} 컨테이너 실패: {r.text[:200]}")
                child_ids.append(r.json()["id"])

            # 2) carousel 컨테이너
            r2 = await client.post(
                f"https://graph.facebook.com/v18.0/{ig_user_id}/media",
                data={
                    "media_type": "CAROUSEL",
                    "children": ",".join(child_ids),
                    "caption": req.caption,
                    "access_token": token,
                },
            )
            if r2.status_code != 200:
                raise HTTPException(r2.status_code, f"carousel 컨테이너 실패: {r2.text[:200]}")
            carousel_id = r2.json()["id"]

            # 3) 게시
            r3 = await client.post(
                f"https://graph.facebook.com/v18.0/{ig_user_id}/media_publish",
                data={"creation_id": carousel_id, "access_token": token},
            )
            if r3.status_code != 200:
                raise HTTPException(r3.status_code, f"carousel 게시 실패: {r3.text[:200]}")
            media_id = r3.json()["id"]

    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(500, f"Carousel 호출 실패: {str(e)[:100]}")

    try:
        await asyncio.to_thread(
            lambda: sb.table("social_posts").insert({
                "store_id": req.store_id,
                "channel": "instagram",
                "external_id": media_id,
                "caption": req.caption[:500],
                "image_url": str(req.image_urls[0]),  # 대표
                "metrics": {"type": "carousel", "image_count": len(req.image_urls)},
                "published_at": datetime.now(timezone.utc).isoformat(),
            }).execute()
        )
    except Exception:
        pass

    return {
        "published": True,
        "media_id": media_id,
        "image_count": len(req.image_urls),
        "permalink": f"https://www.instagram.com/p/{media_id}/",
    }


class ReelsPublishRequest(BaseModel):
    store_id: str
    video_url: HttpUrl  # 공개 .mp4 URL (Supabase Storage 등)
    caption: str = Field(..., max_length=2200)
    cover_url: Optional[HttpUrl] = None


@router.post("/publish/instagram-reels")
async def publish_reels(req: ReelsPublishRequest):
    """
    Instagram Reels (영상) 게시.

    영상 처리는 비동기 — Toss와 달리 미디어 컨테이너 status가 FINISHED 될 때까지 폴링 필요.
    Graph API: GET /{container_id}?fields=status_code
    """
    sb = _get_supabase()
    if sb is None:
        raise HTTPException(503, "Supabase 미설정")

    res = await asyncio.to_thread(
        lambda: sb.table("social_connections")
        .select("external_id, access_token")
        .eq("store_id", req.store_id)
        .eq("channel", "instagram")
        .eq("is_active", True)
        .single()
        .execute()
    )
    conn = res.data
    if not conn:
        raise HTTPException(400, "Instagram 미연결")

    ig_user_id = conn["external_id"]
    token = conn["access_token"]

    try:
        async with httpx.AsyncClient(timeout=120.0) as client:
            # 1) Reels 컨테이너
            payload = {
                "media_type": "REELS",
                "video_url": str(req.video_url),
                "caption": req.caption,
                "access_token": token,
            }
            if req.cover_url:
                payload["cover_url"] = str(req.cover_url)
            r1 = await client.post(
                f"https://graph.facebook.com/v18.0/{ig_user_id}/media",
                data=payload,
            )
            if r1.status_code != 200:
                raise HTTPException(r1.status_code, f"Reels 컨테이너 실패: {r1.text[:200]}")
            creation_id = r1.json()["id"]

            # 2) FINISHED 될 때까지 폴링 (최대 60초)
            for _ in range(20):
                await asyncio.sleep(3)
                status_r = await client.get(
                    f"https://graph.facebook.com/v18.0/{creation_id}",
                    params={"fields": "status_code", "access_token": token},
                )
                if status_r.status_code == 200:
                    status = status_r.json().get("status_code")
                    if status == "FINISHED":
                        break
                    if status == "ERROR":
                        raise HTTPException(500, "Reels 처리 중 ERROR")

            # 3) 게시
            r3 = await client.post(
                f"https://graph.facebook.com/v18.0/{ig_user_id}/media_publish",
                data={"creation_id": creation_id, "access_token": token},
            )
            if r3.status_code != 200:
                raise HTTPException(r3.status_code, f"Reels 게시 실패: {r3.text[:200]}")
            media_id = r3.json()["id"]

    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(500, f"Reels 호출 실패: {str(e)[:100]}")

    try:
        await asyncio.to_thread(
            lambda: sb.table("social_posts").insert({
                "store_id": req.store_id,
                "channel": "instagram",
                "external_id": media_id,
                "caption": req.caption[:500],
                "image_url": str(req.cover_url) if req.cover_url else None,
                "metrics": {"type": "reels", "video_url": str(req.video_url)},
                "published_at": datetime.now(timezone.utc).isoformat(),
            }).execute()
        )
    except Exception:
        pass

    return {
        "published": True,
        "media_id": media_id,
        "type": "reels",
        "permalink": f"https://www.instagram.com/reel/{media_id}/",
    }


@router.post("/cron/refresh-tokens")
async def refresh_long_lived_tokens(
    cron_key: str = Header(default="", alias="X-Cron-Key"),
):
    """
    H5 critical — Instagram 장기 토큰은 60일 후 만료.
    매일 호출되어 만료 30일 이내 토큰을 갱신.

    Graph API: GET /refresh_access_token?grant_type=ig_refresh_token&access_token={token}
    """
    expected = settings.agent_admin_key or ""
    if cron_key != expected:
        raise HTTPException(403, "권한 없음")

    sb = _get_supabase()
    if sb is None:
        raise HTTPException(503, "Supabase 미설정")

    # 30일 이내 만료 또는 expires_at NULL 인 active IG 연결
    threshold = (datetime.now(timezone.utc) + timedelta(days=30)).isoformat()
    res = await asyncio.to_thread(
        lambda: sb.table("social_connections")
        .select("*")
        .eq("channel", "instagram")
        .eq("is_active", True)
        .or_(f"expires_at.lte.{threshold},expires_at.is.null")
        .execute()
    )
    conns = res.data or []
    refreshed = 0
    failed = 0

    for conn in conns:
        try:
            async with httpx.AsyncClient(timeout=15.0) as client:
                r = await client.get(
                    "https://graph.instagram.com/refresh_access_token",
                    params={
                        "grant_type": "ig_refresh_token",
                        "access_token": conn["access_token"],
                    },
                )
                if r.status_code != 200:
                    logger.warning("토큰 갱신 실패 %s: %s", conn.get("external_name"), r.text[:200])
                    failed += 1
                    continue
                data = r.json()
                new_token = data.get("access_token")
                expires_in = int(data.get("expires_in", 60 * 24 * 3600))
                new_expires = datetime.now(timezone.utc) + timedelta(seconds=expires_in)
                await asyncio.to_thread(
                    lambda c=conn, t=new_token, e=new_expires.isoformat(): sb.table("social_connections")
                    .update({"access_token": t, "expires_at": e})
                    .eq("store_id", c["store_id"])
                    .eq("channel", "instagram")
                    .execute()
                )
                refreshed += 1
        except Exception as e:
            logger.error("토큰 갱신 예외: %s", e)
            failed += 1

    return {"refreshed": refreshed, "failed": failed, "total_eligible": len(conns)}


@router.post("/publish/n8n")
async def publish_via_n8n(req: N8nPublishRequest):
    """
    n8n 셀프 호스팅 워크플로우로 페이로드 전달.
    n8n에서 OAuth + multi-channel 분배 + 예약 처리.

    config: settings.n8n_webhook_url
    """
    webhook_url = getattr(settings, "n8n_webhook_url", "") or ""
    if not webhook_url:
        raise HTTPException(503, "n8n 웹훅 미설정 — 환경변수 N8N_WEBHOOK_URL 필요")

    payload = {
        "store_id": req.store_id,
        "channels": req.channels,
        "caption": req.caption,
        "image_url": str(req.image_url) if req.image_url else None,
        "schedule_at": req.schedule_at,
        "triggered_at": datetime.now(timezone.utc).isoformat(),
    }
    try:
        async with httpx.AsyncClient(timeout=15.0) as client:
            r = await client.post(webhook_url, json=payload)
            if r.status_code >= 400:
                raise HTTPException(r.status_code, f"n8n 호출 실패: {r.text[:200]}")
            data = r.json() if r.headers.get("content-type", "").startswith("application/json") else {"ok": True}
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(500, f"n8n 호출 예외: {str(e)[:100]}")

    return {"queued": True, "n8n_response": data, "channels": req.channels}
