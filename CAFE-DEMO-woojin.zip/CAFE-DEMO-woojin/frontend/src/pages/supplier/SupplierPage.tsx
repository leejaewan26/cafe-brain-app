// 공급처 비용 절감 제안 페이지 (Issue #9)
// 재료 DB에서 선택 → Gemini에 분석 요청 → 대안 제안
import { useCallback, useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import {
  Truck, ChevronLeft, Sparkles, Loader2, AlertCircle,
  CheckSquare, Square, TrendingDown, ExternalLink,
} from 'lucide-react'
import toast from 'react-hot-toast'
import { supabase } from '@/lib/supabase'
import { useAuthStore } from '@/store/authStore'
import { useStoreContext } from '@/hooks/useStoreContext'
import { cn, formatCurrency } from '@/lib/utils'
import AiFeedback from '@/components/AiFeedback'

interface Ingredient {
  id: string
  name: string
  unit: string
  unit_price: number
  supplier?: string | null
}

interface Suggestion {
  ingredient: string
  current: string
  alternatives: string[]
  estimated_savings: string
  confidence: string
}

export default function SupplierPage() {
  const user = useAuthStore((s) => s.user)
  const { buildPromptContext } = useStoreContext()
  const [ingredients, setIngredients] = useState<Ingredient[]>([])
  const [selected, setSelected] = useState<Set<string>>(new Set())
  const [loading, setLoading] = useState(true)
  const [analyzing, setAnalyzing] = useState(false)
  const [suggestions, setSuggestions] = useState<Suggestion[]>([])
  const [disclaimer, setDisclaimer] = useState('')
  const [analysisRef, setAnalysisRef] = useState('')

  const loadIngredients = useCallback(async () => {
    if (!user) return
    setLoading(true)
    const { data, error } = await supabase
      .from('ingredients')
      .select('id, name, unit, unit_price, supplier')
      .eq('store_id', user.id)
      .order('unit_price', { ascending: false })
    if (error) toast.error(error.message)
    else setIngredients((data ?? []) as Ingredient[])
    setLoading(false)
  }, [user])

  useEffect(() => {
    if (user) void loadIngredients()
  }, [user, loadIngredients])

  const toggleSelect = (id: string) => {
    const next = new Set(selected)
    if (next.has(id)) next.delete(id); else next.add(id)
    setSelected(next)
  }

  const handleAnalyze = async () => {
    if (!user) return
    const targets = ingredients.filter((i) => selected.has(i.id))
    if (targets.length === 0) { toast.error('재료를 1개 이상 선택하세요'); return }

    setAnalyzing(true)
    setSuggestions([])
    try {
      const res = await fetch('/api/v1/supplier/cost-savings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'X-Store-Id': user.id },
        body: JSON.stringify({
          store_id: user.id,
          store_context: buildPromptContext(),
          ingredients: targets.map((t) => ({
            name: t.name,
            unit: t.unit,
            current_unit_price: t.unit_price,
            current_supplier: t.supplier ?? '',
          })),
        }),
      })
      if (res.status === 429) {
        const d = await res.json().catch(() => ({}))
        throw new Error(d.detail ?? 'AI 호출 한도 초과')
      }
      if (!res.ok) throw new Error(`오류 ${res.status}`)
      const data = await res.json()
      setSuggestions(data.suggestions ?? [])
      setDisclaimer(data.disclaimer ?? '')
      setAnalysisRef(`supplier-${Date.now()}`)
    } catch (e) {
      toast.error(e instanceof Error ? e.message : '분석 실패')
    } finally {
      setAnalyzing(false)
    }
  }

  return (
    <div className="min-h-screen bg-[#FAFAF8] dark:bg-[#1A1A1A]">
      <header className="bg-[#2C1810] text-white px-4 py-3 flex items-center gap-3">
        <Link to="/dashboard" className="hover:text-[#D4A574]"><ChevronLeft size={20} /></Link>
        <Truck size={18} className="text-[#D4A574]" />
        <h1 className="font-bold text-base flex-1">공급처 절감 AI</h1>
      </header>

      <main className="max-w-3xl mx-auto px-4 py-4 space-y-4 pb-24">
        {/* 안내 */}
        <div className="bg-gradient-to-br from-[#D4A574]/10 to-[#2C1810]/5 rounded-2xl p-4 border border-[#D4A574]/30">
          <div className="flex items-start gap-2 mb-2">
            <TrendingDown size={16} className="text-[#D4A574] mt-0.5" />
            <div>
              <h3 className="font-bold text-[#2C1810] dark:text-gray-100 text-sm">재료 비용 절감 제안</h3>
              <p className="text-xs text-gray-500 dark:text-gray-400 mt-0.5 leading-relaxed">
                AI가 시중 시세를 참고해 더 저렴한 대체 공급처를 제안합니다.
                재료 DB에서 분석할 항목을 선택하세요.
              </p>
            </div>
          </div>
        </div>

        {/* 재료 없음 */}
        {!loading && ingredients.length === 0 && (
          <div className="bg-white dark:bg-gray-800 rounded-2xl p-8 text-center text-gray-400 border border-gray-100 dark:border-gray-700">
            <AlertCircle size={24} className="mx-auto mb-2 opacity-50" />
            <p className="text-sm mb-3">먼저 재료 DB에 재료를 등록하세요</p>
            <Link to="/ingredients" className="text-xs text-[#D4A574] font-semibold hover:text-[#c4956a]">
              재료 등록하러 가기 →
            </Link>
          </div>
        )}

        {/* 재료 선택 */}
        {!loading && ingredients.length > 0 && (
          <div className="bg-white dark:bg-gray-800 rounded-2xl p-4 border border-gray-100 dark:border-gray-700">
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-sm font-bold text-[#2C1810] dark:text-gray-100">
                분석할 재료 선택 ({selected.size}/{ingredients.length})
              </h3>
              <button onClick={() => setSelected(new Set(ingredients.slice(0, 5).map((i) => i.id)))}
                className="text-xs text-[#D4A574] font-semibold hover:text-[#c4956a]">
                단가 TOP 5 자동 선택
              </button>
            </div>
            <div className="space-y-1.5 max-h-80 overflow-y-auto">
              {ingredients.map((ing) => {
                const isSel = selected.has(ing.id)
                return (
                  <button key={ing.id} onClick={() => toggleSelect(ing.id)}
                    className={cn('w-full flex items-center gap-2 p-2 rounded-lg text-left transition-colors',
                      isSel ? 'bg-[#D4A574]/10 border border-[#D4A574]' : 'hover:bg-gray-50 dark:hover:bg-gray-700 border border-transparent')}>
                    {isSel
                      ? <CheckSquare size={15} className="text-[#D4A574] shrink-0" />
                      : <Square size={15} className="text-gray-300 shrink-0" />}
                    <span className="flex-1 text-sm font-medium text-[#2C1810] dark:text-gray-100">{ing.name}</span>
                    <span className="text-xs text-gray-500 dark:text-gray-400">{formatCurrency(ing.unit_price)}/{ing.unit}</span>
                    {ing.supplier && <span className="text-[10px] text-gray-400">{ing.supplier}</span>}
                  </button>
                )
              })}
            </div>

            <button onClick={handleAnalyze} disabled={analyzing || selected.size === 0}
              className="w-full mt-4 py-3 bg-gradient-to-r from-[#2C1810] to-[#D4A574] text-white rounded-xl font-semibold text-sm hover:opacity-90 disabled:opacity-50 flex items-center justify-center gap-2">
              {analyzing ? <><Loader2 size={14} className="animate-spin" /> AI 분석 중...</> : <><Sparkles size={14} /> AI 절감 제안 받기</>}
            </button>
          </div>
        )}

        {/* 결과 */}
        {suggestions.length > 0 && (
          <div className="space-y-3">
            <h3 className="text-sm font-bold text-[#2C1810] dark:text-gray-100">💡 절감 제안 결과</h3>
            {suggestions.map((s, i) => (
              <div key={i} className="bg-white dark:bg-gray-800 rounded-2xl p-4 border border-gray-100 dark:border-gray-700 shadow-sm">
                <div className="flex items-start gap-2 mb-2">
                  <h4 className="font-bold text-[#2C1810] dark:text-gray-100 flex-1">{s.ingredient}</h4>
                  <span className={cn('text-[10px] font-bold px-2 py-0.5 rounded-full',
                    s.confidence === '높음' ? 'bg-green-100 text-green-700'
                    : s.confidence === '중간' ? 'bg-amber-100 text-amber-700'
                    : 'bg-gray-100 text-gray-500')}>
                    신뢰도 {s.confidence}
                  </span>
                </div>
                <p className="text-xs text-gray-500 dark:text-gray-400 mb-2">현재: {s.current}</p>
                <div className="space-y-1.5 mb-2">
                  {s.alternatives.map((alt, j) => (
                    <div key={j} className="flex items-start gap-2 p-2 bg-[#FAFAF8] dark:bg-gray-900 rounded-lg">
                      <span className="text-[10px] font-bold text-[#D4A574] bg-[#D4A574]/20 w-4 h-4 rounded-full flex items-center justify-center shrink-0 mt-0.5">{j + 1}</span>
                      <span className="text-xs text-gray-700 dark:text-gray-300 leading-relaxed flex-1">{alt}</span>
                    </div>
                  ))}
                </div>
                <p className="text-xs text-green-600 font-semibold">💰 예상 절감: {s.estimated_savings}</p>
                <AiFeedback sourceType="marketing_seo" sourceRef={`${analysisRef}-${i}`} compact />
              </div>
            ))}

            {disclaimer && (
              <div className="flex items-start gap-2 p-3 bg-amber-50 border border-amber-100 rounded-xl text-xs text-amber-700">
                <AlertCircle size={13} className="mt-0.5 shrink-0" />
                <span className="leading-relaxed">{disclaimer}</span>
              </div>
            )}

            <div className="flex items-center gap-2 p-3 bg-blue-50/50 border border-blue-100 rounded-xl text-xs text-blue-700">
              <ExternalLink size={13} />
              <span>제안을 실제 적용하면 👍 "적용함" 피드백 주세요 — AI가 학습합니다</span>
            </div>
          </div>
        )}

        {loading && <div className="flex items-center justify-center py-10"><Loader2 className="w-6 h-6 animate-spin text-[#D4A574]" /></div>}
      </main>
    </div>
  )
}
