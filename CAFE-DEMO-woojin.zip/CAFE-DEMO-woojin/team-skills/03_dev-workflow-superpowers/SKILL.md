---
name: dev-workflow-superpowers
description: This skill should be used when the user asks to plan a feature before implementation, wants test-driven development (TDD), needs help breaking down a complex task into steps, wants code review between steps, needs parallel development with worktrees, or wants structured software engineering workflow. Activates on phrases like "계획 먼저", "TDD", "테스트 주도", "기능 개발", "작업 분해", "코드 리뷰", "plan before code", "feature planning", "implement step by step".
version: 1.0.0
---

# Dev Workflow Superpowers Skill

Structured software development workflow: design first, plan, implement with TDD, review, and verify. Enables autonomous multi-hour development sessions with consistent quality.

> Based on: https://github.com/obra/superpowers

## When This Skill Applies

Activate when:
- Starting a non-trivial feature or refactor
- User wants to plan before implementing
- Task requires multiple sequential steps
- TDD approach is appropriate
- Parallel development (git worktrees) would help
- Code review checkpoints are needed

---

## Phase 1: Design Refinement (Before Writing Code)

**Do NOT write code yet.** First, collaborate to clarify the design.

Ask Socratic questions:
1. What problem does this solve? Who is the user?
2. What are the constraints? (performance, compatibility, security)
3. What does success look like? How will we verify it?
4. What are the edge cases?
5. Are there simpler alternatives?

Produce a **Design Brief**:
```
## Feature: [name]
### Problem
[1-2 sentences]
### Solution
[Approach chosen and why alternatives were rejected]
### Acceptance Criteria
- [ ] [Specific, testable criterion]
- [ ] [Specific, testable criterion]
### Out of Scope
- [Explicitly excluded items]
```

Get user approval on the Design Brief before proceeding.

---

## Phase 2: Task Breakdown

Break implementation into **2-5 minute chunks**. Each task must be:
- Atomic: one logical change
- Testable: has a clear pass/fail condition
- Specific: exact files and functions to change

```
Task 1: [Action verb] [what]
  Files: [file.ts:line-range]
  Test: [how to verify]
  Time: ~3min

Task 2: [Action verb] [what]
  Files: [file.ts:line-range]
  Test: [how to verify]
  Time: ~2min
```

---

## Phase 3: Test-Driven Development (RED → GREEN → REFACTOR)

For each task:

### RED Phase
Write the test first. It must fail.
```bash
# Run test to confirm it fails
npm test -- --testNamePattern="[test name]"
# Expected: FAIL (red)
```

### GREEN Phase
Write minimum code to make the test pass. No extras.
```bash
# Run test to confirm it passes
npm test -- --testNamePattern="[test name]"
# Expected: PASS (green)
```

### REFACTOR Phase
Clean up without breaking tests.
```bash
# Run full test suite to confirm nothing broke
npm test
# Expected: all PASS
```

---

## Phase 4: Code Review Checkpoint

After each task (or every 3-4 tasks for simple changes), review:

```
## Code Review Checklist
- [ ] Does it solve the stated problem?
- [ ] Are there edge cases not handled?
- [ ] Is error handling appropriate?
- [ ] Are there performance concerns?
- [ ] Is the code readable? Would a new dev understand it?
- [ ] Are there security implications? (injection, auth, data exposure)
- [ ] Does it follow existing patterns in the codebase?
```

Flag issues before moving to the next task.

---

## Phase 5: Verification

After all tasks complete:

1. **Run full test suite**: all tests must pass
2. **Manual smoke test**: exercise the feature end-to-end
3. **Check acceptance criteria**: verify each item from Design Brief
4. **Review diff**: `git diff main` — does the overall change look right?

---

## Parallel Development (Git Worktrees)

For large features or when you need to keep main unblocked:

```bash
# Create isolated worktree for the feature
git worktree add ../feature-branch-name -b feature/my-feature

# Work in the worktree
cd ../feature-branch-name

# When done, merge back
cd ../main-repo
git merge feature/my-feature
git worktree remove ../feature-branch-name
```

Use worktrees when:
- Feature takes multiple sessions
- Need to compare implementations side-by-side
- Running parallel experiments

---

## Debugging Protocol

When a test fails or behavior is unexpected:

1. **Read the error**: don't skim — what exactly failed?
2. **Reproduce**: confirm you can reproduce it consistently
3. **Hypothesize**: form a specific theory ("I think X is null because Y")
4. **Verify hypothesis**: add a targeted log or test to confirm/deny
5. **Fix root cause**: don't patch symptoms
6. **Confirm fix**: re-run the test, then the full suite

Never: try random changes, delete and rewrite, or add workarounds without understanding the cause.

---

## Autonomous Development Guidelines

When working independently for extended periods:

- Follow the approved plan; don't invent new scope
- After each task: commit with a clear message
- If blocked: stop, document what's blocking, ask the user
- If uncertain about scope: prefer doing less, asking more
- Never skip tests to go faster

---

## Commit Message Format

```
[type]: [short description]

[optional body: what changed and why]

Types: feat, fix, refactor, test, docs, chore
```

Examples:
```
feat: add gate_pass_rate to KPI dashboard
fix: correct N/A logic for need_gt=False metrics
refactor: extract _compute_ece to separate method
test: add coverage for OOD recall edge cases
```
