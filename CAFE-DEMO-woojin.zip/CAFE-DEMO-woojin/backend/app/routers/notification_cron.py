"""
G4 후속 — 이메일 트리거 cron 통합 (가입 환영 + 체험 만료 알림)

사용 패턴:
  - 가입 직후 환영 메일은 클라이언트에서 직접 호출 (POST /api/v1/notification-cron/welcome)
  - 체험 만료 알림은 매일 02:00 KST cron으로 호출 (POST /api/v1/notification-cron/trial-expiring)
"""
import asyncio
import logging
from datetime import datetime, timedelta, timezone

from fastapi import APIRouter, Header, HTTPException
from pydantic import BaseModel

from app.config import settings
from app.services.email_service import (
    send_welcome_email,
    send_trial_expiring_email,
    get_store_email,
)
from app.services.gemini_service import _get_supabase

logger = logging.getLogger("notification_cron")
router = APIRouter()


class WelcomeEmailRequest(BaseModel):
    store_id: str


@router.post("/welcome")
async def trigger_welcome_email(req: WelcomeEmailRequest):
    """가입 직후 클라이언트가 호출 — 환영 메일 발송."""
    info = await get_store_email(req.store_id)
    if not info:
        return {"sent": False, "reason": "이메일 조회 실패"}
    email, name = info
    sent = await send_welcome_email(email, name)
    return {"sent": sent}


@router.post("/trial-expiring")
async def cron_trial_expiring(
    cron_key: str = Header(default="", alias="X-Cron-Key"),
):
    """체험 만료 3일 전 매장에 메일 발송. cron이 매일 02:00 KST 호출."""
    expected = settings.agent_admin_key or ""
    if not expected or cron_key != expected:
        raise HTTPException(403, "권한 없음")

    sb = _get_supabase()
    if sb is None:
        return {"sent": 0, "note": "Supabase 미설정"}

    # 정확히 3일 후 만료되는 trial — 한 매장당 1회만 (last_trial_email_sent_at으로 멱등)
    target_date_start = datetime.now(timezone.utc) + timedelta(days=3)
    target_date_end = target_date_start + timedelta(hours=24)

    res = await asyncio.to_thread(
        lambda: sb.table("stores")
        .select("id, name, last_trial_email_sent_at, trial_ends_at")
        .gte("trial_ends_at", target_date_start.isoformat())
        .lte("trial_ends_at", target_date_end.isoformat())
        .or_("subscription_status.eq.trial,subscription_status.is.null")
        .execute()
    )
    rows = res.data or []
    sent_count = 0
    skipped = 0

    for row in rows:
        # 멱등 — 이미 발송했으면 스킵
        if row.get("last_trial_email_sent_at"):
            skipped += 1
            continue
        info = await get_store_email(row["id"])
        if not info:
            continue
        email, name = info
        ok = await send_trial_expiring_email(email, name, days_left=3)
        if ok:
            await asyncio.to_thread(
                lambda r=row: sb.table("stores")
                .update({"last_trial_email_sent_at": datetime.now(timezone.utc).isoformat()})
                .eq("id", r["id"])
                .execute()
            )
            sent_count += 1

    return {"sent": sent_count, "skipped": skipped, "total_eligible": len(rows)}
