// QA 시나리오 3: 매출 업로드 → 분석 차트 → AI 인사이트 → 피드백
// 검증: 핵심 사용자 플로우 end-to-end
import { test, expect } from '@playwright/test'
import { setupApiMocks, signInAsOwner } from './fixtures/apiMock'
import { MOCK_SALES_CSV } from './fixtures/mockData'

test.describe('시나리오 3 — 매출 분석 플로우', () => {
  test('CSV 업로드 → 분석 탭 이동 → 요약 지표 노출', async ({ page }) => {
    await setupApiMocks(page)
    await signInAsOwner(page)

    await page.goto('/sales')

    // 데이터 입력 탭
    await expect(page.getByText(/데이터 입력/)).toBeVisible()

    // CSV 파일 업로드 (메모리 버퍼로)
    const csvBuffer = Buffer.from('\uFEFF' + MOCK_SALES_CSV, 'utf-8')
    const fileInput = page.locator('input[type="file"][accept*="csv"]').first()
    await fileInput.setInputFiles({
      name: 'test-sales.csv',
      mimeType: 'text/csv',
      buffer: csvBuffer,
    })

    // 매핑 단계 확인 (auto-mapping 있음)
    await expect(page.getByText(/필드에 매핑/)).toBeVisible({ timeout: 5000 })

    // 가져오기 버튼
    await page.getByRole('button', { name: /행 가져오기/ }).click()
  })

  test('분석 차트 탭에서 4사분면·히트맵·월별 차트 렌더링', async ({ page }) => {
    await setupApiMocks(page)
    await signInAsOwner(page)

    // 매출 데이터 pre-hydration
    await page.addInitScript(() => {
      const records = [
        { id: 'r1', sale_date: '2026-04-15', menu_name: '아메리카노', quantity: 5, revenue: 22500, cost: 6000, hour_slot: 10, day_of_week: 3, discount: 0 },
        { id: 'r2', sale_date: '2026-04-16', menu_name: '라떼', quantity: 4, revenue: 20000, cost: 6000, hour_slot: 11, day_of_week: 4, discount: 0 },
        { id: 'r3', sale_date: '2026-04-17', menu_name: '크로플', quantity: 3, revenue: 15000, cost: 6000, hour_slot: 14, day_of_week: 5, discount: 0 },
      ]
      localStorage.setItem('cafe-brain-sales', JSON.stringify({ state: { records }, version: 0 }))
    })

    await page.goto('/sales')

    // 분석 차트 탭 클릭
    await page.getByRole('button', { name: /분석 차트/ }).click()

    // 메뉴 4사분면 차트 (SVG)
    await expect(page.locator('svg').first()).toBeVisible({ timeout: 5000 })
    // 히트맵 제목
    await expect(page.getByText(/히트맵/)).toBeVisible()
  })

  test('AI 인사이트 탭에서 생성 → 결과 표시 → 피드백 버튼', async ({ page }) => {
    await setupApiMocks(page)
    await signInAsOwner(page)

    // 데이터 주입
    await page.addInitScript(() => {
      const records = Array.from({ length: 20 }, (_, i) => ({
        id: `r-${i}`,
        sale_date: `2026-04-${String(1 + (i % 28)).padStart(2, '0')}`,
        menu_name: i % 2 === 0 ? '아이스 아메리카노' : '카페라떼',
        quantity: 3 + (i % 5),
        revenue: 4500 * (3 + (i % 5)),
        cost: 1200 * (3 + (i % 5)),
        hour_slot: 10 + (i % 8),
        day_of_week: i % 7,
        discount: 0,
      }))
      localStorage.setItem('cafe-brain-sales', JSON.stringify({ state: { records }, version: 0 }))
    })

    await page.goto('/sales')
    await page.getByRole('button', { name: /AI 인사이트/ }).click()

    // 생성 버튼
    const generateBtn = page.getByRole('button', { name: /AI 인사이트 생성/ })
    await expect(generateBtn).toBeVisible()
    await generateBtn.click()

    // 인사이트 결과 (Mock으로 반환된 텍스트의 일부)
    await expect(page.getByText(/아이스 아메리카노/)).toBeVisible({ timeout: 10_000 })

    // AiFeedback 위젯 — "이 제안 어때요?"
    await expect(page.getByText(/이 제안 어때요/)).toBeVisible()

    // 👍 피드백 버튼 클릭
    const thumbsUp = page.getByLabel(/유용했어요/).first()
    await thumbsUp.click()

    // 반응 기록 피드백
    await expect(page.getByText(/유용한 제안 더 자주|반응이 기록/)).toBeVisible({ timeout: 3000 })
  })
})
