// G2 — 데모 데이터 시더 버튼
// 매장에 데이터가 거의 없을 때 Dashboard에 노출
import { useEffect, useState } from 'react'
import { Sparkles, Loader2 } from 'lucide-react'
import { supabase } from '@/lib/supabase'
import { useAuthStore } from '@/store/authStore'
import { seedDemoData } from '@/lib/demoSeeder'
import toast from 'react-hot-toast'

export default function DemoSeederButton() {
  const user = useAuthStore((s) => s.user)
  const [salesCount, setSalesCount] = useState<number | null>(null)
  const [seeding, setSeeding] = useState(false)

  useEffect(() => {
    if (!user) return
    void (async () => {
      const { count } = await supabase
        .from('sales_records')
        .select('id', { count: 'exact', head: true })
        .eq('store_id', user.id)
      setSalesCount(count ?? 0)
    })()
  }, [user])

  if (!user || salesCount === null) return null
  // 충분한 데이터가 있으면 표시 안 함
  if (salesCount > 50) return null

  const seed = async () => {
    if (!user) return
    setSeeding(true)
    try {
      await seedDemoData(user.id)
      window.location.reload()  // 데이터 다시 로드
    } catch (e) {
      toast.error(`데모 데이터 추가 실패: ${e instanceof Error ? e.message : '오류'}`)
    } finally {
      setSeeding(false)
    }
  }

  return (
    <div className="bg-gradient-to-br from-[#D4A574]/15 to-[#D4A574]/5 border-2 border-[#D4A574]/40 border-dashed rounded-2xl p-5 m-4">
      <div className="flex items-start gap-3">
        <div className="w-10 h-10 rounded-xl bg-[#D4A574] flex items-center justify-center shrink-0">
          <Sparkles size={18} className="text-white" />
        </div>
        <div className="flex-1">
          <h3 className="font-bold text-[#2C1810] text-sm mb-1">
            아직 데이터가 적네요 — 체험 모드로 둘러보실래요?
          </h3>
          <p className="text-xs text-gray-600 leading-relaxed mb-3">
            30일치 가짜 매출·메뉴·리뷰 데이터를 자동으로 채워서 모든 기능을 미리 체험해볼 수 있어요.
            기존 데이터는 보존됩니다.
          </p>
          <button
            onClick={seed}
            disabled={seeding}
            className="bg-[#2C1810] text-white text-xs font-semibold px-4 py-2 rounded-lg hover:bg-[#3A2519] transition-colors disabled:opacity-50 inline-flex items-center gap-1.5"
          >
            {seeding ? (
              <><Loader2 size={12} className="animate-spin" /> 채우는 중…</>
            ) : (
              <><Sparkles size={12} /> 데모 데이터 추가</>
            )}
          </button>
        </div>
      </div>
    </div>
  )
}
