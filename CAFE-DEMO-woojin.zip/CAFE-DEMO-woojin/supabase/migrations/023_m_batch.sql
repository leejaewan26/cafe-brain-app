-- M 배치 — 차별화 기능 영속·통계 + admin 메트릭

-- M1 청결 점수 히스토리
CREATE TABLE IF NOT EXISTS cleanliness_history (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  store_id        UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  area            TEXT NOT NULL DEFAULT '전체',
  score           INT NOT NULL,
  grade           TEXT NOT NULL,
  issues          JSONB,
  recommendations JSONB,
  created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_cleanliness_store_date
  ON cleanliness_history(store_id, created_at DESC);

ALTER TABLE cleanliness_history ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "cleanliness_owner" ON cleanliness_history;
CREATE POLICY "cleanliness_owner" ON cleanliness_history
  FOR ALL USING (auth.uid() = store_id);

-- M2 직원 퀴즈 채점 이력
CREATE TABLE IF NOT EXISTS quiz_attempts (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  store_id        UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  staff_name      TEXT NOT NULL,
  total_questions INT NOT NULL,
  correct_count   INT NOT NULL,
  score           INT NOT NULL,
  duration_sec    INT,
  detail          JSONB,
  created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_quiz_attempts_store_staff
  ON quiz_attempts(store_id, staff_name, created_at DESC);

ALTER TABLE quiz_attempts ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "quiz_attempts_owner" ON quiz_attempts;
CREATE POLICY "quiz_attempts_owner" ON quiz_attempts
  FOR ALL USING (auth.uid() = store_id);

-- M3 stores 매칭용 컬럼
ALTER TABLE stores
  ADD COLUMN IF NOT EXISTS region TEXT,
  ADD COLUMN IF NOT EXISTS employee_count INT;

-- M3 분위수 매칭 RPC
CREATE OR REPLACE FUNCTION revenue_per_day_quartiles_matched(
  p_days INT,
  p_region TEXT DEFAULT NULL,
  p_employee_count INT DEFAULT NULL
)
RETURNS TABLE(
  p25 NUMERIC,
  p50 NUMERIC,
  p75 NUMERIC,
  sample_size BIGINT
)
LANGUAGE SQL
SECURITY DEFINER
AS $$
  WITH per_store AS (
    SELECT
      sr.store_id,
      SUM(sr.revenue)::NUMERIC / GREATEST(p_days, 1) AS avg_per_day
    FROM sales_records sr
    JOIN stores s ON s.id = sr.store_id
    WHERE sr.sale_date >= (CURRENT_DATE - p_days)
      AND (p_region IS NULL OR s.region = p_region)
      AND (
        p_employee_count IS NULL
        OR ABS(COALESCE(s.employee_count, 0) - p_employee_count) <= 2
      )
    GROUP BY sr.store_id
    HAVING COUNT(*) >= 5
  )
  SELECT
    PERCENTILE_CONT(0.25) WITHIN GROUP (ORDER BY avg_per_day) AS p25,
    PERCENTILE_CONT(0.50) WITHIN GROUP (ORDER BY avg_per_day) AS p50,
    PERCENTILE_CONT(0.75) WITHIN GROUP (ORDER BY avg_per_day) AS p75,
    COUNT(*)::BIGINT AS sample_size
  FROM per_store;
$$;

-- M6 stores 정지 컬럼
ALTER TABLE stores
  ADD COLUMN IF NOT EXISTS suspended_reason TEXT,
  ADD COLUMN IF NOT EXISTS suspended_at TIMESTAMPTZ;

-- M6 메모리 archive_reason
ALTER TABLE agent_memory
  ADD COLUMN IF NOT EXISTS archive_reason TEXT;

COMMENT ON FUNCTION revenue_per_day_quartiles_matched IS 'M3 — 지역·규모 매칭 분위수. region 일치 + employee_count ±2명 이내.';
