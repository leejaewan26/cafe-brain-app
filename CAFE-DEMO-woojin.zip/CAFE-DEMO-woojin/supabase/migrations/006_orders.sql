-- Issue #8: 발주 관리 시스템
-- 점장이 요청 → 사장이 승인 → 이력 저장 → 파일 다운로드

-- 발주 헤더
CREATE TABLE IF NOT EXISTS public.orders (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  store_id uuid NOT NULL REFERENCES public.stores(id) ON DELETE CASCADE,

  -- 작성·승인 추적 (profile 참조, nullable은 프로필 삭제 대비)
  requested_by_profile_id uuid REFERENCES public.profiles(id) ON DELETE SET NULL,
  requested_by_name text NOT NULL,  -- 스냅샷 (프로필 삭제돼도 이력 유지)
  approved_by_profile_id uuid REFERENCES public.profiles(id) ON DELETE SET NULL,
  approved_by_name text,

  -- 상태
  status text NOT NULL DEFAULT 'pending' CHECK (status IN (
    'pending',    -- 요청 대기
    'approved',   -- 승인 (발주 준비)
    'rejected',   -- 반려
    'ordered',    -- 실제 발주 완료 (수기 업데이트)
    'received'    -- 수령 완료
  )),

  -- 발주처 정보
  supplier_name text NOT NULL,
  supplier_phone text,
  notes text,

  -- 시간 추적
  requested_at timestamptz NOT NULL DEFAULT now(),
  approved_at timestamptz,
  rejected_reason text,
  ordered_at timestamptz,
  received_at timestamptz,

  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_orders_store_status
  ON public.orders(store_id, status, requested_at DESC);

-- 발주 항목 (라인 아이템)
CREATE TABLE IF NOT EXISTS public.order_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  order_id uuid NOT NULL REFERENCES public.orders(id) ON DELETE CASCADE,

  ingredient_name text NOT NULL,
  quantity numeric NOT NULL CHECK (quantity > 0),
  unit text NOT NULL,                   -- 'kg', 'g', '개', 'L' 등
  estimated_unit_price numeric,         -- 단가 추정 (선택)
  estimated_total numeric,              -- 예상 합계 (선택)
  item_notes text,

  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_order_items_order
  ON public.order_items(order_id);

-- RLS: 본인 매장만 접근
ALTER TABLE public.orders ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.order_items ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "orders: 본인 매장" ON public.orders;
CREATE POLICY "orders: 본인 매장" ON public.orders
  FOR ALL USING (store_id = auth.uid());

DROP POLICY IF EXISTS "order_items: 본인 매장" ON public.order_items;
CREATE POLICY "order_items: 본인 매장" ON public.order_items
  FOR ALL USING (
    EXISTS (SELECT 1 FROM public.orders o WHERE o.id = order_id AND o.store_id = auth.uid())
  );

COMMENT ON TABLE public.orders IS 'Issue #8: 발주 관리. 점장 요청 → 사장 승인 워크플로우.';
