"""
Launch A1 — CORS 설정 검증.
- "*"일 때 credentials=False (브라우저 보안)
- specific origin일 때 credentials=True
"""
from app.config import Settings


def test_cors_wildcard_returns_star_list():
    s = Settings(cors_allow_origins="*")
    assert s.cors_origins_list == ["*"]


def test_cors_specific_origins_parsed():
    s = Settings(cors_allow_origins="https://a.com,https://b.com,https://c.app")
    assert s.cors_origins_list == ["https://a.com", "https://b.com", "https://c.app"]


def test_cors_strips_whitespace():
    s = Settings(cors_allow_origins=" https://a.com , https://b.com ")
    assert s.cors_origins_list == ["https://a.com", "https://b.com"]


def test_cors_empty_falls_back_to_wildcard():
    s = Settings(cors_allow_origins="")
    assert s.cors_origins_list == ["*"]


def test_cors_preflight_with_wildcard(client):
    """preflight OPTIONS — 어떤 origin도 통과 (* 모드)."""
    r = client.options(
        "/health",
        headers={
            "Origin": "https://example.com",
            "Access-Control-Request-Method": "GET",
        },
    )
    # OPTIONS는 별도 라우트 미정의여도 CORS 미들웨어가 200 반환
    assert r.status_code in (200, 204, 405)
