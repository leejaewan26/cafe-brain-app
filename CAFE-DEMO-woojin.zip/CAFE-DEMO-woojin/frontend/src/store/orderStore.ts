// 발주 관리 스토어 (Issue #8)
// Supabase 동기화 + 로컬 캐시
import { create } from 'zustand'
import { supabase } from '@/lib/supabase'

export type OrderStatus = 'pending' | 'approved' | 'rejected' | 'ordered' | 'received'

export interface OrderItem {
  id: string
  order_id: string
  ingredient_name: string
  quantity: number
  unit: string
  estimated_unit_price?: number | null
  estimated_total?: number | null
  item_notes?: string | null
}

export interface Order {
  id: string
  store_id: string
  requested_by_profile_id?: string | null
  requested_by_name: string
  approved_by_profile_id?: string | null
  approved_by_name?: string | null
  status: OrderStatus
  supplier_name: string
  supplier_phone?: string | null
  notes?: string | null
  requested_at: string
  approved_at?: string | null
  rejected_reason?: string | null
  ordered_at?: string | null
  received_at?: string | null
  items: OrderItem[]
}

export const ORDER_STATUS_META: Record<OrderStatus, { label: string; color: string; bg: string }> = {
  pending:  { label: '승인 대기', color: 'text-amber-700',  bg: 'bg-amber-100' },
  approved: { label: '승인됨',    color: 'text-blue-700',   bg: 'bg-blue-100' },
  rejected: { label: '반려',      color: 'text-red-700',    bg: 'bg-red-100' },
  ordered:  { label: '발주 완료', color: 'text-purple-700', bg: 'bg-purple-100' },
  received: { label: '수령 완료', color: 'text-green-700',  bg: 'bg-green-100' },
}

interface OrderState {
  orders: Order[]
  loading: boolean
  error: string | null

  fetchOrders: (storeId: string) => Promise<void>
  createOrder: (
    storeId: string,
    profileId: string,
    profileName: string,
    data: {
      supplier_name: string
      supplier_phone?: string
      notes?: string
      items: Array<Omit<OrderItem, 'id' | 'order_id'>>
    }
  ) => Promise<Order | null>
  approveOrder: (orderId: string, approverId: string, approverName: string) => Promise<void>
  rejectOrder: (orderId: string, reason: string, rejectorName: string) => Promise<void>
  markOrdered: (orderId: string) => Promise<void>
  markReceived: (orderId: string) => Promise<void>
}

export const useOrderStore = create<OrderState>((set, get) => ({
  orders: [],
  loading: false,
  error: null,

  fetchOrders: async (storeId) => {
    set({ loading: true, error: null })
    try {
      const { data: ordersData, error: ordersErr } = await supabase
        .from('orders')
        .select('*')
        .eq('store_id', storeId)
        .order('requested_at', { ascending: false })
      if (ordersErr) throw ordersErr

      const orderIds = (ordersData ?? []).map((o) => o.id)
      let itemsByOrder: Record<string, OrderItem[]> = {}
      if (orderIds.length > 0) {
        const { data: itemsData, error: itemsErr } = await supabase
          .from('order_items')
          .select('*')
          .in('order_id', orderIds)
        if (itemsErr) throw itemsErr
        itemsByOrder = (itemsData ?? []).reduce((acc, i) => {
          const arr = acc[i.order_id] ?? []
          arr.push(i as OrderItem)
          acc[i.order_id] = arr
          return acc
        }, {} as Record<string, OrderItem[]>)
      }

      const orders = (ordersData ?? []).map((o) => ({
        ...o,
        items: itemsByOrder[o.id] ?? [],
      })) as Order[]

      set({ orders, loading: false })
    } catch (e) {
      const msg = e instanceof Error ? e.message : '발주 로드 실패'
      set({ error: msg, loading: false })
    }
  },

  createOrder: async (storeId, profileId, profileName, data) => {
    try {
      const { data: created, error: orderErr } = await supabase
        .from('orders')
        .insert({
          store_id: storeId,
          requested_by_profile_id: profileId,
          requested_by_name: profileName,
          supplier_name: data.supplier_name,
          supplier_phone: data.supplier_phone ?? null,
          notes: data.notes ?? null,
          status: 'pending',
        })
        .select()
        .single()
      if (orderErr) throw orderErr

      // 항목 추가
      if (data.items.length > 0) {
        const itemsPayload = data.items.map((i) => ({
          order_id: created.id,
          ingredient_name: i.ingredient_name,
          quantity: i.quantity,
          unit: i.unit,
          estimated_unit_price: i.estimated_unit_price ?? null,
          estimated_total:
            i.estimated_unit_price && i.quantity
              ? i.estimated_unit_price * i.quantity
              : (i.estimated_total ?? null),
          item_notes: i.item_notes ?? null,
        }))
        const { error: itemsErr } = await supabase.from('order_items').insert(itemsPayload)
        if (itemsErr) throw itemsErr
      }

      await get().fetchOrders(storeId)
      return get().orders.find((o) => o.id === created.id) ?? null
    } catch (e) {
      const msg = e instanceof Error ? e.message : '발주 생성 실패'
      set({ error: msg })
      return null
    }
  },

  approveOrder: async (orderId, approverId, approverName) => {
    const { error } = await supabase
      .from('orders')
      .update({
        status: 'approved',
        approved_by_profile_id: approverId,
        approved_by_name: approverName,
        approved_at: new Date().toISOString(),
      })
      .eq('id', orderId)
    if (error) throw error

    set((s) => ({
      orders: s.orders.map((o) =>
        o.id === orderId
          ? {
              ...o,
              status: 'approved',
              approved_by_profile_id: approverId,
              approved_by_name: approverName,
              approved_at: new Date().toISOString(),
            }
          : o
      ),
    }))
  },

  rejectOrder: async (orderId, reason, rejectorName) => {
    const { error } = await supabase
      .from('orders')
      .update({
        status: 'rejected',
        approved_by_name: rejectorName,
        rejected_reason: reason,
      })
      .eq('id', orderId)
    if (error) throw error

    set((s) => ({
      orders: s.orders.map((o) =>
        o.id === orderId
          ? { ...o, status: 'rejected', approved_by_name: rejectorName, rejected_reason: reason }
          : o
      ),
    }))
  },

  markOrdered: async (orderId) => {
    const { error } = await supabase
      .from('orders')
      .update({ status: 'ordered', ordered_at: new Date().toISOString() })
      .eq('id', orderId)
    if (error) throw error
    set((s) => ({
      orders: s.orders.map((o) =>
        o.id === orderId ? { ...o, status: 'ordered', ordered_at: new Date().toISOString() } : o
      ),
    }))
  },

  markReceived: async (orderId) => {
    const { error } = await supabase
      .from('orders')
      .update({ status: 'received', received_at: new Date().toISOString() })
      .eq('id', orderId)
    if (error) throw error
    set((s) => ({
      orders: s.orders.map((o) =>
        o.id === orderId ? { ...o, status: 'received', received_at: new Date().toISOString() } : o
      ),
    }))
  },
}))
