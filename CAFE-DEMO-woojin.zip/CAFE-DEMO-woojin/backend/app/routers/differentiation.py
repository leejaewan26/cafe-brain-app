"""
J3 + J4 + J5 + J6 — 차별화 기능

J3 청결 OCR 진단
  매장 사진 업로드 → AI가 위생 점수 + 개선점 진단
J4 직원 교육 퀴즈
  메뉴 + 레시피 자동으로 4지선다 + 단답형 퀴즈 생성
J5 음성 메모 → 자동 정리
  녹음 텍스트(STT 결과) → 카테고리별 분류 + 메모리 저장
J6 동네 평균 매출 (익명 벤치마크)
  내 매장 vs 동종업계 익명 통계 비교 (규모/지역 매칭)

J6 프라이버시: 절대 raw 매출 노출 X — p25/p50/p75 분위수만 + 매장 ID는 원-핫 해시
"""
import asyncio
import logging
import re
from datetime import datetime, timedelta, timezone
from typing import Optional

from fastapi import APIRouter, Header, HTTPException
from pydantic import BaseModel, Field

from app.services.feature_flags import is_enabled as flag_enabled
from app.services.gemini_service import (
    _get_supabase,
    generate_insight,
    generate_insight_from_image,
    generate_with_review,
)

logger = logging.getLogger("differentiation")
router = APIRouter()


# ═══════════════════════════════════════════════════════
# J3 — 청결 OCR
# ═══════════════════════════════════════════════════════


class CleanlinessRequest(BaseModel):
    image_base64: str
    mime_type: str = "image/jpeg"
    area: Optional[str] = "전체"  # 카운터·홀·주방·화장실 등


class CleanlinessResponse(BaseModel):
    score: int  # 0-100
    grade: str  # A/B/C/D
    issues: list[str]
    recommendations: list[str]
    raw_observations: str


@router.post("/cleanliness", response_model=CleanlinessResponse)
async def diagnose_cleanliness(
    req: CleanlinessRequest,
    store_id: str = Header(..., alias="X-Store-Id"),
):
    """매장 사진을 분석해서 위생 점수 + 개선점 반환."""
    prompt = f"""당신은 식품위생감독관입니다. 첨부된 사진은 카페의 "{req.area}" 구역입니다.
다음을 평가해주세요:

1. 청결 점수 (0-100)
2. 등급 (A: 90+, B: 75-89, C: 60-74, D: 60 미만)
3. 발견된 문제점 (최대 5개)
4. 개선 권고사항 (최대 5개)
5. 원시 관찰 (사진에서 보이는 모든 위생 관련 요소)

응답 형식 (JSON):
{{
  "score": 정수,
  "grade": "A/B/C/D",
  "issues": ["문제1", "문제2"],
  "recommendations": ["권고1", "권고2"],
  "raw_observations": "사진에서 보이는 것 자세히"
}}

주의: 위생감독관 시각으로 엄격하게. 손님 시점 X. 식약처 기준.
"""
    try:
        # K7: 공통 Vision 함수 사용
        raw = await generate_insight_from_image(
            prompt=prompt,
            image_base64=req.image_base64,
            mime_type=req.mime_type,
            show_watermark=False,
        )
        # JSON 파싱
        import json as _json
        cleaned = re.sub(r"```(?:json)?\s*|\s*```", "", raw).strip()
        m = re.search(r"\{[\s\S]*\}", cleaned)
        if m:
            cleaned = m.group()
        data = _json.loads(cleaned)
        result = CleanlinessResponse(
            score=int(data.get("score", 0)),
            grade=data.get("grade", "C"),
            issues=[str(x)[:200] for x in (data.get("issues") or [])[:5]],
            recommendations=[str(x)[:200] for x in (data.get("recommendations") or [])[:5]],
            raw_observations=str(data.get("raw_observations", ""))[:1000],
        )
    except Exception as e:
        logger.error("cleanliness diagnose 실패: %s", e)
        raise HTTPException(500, f"진단 실패: {str(e)[:100]}")

    # M1 — 결과 영속 저장 (히스토리 추적, 실패해도 응답은 정상 반환)
    sb = _get_supabase()
    if sb is not None:
        try:
            await asyncio.to_thread(
                lambda: sb.table("cleanliness_history").insert({
                    "store_id": store_id,
                    "area": req.area,
                    "score": result.score,
                    "grade": result.grade,
                    "issues": result.issues,
                    "recommendations": result.recommendations,
                    "created_at": datetime.now(timezone.utc).isoformat(),
                }).execute()
            )
        except Exception:
            pass
    return result


# ═══════════════════════════════════════════════════════
# J4 — 직원 교육 퀴즈
# ═══════════════════════════════════════════════════════


class QuizRequest(BaseModel):
    store_id: str
    menu_ids: Optional[list[str]] = None  # 특정 메뉴만, None=전체
    difficulty: str = Field(default="medium", pattern="^(easy|medium|hard)$")
    count: int = Field(default=5, ge=1, le=20)


class QuizQuestion(BaseModel):
    question: str
    type: str  # mcq / short
    choices: Optional[list[str]] = None
    answer: str
    explanation: str


class QuizResponse(BaseModel):
    questions: list[QuizQuestion]
    topic_summary: str


@router.post("/staff-quiz", response_model=QuizResponse)
async def generate_staff_quiz(req: QuizRequest):
    """등록된 메뉴 + 레시피를 기반으로 직원 교육 퀴즈 자동 생성."""
    sb = _get_supabase()
    if sb is None:
        raise HTTPException(503, "Supabase 미설정")

    # 메뉴 조회
    q = sb.table("menus").select("name, description, recipe, price, allergens").eq("store_id", req.store_id)
    if req.menu_ids:
        q = q.in_("id", req.menu_ids)
    res = await asyncio.to_thread(lambda: q.limit(20).execute())
    menus = res.data or []
    if not menus:
        raise HTTPException(400, "퀴즈를 만들 메뉴가 없어요")

    menu_text = "\n".join(
        f"- {m['name']}: {m.get('description') or '-'} / 레시피: {m.get('recipe') or '-'} / 가격: {m.get('price', 0)}원 / 알레르기: {m.get('allergens') or '없음'}"
        for m in menus
    )

    prompt = f"""당신은 카페 사장님이고, 신입 바리스타에게 메뉴를 교육하려고 합니다.
아래 메뉴 정보를 바탕으로 {req.count}문제 퀴즈를 만들어주세요.
난이도: {req.difficulty}

메뉴 정보:
{menu_text}

문제 형식 (JSON):
{{
  "questions": [
    {{
      "question": "문제",
      "type": "mcq" 또는 "short",
      "choices": ["A", "B", "C", "D"] (mcq일 때만),
      "answer": "정답",
      "explanation": "왜 정답인지 자세한 설명 (학습 효과)"
    }}
  ],
  "topic_summary": "이 퀴즈가 다루는 핵심 주제 요약 (2~3문장)"
}}

규칙:
- mcq:short = 7:3
- 알레르기·원가·레시피 비율은 골고루
- 한국어, 친근하고 명확한 어투
- 정답 단답으로 명확히
"""
    try:
        if await flag_enabled("agent_self_correction", req.store_id):
            raw, _ = await generate_with_review(prompt, question_for_review="직원 교육 퀴즈 생성")
        else:
            raw = await generate_insight(prompt, show_watermark=False)
        import json as _json
        cleaned = re.sub(r"```(?:json)?\s*|\s*```", "", raw).strip()
        m = re.search(r"\{[\s\S]*\}", cleaned)
        if m:
            cleaned = m.group()
        data = _json.loads(cleaned)
        questions = [
            QuizQuestion(
                question=str(q.get("question", ""))[:300],
                type=q.get("type", "short"),
                choices=q.get("choices"),
                answer=str(q.get("answer", ""))[:200],
                explanation=str(q.get("explanation", ""))[:500],
            )
            for q in data.get("questions", [])[:req.count]
        ]
        return QuizResponse(
            questions=questions,
            topic_summary=str(data.get("topic_summary", ""))[:500],
        )
    except Exception as e:
        logger.error("quiz 생성 실패: %s", e)
        raise HTTPException(500, f"퀴즈 생성 실패: {str(e)[:100]}")


# ═══════════════════════════════════════════════════════
# J5 — 음성 메모 → 자동 정리
# ═══════════════════════════════════════════════════════


class VoiceMemoRequest(BaseModel):
    store_id: str
    transcript: str = Field(..., min_length=10, max_length=5000)
    duration_sec: Optional[int] = None
    recorded_at: Optional[str] = None


class VoiceMemoResponse(BaseModel):
    summary: str
    categories: list[str]  # 매장운영 / 인사 / 마케팅 / 발주 / 고객 등
    action_items: list[str]
    memories_saved: int


@router.post("/voice-memo/organize", response_model=VoiceMemoResponse)
async def organize_voice_memo(req: VoiceMemoRequest):
    """녹음 텍스트를 분석해서 카테고리별 분류 + 액션아이템 추출 + 메모리 저장."""
    prompt = f"""사장님이 출근길에 녹음한 메모입니다. 분석해주세요.

녹음 내용:
\"\"\"{req.transcript}\"\"\"

응답 형식 (JSON):
{{
  "summary": "한 문장으로 핵심 요약",
  "categories": ["매장운영", "인사", "마케팅", ...],   // 해당하는 것만
  "action_items": [
    "오늘 해야 할 일 1",
    "오늘 해야 할 일 2"
  ],
  "memories": [
    {{"category": "운영_규칙", "content": "기억해야 할 사실 또는 결정"}},
    ...
  ]
}}

규칙:
- 카테고리는 매장운영, 인사, 마케팅, 발주, 고객, 메뉴, 회계 중에서
- 액션아이템은 동사로 시작 (예: "원두 발주하기")
- memories는 영속 저장될 학습 데이터 — 일회성 메모는 X
- 한국어
"""
    try:
        raw = await generate_insight(prompt, show_watermark=False)
        import json as _json
        cleaned = re.sub(r"```(?:json)?\s*|\s*```", "", raw).strip()
        m = re.search(r"\{[\s\S]*\}", cleaned)
        if m:
            cleaned = m.group()
        data = _json.loads(cleaned)

        # 메모리 저장
        memories = data.get("memories", [])
        sb = _get_supabase()
        saved = 0
        if sb and memories:
            for mem in memories[:10]:
                try:
                    await asyncio.to_thread(
                        lambda mm=mem: sb.table("agent_memory").insert({
                            "store_id": req.store_id,
                            "category": mm.get("category", "운영_규칙")[:50],
                            "content": str(mm.get("content", ""))[:1000],
                            "importance": 6,
                            "confidence": 0.8,
                            "source_type": "voice_memo",
                        }).execute()
                    )
                    saved += 1
                except Exception:
                    pass

        return VoiceMemoResponse(
            summary=str(data.get("summary", ""))[:300],
            categories=[str(c)[:30] for c in data.get("categories", [])[:7]],
            action_items=[str(a)[:200] for a in data.get("action_items", [])[:10]],
            memories_saved=saved,
        )
    except Exception as e:
        logger.error("voice memo 정리 실패: %s", e)
        raise HTTPException(500, f"분석 실패: {str(e)[:100]}")


# ═══════════════════════════════════════════════════════
# J6 — 동종업계 익명 벤치마크
# ═══════════════════════════════════════════════════════


class BenchmarkResponse(BaseModel):
    my_value: float
    p25: float
    p50: float
    p75: float
    sample_size: int
    metric: str
    period: str
    note: str
    privacy_note: str


@router.get("/benchmark/revenue-per-day", response_model=BenchmarkResponse)
async def benchmark_revenue(
    period: str = "30d",
    store_id: str = Header(..., alias="X-Store-Id"),
):
    """
    내 매장 일평균 매출 vs 전체 매장 분위수.

    프라이버시:
      - 다른 매장 raw 매출 X
      - 표본 < 10이면 결과 비공개 (k-anonymity)
      - 분위수만 (p25/p50/p75)
    """
    sb = _get_supabase()
    if sb is None:
        raise HTTPException(503, "Supabase 미설정")

    days = int(period.rstrip("d")) if period.endswith("d") else 30
    cutoff = (datetime.now(timezone.utc) - timedelta(days=days)).date().isoformat()

    # 내 매장 일평균
    my_res = await asyncio.to_thread(
        lambda: sb.table("sales_records")
        .select("revenue, sale_date")
        .eq("store_id", store_id)
        .gte("sale_date", cutoff)
        .execute()
    )
    my_rows = my_res.data or []
    my_total = sum(int(r.get("revenue") or 0) for r in my_rows)
    my_avg_per_day = my_total / max(1, days)

    # 전체 매장 (집계 SQL — RPC 권장, 여기선 간단히)
    # 실제로는 스토어드 프로시저로 분위수 계산 — 여기선 in-memory aggregate
    # 한정된 표본으로 demo
    try:
        all_res = await asyncio.to_thread(
            lambda: sb.rpc("revenue_per_day_quartiles", {"p_days": days}).execute()
        )
        rpc_data = (all_res.data or [{}])[0] if all_res.data else {}
        p25 = float(rpc_data.get("p25", 0))
        p50 = float(rpc_data.get("p50", 0))
        p75 = float(rpc_data.get("p75", 0))
        sample = int(rpc_data.get("sample_size", 0))
    except Exception:
        # RPC 미설치 — 간단 stub
        p25, p50, p75, sample = 100000.0, 250000.0, 500000.0, 0

    if sample < 10:
        return BenchmarkResponse(
            my_value=my_avg_per_day,
            p25=0, p50=0, p75=0,
            sample_size=sample,
            metric="일평균 매출 (KRW)",
            period=f"{days}일",
            note=f"비교 표본이 부족합니다 ({sample}개). 10개 이상 매장에서 벤치마크가 활성화됩니다.",
            privacy_note="개별 매장 데이터는 공개하지 않습니다 (k-익명성).",
        )

    # 위치
    if my_avg_per_day < p25:
        position = "하위 25% — 향상 여지 큼"
    elif my_avg_per_day < p50:
        position = "하위 50% — 평균 미만"
    elif my_avg_per_day < p75:
        position = "상위 50% — 평균 이상"
    else:
        position = "상위 25% — 우수 매장"

    return BenchmarkResponse(
        my_value=my_avg_per_day,
        p25=p25,
        p50=p50,
        p75=p75,
        sample_size=sample,
        metric="일평균 매출 (KRW)",
        period=f"{days}일",
        note=position,
        privacy_note="다른 매장 raw 데이터는 절대 공개되지 않습니다. 분위수 통계만 제공.",
    )


# ═══════════════════════════════════════════════════════
# J2 — 로드맵 투표 (단순 INSERT)
# ═══════════════════════════════════════════════════════


class RoadmapVoteRequest(BaseModel):
    feature_id: str
    store_id: str


# ═══════════════════════════════════════════════════════
# M1 — 청결 점수 히스토리
# ═══════════════════════════════════════════════════════


@router.get("/cleanliness/history")
async def cleanliness_history(
    store_id: str = Header(..., alias="X-Store-Id"),
    days: int = 90,
    area: Optional[str] = None,
):
    """매장 청결 점수 시계열 — 차트용."""
    sb = _get_supabase()
    if sb is None:
        return {"history": []}
    cutoff = (datetime.now(timezone.utc) - timedelta(days=days)).isoformat()
    q = sb.table("cleanliness_history").select(
        "created_at, area, score, grade"
    ).eq("store_id", store_id).gte("created_at", cutoff).order("created_at")
    if area and area != "전체":
        q = q.eq("area", area)
    res = await asyncio.to_thread(lambda: q.execute())
    rows = res.data or []
    # 추세 계산: 최근 7일 vs 이전 7일
    if len(rows) >= 4:
        mid = len(rows) // 2
        recent_avg = sum(r["score"] for r in rows[mid:]) / max(1, len(rows) - mid)
        prev_avg = sum(r["score"] for r in rows[:mid]) / max(1, mid)
        trend = recent_avg - prev_avg
    else:
        trend = 0
    return {
        "history": rows,
        "count": len(rows),
        "trend_delta": round(trend, 1),
        "latest_score": rows[-1]["score"] if rows else None,
    }


# ═══════════════════════════════════════════════════════
# M2 — 직원 퀴즈 제출 + 채점 + 통계
# ═══════════════════════════════════════════════════════


class QuizSubmitRequest(BaseModel):
    store_id: str
    staff_name: str
    quiz_questions: list[dict]   # 원본 (정답 포함)
    answers: list[str]
    duration_sec: Optional[int] = None


@router.post("/staff-quiz/submit")
async def submit_quiz(req: QuizSubmitRequest):
    """답안 제출 → 자동 채점 → quiz_attempts 저장."""
    if len(req.answers) != len(req.quiz_questions):
        raise HTTPException(400, "답안 수가 문제 수와 일치하지 않음")

    correct = 0
    detail = []
    for q, a in zip(req.quiz_questions, req.answers):
        # 정답 비교 (대소문자/공백 무시)
        ans = (q.get("answer") or "").strip().lower()
        user_ans = (a or "").strip().lower()
        is_correct = ans == user_ans or (ans and ans in user_ans)
        if is_correct:
            correct += 1
        detail.append({
            "question": q.get("question", "")[:100],
            "user_answer": a[:100],
            "correct_answer": q.get("answer", "")[:100],
            "is_correct": is_correct,
        })

    score = int((correct / len(req.quiz_questions)) * 100) if req.quiz_questions else 0

    sb = _get_supabase()
    if sb is not None:
        try:
            await asyncio.to_thread(
                lambda: sb.table("quiz_attempts").insert({
                    "store_id": req.store_id,
                    "staff_name": req.staff_name,
                    "total_questions": len(req.quiz_questions),
                    "correct_count": correct,
                    "score": score,
                    "duration_sec": req.duration_sec,
                    "detail": detail,
                    "created_at": datetime.now(timezone.utc).isoformat(),
                }).execute()
            )
        except Exception:
            pass

    return {
        "score": score,
        "correct": correct,
        "total": len(req.quiz_questions),
        "detail": detail,
        "grade": "A" if score >= 90 else "B" if score >= 75 else "C" if score >= 60 else "D",
    }


@router.get("/staff-quiz/stats")
async def quiz_stats(store_id: str = Header(..., alias="X-Store-Id"), days: int = 30):
    """직원별·기간별 퀴즈 통계."""
    sb = _get_supabase()
    if sb is None:
        return {"by_staff": [], "overall": {}}
    cutoff = (datetime.now(timezone.utc) - timedelta(days=days)).isoformat()
    res = await asyncio.to_thread(
        lambda: sb.table("quiz_attempts")
        .select("staff_name, score, total_questions, correct_count, created_at")
        .eq("store_id", store_id)
        .gte("created_at", cutoff)
        .execute()
    )
    rows = res.data or []
    by_staff: dict[str, list] = {}
    for r in rows:
        by_staff.setdefault(r["staff_name"], []).append(r)
    summary = []
    for name, attempts in by_staff.items():
        avg = sum(a["score"] for a in attempts) / len(attempts)
        summary.append({
            "staff_name": name,
            "attempts": len(attempts),
            "avg_score": round(avg, 1),
            "best_score": max(a["score"] for a in attempts),
            "last_attempt": max(a["created_at"] for a in attempts),
        })
    summary.sort(key=lambda x: x["avg_score"], reverse=True)
    overall_avg = sum(r["score"] for r in rows) / len(rows) if rows else 0
    return {
        "by_staff": summary,
        "overall": {
            "total_attempts": len(rows),
            "avg_score": round(overall_avg, 1),
            "period_days": days,
        },
    }


# ═══════════════════════════════════════════════════════
# M3 — 벤치마크 지역·규모 매칭
# ═══════════════════════════════════════════════════════


@router.get("/benchmark/revenue-per-day-matched")
async def benchmark_matched(
    store_id: str = Header(..., alias="X-Store-Id"),
    period: str = "30d",
    match_region: bool = True,
    match_size: bool = True,
):
    """
    매장 위치(region) + 규모(매장면적/직원수) 가까운 매장만 비교.
    프라이버시는 동일 — 분위수만, k-anonymity ≥ 10.
    """
    sb = _get_supabase()
    if sb is None:
        raise HTTPException(503, "Supabase 미설정")

    # 본인 매장 정보
    store_res = await asyncio.to_thread(
        lambda: sb.table("stores").select("region, employee_count").eq("id", store_id).single().execute()
    )
    me = store_res.data or {}
    days = int(period.rstrip("d")) if period.endswith("d") else 30
    cutoff = (datetime.now(timezone.utc) - timedelta(days=days)).date().isoformat()

    # 본인 일평균
    my_res = await asyncio.to_thread(
        lambda: sb.table("sales_records")
        .select("revenue")
        .eq("store_id", store_id)
        .gte("sale_date", cutoff)
        .execute()
    )
    my_total = sum(int(r.get("revenue") or 0) for r in (my_res.data or []))
    my_avg = my_total / max(1, days)

    # RPC가 region·size 매칭 지원 (없으면 전체 fallback)
    try:
        rpc_res = await asyncio.to_thread(
            lambda: sb.rpc("revenue_per_day_quartiles_matched", {
                "p_days": days,
                "p_region": me.get("region") if match_region else None,
                "p_employee_count": me.get("employee_count") if match_size else None,
            }).execute()
        )
        d = (rpc_res.data or [{}])[0]
        p25, p50, p75, sample = float(d.get("p25", 0)), float(d.get("p50", 0)), float(d.get("p75", 0)), int(d.get("sample_size", 0))
    except Exception:
        # RPC 미설치 — 일반 분위수 호출
        rpc_res = await asyncio.to_thread(
            lambda: sb.rpc("revenue_per_day_quartiles", {"p_days": days}).execute()
        )
        d = (rpc_res.data or [{}])[0] if rpc_res.data else {}
        p25, p50, p75, sample = float(d.get("p25", 0)), float(d.get("p50", 0)), float(d.get("p75", 0)), int(d.get("sample_size", 0))

    if sample < 10:
        return {
            "my_value": my_avg,
            "p25": 0, "p50": 0, "p75": 0,
            "sample_size": sample,
            "match_filters": {"region": me.get("region") if match_region else None, "employee_count": me.get("employee_count") if match_size else None},
            "note": f"매칭된 표본 {sample}개 — 10개 이상 필요",
        }

    return {
        "my_value": my_avg,
        "p25": p25, "p50": p50, "p75": p75,
        "sample_size": sample,
        "match_filters": {
            "region": me.get("region") if match_region else None,
            "employee_count": me.get("employee_count") if match_size else None,
        },
        "note": "비슷한 지역·규모 매장만 포함된 분위수입니다",
    }


@router.post("/roadmap/vote")
async def roadmap_vote(req: RoadmapVoteRequest):
    sb = _get_supabase()
    if sb is None:
        return {"voted": False, "note": "Supabase 미설정"}
    try:
        # 매장당 1표 (UNIQUE feature_id+store_id)
        await asyncio.to_thread(
            lambda: sb.table("roadmap_votes").upsert({
                "feature_id": req.feature_id,
                "store_id": req.store_id,
                "voted_at": datetime.now(timezone.utc).isoformat(),
            }, on_conflict="feature_id,store_id").execute()
        )
        return {"voted": True}
    except Exception as e:
        return {"voted": False, "error": str(e)[:100]}
