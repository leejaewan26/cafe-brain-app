// 사용자 앱 설정 스토어 (Zustand + localStorage 영속화)
// - Issue #16 다크모드 테마
// - Issue #17 리뷰 답글 기본 어조
// - AI 워터마크 표시 여부 등 UX 설정
import { create } from 'zustand'
import { persist } from 'zustand/middleware'

// ─── 테마 옵션 ───
export type ThemeMode = 'light' | 'dark' | 'system'

// ─── 리뷰 답글 어조 옵션 (Issue #17) ───
export type ReplyTone = 'polite' | 'friendly' | 'humor'

export const TONE_META: Record<ReplyTone, { label: string; desc: string; emoji: string }> = {
  polite:   { label: '정중한 존댓말', desc: '격식 있고 정중하게 고객을 응대',        emoji: '🙇' },
  friendly: { label: '친근한 반말',    desc: '사장님이 직접 쓰는 듯한 편안한 어투',  emoji: '😊' },
  humor:    { label: '유머·위트',      desc: '재치 있는 표현으로 인상 깊게',         emoji: '😄' },
}

interface SettingsState {
  // 화면 설정
  theme: ThemeMode
  // AI 설정
  defaultTone: ReplyTone
  showAiWatermark: boolean
  // 액션
  setTheme: (t: ThemeMode) => void
  setDefaultTone: (t: ReplyTone) => void
  setShowAiWatermark: (v: boolean) => void
  reset: () => void
}

const DEFAULT_STATE = {
  theme: 'system' as ThemeMode,
  // S8 적용: 한국 카페 업계 정서상 정중한 존댓말이 90%의 표준 기본값
  defaultTone: 'polite' as ReplyTone,
  showAiWatermark: true,
}

export const useSettingsStore = create<SettingsState>()(
  persist(
    (set) => ({
      ...DEFAULT_STATE,
      setTheme: (theme) => set({ theme }),
      setDefaultTone: (defaultTone) => set({ defaultTone }),
      setShowAiWatermark: (showAiWatermark) => set({ showAiWatermark }),
      reset: () => set(DEFAULT_STATE),
    }),
    {
      name: 'cafe-brain-settings',
    }
  )
)
