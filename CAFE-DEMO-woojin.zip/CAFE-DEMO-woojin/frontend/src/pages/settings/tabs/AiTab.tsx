// 설정 > AI 설정 탭 (Issue #17 어조 커스터마이징)
import { Sparkles, Info, Quote } from 'lucide-react'
import { useSettingsStore, TONE_META, type ReplyTone } from '@/store/settingsStore'

// 어조별 샘플 답글 미리보기 (S5)
const TONE_SAMPLES: Record<ReplyTone, string> = {
  polite: '민수님, 소중한 리뷰 남겨주셔서 진심으로 감사드립니다. 아메리카노를 만족스럽게 드셨다니 저희도 기쁩니다. 다음 방문 시에는 신메뉴 크로플도 꼭 드셔보세요.',
  friendly: '민수님~ 우리 카페 찾아주셔서 너무 고마워요! 아메리카노 맛있게 드셨다니 기분 좋네요 ☕ 다음엔 따끈한 크로플도 한번 드셔보세요!',
  humor: '민수님, "진하고 쓴맛이 좋아요"라고 해주셨네요 — 저희도 삶이 그렇답니다 😅 다음엔 인생의 달콤함을 크로플에 담아 준비해둘게요!',
}

export default function AiTab() {
  const { defaultTone, setDefaultTone, showAiWatermark, setShowAiWatermark } =
    useSettingsStore()

  return (
    <div className="space-y-6">
      {/* 리뷰 답글 기본 어조 (Issue #17) */}
      <section className="bg-white rounded-2xl p-5 border border-gray-100 shadow-sm">
        <h3 className="font-bold text-[#2C1810] mb-1 flex items-center gap-2">
          <Sparkles size={16} className="text-[#D4A574]" />
          리뷰 답글 기본 어조
        </h3>
        <p className="text-xs text-gray-400 mb-4">
          AI가 리뷰 답글을 생성할 때 기본으로 사용할 어조입니다. 답글 작성 화면에서 개별 변경도 가능합니다.
        </p>

        <div
          className="grid grid-cols-1 md:grid-cols-3 gap-2"
          role="radiogroup"
          aria-label="리뷰 답글 어조"
        >
          {(Object.keys(TONE_META) as ReplyTone[]).map((tone) => {
            const meta = TONE_META[tone]
            const active = defaultTone === tone
            return (
              <button
                key={tone}
                onClick={() => setDefaultTone(tone)}
                role="radio"
                aria-checked={active}
                aria-label={`${meta.label} — ${meta.desc}${active ? ' (선택됨)' : ''}`}
                className={`text-left p-4 rounded-xl border-2 transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-[#D4A574] ${
                  active
                    ? 'border-[#D4A574] bg-[#D4A574]/5 shadow-sm'
                    : 'border-gray-100 hover:border-gray-200'
                }`}
              >
                <div className="flex items-center gap-2 mb-1">
                  <span className="text-lg" aria-hidden="true">{meta.emoji}</span>
                  <span className={`font-semibold text-sm ${active ? 'text-[#2C1810]' : 'text-gray-700'}`}>
                    {meta.label}
                    {active && <span className="ml-1 text-[#D4A574]" aria-hidden="true">✓</span>}
                  </span>
                </div>
                <p className="text-xs text-gray-500 leading-relaxed">{meta.desc}</p>
              </button>
            )
          })}
        </div>

        {/* 어조 샘플 미리보기 (S5) */}
        <div className="mt-4 p-4 bg-[#FAFAF8] rounded-xl border border-gray-100">
          <div className="flex items-start gap-2 mb-2">
            <Quote size={14} className="text-[#D4A574] mt-0.5 shrink-0" />
            <p className="text-xs font-semibold text-[#2C1810]">
              샘플 리뷰에 대한 답글 미리보기
            </p>
          </div>
          <p className="text-xs text-gray-500 mb-2 italic">
            "아메리카노 진하고 쓴맛이 좋아요. 다음에도 올게요" — 민수 · ⭐⭐⭐⭐
          </p>
          <p className="text-sm text-gray-700 leading-relaxed whitespace-pre-line">
            {TONE_SAMPLES[defaultTone]}
          </p>
        </div>
      </section>

      {/* AI 워터마크 — 리뷰 답글 한정 */}
      <section className="bg-white rounded-2xl p-5 border border-gray-100 shadow-sm">
        <div className="flex items-center justify-between gap-4">
          <div className="min-w-0 flex-1">
            <h3 className="font-bold text-[#2C1810] text-sm">리뷰 답글 AI 표시</h3>
            <p className="text-xs text-gray-400 mt-0.5 leading-relaxed">
              리뷰 답글 하단의 "ⓘ AI가 생성한 답글입니다" 문구 표시.
              끄면 사장님이 직접 쓴 것처럼 보이지만, <strong>AI 기본법상 고객에게 AI 사용 사실을 알릴 의무</strong>가 있을 수 있어요.
            </p>
            <p className="text-[10px] text-gray-400 mt-1">
              ※ 매출 분석·마케팅 등 다른 AI 콘텐츠의 워터마크는 항상 유지됩니다
            </p>
          </div>
          <label className="relative inline-flex items-center cursor-pointer shrink-0">
            <input
              type="checkbox"
              role="switch"
              aria-checked={showAiWatermark}
              aria-label={`리뷰 답글 AI 표시 ${showAiWatermark ? '켜짐' : '꺼짐'}`}
              checked={showAiWatermark}
              onChange={(e) => setShowAiWatermark(e.target.checked)}
              className="sr-only peer"
            />
            <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-2 peer-focus:ring-[#D4A574]/30 rounded-full peer peer-checked:after:translate-x-5 after:content-[''] after:absolute after:top-0.5 after:left-0.5 after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-[#2C1810] flex items-center justify-between px-1.5">
              <span className={`text-[9px] font-bold text-white transition-opacity ${showAiWatermark ? 'opacity-100' : 'opacity-0'}`}>ON</span>
              <span className={`text-[9px] font-bold text-gray-500 transition-opacity ${showAiWatermark ? 'opacity-0' : 'opacity-100'}`}>OFF</span>
            </div>
          </label>
        </div>
      </section>

      {/* 안내 */}
      <div className="flex items-start gap-2 p-3 bg-blue-50/50 border border-blue-100 rounded-xl">
        <Info size={14} className="text-blue-500 mt-0.5 shrink-0" />
        <div className="text-xs text-blue-700 leading-relaxed">
          <p className="font-semibold mb-1">AI 호출 제한</p>
          <p>분당 10회 제한이 적용됩니다. 24시간 캐싱으로 동일 요청은 빠르게 응답됩니다 (API 비용 절감).</p>
        </div>
      </div>
    </div>
  )
}
