// F2 + F3 + F4 + F5 — 백엔드만 있던 4개 기능을 한 화면에 노출
//   /plan      Multi-step 전략 분해
//   /compare   A/B 옵션 비교
//   /memory/semantic   의미적 메모리 검색
//   /audit     감사 로그 전체 (페이지네이션·CSV)
import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import {
  ChevronLeft, Sparkles, Loader2, Trophy,
  Search, Brain, ShieldCheck, Download, AlertCircle,
} from 'lucide-react'
import { useAuthStore } from '@/store/authStore'
import { useStoreContext } from '@/hooks/useStoreContext'
import { cn } from '@/lib/utils'
import toast from 'react-hot-toast'

type Tab = 'plan' | 'compare' | 'memory' | 'audit'

export default function AgentToolsPage() {
  const [tab, setTab] = useState<Tab>('plan')
  return (
    <div className="min-h-screen bg-[#FAFAF8]">
      <header className="sticky top-0 z-10 bg-white border-b border-gray-100">
        <div className="max-w-4xl mx-auto px-4 py-3 flex items-center gap-3">
          <Link to="/dashboard" className="text-gray-400 hover:text-[#2C1810]">
            <ChevronLeft size={18} />
          </Link>
          <h1 className="text-base font-bold text-[#2C1810]">에이전트 도구</h1>
        </div>
        <nav className="max-w-4xl mx-auto px-4 flex gap-1 border-b border-gray-100">
          {[
            { id: 'plan' as const, label: '전략 분해', icon: Sparkles },
            { id: 'compare' as const, label: 'A/B 비교', icon: Trophy },
            { id: 'memory' as const, label: '메모리 검색', icon: Brain },
            { id: 'audit' as const, label: '감사 로그', icon: ShieldCheck },
          ].map((t) => {
            const Icon = t.icon
            return (
              <button
                key={t.id}
                onClick={() => setTab(t.id)}
                className={cn(
                  'flex items-center gap-1.5 px-3 py-2.5 text-xs font-semibold transition-colors border-b-2',
                  tab === t.id
                    ? 'border-[#2C1810] text-[#2C1810]'
                    : 'border-transparent text-gray-400 hover:text-[#2C1810]'
                )}
              >
                <Icon size={13} /> {t.label}
              </button>
            )
          })}
        </nav>
      </header>

      <main className="max-w-4xl mx-auto px-4 py-5">
        {tab === 'plan' && <PlanTab />}
        {tab === 'compare' && <CompareTab />}
        {tab === 'memory' && <MemorySearchTab />}
        {tab === 'audit' && <AuditTab />}
      </main>
    </div>
  )
}

// ═══════════════════════════════════════════════════════
// F2 — Multi-step Plan
// ═══════════════════════════════════════════════════════

interface PlanStep { step: number; title: string; analysis: string }
interface PlanResponse { plan: PlanStep[]; final_recommendation: string; sources: string[] }

function PlanTab() {
  const user = useAuthStore((s) => s.user)
  const { buildPromptContext } = useStoreContext()
  const [goal, setGoal] = useState('')
  const [loading, setLoading] = useState(false)
  const [result, setResult] = useState<PlanResponse | null>(null)

  const submit = async () => {
    if (!user || goal.trim().length < 5) {
      toast.error('5자 이상 입력해주세요')
      return
    }
    setLoading(true)
    setResult(null)
    try {
      const r = await fetch('/api/v1/agent/plan', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          store_id: user.id,
          goal: goal.trim(),
          store_context: buildPromptContext(),
        }),
      })
      if (!r.ok) {
        toast.error('분석 실패 — 다시 시도해주세요')
        return
      }
      const data: PlanResponse = await r.json()
      setResult(data)
    } catch {
      toast.error('네트워크 오류')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="space-y-4">
      <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-5">
        <h2 className="text-sm font-bold text-[#2C1810] mb-2">복잡한 전략을 4~5 단계로 분해</h2>
        <p className="text-xs text-gray-500 mb-3 leading-relaxed">
          예: <em>"다음 분기 매출 10% 끌어올릴 전략"</em>, <em>"여름 시그니처 메뉴 라인업"</em>, <em>"인건비 -20% 방안"</em>
        </p>
        <textarea
          value={goal}
          onChange={(e) => setGoal(e.target.value)}
          placeholder="목표를 자세히 설명해주세요"
          className="w-full px-3 py-2 border border-gray-200 rounded-lg text-sm focus:outline-none focus:border-[#2C1810] min-h-[80px]"
          maxLength={500}
        />
        <div className="flex items-center justify-between mt-2">
          <span className="text-[10px] text-gray-400">{goal.length}/500</span>
          <button
            onClick={submit}
            disabled={loading || goal.trim().length < 5}
            className="px-4 py-2 bg-[#2C1810] text-white text-sm font-semibold rounded-lg disabled:opacity-50 hover:bg-[#3A2519] flex items-center gap-1.5"
          >
            {loading ? <><Loader2 size={14} className="animate-spin" /> 분석 중…</> : <><Sparkles size={14} /> 분해 시작</>}
          </button>
        </div>
      </div>

      {result && (
        <div className="space-y-3">
          {result.plan.map((s) => (
            <div key={s.step} className="bg-white rounded-2xl border border-gray-100 shadow-sm p-4">
              <div className="flex items-center gap-2 mb-2">
                <span className="w-7 h-7 rounded-full bg-[#D4A574] text-[#2C1810] flex items-center justify-center text-xs font-bold">
                  {s.step}
                </span>
                <h3 className="font-bold text-sm text-[#2C1810]">{s.title}</h3>
              </div>
              <p className="text-sm text-gray-700 leading-relaxed">{s.analysis}</p>
            </div>
          ))}
          <div className="bg-gradient-to-br from-[#2C1810] to-[#3A2519] rounded-2xl p-5 text-white">
            <h3 className="font-bold flex items-center gap-2 mb-2">
              <Trophy size={15} className="text-[#D4A574]" /> 통합 권고안
            </h3>
            <p className="text-sm leading-relaxed text-white/90">{result.final_recommendation}</p>
            {result.sources.length > 0 && (
              <p className="text-[10px] text-[#D4A574] mt-3">
                📎 활용 데이터: {result.sources.join(' · ')}
              </p>
            )}
          </div>
        </div>
      )}
    </div>
  )
}

// ═══════════════════════════════════════════════════════
// F3 — A/B Compare
// ═══════════════════════════════════════════════════════

interface CompareScore { option: string; score: number; pros: string[]; cons: string[] }
interface CompareResponse { scores: CompareScore[]; winner: string; reasoning: string }

function CompareTab() {
  const user = useAuthStore((s) => s.user)
  const { buildPromptContext } = useStoreContext()
  const [question, setQuestion] = useState('')
  const [optA, setOptA] = useState('')
  const [optB, setOptB] = useState('')
  const [loading, setLoading] = useState(false)
  const [result, setResult] = useState<CompareResponse | null>(null)

  const submit = async () => {
    if (!user || !question.trim() || !optA.trim() || !optB.trim()) {
      toast.error('질문 + 두 옵션 모두 입력해주세요')
      return
    }
    setLoading(true)
    setResult(null)
    try {
      const r = await fetch('/api/v1/agent/compare', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          store_id: user.id,
          question: question.trim(),
          option_a: optA.trim(),
          option_b: optB.trim(),
          store_context: buildPromptContext(),
        }),
      })
      if (!r.ok) {
        toast.error('분석 실패')
        return
      }
      const data: CompareResponse = await r.json()
      setResult(data)
    } catch {
      toast.error('네트워크 오류')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="space-y-4">
      <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-5">
        <h2 className="text-sm font-bold text-[#2C1810] mb-2">두 옵션 비교</h2>
        <p className="text-xs text-gray-500 mb-3">예: "할인 50% vs 1+1, 어느 게 더 효과적일까?"</p>
        <input
          type="text"
          value={question}
          onChange={(e) => setQuestion(e.target.value)}
          placeholder="비교 질문"
          className="w-full px-3 py-2 border border-gray-200 rounded-lg text-sm mb-2 focus:outline-none focus:border-[#2C1810]"
        />
        <div className="grid grid-cols-2 gap-2">
          <textarea
            value={optA}
            onChange={(e) => setOptA(e.target.value)}
            placeholder="옵션 A 설명"
            className="px-3 py-2 border-2 border-blue-200 bg-blue-50/50 rounded-lg text-sm focus:outline-none focus:border-blue-400 min-h-[80px]"
          />
          <textarea
            value={optB}
            onChange={(e) => setOptB(e.target.value)}
            placeholder="옵션 B 설명"
            className="px-3 py-2 border-2 border-amber-200 bg-amber-50/50 rounded-lg text-sm focus:outline-none focus:border-amber-400 min-h-[80px]"
          />
        </div>
        <button
          onClick={submit}
          disabled={loading}
          className="w-full mt-3 px-4 py-2.5 bg-[#2C1810] text-white text-sm font-semibold rounded-lg disabled:opacity-50 hover:bg-[#3A2519] flex items-center justify-center gap-1.5"
        >
          {loading ? <><Loader2 size={14} className="animate-spin" /> 채점 중…</> : <><Trophy size={14} /> 분석 시작</>}
        </button>
      </div>

      {result && (
        <>
          <div className="grid grid-cols-2 gap-3">
            {result.scores.map((s) => {
              const isWinner = result.winner === s.option
              const accent = s.option === 'A' ? 'blue' : 'amber'
              return (
                <div
                  key={s.option}
                  className={cn(
                    'bg-white rounded-2xl border-2 shadow-sm p-4 relative',
                    isWinner ? `border-${accent}-400` : 'border-gray-100'
                  )}
                >
                  {isWinner && (
                    <div className="absolute -top-2 -right-2 bg-[#D4A574] text-[#2C1810] text-[10px] font-bold px-2 py-0.5 rounded-full shadow">
                      ⭐ 추천
                    </div>
                  )}
                  <div className="flex items-baseline gap-2 mb-3">
                    <h3 className="text-2xl font-bold text-[#2C1810]">옵션 {s.option}</h3>
                    <span className="text-3xl font-bold tabular-nums" style={{ color: isWinner ? '#D4A574' : '#999' }}>
                      {s.score}
                    </span>
                    <span className="text-xs text-gray-400">/100</span>
                  </div>
                  <div className="space-y-2">
                    <div>
                      <p className="text-[10px] font-bold text-green-600 mb-1">👍 장점</p>
                      <ul className="text-xs text-gray-700 space-y-0.5 pl-3 list-disc">
                        {s.pros.map((p, i) => <li key={i}>{p}</li>)}
                      </ul>
                    </div>
                    <div>
                      <p className="text-[10px] font-bold text-red-600 mb-1">👎 단점</p>
                      <ul className="text-xs text-gray-700 space-y-0.5 pl-3 list-disc">
                        {s.cons.map((c, i) => <li key={i}>{c}</li>)}
                      </ul>
                    </div>
                  </div>
                </div>
              )
            })}
          </div>
          <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-4">
            <h3 className="text-sm font-bold text-[#2C1810] mb-1">왜 이 결정인가요?</h3>
            <p className="text-sm text-gray-700 leading-relaxed">{result.reasoning}</p>
          </div>
        </>
      )}
    </div>
  )
}

// ═══════════════════════════════════════════════════════
// F4 — Semantic Memory Search
// ═══════════════════════════════════════════════════════

interface MemoryResult {
  id: string
  category: string
  content: string
  importance: number
  confidence: number
  similarity?: number
  created_at: string
}

function MemorySearchTab() {
  const user = useAuthStore((s) => s.user)
  const [query, setQuery] = useState('')
  const [loading, setLoading] = useState(false)
  const [results, setResults] = useState<MemoryResult[]>([])
  const [searched, setSearched] = useState(false)

  const submit = async () => {
    if (!user || !query.trim()) return
    setLoading(true)
    try {
      // 의미 검색 endpoint — 백엔드에 라우터 추가 필요 (없으면 키워드 fallback)
      const r = await fetch('/api/v1/agent/memory/search', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'X-Store-Id': user.id },
        body: JSON.stringify({ query: query.trim(), limit: 12 }),
      })
      if (!r.ok) {
        // fallback: 일반 메모리 조회
        const fallback = await fetch(`/api/v1/agent/memory?store_id=${user.id}&limit=20`)
        const data = await fallback.json()
        setResults((data.memories ?? []).filter((m: MemoryResult) =>
          m.content.toLowerCase().includes(query.toLowerCase())
        ))
      } else {
        const data = await r.json()
        setResults(data.memories ?? [])
      }
      setSearched(true)
    } catch {
      toast.error('검색 실패')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="space-y-4">
      <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-5">
        <h2 className="text-sm font-bold text-[#2C1810] mb-2">의미적 메모리 검색</h2>
        <p className="text-xs text-gray-500 mb-3">
          "고객 불만"으로 검색하면 "민원" "컴플레인" "악평" 등 비슷한 의미 메모리도 찾아냅니다
        </p>
        <div className="flex gap-2">
          <input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && submit()}
            placeholder="자연어로 검색"
            className="flex-1 px-3 py-2 border border-gray-200 rounded-lg text-sm focus:outline-none focus:border-[#2C1810]"
          />
          <button
            onClick={submit}
            disabled={loading || !query.trim()}
            className="px-4 py-2 bg-[#2C1810] text-white text-sm font-semibold rounded-lg disabled:opacity-50 hover:bg-[#3A2519] flex items-center gap-1"
          >
            {loading ? <Loader2 size={14} className="animate-spin" /> : <Search size={14} />}
            검색
          </button>
        </div>
      </div>

      {searched && results.length === 0 && (
        <div className="bg-white rounded-2xl border border-gray-100 p-8 text-center">
          <Brain size={28} className="text-gray-300 mx-auto mb-2" />
          <p className="text-sm text-gray-500">매칭되는 메모리가 없어요</p>
        </div>
      )}

      {results.map((m) => (
        <div key={m.id} className="bg-white rounded-2xl border border-gray-100 shadow-sm p-4">
          <div className="flex items-center gap-2 mb-1.5">
            <span className="text-[10px] px-1.5 py-0.5 bg-gray-100 text-gray-600 rounded font-medium">
              {m.category}
            </span>
            <span className="text-[10px] text-gray-400">중요도 {m.importance}/10</span>
            {typeof m.similarity === 'number' && (
              <span className="text-[10px] text-[#22C55E] ml-auto">
                유사도 {(m.similarity * 100).toFixed(0)}%
              </span>
            )}
          </div>
          <p className="text-sm text-[#2C1810] leading-relaxed">{m.content}</p>
        </div>
      ))}
    </div>
  )
}

// ═══════════════════════════════════════════════════════
// F5 — Audit Log full page (paginate + filter + CSV)
// ═══════════════════════════════════════════════════════

interface AuditItem {
  id: string
  action: string
  actor_role: string | null
  target_type: string | null
  target_id: string | null
  created_at: string
}

const ACTION_FILTERS = [
  { id: '', label: '전체' },
  { id: 'memory_delete', label: '메모리 삭제' },
  { id: 'memory_create', label: '메모리 추가' },
  { id: 'anomaly_rule_create', label: '룰 추가' },
  { id: 'anomaly_rule_update', label: '룰 수정' },
  { id: 'anomaly_rule_delete', label: '룰 삭제' },
]

function AuditTab() {
  const user = useAuthStore((s) => s.user)
  const [items, setItems] = useState<AuditItem[]>([])
  const [filter, setFilter] = useState('')
  const [loading, setLoading] = useState(false)

  const fetchItems = async () => {
    if (!user) return
    setLoading(true)
    try {
      const params = new URLSearchParams({ store_id: user.id, limit: '200' })
      if (filter) params.set('action', filter)
      const r = await fetch(`/api/v1/agent/audit?${params}`)
      if (r.ok) setItems(await r.json())
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => { void fetchItems() }, [user, filter])  // eslint-disable-line

  const exportCsv = () => {
    if (items.length === 0) return
    const header = ['timestamp', 'action', 'actor_role', 'target_type', 'target_id'].join(',')
    const rows = items.map((it) => [
      it.created_at,
      it.action,
      it.actor_role ?? '',
      it.target_type ?? '',
      it.target_id ?? '',
    ].map((v) => `"${String(v).replace(/"/g, '""')}"`).join(','))
    const csv = [header, ...rows].join('\n')
    const blob = new Blob(['﻿' + csv], { type: 'text/csv;charset=utf-8' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `audit-log-${new Date().toISOString().slice(0, 10)}.csv`
    a.click()
    URL.revokeObjectURL(url)
    toast.success('감사 로그 CSV 저장됨')
  }

  return (
    <div className="space-y-4">
      <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-4">
        <div className="flex flex-wrap items-center gap-2">
          {ACTION_FILTERS.map((f) => (
            <button
              key={f.id}
              onClick={() => setFilter(f.id)}
              className={cn(
                'px-2.5 py-1 rounded-full text-xs font-medium transition-colors',
                filter === f.id
                  ? 'bg-[#2C1810] text-white'
                  : 'bg-gray-50 text-gray-500 hover:bg-gray-100'
              )}
            >
              {f.label}
            </button>
          ))}
          <button
            onClick={exportCsv}
            disabled={items.length === 0}
            className="ml-auto flex items-center gap-1 px-3 py-1.5 border border-gray-200 text-xs font-semibold text-gray-600 rounded-lg hover:bg-gray-50 disabled:opacity-50"
          >
            <Download size={11} /> CSV
          </button>
        </div>
      </div>

      <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
        {loading && (
          <div className="p-8 flex items-center justify-center text-gray-400 text-sm">
            <Loader2 size={14} className="animate-spin mr-2" /> 불러오는 중…
          </div>
        )}
        {!loading && items.length === 0 && (
          <div className="p-8 text-center">
            <AlertCircle size={24} className="text-gray-300 mx-auto mb-2" />
            <p className="text-sm text-gray-500">기록된 행위가 없어요</p>
          </div>
        )}
        {items.length > 0 && (
          <table className="w-full text-xs">
            <thead className="bg-[#FAFAF8] text-gray-500 sticky top-0">
              <tr>
                <th className="text-left px-3 py-2 font-semibold w-32">시각</th>
                <th className="text-left px-3 py-2 font-semibold w-28">동작</th>
                <th className="text-left px-3 py-2 font-semibold w-20">권한</th>
                <th className="text-left px-3 py-2 font-semibold">대상</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {items.map((it) => (
                <tr key={it.id} className="hover:bg-[#FAFAF8]">
                  <td className="px-3 py-2 text-gray-500 font-mono">
                    {new Date(it.created_at).toLocaleString('ko-KR', {
                      month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit',
                    })}
                  </td>
                  <td className="px-3 py-2 font-semibold text-[#2C1810]">{it.action}</td>
                  <td className="px-3 py-2">
                    {it.actor_role && (
                      <span className="text-[10px] px-1.5 py-0.5 bg-gray-100 text-gray-600 rounded">
                        {it.actor_role}
                      </span>
                    )}
                  </td>
                  <td className="px-3 py-2 text-gray-500 truncate">
                    {it.target_type && <span className="font-mono">{it.target_type}</span>}
                    {it.target_id && <span className="text-gray-300 ml-1">{it.target_id.slice(0, 8)}</span>}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  )
}
