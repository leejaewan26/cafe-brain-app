#!/usr/bin/env node
// N1 — i18n 누락 키 검사
// 사용된 t('key') 호출과 ko/en JSON 키를 비교 → 누락·미사용 보고
import { readdir, readFile } from 'node:fs/promises'
import path from 'node:path'

const SRC = path.resolve(process.cwd(), 'src')
const KO = path.resolve(SRC, 'lib/locales/ko.json')
const EN = path.resolve(SRC, 'lib/locales/en.json')

async function* walk(dir) {
  for (const e of await readdir(dir, { withFileTypes: true })) {
    const full = path.join(dir, e.name)
    if (e.isDirectory()) yield* walk(full)
    else if (e.isFile() && (full.endsWith('.tsx') || full.endsWith('.ts'))) yield full
  }
}

function flatten(obj, prefix = '') {
  const out = new Set()
  for (const [k, v] of Object.entries(obj)) {
    const key = prefix ? `${prefix}.${k}` : k
    if (typeof v === 'object' && v !== null) {
      for (const sub of flatten(v, key)) out.add(sub)
    } else {
      out.add(key)
    }
  }
  return out
}

const usedKeys = new Set()
const KEY_PATTERN = /\bt\(\s*['"`]([a-z0-9_.]+)['"`]/gi

for await (const fp of walk(SRC)) {
  const content = await readFile(fp, 'utf8')
  let m
  while ((m = KEY_PATTERN.exec(content))) {
    usedKeys.add(m[1])
  }
}

const ko = JSON.parse(await readFile(KO, 'utf8'))
const en = JSON.parse(await readFile(EN, 'utf8'))
const koKeys = flatten(ko)
const enKeys = flatten(en)

const missingInKo = [...usedKeys].filter((k) => !koKeys.has(k))
const missingInEn = [...usedKeys].filter((k) => !enKeys.has(k))
const unusedInKo = [...koKeys].filter((k) => !usedKeys.has(k))
const koVsEn = [...koKeys].filter((k) => !enKeys.has(k))
const enVsKo = [...enKeys].filter((k) => !koKeys.has(k))

let problems = 0

if (missingInKo.length) {
  console.log(`❌ ko.json 에 누락된 키 (${missingInKo.length}):`)
  missingInKo.slice(0, 20).forEach((k) => console.log(`   - ${k}`))
  problems += missingInKo.length
}
if (missingInEn.length) {
  console.log(`❌ en.json 에 누락된 키 (${missingInEn.length}):`)
  missingInEn.slice(0, 20).forEach((k) => console.log(`   - ${k}`))
  problems += missingInEn.length
}
if (koVsEn.length) {
  console.log(`⚠️ ko.json 에는 있는데 en.json 에 없는 키 (${koVsEn.length}):`)
  koVsEn.slice(0, 10).forEach((k) => console.log(`   - ${k}`))
}
if (enVsKo.length) {
  console.log(`⚠️ en.json 에는 있는데 ko.json 에 없는 키 (${enVsKo.length}):`)
  enVsKo.slice(0, 10).forEach((k) => console.log(`   - ${k}`))
}

console.log(`\n사용된 키: ${usedKeys.size}, ko 키: ${koKeys.size}, en 키: ${enKeys.size}`)
console.log(`사용 안 되는 ko 키: ${unusedInKo.length}`)

if (problems > 0 && process.env.CI) {
  process.exit(1)
}
