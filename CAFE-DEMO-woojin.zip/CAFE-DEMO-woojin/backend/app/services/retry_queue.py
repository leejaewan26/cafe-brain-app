"""
L7 — 외부 API 호출 재시도 큐

failed → pending → processing → done/dead
exponential backoff: 1m, 5m, 15m, 1h, 6h (최대 5회)

사용:
    from app.services.retry_queue import enqueue
    await enqueue(
        kind="resend_email",
        payload={"to": "...", "subject": "..."},
        store_id="...",
    )

Cron이 매 분 호출:
    POST /api/v1/retry-queue/process
"""
import asyncio
import logging
import uuid
from datetime import datetime, timedelta, timezone
from typing import Any

from app.services.gemini_service import _get_supabase

logger = logging.getLogger("retry_queue")

# kind별 핸들러 매핑 — 외부 호출 함수 등록
_HANDLERS: dict[str, Any] = {}

# 백오프 (분)
BACKOFF_MINUTES = [1, 5, 15, 60, 360]


def register_handler(kind: str):
    """데코레이터 — 핸들러 등록."""
    def deco(fn):
        _HANDLERS[kind] = fn
        return fn
    return deco


async def enqueue(kind: str, payload: dict, store_id: str | None = None) -> str:
    """큐에 job 추가."""
    sb = _get_supabase()
    if sb is None:
        # 즉시 시도
        handler = _HANDLERS.get(kind)
        if handler:
            try:
                await handler(payload)
            except Exception:
                pass
        return ""

    job_id = str(uuid.uuid4())
    await asyncio.to_thread(
        lambda: sb.table("retry_queue").insert({
            "id": job_id,
            "kind": kind,
            "payload": payload,
            "store_id": store_id,
            "status": "pending",
            "attempts": 0,
            "next_attempt_at": datetime.now(timezone.utc).isoformat(),
            "created_at": datetime.now(timezone.utc).isoformat(),
        }).execute()
    )
    return job_id


async def process_queue(limit: int = 50) -> dict:
    """대기 중 job 처리. cron에서 호출."""
    sb = _get_supabase()
    if sb is None:
        return {"processed": 0, "note": "Supabase 미설정"}

    now = datetime.now(timezone.utc)
    res = await asyncio.to_thread(
        lambda: sb.table("retry_queue")
        .select("*")
        .eq("status", "pending")
        .lte("next_attempt_at", now.isoformat())
        .order("next_attempt_at")
        .limit(limit)
        .execute()
    )
    jobs = res.data or []

    succeeded = 0
    failed = 0
    dead = 0

    for job in jobs:
        # processing 락
        await asyncio.to_thread(
            lambda j=job: sb.table("retry_queue")
            .update({"status": "processing"})
            .eq("id", j["id"])
            .execute()
        )

        kind = job["kind"]
        handler = _HANDLERS.get(kind)
        if handler is None:
            await asyncio.to_thread(
                lambda j=job: sb.table("retry_queue")
                .update({"status": "dead", "last_error": "no handler"})
                .eq("id", j["id"])
                .execute()
            )
            dead += 1
            continue

        try:
            await handler(job["payload"])
            await asyncio.to_thread(
                lambda j=job: sb.table("retry_queue")
                .update({"status": "done", "completed_at": now.isoformat()})
                .eq("id", j["id"])
                .execute()
            )
            succeeded += 1
        except Exception as e:
            attempts = (job.get("attempts") or 0) + 1
            if attempts >= len(BACKOFF_MINUTES):
                # dead letter
                await asyncio.to_thread(
                    lambda j=job, err=str(e)[:300]: sb.table("retry_queue")
                    .update({
                        "status": "dead",
                        "attempts": attempts,
                        "last_error": err,
                    })
                    .eq("id", j["id"])
                    .execute()
                )
                dead += 1
            else:
                # 다음 backoff
                next_at = (now + timedelta(minutes=BACKOFF_MINUTES[attempts - 1])).isoformat()
                await asyncio.to_thread(
                    lambda j=job, na=next_at, a=attempts, err=str(e)[:300]: sb.table("retry_queue")
                    .update({
                        "status": "pending",
                        "attempts": a,
                        "next_attempt_at": na,
                        "last_error": err,
                    })
                    .eq("id", j["id"])
                    .execute()
                )
                failed += 1

    return {"processed": len(jobs), "succeeded": succeeded, "retry_later": failed, "dead": dead}


# ─── 핸들러 등록 (lazy import로 순환 방지) ──────────────


@register_handler("resend_email")
async def _h_resend(payload: dict) -> None:
    from app.services.email_service import send_email
    ok = await send_email(
        to=payload["to"],
        subject=payload["subject"],
        html=payload["html"],
        text=payload.get("text"),
    )
    if not ok:
        raise RuntimeError("이메일 발송 실패")


@register_handler("toss_charge")
async def _h_toss_charge(payload: dict) -> None:
    """결제 재시도. payload: {billing_key, customer_key, amount, order_id, order_name}"""
    import os, base64, httpx
    secret = os.getenv("TOSS_SECRET_KEY", "")
    if not secret:
        raise RuntimeError("Toss 시크릿 없음")
    auth = base64.b64encode(f"{secret}:".encode()).decode()
    async with httpx.AsyncClient(timeout=15.0) as client:
        r = await client.post(
            f"https://api.tosspayments.com/v1/billing/{payload['billing_key']}",
            headers={"Authorization": f"Basic {auth}", "Content-Type": "application/json"},
            json={
                "customerKey": payload["customer_key"],
                "amount": payload["amount"],
                "orderId": payload["order_id"],
                "orderName": payload["order_name"],
            },
        )
        if r.status_code >= 400:
            raise RuntimeError(f"Toss {r.status_code}: {r.text[:200]}")


@register_handler("instagram_publish")
async def _h_ig_publish(payload: dict) -> None:
    """payload: {ig_user_id, image_url, caption, access_token}"""
    import httpx
    async with httpx.AsyncClient(timeout=30.0) as client:
        r1 = await client.post(
            f"https://graph.facebook.com/v18.0/{payload['ig_user_id']}/media",
            data={
                "image_url": payload["image_url"],
                "caption": payload["caption"],
                "access_token": payload["access_token"],
            },
        )
        if r1.status_code != 200:
            raise RuntimeError(f"IG container {r1.status_code}")
        creation_id = r1.json()["id"]
        r2 = await client.post(
            f"https://graph.facebook.com/v18.0/{payload['ig_user_id']}/media_publish",
            data={"creation_id": creation_id, "access_token": payload["access_token"]},
        )
        if r2.status_code != 200:
            raise RuntimeError(f"IG publish {r2.status_code}")
