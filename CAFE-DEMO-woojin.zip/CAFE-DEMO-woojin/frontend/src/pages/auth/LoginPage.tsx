// 로그인 & 회원가입 페이지
import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { useAuth } from '@/hooks/useAuth'
import { Coffee, Eye, EyeOff, Loader2 } from 'lucide-react'

export default function LoginPage() {
  const navigate = useNavigate()
  const { signIn, signUp } = useAuth()

  // 탭 상태: 'login' | 'signup'
  const [tab, setTab] = useState<'login' | 'signup'>('login')
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [showPassword, setShowPassword] = useState(false)
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState('')
  const [successMsg, setSuccessMsg] = useState('')

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError('')
    setSuccessMsg('')
    setIsLoading(true)

    try {
      if (tab === 'login') {
        const { user } = await signIn(email, password)
        // DB에서 매장 정보 확인 후 라우팅 (localStorage 캐시 불신)
        if (user) {
          const { data: storeData } = await import('@/lib/supabase').then(({ supabase }) =>
            supabase.from('stores').select('id').eq('id', user.id).single()
          )
          navigate(storeData ? '/dashboard' : '/onboarding')
        }
      } else {
        await signUp(email, password)
        setSuccessMsg('가입 확인 이메일을 발송했습니다. 이메일을 확인해 주세요.')
      }
    } catch (err: unknown) {
      const message = err instanceof Error ? err.message : '오류가 발생했습니다.'
      // 에러 메시지 한국어 변환
      if (message.includes('Invalid login credentials')) {
        setError('이메일 또는 비밀번호가 올바르지 않습니다.')
      } else if (message.includes('User already registered')) {
        setError('이미 가입된 이메일입니다. 로그인을 시도해 보세요.')
      } else if (message.includes('Password should be at least')) {
        setError('비밀번호는 최소 6자 이상이어야 합니다.')
      } else {
        setError(message)
      }
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-[#FAFAF8] px-4">
      {/* 배경 장식 */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute -top-40 -right-40 w-96 h-96 rounded-full bg-[#D4A574]/10 blur-3xl" />
        <div className="absolute -bottom-40 -left-40 w-96 h-96 rounded-full bg-[#2C1810]/5 blur-3xl" />
      </div>

      <div className="relative w-full max-w-md">
        {/* 로고 헤더 */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-[#2C1810] mb-4 shadow-lg">
            <Coffee className="w-8 h-8 text-[#D4A574]" />
          </div>
          <h1 className="text-3xl font-bold text-[#2C1810]">카페 브레인</h1>
          <p className="text-gray-500 mt-1 text-sm">소형 카페를 위한 AI 경영 파트너</p>
        </div>

        {/* 카드 */}
        <div className="bg-white rounded-2xl shadow-xl p-8 border border-gray-100">
          {/* 탭 */}
          <div className="flex rounded-xl bg-gray-100 p-1 mb-6">
            <button
              onClick={() => { setTab('login'); setError(''); setSuccessMsg('') }}
              className={`flex-1 py-2 rounded-lg text-sm font-medium transition-all duration-200 ${
                tab === 'login'
                  ? 'bg-white text-[#2C1810] shadow-sm'
                  : 'text-gray-500 hover:text-gray-700'
              }`}
            >
              로그인
            </button>
            <button
              onClick={() => { setTab('signup'); setError(''); setSuccessMsg('') }}
              className={`flex-1 py-2 rounded-lg text-sm font-medium transition-all duration-200 ${
                tab === 'signup'
                  ? 'bg-white text-[#2C1810] shadow-sm'
                  : 'text-gray-500 hover:text-gray-700'
              }`}
            >
              회원가입
            </button>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            {/* 이메일 */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1.5">이메일</label>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="cafe@example.com"
                required
                className="w-full px-4 py-2.5 rounded-xl border border-gray-200 text-sm focus:outline-none focus:ring-2 focus:ring-[#D4A574] focus:border-transparent transition-all duration-200"
              />
            </div>

            {/* 비밀번호 */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1.5">비밀번호</label>
              <div className="relative">
                <input
                  type={showPassword ? 'text' : 'password'}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="6자 이상 입력"
                  required
                  minLength={6}
                  className="w-full px-4 py-2.5 rounded-xl border border-gray-200 text-sm focus:outline-none focus:ring-2 focus:ring-[#D4A574] focus:border-transparent transition-all duration-200 pr-10"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600 transition-colors duration-200"
                >
                  {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
                </button>
              </div>
            </div>

            {/* 에러 메시지 */}
            {error && (
              <div className="p-3 rounded-xl bg-red-50 border border-red-100 text-red-600 text-sm">
                {error}
              </div>
            )}

            {/* 성공 메시지 */}
            {successMsg && (
              <div className="p-3 rounded-xl bg-green-50 border border-green-100 text-green-700 text-sm">
                {successMsg}
              </div>
            )}

            {/* 제출 버튼 */}
            <button
              type="submit"
              disabled={isLoading}
              className="w-full py-3 rounded-xl bg-[#2C1810] text-white font-semibold text-sm hover:bg-[#3d2418] active:bg-[#1a0f09] transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2 mt-2"
            >
              {isLoading && <Loader2 className="w-4 h-4 animate-spin" />}
              {tab === 'login' ? '로그인' : '회원가입'}
            </button>
          </form>
        </div>

        <p className="text-center text-xs text-gray-400 mt-6">
          카페 브레인은 소형 카페 점주를 위한 AI 경영 도구입니다
        </p>
      </div>
    </div>
  )
}
