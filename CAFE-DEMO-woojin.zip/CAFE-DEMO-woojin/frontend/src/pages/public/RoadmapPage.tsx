// J2 — 공개 로드맵
// 사장님이 "다음 분기에 뭐 들어올지" 미리 보고 투표할 수 있게
import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import {
  ChevronLeft, Map, Heart, Clock, Construction, CheckCircle2,
} from 'lucide-react'
import toast from 'react-hot-toast'
import { useAuthStore } from '@/store/authStore'
import { cn } from '@/lib/utils'

type Status = 'shipped' | 'building' | 'planned' | 'considering'

interface RoadmapItem {
  id: string
  title: string
  description: string
  status: Status
  quarter: string
  votes?: number
}

const ITEMS: RoadmapItem[] = [
  // 출시 완료
  { id: 'invoice-ocr', status: 'shipped', quarter: '2026 Q2', title: '송장 OCR 자동 입력', description: '사진 한 장으로 매입 데이터 등록' },
  { id: 'multi-step-plan', status: 'shipped', quarter: '2026 Q2', title: '다단계 전략 분해', description: '복잡한 목표를 4~5 단계로 자동 분해' },
  { id: 'naver-reviews', status: 'shipped', quarter: '2026 Q2', title: '네이버 리뷰 동기화', description: '예약 API + 검색 + 수동 import 3중 fallback' },
  { id: 'instagram-publish', status: 'shipped', quarter: '2026 Q2', title: 'Instagram 자동 게시', description: 'Graph API + n8n 멀티채널' },
  { id: 'i18n-en', status: 'shipped', quarter: '2026 Q2', title: '영어 지원', description: '한국 거주 외국인 사장님' },

  // 개발 중
  { id: 'kakao-channel', status: 'building', quarter: '2026 Q3', title: '카카오 채널 메시지', description: '예약·리뷰 알림을 카카오톡으로' },
  { id: 'pos-realtime', status: 'building', quarter: '2026 Q3', title: 'POS 실시간 동기화', description: '5초 안에 새 매출이 대시보드에' },

  // 예정
  { id: 'voice-only-mode', status: 'planned', quarter: '2026 Q3', title: '음성 전용 모드', description: '운전·청소 중에도 음성으로 매장 관리' },
  { id: 'gpt-style-canvas', status: 'planned', quarter: '2026 Q3', title: 'AI Canvas (마케팅 디자인)', description: '한국어 카드뉴스·포스터 자동 생성' },
  { id: 'staff-mobile-app', status: 'planned', quarter: '2026 Q4', title: '직원 전용 모바일 앱', description: '근태 + 시급 + 메뉴 학습' },
  { id: 'multi-store', status: 'planned', quarter: '2026 Q4', title: '멀티 매장', description: '체인점·복수 사장 매장 통합' },

  // 검토 중 (사장님 투표)
  { id: 'ai-camera-customer', status: 'considering', quarter: '2027+', title: 'AI 카메라 고객 분석', description: '연령·성별 분포 (개인정보 X, 익명 통계만)' },
  { id: 'reservation-system', status: 'considering', quarter: '2027+', title: '예약 시스템 (네이버 X 자체)', description: '카페 브레인 자체 예약 페이지' },
  { id: 'recipe-cost-realtime', status: 'considering', quarter: '2027+', title: '레시피 원가 실시간', description: '재료 가격 변동 시 메뉴 마진 자동 재계산' },
  { id: 'weather-forecast', status: 'considering', quarter: '2027+', title: '날씨 기반 발주 예측', description: '내일 비 예보 → 따뜻한 음료 발주 +20%' },
]

const STATUS_META: Record<Status, { label: string; color: string; icon: React.ElementType }> = {
  shipped: { label: '출시 완료', color: '#22C55E', icon: CheckCircle2 },
  building: { label: '개발 중', color: '#D4A574', icon: Construction },
  planned: { label: '예정', color: '#4A90A4', icon: Clock },
  considering: { label: '검토 중 (투표)', color: '#7B6CB0', icon: Heart },
}

const VOTE_KEY = 'cafe-brain-roadmap-votes'

function loadVotes(): Record<string, true> {
  try {
    return JSON.parse(localStorage.getItem(VOTE_KEY) || '{}')
  } catch {
    return {}
  }
}

export default function RoadmapPage() {
  const user = useAuthStore((s) => s.user)
  const [voted, setVoted] = useState<Record<string, true>>({})

  useEffect(() => {
    setVoted(loadVotes())
  }, [])

  const groups = ITEMS.reduce<Record<Status, RoadmapItem[]>>((acc, it) => {
    if (!acc[it.status]) acc[it.status] = []
    acc[it.status].push(it)
    return acc
  }, { shipped: [], building: [], planned: [], considering: [] })

  const vote = (id: string) => {
    if (voted[id]) {
      toast('이미 투표하셨어요')
      return
    }
    if (!user) {
      toast.error('로그인이 필요해요')
      return
    }
    const next = { ...voted, [id]: true as const }
    setVoted(next)
    localStorage.setItem(VOTE_KEY, JSON.stringify(next))
    // 백엔드 트래킹 (실패해도 UI는 진행)
    fetch('/api/v1/roadmap/vote', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ feature_id: id, store_id: user.id }),
    }).catch(() => {})
    toast.success('투표 감사합니다 🙏')
  }

  return (
    <div className="min-h-screen bg-[#FAFAF8]">
      <header className="bg-white border-b border-gray-100 sticky top-0 z-10">
        <div className="max-w-3xl mx-auto px-4 py-3 flex items-center gap-3">
          <Link to="/" className="text-gray-400 hover:text-[#2C1810]">
            <ChevronLeft size={18} />
          </Link>
          <div className="flex items-center gap-2">
            <Map size={16} className="text-[#D4A574]" />
            <h1 className="text-base font-bold text-[#2C1810]">로드맵</h1>
          </div>
          <Link
            to="/changelog"
            className="ml-auto text-xs text-[#D4A574] hover:text-[#c4956a] font-semibold"
          >
            변경 이력 →
          </Link>
        </div>
      </header>

      <main className="max-w-3xl mx-auto px-4 py-6 space-y-6">
        <p className="text-sm text-gray-600 leading-relaxed">
          사장님 의견이 가장 중요합니다. <strong>검토 중</strong> 항목에 ❤️ 눌러주시면 우선순위를 올립니다.
        </p>

        {(['shipped', 'building', 'planned', 'considering'] as Status[]).map((status) => {
          const meta = STATUS_META[status]
          const Icon = meta.icon
          const items = groups[status]
          if (items.length === 0) return null
          return (
            <section key={status}>
              <div className="flex items-center gap-2 mb-3">
                <Icon size={15} style={{ color: meta.color }} />
                <h2 className="text-sm font-bold" style={{ color: meta.color }}>
                  {meta.label}
                </h2>
                <span className="text-xs text-gray-400">({items.length})</span>
              </div>
              <div className="space-y-2">
                {items.map((it) => (
                  <article
                    key={it.id}
                    className={cn(
                      'bg-white rounded-2xl border p-4 flex items-start gap-3',
                      status === 'shipped' && 'opacity-70'
                    )}
                    style={{ borderColor: meta.color + '40' }}
                  >
                    <div className="flex-1 min-w-0">
                      <h3 className="font-bold text-sm text-[#2C1810]">{it.title}</h3>
                      <p className="text-xs text-gray-500 mt-1 leading-relaxed">{it.description}</p>
                      <p className="text-[10px] text-gray-400 mt-1.5">{it.quarter}</p>
                    </div>
                    {status === 'considering' && (
                      <button
                        onClick={() => vote(it.id)}
                        className={cn(
                          'shrink-0 flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-semibold transition-all',
                          voted[it.id]
                            ? 'bg-[#7B6CB0] text-white'
                            : 'bg-[#7B6CB0]/10 text-[#7B6CB0] hover:bg-[#7B6CB0]/20'
                        )}
                      >
                        <Heart size={11} className={cn(voted[it.id] && 'fill-current')} />
                        {voted[it.id] ? '투표됨' : '투표'}
                      </button>
                    )}
                  </article>
                ))}
              </div>
            </section>
          )
        })}
      </main>

      <footer className="max-w-3xl mx-auto px-4 py-12 text-center text-xs text-gray-400">
        궁금한 점은 <a href="mailto:support@cafe-brain.app" className="text-[#D4A574] underline">support@cafe-brain.app</a> 으로 알려주세요.
      </footer>
    </div>
  )
}
