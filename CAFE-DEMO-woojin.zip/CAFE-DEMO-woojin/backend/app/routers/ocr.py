"""
영수증·POS 전표 OCR 라우터 (Wave 5G)

Gemini 1.5 Flash 비전 멀티모달로 이미지에서 매출 데이터 자동 추출.
CSV를 모르는 사장님도 사진 한 장으로 매출 입력 가능.

지원:
- 토스·키움·캐시노트 POS 영수증
- 일일 마감 보고서
- 손글씨 매출 장부 (제한적)
- 복수 항목 (메뉴명·수량·금액)
"""
import asyncio
import base64
import json
import re
from datetime import datetime
from typing import Optional

import google.generativeai as genai
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field

from app.config import settings

router = APIRouter()


# ═══════════════════════════════════════════════════════
# 스키마
# ═══════════════════════════════════════════════════════


class OcrRequest(BaseModel):
    """영수증 OCR 요청"""
    image_base64: str = Field(..., description="이미지 base64 (data:image/...;base64, 헤더 포함 가능)")
    mime_type: str = Field(default="image/jpeg", description="image/jpeg | image/png | image/webp")
    store_context: Optional[str] = Field(default=None, description="매장 메뉴 힌트")
    receipt_date_hint: Optional[str] = Field(default=None, description="YYYY-MM-DD (영수증에 날짜 없을 때 폴백)")


class ExtractedRow(BaseModel):
    """추출된 매출 한 줄"""
    sale_date: str       # YYYY-MM-DD
    menu_name: str
    quantity: int
    revenue: int         # 원 단위
    cost: int = 0
    hour_slot: int = 12  # 0-23, 모르면 12(점심)
    discount: int = 0
    confidence: float    # 0-1 — 이 줄 추출 신뢰도


class OcrResponse(BaseModel):
    rows: list[ExtractedRow]
    raw_text: Optional[str] = None   # AI가 읽은 원문 (검증용)
    warnings: list[str] = []          # "날짜 불명확", "메뉴명 흐림" 등
    receipt_type: str = "unknown"     # 'pos_receipt' | 'daily_summary' | 'handwritten' | 'unknown'


# ═══════════════════════════════════════════════════════
# Gemini Vision 호출
# ═══════════════════════════════════════════════════════


OCR_PROMPT = """당신은 한국 카페의 POS 영수증·매출 장부를 분석하는 전문 AI입니다.
이 이미지에서 매출 데이터를 정확히 추출하세요.

[영수증 유형 자동 판별]
- pos_receipt: 카드 단말기·POS 영수증 (시간·메뉴·금액 명시)
- daily_summary: 일일 마감 보고서·매출 리포트
- handwritten: 손글씨 매출 장부
- unknown: 위에 해당 안 함

[추출 규칙]
1. 각 메뉴 항목마다 한 줄로 추출 (동일 메뉴 여러 잔이면 quantity만 증가)
2. 날짜: YYYY-MM-DD 형식. 영수증에 날짜 없으면 `receipt_date_hint`를 사용, 그것도 없으면 오늘 날짜
3. 시간대(hour_slot): 0-23. 영수증의 시각을 시(hour)로 변환. 없으면 12(점심 추정)
4. 금액: 원 단위 정수. "5,000" → 5000. "5.5k" → 5500
5. 원가(cost): 영수증에 없으면 0 (사장님이 나중에 입력)
6. 할인(discount): 할인 금액 있으면 양수
7. 메뉴명: 정확히 그대로. 약어는 풀어쓰되 오타는 유지
8. 합계·부가세·결제수단은 제외 (개별 항목만)

[출력 형식]
JSON만 출력 (코드블록 없이). 구조:
{
  "receipt_type": "...",
  "rows": [
    { "sale_date": "YYYY-MM-DD", "menu_name": "...", "quantity": N, "revenue": N, "cost": 0, "hour_slot": H, "discount": 0, "confidence": 0.0~1.0 }
  ],
  "raw_text": "영수증에서 읽은 전체 텍스트",
  "warnings": ["메뉴명 흐림", "..."]
}

이미지가 영수증·매출 자료가 아니면 rows를 빈 배열로 반환하고 warnings에 "매출 관련 이미지 아님" 추가.
"""


def _strip_data_url(s: str) -> bytes:
    """data:image/jpeg;base64,XXX → bytes"""
    if "," in s:
        s = s.split(",", 1)[1]
    return base64.b64decode(s)


async def _call_gemini_vision(image_bytes: bytes, mime_type: str, extra_context: str) -> str:
    """Gemini 1.5 Flash 비전 호출 — 동기 API를 thread로 감쌈"""
    genai.configure(api_key=settings.gemini_api_key)
    model = genai.GenerativeModel('gemini-1.5-flash')

    prompt = OCR_PROMPT
    if extra_context:
        prompt += f"\n\n[추가 컨텍스트]\n{extra_context}"

    def _sync_call():
        response = model.generate_content([
            prompt,
            {"mime_type": mime_type, "data": image_bytes},
        ])
        return response.text

    return await asyncio.to_thread(_sync_call)


def _parse_json_response(raw: str) -> dict:
    """코드블록·앞뒤 공백 제거 후 JSON 파싱"""
    cleaned = re.sub(r"```(?:json)?\s*|\s*```", "", raw).strip()
    # 앞에 설명 문장이 붙는 경우 대응 — 첫 { 부터 마지막 } 까지
    match = re.search(r"\{[\s\S]*\}", cleaned)
    if match:
        cleaned = match.group()
    return json.loads(cleaned)


# ═══════════════════════════════════════════════════════
# 엔드포인트
# ═══════════════════════════════════════════════════════


@router.post("/ocr-receipt", response_model=OcrResponse)
async def ocr_receipt(req: OcrRequest):
    """
    영수증·매출 전표 이미지 → 매출 레코드 자동 추출.
    Gemini 비전 API 사용. 프론트는 결과를 검토 후 salesStore에 추가.
    """
    try:
        image_bytes = _strip_data_url(req.image_base64)
    except Exception:
        raise HTTPException(400, "이미지 base64 디코딩 실패")

    if len(image_bytes) > 10 * 1024 * 1024:
        raise HTTPException(413, "이미지가 너무 큽니다 (10MB 이하)")

    # Gemini 호출
    extra_context = ""
    if req.store_context:
        extra_context += f"매장 정보: {req.store_context}\n"
    if req.receipt_date_hint:
        extra_context += f"영수증 날짜 힌트: {req.receipt_date_hint}\n"

    try:
        raw_text = await _call_gemini_vision(image_bytes, req.mime_type, extra_context)
    except Exception as e:
        raise HTTPException(503, f"Gemini 비전 호출 실패: {str(e)[:200]}")

    # JSON 파싱
    try:
        parsed = _parse_json_response(raw_text)
    except Exception:
        # 파싱 실패 시 전체 텍스트만 반환
        return OcrResponse(
            rows=[],
            raw_text=raw_text[:2000],
            warnings=["AI 응답 파싱 실패 — 직접 입력이 필요합니다"],
            receipt_type="unknown",
        )

    # 정규화 및 유효성 검사
    today = datetime.now().strftime("%Y-%m-%d")
    rows_raw = parsed.get("rows", [])
    valid_rows: list[ExtractedRow] = []
    warnings: list[str] = parsed.get("warnings", []) or []

    for item in rows_raw:
        try:
            # 필수 필드 검증·정규화
            sale_date = str(item.get("sale_date", "") or req.receipt_date_hint or today)[:10]
            menu = str(item.get("menu_name", "")).strip()
            qty = max(1, int(item.get("quantity", 1) or 1))
            revenue = max(0, int(item.get("revenue", 0) or 0))

            if not menu or revenue == 0:
                continue  # 메뉴명 없거나 금액 0이면 스킵

            # 날짜 형식 보정
            if not re.match(r"^\d{4}-\d{2}-\d{2}$", sale_date):
                sale_date = today
                warnings.append(f"'{menu}' 날짜 형식 보정됨")

            hour_slot = int(item.get("hour_slot", 12) or 12)
            hour_slot = max(0, min(23, hour_slot))

            valid_rows.append(ExtractedRow(
                sale_date=sale_date,
                menu_name=menu,
                quantity=qty,
                revenue=revenue,
                cost=max(0, int(item.get("cost", 0) or 0)),
                hour_slot=hour_slot,
                discount=max(0, int(item.get("discount", 0) or 0)),
                confidence=float(item.get("confidence", 0.7) or 0.7),
            ))
        except (ValueError, TypeError):
            continue  # 형식 오류 항목은 스킵

    if not valid_rows and not warnings:
        warnings.append("추출된 항목이 없어요 — 이미지를 다시 확인해주세요")

    return OcrResponse(
        rows=valid_rows,
        raw_text=parsed.get("raw_text", "")[:2000] if parsed.get("raw_text") else None,
        warnings=warnings,
        receipt_type=parsed.get("receipt_type", "unknown"),
    )


# ═══════════════════════════════════════════════════════
# Bonus E4 — 송장·매입 영수증 OCR (라인 아이템 자동 추출)
# ═══════════════════════════════════════════════════════
# 매입은 매출과 다르게:
# - 거래처명 (supplier_name)
# - 거래일 (invoice_date)
# - 품목별 단가/수량/공급가
# - 부가세 (VAT)
# - 결제 조건 (외상/현금)


class InvoiceLineItem(BaseModel):
    item_name: str           # "원두 1kg" "우유 200ml ×24" 등
    quantity: float          # 0.5, 24 등
    unit: Optional[str] = None  # "kg", "박스", "EA"
    unit_price: int          # 원 단위
    line_total: int          # 단가 × 수량 (부가세 별도)
    confidence: float


class InvoiceOcrResponse(BaseModel):
    supplier_name: Optional[str] = None
    invoice_date: Optional[str] = None  # YYYY-MM-DD
    invoice_no: Optional[str] = None
    line_items: list[InvoiceLineItem] = []
    subtotal: int = 0        # 공급가 합계
    vat: int = 0             # 부가세
    total: int = 0           # 합계 (공급가 + 부가세)
    payment_terms: Optional[str] = None  # '현금' | '카드' | '외상' | None
    raw_text: Optional[str] = None
    warnings: list[str] = []
    document_type: str = "invoice"  # 'invoice' | 'tax_invoice' | 'simple_receipt'


INVOICE_PROMPT = """당신은 한국 카페 매입 송장(세금계산서·간이영수증·거래명세서)을 분석하는 전문 AI입니다.
이 이미지에서 매입 정보를 정확히 추출하세요.

[문서 유형]
- tax_invoice: 세금계산서 (공급가/부가세 분리)
- invoice: 거래명세서/거래내역서
- simple_receipt: 간이영수증 (부가세 포함가)

[추출 규칙]
1. 거래처명(supplier_name): 발행인·공급자 이름
2. 거래일(invoice_date): YYYY-MM-DD
3. 송장번호(invoice_no): 있으면
4. 품목별 line_items: 각 줄을 한 항목으로
   - item_name: "원두 1kg", "우유 200ml ×24" 등 정확히
   - quantity: 수량 (소수 가능)
   - unit: "kg" "박스" "EA" "L" 등 (모르면 null)
   - unit_price: 원 단위 정수
   - line_total: 단가 × 수량 (공급가 기준)
5. subtotal: 공급가 합계 (부가세 제외)
6. vat: 부가세 10% (없으면 0)
7. total: 최종 합계
8. payment_terms: '현금' | '카드' | '외상' | null

[출력 — JSON만 (코드블록 X)]
{
  "document_type": "...",
  "supplier_name": "...",
  "invoice_date": "YYYY-MM-DD",
  "invoice_no": "...",
  "line_items": [
    {"item_name": "...", "quantity": N, "unit": "...", "unit_price": N, "line_total": N, "confidence": 0.0~1.0}
  ],
  "subtotal": N,
  "vat": N,
  "total": N,
  "payment_terms": "...",
  "raw_text": "전체 OCR 텍스트",
  "warnings": ["..."]
}

매입 영수증·송장이 아니면 line_items=[] + warnings=["매입 자료 아님"].
"""


@router.post("/ocr-invoice", response_model=InvoiceOcrResponse)
async def ocr_invoice(req: OcrRequest):
    """
    매입 송장·세금계산서·거래명세서 OCR.
    품목별 라인 아이템 + 공급가/부가세 분리 추출.
    프론트는 결과를 검토 후 ingredients/accounting 테이블에 INSERT.
    """
    try:
        image_bytes = _strip_data_url(req.image_base64)
    except Exception:
        raise HTTPException(400, "이미지 base64 디코딩 실패")

    if len(image_bytes) > 10 * 1024 * 1024:
        raise HTTPException(413, "이미지가 너무 큽니다 (10MB 이하)")

    # Gemini Vision 호출 (송장 전용 프롬프트)
    extra_context = req.store_context or ""

    def _sync_invoice_call() -> str:
        genai.configure(api_key=settings.gemini_api_key)
        model = genai.GenerativeModel("gemini-2.5-flash")
        prompt = INVOICE_PROMPT
        if extra_context:
            prompt += f"\n\n[추가 컨텍스트]\n{extra_context}"
        response = model.generate_content([
            prompt,
            {"mime_type": req.mime_type, "data": image_bytes},
        ])
        return response.text or ""

    try:
        raw_text = await asyncio.to_thread(_sync_invoice_call)
    except Exception as e:
        raise HTTPException(503, f"Gemini Vision 호출 실패: {str(e)[:200]}")

    try:
        parsed = _parse_json_response(raw_text)
    except Exception:
        return InvoiceOcrResponse(
            line_items=[],
            raw_text=raw_text[:2000],
            warnings=["AI 응답 파싱 실패 — 직접 입력 필요"],
            document_type="invoice",
        )

    # 정규화
    items_raw = parsed.get("line_items", []) or []
    valid_items: list[InvoiceLineItem] = []
    warnings: list[str] = parsed.get("warnings", []) or []

    for item in items_raw:
        try:
            name = str(item.get("item_name", "")).strip()
            qty = float(item.get("quantity", 1) or 1)
            unit_price = max(0, int(item.get("unit_price", 0) or 0))
            line_total = max(0, int(item.get("line_total", 0) or 0))
            if not name or unit_price == 0:
                continue
            # line_total 누락 시 자동 계산
            if line_total == 0 and qty > 0:
                line_total = int(unit_price * qty)
            valid_items.append(InvoiceLineItem(
                item_name=name,
                quantity=max(0.001, qty),
                unit=(str(item.get("unit")) if item.get("unit") else None),
                unit_price=unit_price,
                line_total=line_total,
                confidence=float(item.get("confidence", 0.7) or 0.7),
            ))
        except (ValueError, TypeError):
            continue

    invoice_date = parsed.get("invoice_date")
    if invoice_date and not re.match(r"^\d{4}-\d{2}-\d{2}$", invoice_date):
        invoice_date = req.receipt_date_hint
        warnings.append("거래일 형식 보정됨")

    if not valid_items:
        warnings.append("추출된 품목이 없어요 — 이미지를 다시 확인해주세요")

    return InvoiceOcrResponse(
        supplier_name=parsed.get("supplier_name"),
        invoice_date=invoice_date or req.receipt_date_hint,
        invoice_no=parsed.get("invoice_no"),
        line_items=valid_items,
        subtotal=int(parsed.get("subtotal", 0) or 0),
        vat=int(parsed.get("vat", 0) or 0),
        total=int(parsed.get("total", 0) or 0),
        payment_terms=parsed.get("payment_terms"),
        raw_text=str(parsed.get("raw_text", "") or "")[:2000] or None,
        warnings=warnings,
        document_type=parsed.get("document_type", "invoice"),
    )
