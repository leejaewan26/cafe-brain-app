// 리뷰 관리 모듈 메인 페이지
// 탭: 리뷰 목록 | 엑셀 업로드
import { useState, useMemo, useRef, useCallback } from 'react'
import { Link } from 'react-router-dom'
import {
  Star, Upload, ChevronLeft, Filter, CheckSquare, Square,
  Sparkles, Copy, Loader2, Download, Check,
  MessageSquare, AlertCircle, ChevronDown, ChevronUp,
} from 'lucide-react'
import { useReviewStore } from '@/store/reviewStore'
import { useSettingsStore, TONE_META, type ReplyTone } from '@/store/settingsStore'
import { useStoreContext } from '@/hooks/useStoreContext'
import type { Review, ReviewRating } from '@/types/review'
import { cn } from '@/lib/utils'
import AiFeedback from '@/components/AiFeedback'
import ReviewInsights from './ReviewInsights'

// ─── 별점 컴포넌트 ───
function StarRating({ rating, size = 14 }: { rating: number; size?: number }) {
  return (
    <div className="flex gap-0.5">
      {Array.from({ length: 5 }, (_, i) => (
        <Star
          key={i}
          size={size}
          className={i < rating ? 'text-amber-400 fill-amber-400' : 'text-gray-200 fill-gray-200'}
        />
      ))}
    </div>
  )
}

// ─── 플랫폼 뱃지 ───
const PLATFORM_COLORS: Record<string, string> = {
  '네이버': 'bg-green-100 text-green-700',
  '카카오': 'bg-yellow-100 text-yellow-700',
  '구글': 'bg-blue-100 text-blue-700',
}

// ─── CSV 파서 ───
function parseCSV(text: string): { headers: string[]; rows: Record<string, string>[] } {
  const lines = text.split('\n').filter((l) => l.trim())
  const headers = lines[0].split(',').map((h) => h.trim().replace(/"/g, ''))
  const rows = lines.slice(1).map((line) => {
    const values = line.split(',').map((v) => v.trim().replace(/"/g, ''))
    return Object.fromEntries(headers.map((h, i) => [h, values[i] ?? '']))
  })
  return { headers, rows }
}

// ═════════════════════════════════════════
// ─── CSV 업로드 컴포넌트 ───
// ═════════════════════════════════════════
function ReviewUploadSection({ onImport }: { onImport: (reviews: Omit<Review, 'id' | 'ai_reply' | 'reply_status' | 'is_selected'>[]) => void }) {
  const fileRef = useRef<HTMLInputElement>(null)
  const [csvHeaders, setHeaders] = useState<string[]>([])
  const [csvRows, setRows] = useState<Record<string, string>[]>([])
  const [mapping, setMapping] = useState<Record<string, string>>({})
  const [step, setStep] = useState<'idle' | 'mapping'>('idle')
  const [error, setError] = useState('')

  const autoMapping: Record<string, string> = {
    닉네임: 'nickname', 이름: 'nickname', 작성자: 'nickname', nickname: 'nickname',
    리뷰내용: 'content', 내용: 'content', 리뷰: 'content', content: 'content',
    별점: 'rating', rating: 'rating', 점수: 'rating',
    날짜: 'date', 작성일: 'date', date: 'date',
    플랫폼: 'platform', platform: 'platform',
  }

  const handleFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return
    const reader = new FileReader()
    reader.onload = (ev) => {
      try {
        const text = ev.target?.result as string
        const { headers, rows } = parseCSV(text)
        setHeaders(headers)
        setRows(rows)
        const auto: Record<string, string> = {}
        headers.forEach((h) => {
          const key = autoMapping[h] ?? autoMapping[h.replace(/\s/g, '')]
          if (key) auto[key] = h
        })
        setMapping(auto)
        setStep('mapping')
      } catch { setError('CSV 파싱 오류가 발생했습니다.') }
    }
    reader.readAsText(file, 'utf-8')
  }

  const handleImport = () => {
    if (!mapping.nickname || !mapping.content || !mapping.rating) {
      setError('닉네임, 리뷰내용, 별점은 필수입니다.')
      return
    }
    const reviews = csvRows
      .filter((r) => r[mapping.nickname])
      .map((r) => ({
        nickname: r[mapping.nickname] ?? '',
        content: r[mapping.content] ?? '',
        rating: (Math.min(5, Math.max(1, parseInt(r[mapping.rating] || '3') || 3))) as ReviewRating,
        date: r[mapping.date] ?? new Date().toISOString().split('T')[0],
        platform: r[mapping.platform ?? ''] ?? undefined,
      }))
    onImport(reviews)
    setStep('idle')
    setHeaders([]); setRows([]); setMapping({})
    if (fileRef.current) fileRef.current.value = ''
  }

  return (
    <div className="bg-white rounded-2xl p-6 border border-gray-100 shadow-sm">
      <h3 className="font-bold text-[#2C1810] mb-4 flex items-center gap-2">
        <Upload size={18} className="text-[#D4A574]" />
        엑셀/CSV 일괄 업로드
      </h3>
      <p className="text-xs text-gray-400 mb-4">
        📄 샘플 파일: <code className="bg-gray-100 px-1 rounded">sample_data/sample_reviews.csv</code>
      </p>

      {step === 'idle' && (
        <div onClick={() => fileRef.current?.click()}
          className="border-2 border-dashed border-[#D4A574]/40 rounded-xl p-8 text-center cursor-pointer hover:border-[#D4A574] hover:bg-[#D4A574]/5 transition-all duration-200">
          <Upload className="w-8 h-8 text-[#D4A574] mx-auto mb-2" />
          <p className="text-sm font-medium text-[#2C1810]">CSV 파일 클릭하여 업로드</p>
          <p className="text-xs text-gray-400 mt-1">컬럼: 닉네임, 리뷰내용, 별점, 날짜, 플랫폼</p>
          <input ref={fileRef} type="file" accept=".csv,.txt" className="hidden" onChange={handleFile} />
        </div>
      )}

      {step === 'mapping' && (
        <div className="space-y-4">
          <p className="text-sm text-gray-600">컬럼을 필드에 매핑하세요:</p>
          <div className="grid grid-cols-2 gap-3">
            {[
              { key: 'nickname', label: '닉네임 *' },
              { key: 'content', label: '리뷰내용 *' },
              { key: 'rating', label: '별점 *' },
              { key: 'date', label: '날짜' },
              { key: 'platform', label: '플랫폼' },
            ].map(({ key, label }) => (
              <div key={key}>
                <label className="block text-xs font-medium text-gray-600 mb-1">{label}</label>
                <select value={mapping[key] ?? ''} onChange={(e) => setMapping({ ...mapping, [key]: e.target.value })}
                  className="w-full px-3 py-1.5 rounded-lg border border-gray-200 text-sm focus:outline-none focus:ring-2 focus:ring-[#D4A574]">
                  <option value="">선택</option>
                  {csvHeaders.map((h) => <option key={h} value={h}>{h}</option>)}
                </select>
              </div>
            ))}
          </div>
          {/* 미리보기 */}
          <div className="overflow-x-auto rounded-lg border border-gray-200">
            <table className="text-xs w-full">
              <thead className="bg-gray-50">
                <tr>{csvHeaders.map((h) => <th key={h} className="px-3 py-2 text-left text-gray-600">{h}</th>)}</tr>
              </thead>
              <tbody>
                {csvRows.slice(0, 2).map((row, i) => (
                  <tr key={i} className="border-t border-gray-100">
                    {csvHeaders.map((h) => <td key={h} className="px-3 py-1.5 text-gray-700 max-w-[120px] truncate">{row[h]}</td>)}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          {error && <p className="text-red-500 text-xs">{error}</p>}
          <div className="flex gap-2">
            <button onClick={() => setStep('idle')} className="px-4 py-2 rounded-xl border border-gray-200 text-sm text-gray-600 hover:bg-gray-50 transition-colors duration-200">취소</button>
            <button onClick={handleImport} className="flex-1 py-2 rounded-xl bg-[#2C1810] text-white text-sm font-semibold hover:bg-[#3d2418] transition-colors duration-200">
              {csvRows.length}개 리뷰 불러오기
            </button>
          </div>
        </div>
      )}
    </div>
  )
}

// ═════════════════════════════════════════
// ─── 개별 리뷰 카드 ───
// ═════════════════════════════════════════
function ReviewCard({
  review,
  storeName,
  menuList,
  tone,
  showWatermark,
  onToggleSelect,
  onReplyUpdate,
}: {
  review: Review
  storeName: string
  menuList: string[]
  tone: ReplyTone
  showWatermark: boolean
  onToggleSelect: () => void
  onReplyUpdate: (id: string, reply: string, status: Review['reply_status']) => void
}) {
  const [isExpanded, setIsExpanded] = useState(false)
  const [isGenerating, setIsGenerating] = useState(false)
  const [editReply, setEditReply] = useState(review.ai_reply)
  const [isEditing, setIsEditing] = useState(false)
  const [copied, setCopied] = useState(false)
  const [genError, setGenError] = useState('')
  const [cardTone, setCardTone] = useState<ReplyTone>(tone)

  const handleGenerate = async () => {
    setIsGenerating(true)
    setGenError('')
    try {
      const res = await fetch('/api/v1/reviews/reply', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          nickname: review.nickname,
          content: review.content,
          rating: review.rating,
          store_name: storeName,
          menu_list: menuList,
          tone: cardTone,
          show_watermark: showWatermark,
        }),
      })
      if (!res.ok) {
        // Rate limit 전용 메시지
        if (res.status === 429) {
          const detail = await res.json().catch(() => ({}))
          throw new Error(detail.detail ?? 'AI 호출 한도 초과 (분당 10회)')
        }
        throw new Error(`오류: ${res.status}`)
      }
      const data = await res.json()
      setEditReply(data.reply)
      onReplyUpdate(review.id, data.reply, 'generated')
      setIsExpanded(true)
    } catch (e) {
      const msg = e instanceof Error ? e.message : '오류'
      setGenError(msg.includes('Failed to fetch') ? '백엔드 서버를 먼저 시작해주세요' : msg)
    } finally {
      setIsGenerating(false)
    }
  }

  const handleCopy = async () => {
    await navigator.clipboard.writeText(editReply)
    setCopied(true)
    onReplyUpdate(review.id, editReply, 'copied')
    setTimeout(() => setCopied(false), 2000)
  }

  const handleSaveEdit = () => {
    onReplyUpdate(review.id, editReply, 'edited')
    setIsEditing(false)
  }

  const STATUS_STYLE: Record<Review['reply_status'], string> = {
    pending: 'bg-gray-100 text-gray-500',
    generated: 'bg-blue-100 text-blue-600',
    edited: 'bg-purple-100 text-purple-600',
    copied: 'bg-green-100 text-green-600',
  }
  const STATUS_LABEL: Record<Review['reply_status'], string> = {
    pending: '미작성', generated: 'AI생성', edited: '수정완료', copied: '복사완료',
  }

  return (
    <div className={cn(
      'bg-white rounded-2xl border shadow-sm transition-all duration-200',
      review.is_selected ? 'border-[#D4A574] ring-1 ring-[#D4A574]/30' : 'border-gray-100'
    )}>
      <div className="p-4">
        {/* 카드 헤더 */}
        <div className="flex items-start gap-3">
          {/* 체크박스 */}
          <button onClick={onToggleSelect} className="mt-0.5 shrink-0">
            {review.is_selected
              ? <CheckSquare size={18} className="text-[#D4A574]" />
              : <Square size={18} className="text-gray-300" />}
          </button>

          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 flex-wrap mb-1.5">
              <span className="font-semibold text-[#2C1810] text-sm">{review.nickname}</span>
              <StarRating rating={review.rating} />
              {review.platform && (
                <span className={cn('text-xs px-2 py-0.5 rounded-full font-medium', PLATFORM_COLORS[review.platform] ?? 'bg-gray-100 text-gray-600')}>
                  {review.platform}
                </span>
              )}
              <span className={cn('text-xs px-2 py-0.5 rounded-full font-medium ml-auto', STATUS_STYLE[review.reply_status])}>
                {STATUS_LABEL[review.reply_status]}
              </span>
            </div>
            <p className="text-sm text-gray-700 leading-relaxed line-clamp-2">{review.content}</p>
            <p className="text-xs text-gray-400 mt-1">{review.date}</p>
          </div>
        </div>

        {/* 액션 버튼 */}
        <div className="flex items-center gap-2 mt-3 pl-7 flex-wrap">
          {/* 어조 드롭다운 (Issue #17) */}
          <select
            value={cardTone}
            onChange={(e) => setCardTone(e.target.value as ReplyTone)}
            className="text-xs border border-gray-200 rounded-lg px-2 py-1.5 text-gray-600 bg-white focus:outline-none focus:ring-2 focus:ring-[#D4A574]/30"
            title="답글 어조 선택"
          >
            {(Object.keys(TONE_META) as ReplyTone[]).map((t) => (
              <option key={t} value={t}>
                {TONE_META[t].emoji} {TONE_META[t].label}
              </option>
            ))}
          </select>

          <button onClick={handleGenerate} disabled={isGenerating}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-gradient-to-r from-[#2C1810] to-[#D4A574] text-white rounded-lg text-xs font-medium hover:opacity-90 transition-opacity duration-200 disabled:opacity-50">
            {isGenerating ? <Loader2 size={12} className="animate-spin" /> : <Sparkles size={12} />}
            AI 답글 생성
          </button>
          {review.ai_reply && (
            <button onClick={() => setIsExpanded(!isExpanded)}
              className="flex items-center gap-1 px-3 py-1.5 border border-gray-200 text-gray-600 rounded-lg text-xs hover:bg-gray-50 transition-colors duration-200">
              답글 보기 {isExpanded ? <ChevronUp size={11} /> : <ChevronDown size={11} />}
            </button>
          )}
        </div>

        {genError && (
          <div className="mt-2 pl-7 text-xs text-orange-600 flex items-center gap-1">
            <AlertCircle size={11} />{genError}
          </div>
        )}
      </div>

      {/* 답글 미리보기 */}
      {isExpanded && review.ai_reply && (
        <div className="border-t border-gray-100 p-4 bg-[#FAFAF8] rounded-b-2xl">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-semibold text-[#2C1810]">AI 생성 답글</span>
            <div className="flex gap-2">
              <button onClick={() => { setIsEditing(!isEditing); setEditReply(review.ai_reply) }}
                className="text-xs text-gray-500 hover:text-[#2C1810] transition-colors duration-200">
                {isEditing ? '취소' : '수정'}
              </button>
              <button onClick={handleCopy}
                className="flex items-center gap-1 px-2.5 py-1 bg-[#2C1810] text-white rounded-lg text-xs hover:bg-[#3d2418] transition-colors duration-200">
                {copied ? <><Check size={11} /> 복사됨</> : <><Copy size={11} /> 복사</>}
              </button>
            </div>
          </div>
          {isEditing ? (
            <div>
              <textarea
                value={editReply}
                onChange={(e) => setEditReply(e.target.value)}
                rows={6}
                className="w-full px-3 py-2 rounded-xl border border-gray-200 text-sm focus:outline-none focus:ring-2 focus:ring-[#D4A574] resize-none"
              />
              <button onClick={handleSaveEdit}
                className="mt-2 px-4 py-1.5 bg-[#D4A574] text-white rounded-xl text-xs font-medium hover:bg-[#c4956a] transition-colors duration-200">
                저장
              </button>
            </div>
          ) : (
            <>
              <p className="text-sm text-gray-700 leading-relaxed whitespace-pre-line">{review.ai_reply}</p>
              {/* AI 피드백 수집 — 이 답글이 도움됐는지 */}
              <AiFeedback
                sourceType="review_reply"
                sourceRef={`review-reply-${review.id}`}
                compact
              />
            </>
          )}
        </div>
      )}
    </div>
  )
}

// ═════════════════════════════════════════
// ─── 메인 ReviewPage ───
// ═════════════════════════════════════════
export default function ReviewPage() {
  const { reviews, addReviews, updateReview, toggleSelect, selectAll } = useReviewStore()
  const { storeInfo } = useStoreContext()
  const defaultTone = useSettingsStore((s) => s.defaultTone)
  const showAiWatermark = useSettingsStore((s) => s.showAiWatermark)

  const [activeTab, setActiveTab] = useState<'list' | 'insights' | 'upload'>('list')
  const [ratingFilter, setRatingFilter] = useState<number | null>(null)
  const [statusFilter, setStatusFilter] = useState<'all' | 'pending' | 'done'>('all')
  const [batchProgress, setBatchProgress] = useState(0)
  const [isBatchRunning, setIsBatchRunning] = useState(false)
  const [batchDone, setBatchDone] = useState(false)

  // 매장 정보 from useStoreContext
  const storeName = storeInfo?.store_name ?? '우리 카페'
  // 샘플 메뉴 리스트 (onboarding에서 입력한 메뉴 활용)
  const menuList = ['아이스 아메리카노', '카라멜 마키아토', '바닐라 라떼', '크로플', '콜드브루', '플랫화이트', '티라미수 케이크', '얼그레이 티라미수', '아보카도 토스트']

  // 필터링된 리뷰
  const filteredReviews = useMemo(() => {
    return reviews.filter((r) => {
      if (ratingFilter !== null && r.rating !== ratingFilter) return false
      if (statusFilter === 'pending' && r.reply_status !== 'pending') return false
      if (statusFilter === 'done' && r.reply_status === 'pending') return false
      return true
    })
  }, [reviews, ratingFilter, statusFilter])

  const selectedCount = reviews.filter((r) => r.is_selected).length
  const doneCount = reviews.filter((r) => r.reply_status !== 'pending').length

  // 단일 리뷰 업데이트
  const handleReplyUpdate = useCallback((id: string, reply: string, status: Review['reply_status']) => {
    updateReview(id, { ai_reply: reply, reply_status: status })
  }, [updateReview])

  // 일괄 AI 답글 생성
  const handleBatchGenerate = async () => {
    const targets = reviews.filter((r) => r.is_selected && r.reply_status === 'pending')
    if (!targets.length) return
    setIsBatchRunning(true)
    setBatchProgress(0)
    setBatchDone(false)

    for (let i = 0; i < targets.length; i++) {
      const r = targets[i]
      try {
        const res = await fetch('/api/v1/reviews/reply', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            nickname: r.nickname,
            content: r.content,
            rating: r.rating,
            store_name: storeName,
            menu_list: menuList,
            tone: defaultTone,
            show_watermark: showAiWatermark,
          }),
        })
        if (res.ok) {
          const data = await res.json()
          updateReview(r.id, { ai_reply: data.reply, reply_status: 'generated' })
        }
      } catch { /* 오류 무시하고 다음 진행 */ }
      setBatchProgress(Math.round(((i + 1) / targets.length) * 100))
      await new Promise((res) => setTimeout(res, 300)) // rate limit 방지
    }
    setIsBatchRunning(false)
    setBatchDone(true)
  }

  // 엑셀(CSV) 다운로드
  const handleExportCSV = () => {
    const targets = reviews.filter((r) => r.ai_reply)
    if (!targets.length) return
    const rows = [['닉네임', '원본 리뷰', '별점', 'AI 답글', '날짜', '플랫폼']]
    targets.forEach((r) => {
      rows.push([
        r.nickname,
        `"${r.content.replace(/"/g, '""')}"`,
        String(r.rating),
        `"${r.ai_reply.replace(/"/g, '""')}"`,
        r.date,
        r.platform ?? '',
      ])
    })
    const csv = rows.map((r) => r.join(',')).join('\n')
    const blob = new Blob(['\uFEFF' + csv], { type: 'text/csv;charset=utf-8;' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `reviews_with_replies_${new Date().toISOString().split('T')[0]}.csv`
    a.click()
    URL.revokeObjectURL(url)
  }

  // 통계 계산
  const avgRating = reviews.length
    ? (reviews.reduce((s, r) => s + r.rating, 0) / reviews.length).toFixed(1)
    : '0.0'
  const ratingDist = [5, 4, 3, 2, 1].map((star) => ({
    star,
    count: reviews.filter((r) => r.rating === star).length,
    pct: reviews.length ? Math.round((reviews.filter((r) => r.rating === star).length / reviews.length) * 100) : 0,
  }))

  return (
    <div className="min-h-screen bg-[#FAFAF8]">
      {/* 헤더 */}
      <header className="bg-[#2C1810] text-white px-4 py-3 flex items-center gap-3">
        <Link to="/dashboard" className="hover:text-[#D4A574] transition-colors duration-200">
          <ChevronLeft size={20} />
        </Link>
        <MessageSquare size={18} className="text-[#D4A574]" />
        <h1 className="font-bold text-base flex-1">리뷰 관리</h1>
        <span className="text-xs text-[#D4A574]">{reviews.length}개</span>
      </header>

      {/* 리뷰 통계 */}
      <div className="bg-white border-b border-gray-100 px-4 py-3">
        <div className="max-w-3xl mx-auto flex items-center gap-4">
          {/* 평균 별점 */}
          <div className="text-center">
            <p className="text-2xl font-bold text-[#2C1810]">{avgRating}</p>
            <StarRating rating={Math.round(+avgRating)} size={12} />
            <p className="text-xs text-gray-400 mt-0.5">{reviews.length}개 리뷰</p>
          </div>
          {/* 분포 */}
          <div className="flex-1 space-y-1">
            {ratingDist.map(({ star, count, pct }) => (
              <div key={star} className="flex items-center gap-2">
                <span className="text-xs text-gray-500 w-4">{star}</span>
                <div className="flex-1 bg-gray-100 rounded-full h-1.5 overflow-hidden">
                  <div className="h-1.5 bg-amber-400 rounded-full transition-all duration-500" style={{ width: `${pct}%` }} />
                </div>
                <span className="text-xs text-gray-400 w-6 text-right">{count}</span>
              </div>
            ))}
          </div>
          {/* 답글 현황 */}
          <div className="text-center border-l border-gray-100 pl-4">
            <p className="text-xs text-gray-400">답글 현황</p>
            <p className="text-lg font-bold text-[#2C1810]">{doneCount}<span className="text-xs text-gray-400">/{reviews.length}</span></p>
            <p className="text-xs text-green-500">완료</p>
          </div>
        </div>
      </div>

      {/* 탭 */}
      <div className="flex bg-white border-b border-gray-100 px-4 overflow-x-auto">
        <button onClick={() => setActiveTab('list')}
          className={cn('px-4 py-2.5 text-sm font-medium transition-all duration-200 whitespace-nowrap',
            activeTab === 'list' ? 'border-b-2 border-[#2C1810] text-[#2C1810]' : 'text-gray-400 hover:text-gray-600')}>
          📝 리뷰 목록
        </button>
        <button onClick={() => setActiveTab('insights')}
          className={cn('px-4 py-2.5 text-sm font-medium transition-all duration-200 whitespace-nowrap',
            activeTab === 'insights' ? 'border-b-2 border-[#2C1810] text-[#2C1810]' : 'text-gray-400 hover:text-gray-600')}>
          📊 인사이트
        </button>
        <button onClick={() => setActiveTab('upload')}
          className={cn('px-4 py-2.5 text-sm font-medium transition-all duration-200 whitespace-nowrap',
            activeTab === 'upload' ? 'border-b-2 border-[#2C1810] text-[#2C1810]' : 'text-gray-400 hover:text-gray-600')}>
          📤 업로드
        </button>
      </div>

      <main className="max-w-3xl mx-auto px-4 py-4 space-y-4">

        {/* ─── 인사이트 탭 (Issue #4) ─── */}
        {activeTab === 'insights' && <ReviewInsights reviews={reviews} />}

        {/* ─── 업로드 탭 ─── */}
        {activeTab === 'upload' && (
          <ReviewUploadSection onImport={(reviews) => { addReviews(reviews); setActiveTab('list') }} />
        )}

        {/* ─── 리뷰 목록 탭 ─── */}
        {activeTab === 'list' && (
          <>
            {/* 일괄 작업 툴바 */}
            <div className="bg-white rounded-2xl p-4 border border-gray-100 shadow-sm">
              <div className="flex items-center gap-3 mb-3 flex-wrap">
                {/* 전체 선택 */}
                <button onClick={() => selectAll(selectedCount < reviews.length)}
                  className="flex items-center gap-1.5 text-sm text-gray-600 hover:text-[#2C1810] transition-colors duration-200">
                  {selectedCount === reviews.length && reviews.length > 0
                    ? <CheckSquare size={16} className="text-[#D4A574]" />
                    : <Square size={16} />}
                  전체 ({selectedCount}/{reviews.length})
                </button>

                {/* 필터: 별점 */}
                <div className="flex items-center gap-1 ml-2">
                  <Filter size={13} className="text-gray-400" />
                  {[null, 5, 4, 3, 2, 1].map((r) => (
                    <button key={r ?? 'all'} onClick={() => setRatingFilter(r)}
                      className={cn('text-xs px-2 py-1 rounded-full transition-all duration-200',
                        ratingFilter === r ? 'bg-[#2C1810] text-white' : 'bg-gray-100 text-gray-600 hover:bg-gray-200')}>
                      {r === null ? '전체' : `${r}★`}
                    </button>
                  ))}
                </div>

                {/* 필터: 답글 상태 */}
                <div className="flex items-center gap-1 ml-auto">
                  {(['all', 'pending', 'done'] as const).map((s) => (
                    <button key={s} onClick={() => setStatusFilter(s)}
                      className={cn('text-xs px-2 py-1 rounded-full transition-all duration-200',
                        statusFilter === s ? 'bg-[#D4A574] text-white' : 'bg-gray-100 text-gray-600 hover:bg-gray-200')}>
                      {s === 'all' ? '전체' : s === 'pending' ? '미작성' : '완료'}
                    </button>
                  ))}
                </div>
              </div>

              {/* 일괄 생성 */}
              {selectedCount > 0 && (
                <div className="space-y-3">
                  <div className="flex items-center gap-2">
                    <button onClick={handleBatchGenerate} disabled={isBatchRunning}
                      className="flex-1 py-2.5 bg-gradient-to-r from-[#2C1810] to-[#D4A574] text-white rounded-xl text-sm font-semibold hover:opacity-90 transition-opacity duration-200 disabled:opacity-50 flex items-center justify-center gap-2">
                      {isBatchRunning
                        ? <><Loader2 size={14} className="animate-spin" /> 생성 중... {batchProgress}%</>
                        : <><Sparkles size={14} /> 선택 {selectedCount}개 일괄 AI 답글 생성</>}
                    </button>
                    {batchDone && (
                      <button onClick={handleExportCSV}
                        className="flex items-center gap-1.5 px-4 py-2.5 bg-green-600 text-white rounded-xl text-sm font-semibold hover:bg-green-700 transition-colors duration-200">
                        <Download size={14} /> 엑셀 다운
                      </button>
                    )}
                  </div>
                  {/* 진행률 바 */}
                  {isBatchRunning && (
                    <div className="w-full bg-gray-100 rounded-full h-2 overflow-hidden">
                      <div className="h-2 bg-gradient-to-r from-[#2C1810] to-[#D4A574] rounded-full transition-all duration-300"
                        style={{ width: `${batchProgress}%` }} />
                    </div>
                  )}
                  {batchDone && (
                    <div className="flex items-center gap-2 text-sm text-green-600 bg-green-50 rounded-xl p-2">
                      <Check size={14} />
                      일괄 생성 완료! 엑셀로 다운로드하거나 각 리뷰에서 복사하세요.
                    </div>
                  )}
                </div>
              )}
            </div>

            {/* AI 생성된 답글이 있으면 언제든 다운로드 가능 */}
            {doneCount > 0 && selectedCount === 0 && (
              <button onClick={handleExportCSV}
                className="w-full flex items-center justify-center gap-2 py-2.5 border border-green-200 text-green-600 rounded-xl text-sm hover:bg-green-50 transition-colors duration-200">
                <Download size={14} /> AI 답글 {doneCount}개 엑셀 다운로드
              </button>
            )}

            {/* 리뷰 카드 목록 */}
            {filteredReviews.length === 0 ? (
              <div className="text-center py-12 text-gray-400">
                <MessageSquare size={32} className="mx-auto mb-2 opacity-30" />
                <p className="text-sm">필터 조건에 맞는 리뷰가 없습니다</p>
              </div>
            ) : (
              <div className="space-y-3">
                {filteredReviews.map((review) => (
                  <ReviewCard
                    key={review.id}
                    review={review}
                    storeName={storeName}
                    menuList={menuList}
                    tone={defaultTone}
                    showWatermark={showAiWatermark}
                    onToggleSelect={() => toggleSelect(review.id)}
                    onReplyUpdate={handleReplyUpdate}
                  />
                ))}
              </div>
            )}
          </>
        )}
      </main>
    </div>
  )
}
