"""
PII 필터링 미들웨어
민감정보를 마스킹한 후 Gemini에 전송 (Rule 1 준수)
마스킹 대상: 전화번호, 카드번호, 주민번호, 이메일, 한국 이름(2-4자)
"""
import re
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request

# 마스킹 패턴 정의 (순서 중요 - 구체적인 패턴 먼저)
PII_PATTERNS = [
    # 이메일 주소
    (re.compile(r'[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}'), '[이메일 삭제]'),
    # 한국 전화번호: 010-XXXX-XXXX / 02-XXXX-XXXX
    (re.compile(r'(01[016789]|02|0[3-9]\d)[- ]?\d{3,4}[- ]?\d{4}'), '[전화번호 삭제]'),
    # 카드번호: 16자리 숫자 (공백/대시 허용)
    (re.compile(r'\b\d{4}[- ]?\d{4}[- ]?\d{4}[- ]?\d{4}\b'), '[카드번호 삭제]'),
    # 주민등록번호: 6자리-7자리
    (re.compile(r'\d{6}[- ]?\d{7}'), '[주민번호 삭제]'),
    # 사업자등록번호: 3-2-5 형식
    (re.compile(r'\b\d{3}-\d{2}-\d{5}\b'), '[사업자번호 삭제]'),
    # 한국 이름 앞에 "(이름)님" 또는 "고객명:" 등 뒤에 오는 2-4자 한글
    (re.compile(r'(고객명|작성자|닉네임)[:\s]*([가-힣]{2,4})\b'), r'\1: [이름 삭제]'),
]


def mask_pii(text: str) -> str:
    """텍스트에서 민감정보를 마스킹"""
    for pattern, replacement in PII_PATTERNS:
        text = pattern.sub(replacement, text)
    return text


class PIIFilterMiddleware(BaseHTTPMiddleware):
    """요청 바디의 PII를 자동 마스킹하는 미들웨어"""

    # PII 필터링 적용 경로 (Phase 2: 모든 AI 호출 라우트에 적용)
    FILTER_PATHS = [
        '/ai-insight',          # /api/sales/ai-insight, /api/schedule/ai-insight
        '/chat',                # /api/chat/message
        '/reviews/reply',       # /api/reviews/reply
        '/marketing',           # /api/marketing/generate, /api/marketing/seo
        '/menu/recipe',
        '/menu/manual',
        '/menu/recommend',      # 신규
        '/agent',               # /api/agent/* — 메모리·브리핑
        '/supplier',            # /api/supplier/cost-savings
    ]

    async def dispatch(self, request: Request, call_next):
        path = request.url.path
        if any(p in path for p in self.FILTER_PATHS):
            body = await request.body()
            if body:
                try:
                    masked = mask_pii(body.decode('utf-8'))
                    request._body = masked.encode('utf-8')
                except Exception:
                    pass  # 디코딩 실패 시 원본 유지 (이미지 등)

        return await call_next(request)
