-- Issue #5: 멀티 프로필 시스템 (계정 1개 → 프로필 최대 3개)
-- 사장 / 점장·매니저 2단계 역할
-- 데이터는 store_id 기준 공유 (프로필 간 격리 X), 기능 접근만 역할별 제한

CREATE TABLE IF NOT EXISTS public.profiles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  store_id uuid NOT NULL REFERENCES public.stores(id) ON DELETE CASCADE,

  -- 프로필 기본 정보
  name text NOT NULL CHECK (char_length(name) BETWEEN 1 AND 20),
  role text NOT NULL CHECK (role IN ('owner', 'manager')),

  -- 선택적 PIN (4-6자리 숫자)
  pin_hash text,  -- 해시된 PIN (보안상 평문 저장 금지)

  -- 시각 구분
  avatar_emoji text DEFAULT '☕',
  avatar_color text DEFAULT '#D4A574',

  -- 생성/사용
  created_at timestamptz NOT NULL DEFAULT now(),
  last_active_at timestamptz
);

-- 스토어당 최대 3개 프로필 제약
CREATE OR REPLACE FUNCTION enforce_max_profiles_per_store()
RETURNS TRIGGER AS $$
BEGIN
  IF (SELECT count(*) FROM public.profiles WHERE store_id = NEW.store_id) >= 3 THEN
    RAISE EXCEPTION '한 매장당 최대 3개의 프로필만 생성 가능합니다';
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_max_profiles ON public.profiles;
CREATE TRIGGER trg_max_profiles
  BEFORE INSERT ON public.profiles
  FOR EACH ROW EXECUTE FUNCTION enforce_max_profiles_per_store();

-- 스토어당 최소 1명의 owner 유지
CREATE OR REPLACE FUNCTION enforce_at_least_one_owner()
RETURNS TRIGGER AS $$
BEGIN
  IF OLD.role = 'owner' AND TG_OP IN ('DELETE', 'UPDATE') THEN
    IF NOT EXISTS (
      SELECT 1 FROM public.profiles
      WHERE store_id = OLD.store_id
        AND role = 'owner'
        AND id != OLD.id
    ) THEN
      RAISE EXCEPTION '매장에 최소 1명의 사장 프로필은 있어야 합니다';
    END IF;
  END IF;
  RETURN OLD;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_keep_owner ON public.profiles;
CREATE TRIGGER trg_keep_owner
  BEFORE UPDATE OR DELETE ON public.profiles
  FOR EACH ROW EXECUTE FUNCTION enforce_at_least_one_owner();

-- 인덱스
CREATE INDEX IF NOT EXISTS idx_profiles_store ON public.profiles(store_id);

-- RLS: 본인 매장 프로필만 접근
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "profiles: 본인 매장 프로필 접근" ON public.profiles;
CREATE POLICY "profiles: 본인 매장 프로필 접근" ON public.profiles
  FOR ALL USING (store_id = auth.uid());

COMMENT ON TABLE public.profiles IS
  'Issue #5: 계정 1개에 최대 3개 프로필. 사장/점장 2단계 권한. 데이터는 공유, 접근만 제한.';


-- ══════════════════════════════════════════════════════════
-- 기존 매장에 기본 owner 프로필 자동 생성 (마이그레이션 안전)
-- ══════════════════════════════════════════════════════════
INSERT INTO public.profiles (store_id, name, role, avatar_emoji)
SELECT id, owner_name, 'owner', '👨‍💼'
FROM public.stores
WHERE NOT EXISTS (
  SELECT 1 FROM public.profiles p WHERE p.store_id = public.stores.id
)
ON CONFLICT DO NOTHING;
