// F1 — 송장·매입 영수증 OCR 업로드 위젯
// 파일 선택 → base64 → /api/sales/ocr-invoice → 라인 아이템 추출 → 사장님 승인
import { useRef, useState } from 'react'
import { Upload, Loader2, Check, X, FileText, AlertCircle } from 'lucide-react'
import { useAuthStore } from '@/store/authStore'
import { useStoreContext } from '@/hooks/useStoreContext'
import toast from 'react-hot-toast'
import { cn } from '@/lib/utils'

interface InvoiceLineItem {
  item_name: string
  quantity: number
  unit?: string | null
  unit_price: number
  line_total: number
  confidence: number
}

interface InvoiceOcrResponse {
  supplier_name?: string | null
  invoice_date?: string | null
  invoice_no?: string | null
  line_items: InvoiceLineItem[]
  subtotal: number
  vat: number
  total: number
  payment_terms?: string | null
  warnings: string[]
  document_type: string
}

interface Props {
  onConfirm: (resp: InvoiceOcrResponse) => Promise<void> | void
}

export default function InvoiceOcrUploader({ onConfirm }: Props) {
  const user = useAuthStore((s) => s.user)
  const { buildPromptContext } = useStoreContext()
  const inputRef = useRef<HTMLInputElement>(null)
  const [loading, setLoading] = useState(false)
  const [result, setResult] = useState<InvoiceOcrResponse | null>(null)
  const [confirming, setConfirming] = useState(false)

  const handlePick = () => inputRef.current?.click()

  const handleFile = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file || !user) return
    if (file.size > 10 * 1024 * 1024) {
      toast.error('파일이 너무 커요 (10MB 이하)')
      return
    }

    setLoading(true)
    setResult(null)
    try {
      const reader = new FileReader()
      const dataUrl: string = await new Promise((resolve, reject) => {
        reader.onload = () => resolve(reader.result as string)
        reader.onerror = () => reject(new Error('파일 읽기 실패'))
        reader.readAsDataURL(file)
      })

      const r = await fetch('/api/v1/sales/ocr-invoice', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-Store-Id': user.id,
        },
        body: JSON.stringify({
          image_base64: dataUrl,
          mime_type: file.type || 'image/jpeg',
          store_context: buildPromptContext().slice(0, 500),
          receipt_date_hint: new Date().toISOString().split('T')[0],
        }),
      })
      if (!r.ok) {
        toast.error('OCR 분석 실패')
        return
      }
      const data: InvoiceOcrResponse = await r.json()
      setResult(data)
      if (data.line_items.length === 0) {
        toast(`품목 인식 실패 — ${data.warnings[0] ?? '이미지를 다시 확인해주세요'}`)
      } else {
        toast.success(`${data.line_items.length}개 품목 추출됨 — 검토 후 승인하세요`)
      }
    } catch (err) {
      toast.error(`업로드 실패 — ${err instanceof Error ? err.message : '오류'}`)
    } finally {
      setLoading(false)
      if (inputRef.current) inputRef.current.value = ''
    }
  }

  const confirm = async () => {
    if (!result) return
    setConfirming(true)
    try {
      await onConfirm(result)
      setResult(null)
      toast.success('매입 데이터로 등록했어요 ✨')
    } catch (err) {
      toast.error(`등록 실패 — ${err instanceof Error ? err.message : '오류'}`)
    } finally {
      setConfirming(false)
    }
  }

  return (
    <div className="space-y-3">
      <input
        ref={inputRef}
        type="file"
        accept="image/jpeg,image/png,image/webp"
        onChange={handleFile}
        className="hidden"
      />

      {!result && (
        <button
          onClick={handlePick}
          disabled={loading}
          className={cn(
            'w-full flex items-center justify-center gap-2 px-4 py-3 rounded-xl border-2 border-dashed transition-colors',
            loading
              ? 'border-gray-200 bg-gray-50 text-gray-400 cursor-wait'
              : 'border-[#D4A574]/50 bg-[#D4A574]/5 text-[#2C1810] hover:bg-[#D4A574]/10 cursor-pointer'
          )}
        >
          {loading ? (
            <>
              <Loader2 size={16} className="animate-spin" />
              <span className="text-sm">AI가 분석 중…</span>
            </>
          ) : (
            <>
              <Upload size={16} />
              <span className="text-sm font-semibold">송장·세금계산서 사진 업로드</span>
            </>
          )}
        </button>
      )}

      {result && (
        <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
          {/* 헤더 */}
          <div className="px-4 py-3 bg-[#FAFAF8] border-b border-gray-100">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <FileText size={14} className="text-[#D4A574]" />
                <span className="text-sm font-bold text-[#2C1810]">
                  {result.supplier_name || '거래처 미식별'}
                </span>
                <span className="text-xs text-gray-400">{result.invoice_date || '-'}</span>
                {result.document_type && (
                  <span className="text-[10px] px-2 py-0.5 bg-gray-100 text-gray-500 rounded-full">
                    {result.document_type === 'tax_invoice'
                      ? '세금계산서'
                      : result.document_type === 'invoice'
                      ? '거래명세서'
                      : '간이영수증'}
                  </span>
                )}
              </div>
              <button
                onClick={() => setResult(null)}
                className="p-1 text-gray-400 hover:text-[#2C1810]"
                title="취소"
              >
                <X size={14} />
              </button>
            </div>
          </div>

          {/* 라인 아이템 */}
          <div className="max-h-72 overflow-y-auto">
            {result.line_items.length === 0 ? (
              <div className="p-8 text-center">
                <AlertCircle size={24} className="text-amber-500 mx-auto mb-2" />
                <p className="text-sm text-gray-500">추출된 품목이 없어요. 직접 입력 필요.</p>
              </div>
            ) : (
              <table className="w-full text-xs">
                <thead className="bg-gray-50 text-gray-500 sticky top-0">
                  <tr>
                    <th className="text-left px-3 py-2 font-semibold">품목</th>
                    <th className="text-right px-3 py-2 font-semibold">수량</th>
                    <th className="text-right px-3 py-2 font-semibold">단가</th>
                    <th className="text-right px-3 py-2 font-semibold">소계</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-100">
                  {result.line_items.map((li, i) => (
                    <tr key={i} className="hover:bg-gray-50">
                      <td className="px-3 py-2 text-[#2C1810]">{li.item_name}</td>
                      <td className="text-right px-3 py-2 tabular-nums">
                        {li.quantity}{li.unit ? ` ${li.unit}` : ''}
                      </td>
                      <td className="text-right px-3 py-2 tabular-nums text-gray-500">
                        ₩{li.unit_price.toLocaleString()}
                      </td>
                      <td className="text-right px-3 py-2 tabular-nums font-semibold text-[#2C1810]">
                        ₩{li.line_total.toLocaleString()}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}
          </div>

          {/* 합계 + 액션 */}
          {result.line_items.length > 0 && (
            <div className="border-t border-gray-100 px-4 py-3 space-y-2">
              <div className="flex justify-between text-xs text-gray-500">
                <span>공급가</span>
                <span className="tabular-nums">₩{result.subtotal.toLocaleString()}</span>
              </div>
              <div className="flex justify-between text-xs text-gray-500">
                <span>부가세</span>
                <span className="tabular-nums">₩{result.vat.toLocaleString()}</span>
              </div>
              <div className="flex justify-between text-sm font-bold text-[#2C1810]">
                <span>합계</span>
                <span className="tabular-nums">₩{result.total.toLocaleString()}</span>
              </div>
              {result.warnings.length > 0 && (
                <div className="text-[10px] text-amber-700 bg-amber-50 rounded-lg p-2 mt-2">
                  ⚠️ {result.warnings.join(' / ')}
                </div>
              )}
              <button
                onClick={confirm}
                disabled={confirming}
                className="w-full mt-2 flex items-center justify-center gap-1.5 bg-[#2C1810] text-white py-2.5 rounded-lg text-sm font-semibold hover:bg-[#3A2519] transition-colors disabled:opacity-50"
              >
                {confirming ? (
                  <><Loader2 size={14} className="animate-spin" /> 등록 중…</>
                ) : (
                  <><Check size={14} /> 매입 데이터로 등록</>
                )}
              </button>
            </div>
          )}
        </div>
      )}
    </div>
  )
}
