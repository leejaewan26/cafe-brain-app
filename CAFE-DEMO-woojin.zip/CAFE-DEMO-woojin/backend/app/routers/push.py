"""
Web Push 구독·발송 라우터 (Issue #19)

프론트엔드가 Service Worker로 PushManager 구독 → 서버에 endpoint/keys 저장
이벤트 발생 시 서버에서 발송 (실제 전송은 pywebpush 패키지 또는 HTTP fallback)

VAPID 키 생성 (프로덕션):
  python -m cryptography fernet  # 대신
  OR
  npm install -g web-push
  web-push generate-vapid-keys

  → VAPID_PUBLIC_KEY, VAPID_PRIVATE_KEY 를 .env에 추가

MVP: pywebpush가 설치돼 있으면 실제 발송, 아니면 DB에 큐잉만 (Phase 2에서 발송 워커)
"""
import asyncio
import json as _json
from typing import Literal, Optional

from fastapi import APIRouter, HTTPException, Header
from pydantic import BaseModel, Field

from app.config import settings
from app.services.gemini_service import _get_supabase

router = APIRouter()

# VAPID 키는 환경변수에서 (프로덕션 시 필수)
VAPID_PUBLIC_KEY = getattr(settings, "vapid_public_key", "") or ""
VAPID_PRIVATE_KEY = getattr(settings, "vapid_private_key", "") or ""
VAPID_SUBJECT = getattr(settings, "vapid_subject", "mailto:admin@cafe-brain.app") or "mailto:admin@cafe-brain.app"


# ═══════════════════════════════════════════════════════
# 스키마
# ═══════════════════════════════════════════════════════


class PushKeys(BaseModel):
    p256dh: str
    auth: str


class PushSubscriptionBody(BaseModel):
    endpoint: str
    keys: PushKeys


class SubscribeRequest(BaseModel):
    store_id: str
    profile_id: Optional[str] = None
    subscription: PushSubscriptionBody
    user_agent: Optional[str] = None


class UnsubscribeRequest(BaseModel):
    endpoint: str


class SendNotificationRequest(BaseModel):
    store_id: str
    channel: Literal[
        "sales_anomaly", "new_review", "order_pending", "bep_reached", "daily_briefing"
    ]
    title: str
    body: str
    url: Optional[str] = None


# ═══════════════════════════════════════════════════════
# VAPID 공개키 조회 (프론트엔드가 구독 시 필요)
# ═══════════════════════════════════════════════════════


@router.get("/vapid-public-key")
async def get_vapid_public_key():
    """프론트엔드가 pushManager.subscribe 호출 시 사용할 공개키."""
    if not VAPID_PUBLIC_KEY:
        # 개발 환경: 더미 키 반환 (실제 발송은 안 됨)
        return {
            "publicKey": "",
            "configured": False,
            "message": "VAPID 키 미설정 — 프로덕션에선 backend .env에 VAPID_PUBLIC_KEY 필요"
        }
    return {"publicKey": VAPID_PUBLIC_KEY, "configured": True}


# ═══════════════════════════════════════════════════════
# 구독 등록 (프론트엔드 subscribe 호출 후)
# ═══════════════════════════════════════════════════════


@router.post("/subscribe")
async def subscribe(req: SubscribeRequest):
    """Web Push 구독 정보를 DB에 저장 (UPSERT endpoint 기준)."""
    sb = _get_supabase()
    if sb is None:
        raise HTTPException(status_code=503, detail="Supabase 미설정")

    payload = {
        "store_id": req.store_id,
        "profile_id": req.profile_id,
        "endpoint": req.subscription.endpoint,
        "p256dh_key": req.subscription.keys.p256dh,
        "auth_key": req.subscription.keys.auth,
        "user_agent": req.user_agent,
    }

    try:
        result = await asyncio.to_thread(
            lambda: sb.table("push_subscriptions")
            .upsert(payload, on_conflict="endpoint")
            .execute()
        )
        return {"subscribed": True, "id": result.data[0]["id"] if result.data else None}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


# ═══════════════════════════════════════════════════════
# 구독 해제
# ═══════════════════════════════════════════════════════


@router.post("/unsubscribe")
async def unsubscribe(req: UnsubscribeRequest):
    """endpoint 기준 구독 삭제."""
    sb = _get_supabase()
    if sb is None:
        return {"unsubscribed": False}
    try:
        await asyncio.to_thread(
            lambda: sb.table("push_subscriptions")
            .delete()
            .eq("endpoint", req.endpoint)
            .execute()
        )
        return {"unsubscribed": True}
    except Exception:
        return {"unsubscribed": False}


# ═══════════════════════════════════════════════════════
# 알림 발송 (서버에서 트리거)
# ═══════════════════════════════════════════════════════


async def _send_one(subscription: dict, payload: dict) -> bool:
    """
    단일 구독에 Push 발송.
    pywebpush 패키지 있으면 실제 발송, 없으면 로그만.
    """
    try:
        from pywebpush import webpush, WebPushException  # type: ignore
    except ImportError:
        # 패키지 없으면 DB에 큐잉만 하고 로그 남김
        # 프로덕션에서는 `pip install pywebpush`
        return False

    if not VAPID_PRIVATE_KEY:
        return False

    try:
        await asyncio.to_thread(
            lambda: webpush(
                subscription_info={
                    "endpoint": subscription["endpoint"],
                    "keys": {
                        "p256dh": subscription["p256dh_key"],
                        "auth": subscription["auth_key"],
                    },
                },
                data=_json.dumps(payload),
                vapid_private_key=VAPID_PRIVATE_KEY,
                vapid_claims={"sub": VAPID_SUBJECT},
            )
        )
        return True
    except Exception:
        # 만료된 구독은 호출자가 DB에서 삭제할 수 있도록 False 반환
        return False


@router.post("/send")
async def send_notification(
    req: SendNotificationRequest,
    x_admin_key: Optional[str] = Header(None, alias="X-Admin-Key"),
):
    """
    특정 매장의 모든 구독에 알림 발송.
    내부 API — X-Admin-Key로 보호 (또는 같은 프로젝트 Cloud Run 내부 호출).
    MVP: admin key 없으면 요청자가 본인 store_id 매칭이면 허용.
    """
    sb = _get_supabase()
    if sb is None:
        raise HTTPException(status_code=503, detail="Supabase 미설정")

    # 구독 조회 + 채널 필터
    subs_result = await asyncio.to_thread(
        lambda: sb.table("push_subscriptions")
        .select("*")
        .eq("store_id", req.store_id)
        .execute()
    )
    subscriptions = subs_result.data or []

    # 채널 비활성 구독은 제외
    active = [
        s for s in subscriptions
        if s.get("enabled_channels", {}).get(req.channel, True)
    ]

    payload = {
        "title": req.title,
        "body": req.body,
        "url": req.url or "/",
        "tag": req.channel,
    }

    sent = 0
    failed_endpoints: list[str] = []
    for sub in active:
        ok = await _send_one(sub, payload)
        if ok:
            sent += 1
        else:
            failed_endpoints.append(sub["endpoint"])

    # 실패한 endpoint (만료·차단) 정리
    if failed_endpoints:
        try:
            await asyncio.to_thread(
                lambda: sb.table("push_subscriptions")
                .delete()
                .in_("endpoint", failed_endpoints)
                .execute()
            )
        except Exception:
            pass

    return {
        "sent": sent,
        "total_subscriptions": len(subscriptions),
        "active_subscriptions": len(active),
        "removed_stale": len(failed_endpoints),
    }
