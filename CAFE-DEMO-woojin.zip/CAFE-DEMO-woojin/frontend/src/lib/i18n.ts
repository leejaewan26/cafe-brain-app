// H6 — i18n 설정 (i18next + react-i18next)
// 한국어 기본, 영어 지원. 자동 감지 (navigator.language) + localStorage persistence.
import i18n from 'i18next'
import { initReactI18next } from 'react-i18next'
import LanguageDetector from 'i18next-browser-languagedetector'

import ko from './locales/ko.json'
import en from './locales/en.json'

void i18n
  .use(LanguageDetector)
  .use(initReactI18next)
  .init({
    fallbackLng: 'ko',
    supportedLngs: ['ko', 'en'],
    resources: {
      ko: { translation: ko },
      en: { translation: en },
    },
    interpolation: {
      escapeValue: false,
    },
    detection: {
      order: ['localStorage', 'navigator'],
      lookupLocalStorage: 'cafe-brain-locale',
      caches: ['localStorage'],
    },
  })

export default i18n
