// G1 — 첫 로그인 온보딩 투어
// localStorage에 마커 저장 → 한 번만 표시. "다시 보지 않기" + "스킵" 옵션.
// 5단계로 핵심 기능 안내.
import { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { ArrowRight, X, BarChart2, MessageCircle, Brain, Sparkles, Coffee } from 'lucide-react'
import { useAuthStore } from '@/store/authStore'
import { cn } from '@/lib/utils'

const TOUR_KEY = 'cafe-brain-tour-completed'

interface TourStep {
  title: string
  description: string
  icon: React.ElementType
  cta?: { label: string; route?: string }
}

const STEPS: TourStep[] = [
  {
    icon: Coffee,
    title: '카페 브레인에 오신 걸 환영합니다 ☕',
    description: '사장님 매장만을 위한 AI 비서예요. 5단계로 핵심 기능을 직접 체험해볼게요. 각 단계에서 "지금 해보기"를 누르면 실제 화면으로 이동합니다.',
  },
  {
    icon: BarChart2,
    title: '1. 매출 분석',
    description: 'POS CSV 업로드 또는 영수증 사진 촬영 → AI가 자동 인식 → 4사분면 차트로 베스트셀러·악성메뉴 즉시 분류. 일평균 매출, 시간대별 인기 메뉴, 요일별 패턴까지.',
    cta: { label: '매출 페이지 직접 보기', route: '/sales' },
  },
  {
    icon: MessageCircle,
    title: '2. AI 어시스턴트',
    description: '"비 오는 금요일 매출 어땠어?", "원두값 15% 오르면 가격 얼마로 올려야 해?" 같은 자연어 질문에 매장 데이터 + 트렌드를 종합해 답합니다.',
    cta: { label: 'AI와 첫 대화', route: '/chat' },
  },
  {
    icon: Brain,
    title: '3. AI 학습 (매장 메모리)',
    description: '운영하시는 동안 매장 패턴·고객 특성·사장님 선호를 60일간 학습합니다. 모든 학습 내용은 투명하게 공개되며 언제든 삭제·편집 가능.',
    cta: { label: 'AI 학습 내용 보기', route: '/settings' },
  },
  {
    icon: Sparkles,
    title: '4. 능동 브리핑 + 이상치 룰',
    description: '아침마다 AI가 먼저 말 걸어줍니다. "주말 매출이 평균 -30%면 알림", "특정 메뉴 매출 급락 감지" 같은 룰도 사장님이 직접 정의하실 수 있어요.',
    cta: { label: '대시보드로', route: '/dashboard' },
  },
]

interface OnboardingTourProps {
  onComplete?: () => void
}

export default function OnboardingTour({ onComplete }: OnboardingTourProps) {
  const user = useAuthStore((s) => s.user)
  const navigate = useNavigate()
  const [open, setOpen] = useState(false)
  const [step, setStep] = useState(0)

  useEffect(() => {
    if (!user) return
    const completed = localStorage.getItem(TOUR_KEY)
    if (completed === user.id) return
    // 살짝 지연 후 표시 (페이지 로드 후 자연스러운 등장)
    const t = setTimeout(() => setOpen(true), 800)
    return () => clearTimeout(t)
  }, [user])

  const close = (markCompleted = true) => {
    setOpen(false)
    if (markCompleted && user) {
      localStorage.setItem(TOUR_KEY, user.id)
    }
    onComplete?.()
  }

  const next = () => {
    if (step < STEPS.length - 1) {
      setStep(step + 1)
    } else {
      close(true)
    }
  }

  if (!open) return null

  const current = STEPS[step]
  const Icon = current.icon
  const isLast = step === STEPS.length - 1

  return (
    <div className="fixed inset-0 z-[55] bg-black/60 flex items-center justify-center p-4 backdrop-blur-sm animate-in fade-in duration-300">
      <div className="bg-white rounded-3xl shadow-2xl max-w-md w-full overflow-hidden animate-in zoom-in-95 duration-300">
        {/* 헤더 */}
        <div className="bg-gradient-to-br from-[#D4A574] to-[#2C1810] p-6 relative">
          <button
            onClick={() => close(true)}
            className="absolute top-4 right-4 w-8 h-8 rounded-full bg-white/20 hover:bg-white/30 text-white flex items-center justify-center transition-colors"
            aria-label="투어 닫기"
          >
            <X size={14} />
          </button>
          <div className="w-14 h-14 rounded-2xl bg-white/20 backdrop-blur flex items-center justify-center mb-3">
            <Icon size={26} className="text-white" />
          </div>
          {/* 진행 바 */}
          <div className="flex gap-1">
            {STEPS.map((_, i) => (
              <div
                key={i}
                className={cn(
                  'h-1 rounded-full flex-1 transition-all',
                  i === step ? 'bg-white' : i < step ? 'bg-white/60' : 'bg-white/20'
                )}
              />
            ))}
          </div>
        </div>

        {/* 본문 */}
        <div className="p-6">
          <h2 className="text-xl font-bold text-[#2C1810] mb-2">{current.title}</h2>
          <p className="text-sm text-gray-600 leading-relaxed mb-5">{current.description}</p>

          <div className="flex items-center gap-2">
            <span className="text-xs text-gray-400">{step + 1} / {STEPS.length}</span>
            <button
              onClick={() => close(true)}
              className="ml-auto text-xs text-gray-400 hover:text-gray-600 transition-colors"
            >
              건너뛰기
            </button>
            <button
              onClick={() => {
                if (isLast && current.cta?.route) {
                  navigate(current.cta.route)
                  close(true)
                } else if (current.cta?.route && step > 0) {
                  navigate(current.cta.route)
                  close(true)
                } else {
                  next()
                }
              }}
              className="flex items-center gap-1.5 bg-[#2C1810] text-white px-4 py-2 rounded-xl text-sm font-semibold hover:bg-[#3A2519] transition-colors"
            >
              {isLast ? '시작하기' : current.cta?.label || '다음'}
              <ArrowRight size={13} />
            </button>
          </div>
        </div>
      </div>
    </div>
  )
}
