"""
Phase 6 #13 — Response time SLO 추적 미들웨어.

모든 AI 엔드포인트의 (start, end, status, cache_hit, store_id)를
agent_latency_log 에 백그라운드로 INSERT.

응답 자체는 0ms 지연 — asyncio.create_task 로 fire-and-forget.
"""
import asyncio
from time import perf_counter
from fastapi import Request
from starlette.middleware.base import BaseHTTPMiddleware

from app.middleware.rate_limit import AI_ENDPOINTS
from app.services.slo_service import record_latency


class SLOTrackerMiddleware(BaseHTTPMiddleware):
    """AI 엔드포인트 응답시간 측정 — DB 비동기 INSERT."""

    async def dispatch(self, request: Request, call_next):
        # AI 엔드포인트가 아니면 측정 안 함
        if not request.url.path.startswith(AI_ENDPOINTS):
            return await call_next(request)

        start = perf_counter()
        response = await call_next(request)
        duration_ms = int((perf_counter() - start) * 1000)

        # 응답 헤더에서 캐시 적중 추론 (gemini_service가 X-Cache 헤더 세팅 시)
        cache_hit = response.headers.get("X-Cache") == "HIT"
        store_hint = request.headers.get("X-Store-Id", "") or None

        # fire-and-forget — 응답 블로킹 X
        asyncio.create_task(
            record_latency(
                endpoint=request.url.path,
                method=request.method,
                duration_ms=duration_ms,
                status_code=response.status_code,
                store_id=store_hint,
                cache_hit=cache_hit,
            )
        )

        # 응답 헤더에 측정값 노출 (디버그용)
        response.headers["X-Response-Time-MS"] = str(duration_ms)
        return response
