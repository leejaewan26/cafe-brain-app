// Cafe Brain Service Worker
//   Issue #19: Web Push 알림 수신
//   Bonus E6: 오프라인 모드 (stale-while-revalidate API 캐시 + app shell)
//
// 캐시 버전 변경 시 자동 폐기 — 활성화 단계에서 다른 버전 캐시 모두 삭제.

const CACHE_VERSION = 'v2'
const SHELL_CACHE = `cafe-brain-shell-${CACHE_VERSION}`
const API_CACHE = `cafe-brain-api-${CACHE_VERSION}`

const SHELL_PRECACHE = [
  '/',
  '/index.html',
  '/manifest.webmanifest',
  '/cafe-icon.svg',
  '/favicon.svg',
]

// API GET 응답 30분 stale-while-revalidate
const API_TTL_MS = 30 * 60 * 1000

// ─── 설치 단계: app shell 사전 캐싱 ───
self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(SHELL_CACHE)
      .then((cache) => cache.addAll(SHELL_PRECACHE).catch(() => null))
      .then(() => self.skipWaiting())
  )
})

// ─── 활성화 단계: 구 버전 캐시 정리 ───
self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((names) =>
      Promise.all(
        names
          .filter((n) => n !== SHELL_CACHE && n !== API_CACHE)
          .map((n) => caches.delete(n))
      )
    ).then(() => self.clients.claim())
  )
})

// ─── Fetch 핸들러 (E6 — offline strategies) ───
function isApiGet(request) {
  if (request.method !== 'GET') return false
  const url = new URL(request.url)
  if (url.origin !== self.location.origin) return false
  return url.pathname.startsWith('/api/')
}

function isStaticAsset(request) {
  const url = new URL(request.url)
  return /\.(?:js|css|svg|png|jpg|jpeg|webp|woff2?)$/.test(url.pathname)
}

async function networkFirstNavigation(request) {
  try {
    return await fetch(request)
  } catch {
    const cached = await caches.match('/index.html')
    if (cached) return cached
    return new Response('Offline', { status: 503 })
  }
}

async function cacheFirstStatic(request) {
  const cached = await caches.match(request)
  if (cached) return cached
  try {
    const fresh = await fetch(request)
    if (fresh.ok) {
      const cache = await caches.open(SHELL_CACHE)
      cache.put(request, fresh.clone()).catch(() => null)
    }
    return fresh
  } catch (err) {
    if (cached) return cached
    throw err
  }
}

async function staleWhileRevalidateApi(request) {
  const cache = await caches.open(API_CACHE)
  const cached = await cache.match(request)

  const networkPromise = fetch(request).then((response) => {
    if (response.ok) {
      cache.put(request, response.clone()).catch(() => null)
    }
    return response
  }).catch(() => null)

  if (cached) {
    const dateHeader = cached.headers.get('date')
    if (dateHeader) {
      const cachedAt = new Date(dateHeader).getTime()
      if (Number.isFinite(cachedAt) && Date.now() - cachedAt > API_TTL_MS) {
        const fresh = await networkPromise
        if (fresh) return fresh
      }
    }
    return cached
  }

  const fresh = await networkPromise
  if (fresh) return fresh
  return new Response(
    JSON.stringify({ detail: '오프라인 — 캐시된 데이터 없음', offline: true }),
    { status: 503, headers: { 'Content-Type': 'application/json' } }
  )
}

self.addEventListener('fetch', (event) => {
  const { request } = event
  if (request.method !== 'GET') return  // POST/PUT/DELETE pass-through
  if (request.url.includes('/sw.js')) return  // SW 자체 업데이트는 캐시 X

  if (request.mode === 'navigate' || request.destination === 'document') {
    event.respondWith(networkFirstNavigation(request))
    return
  }
  if (isApiGet(request)) {
    event.respondWith(staleWhileRevalidateApi(request))
    return
  }
  if (isStaticAsset(request)) {
    event.respondWith(cacheFirstStatic(request))
    return
  }
})

// ─── 클라이언트 메시지 (로그아웃 시 API 캐시 삭제) ───
self.addEventListener('message', (event) => {
  if (event.data && event.data.type === 'CLEAR_API_CACHE') {
    caches.delete(API_CACHE).catch(() => null)
  }
})

// ─── Issue #19: Push 알림 수신 ───
self.addEventListener('push', (event) => {
  if (!event.data) return

  let payload
  try {
    payload = event.data.json()
  } catch {
    payload = { title: '카페 브레인', body: event.data.text() }
  }

  const title = payload.title || '카페 브레인'
  const options = {
    body: payload.body || '',
    icon: payload.icon || '/favicon.svg',
    badge: '/favicon.svg',
    tag: payload.tag || 'cafe-brain',
    data: {
      url: payload.url || '/',
      ...payload.data,
    },
    vibrate: [100, 50, 100],
    actions: payload.actions || [],
    requireInteraction: payload.requireInteraction === true,
  }

  event.waitUntil(self.registration.showNotification(title, options))
})

self.addEventListener('notificationclick', (event) => {
  event.notification.close()
  const targetUrl = event.notification.data?.url || '/'

  event.waitUntil(
    self.clients.matchAll({ type: 'window', includeUncontrolled: true }).then((clientList) => {
      for (const client of clientList) {
        if ('focus' in client) {
          client.focus()
          if ('navigate' in client) {
            client.navigate(targetUrl)
          }
          return
        }
      }
      if (self.clients.openWindow) {
        return self.clients.openWindow(targetUrl)
      }
    })
  )
})

self.addEventListener('pushsubscriptionchange', (event) => {
  event.waitUntil(
    self.registration.pushManager
      .subscribe({
        userVisibleOnly: true,
        applicationServerKey: event.oldSubscription?.options?.applicationServerKey,
      })
      .then((newSub) => {
        return fetch('/api/push/subscribe', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ subscription: newSub.toJSON() }),
        })
      })
      .catch(() => {})
  )
})
