// 마케팅 콘텐츠 생성 모듈 타입 정의
export type Platform = 'instagram_feed' | 'instagram_story' | 'threads' | 'naver_blog' | 'kakao'

export type PromotionTarget = 'new_menu' | 'event' | 'season' | 'daily' | 'intro'

export type Tone = 'emotional' | 'humor' | 'informative' | 'casual'

export type TargetAudience = 'mz_women' | 'office' | 'student' | 'family' | 'general'

// 생성 요청 입력 폼
export interface MarketingInput {
  platform: Platform
  promotion_target: PromotionTarget
  description: string
  tone: Tone
  target_audience: TargetAudience
  store_name: string
  menu_list: string[]
}

// 생성된 시안
export interface ContentDraft {
  id: string
  platform: Platform
  content: string
  hashtags?: string[]       // 인스타그램용
  seo_keywords?: string[]   // 블로그용
  char_count: number
}

// SEO 분석 결과
export interface SeoAnalysis {
  keyword_density: Record<string, number>  // 키워드별 밀도
  title_found: boolean
  heading_count: number
  char_count: number
  score: number   // 0-100
  suggestions: string[]
}
