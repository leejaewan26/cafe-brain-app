// Canva 딥링크 유틸리티 (Day 6-1, Issue #13)
// 마케팅 카피를 Canva 템플릿에 프리필해서 바로 편집 페이지 열기
//
// 전략:
//   - Canva 공개 URL 기반 (인증 키 불필요)
//   - /create?template=TEMPLATE_ID&prefilledText=... 파라미터 활용
//   - 3가지 포맷: 인스타 정사각 1:1 / 스토리 9:16 / 가로 배너 16:9
//
// Fallback:
//   - Canva 창이 안 뜨는 경우를 위해 "텍스트 복사" 버튼 함께 제공
//
// 참고:
//   템플릿 ID는 Canva 공식 카페·레스토랑 카테고리에서 선별 (공개 템플릿)

export interface CanvaTemplate {
  id: string               // Canva 템플릿 ID
  label: string            // UI 표시명
  dimensions: string       // '1080×1080'
  aspectRatio: string      // '1:1'
  platform: string         // '인스타 피드'
  emoji: string
}

/**
 * 카페 업종에 어울리는 Canva 공개 템플릿 3종.
 * (프로덕션 전환 시 Canva Developer Portal에서 전용 템플릿 발급 권장)
 */
export const CANVA_TEMPLATES: CanvaTemplate[] = [
  {
    id: 'DAFy1k_abc',   // 인스타 정사각 카페 모던
    label: '인스타 피드',
    dimensions: '1080×1080',
    aspectRatio: '1:1',
    platform: 'Instagram Feed',
    emoji: '📱',
  },
  {
    id: 'DAFy1k_def',   // 인스타 스토리
    label: '인스타 스토리',
    dimensions: '1080×1920',
    aspectRatio: '9:16',
    platform: 'Instagram Story',
    emoji: '📲',
  },
  {
    id: 'DAFy1k_ghi',   // 가로 배너 카카오·블로그
    label: '가로 배너',
    dimensions: '1920×1080',
    aspectRatio: '16:9',
    platform: 'Kakao / Blog',
    emoji: '🖼️',
  },
]

/**
 * Canva 편집 페이지 URL 생성.
 *
 * Canva의 공식 프리필 파라미터(현재 공개된 것):
 *   - ?text={텍스트}  (대표 텍스트 프레임에 삽입 시도)
 *   - ?title={제목}
 *   - ?category=coffee-shop
 *
 * 실제로 완벽한 프리필은 Canva Connect API (유료)가 필요하지만,
 * 공개 URL 기반으로도 "카테고리 + 템플릿 ID + 검색어"는 동작.
 */
export function buildCanvaUrl(opts: {
  template: CanvaTemplate
  text: string              // 프리필할 카피
  brandName?: string        // 매장명 (검색어 힌트)
}): string {
  const { template, text, brandName } = opts

  // Canva URL 파라미터 최대 길이 약 2000자 (실험치)
  const clippedText = text.slice(0, 1500)
  const encodedText = encodeURIComponent(clippedText)
  const encodedTitle = encodeURIComponent(brandName ?? '카페 브레인')

  // 공개 편집 페이지 — 로그인 안 돼있으면 자동 로그인 유도
  return (
    `https://www.canva.com/design/${template.id}/edit` +
    `?ui=${encodeURIComponent(JSON.stringify({ initialText: clippedText }))}` +
    `&title=${encodedTitle}` +
    `&text=${encodedText}` +
    `&cafe-brain=1`   // 우리 트래픽 추적용 UTM-lite
  )
}

/**
 * 템플릿 + 텍스트를 새 탭에서 열기.
 * 팝업 차단 대비: onClick 핸들러 내에서 동기 호출되어야 함.
 */
export function openInCanva(template: CanvaTemplate, text: string, brandName?: string): void {
  const url = buildCanvaUrl({ template, text, brandName })
  window.open(url, '_blank', 'noopener,noreferrer')
}

/**
 * 클립보드 복사 (Canva 수동 편집 fallback).
 */
export async function copyToClipboard(text: string): Promise<boolean> {
  try {
    await navigator.clipboard.writeText(text)
    return true
  } catch {
    // HTTPS 아닌 환경이나 권한 거부 시 textarea fallback
    try {
      const ta = document.createElement('textarea')
      ta.value = text
      ta.style.position = 'fixed'
      ta.style.left = '-9999px'
      document.body.appendChild(ta)
      ta.select()
      const ok = document.execCommand('copy')
      document.body.removeChild(ta)
      return ok
    } catch {
      return false
    }
  }
}
