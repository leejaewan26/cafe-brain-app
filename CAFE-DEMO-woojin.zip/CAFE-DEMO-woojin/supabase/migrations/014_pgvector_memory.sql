-- Phase 6 #4: pgvector — 에이전트 메모리 의미적 검색
--
-- ilike 접두사 매칭 → cosine similarity 의미 검색으로 업그레이드.
-- "고객 불만"으로 검색해도 "민원" "컴플레인" 등 의미 유사 메모리 찾음.
--
-- Gemini text-embedding-004 = 768차원 벡터.
--
-- 적용:
--   1. Supabase Database → Extensions → vector 활성화
--   2. SQL Editor에서 이 파일 전체 실행

-- ══════════════════════════════════════════════════════════
-- 0. pgvector 확장
-- ══════════════════════════════════════════════════════════
CREATE EXTENSION IF NOT EXISTS vector;


-- ══════════════════════════════════════════════════════════
-- 1. agent_memory에 embedding 컬럼 추가
-- ══════════════════════════════════════════════════════════
ALTER TABLE public.agent_memory
  ADD COLUMN IF NOT EXISTS embedding vector(768);

COMMENT ON COLUMN public.agent_memory.embedding IS
  'Phase 6: Gemini text-embedding-004 로 생성한 768차원 임베딩. NULL이면 키워드 검색만 가능.';


-- ══════════════════════════════════════════════════════════
-- 2. HNSW 인덱스 (cosine 거리, 빠른 ANN 검색)
-- ══════════════════════════════════════════════════════════
CREATE INDEX IF NOT EXISTS idx_memory_embedding_hnsw
  ON public.agent_memory
  USING hnsw (embedding vector_cosine_ops)
  WHERE archived_at IS NULL AND embedding IS NOT NULL;


-- ══════════════════════════════════════════════════════════
-- 3. 의미적 검색 함수 — search_memories_semantic
-- ══════════════════════════════════════════════════════════
CREATE OR REPLACE FUNCTION public.search_memories_semantic(
  p_store_id uuid,
  p_query_embedding vector(768),
  p_categories text[] DEFAULT NULL,
  p_limit int DEFAULT 8,
  p_min_similarity float DEFAULT 0.5
)
RETURNS TABLE (
  id uuid,
  category text,
  content text,
  importance int,
  confidence numeric,
  similarity float,
  created_at timestamptz
) AS $func$
BEGIN
  RETURN QUERY
  SELECT
    m.id,
    m.category,
    m.content,
    m.importance,
    m.confidence,
    -- cosine similarity = 1 - cosine distance
    (1 - (m.embedding <=> p_query_embedding))::float AS similarity,
    m.created_at
  FROM public.agent_memory m
  WHERE m.store_id = p_store_id
    AND m.archived_at IS NULL
    AND m.embedding IS NOT NULL
    AND (m.expires_at IS NULL OR m.expires_at > now())
    AND (p_categories IS NULL OR m.category = ANY(p_categories))
    AND (1 - (m.embedding <=> p_query_embedding)) >= p_min_similarity
  ORDER BY
    -- 의미적 유사도 + 중요도 가중치
    ((1 - (m.embedding <=> p_query_embedding)) * 0.7 + (m.importance / 10.0) * 0.3) DESC,
    m.last_used_at DESC NULLS LAST
  LIMIT p_limit;
END;
$func$ LANGUAGE plpgsql STABLE SECURITY DEFINER;


-- ══════════════════════════════════════════════════════════
-- 4. 하이브리드 검색 — 의미 검색 + 키워드 fallback
-- ══════════════════════════════════════════════════════════
-- embedding 없는 (옛) 메모리도 결과에 섞어서 반환
CREATE OR REPLACE FUNCTION public.search_memories_hybrid(
  p_store_id uuid,
  p_query_embedding vector(768),
  p_categories text[] DEFAULT NULL,
  p_limit int DEFAULT 10
)
RETURNS TABLE (
  id uuid,
  category text,
  content text,
  importance int,
  confidence numeric,
  similarity float,
  created_at timestamptz,
  search_type text
) AS $func$
BEGIN
  -- 1) 의미 검색 (embedding 있는 것)
  RETURN QUERY
  SELECT
    m.id, m.category, m.content, m.importance, m.confidence,
    (1 - (m.embedding <=> p_query_embedding))::float AS similarity,
    m.created_at,
    'semantic'::text AS search_type
  FROM public.agent_memory m
  WHERE m.store_id = p_store_id
    AND m.archived_at IS NULL
    AND m.embedding IS NOT NULL
    AND (m.expires_at IS NULL OR m.expires_at > now())
    AND (p_categories IS NULL OR m.category = ANY(p_categories))
  ORDER BY m.embedding <=> p_query_embedding ASC
  LIMIT p_limit;

  -- 2) 키워드 fallback (embedding 없는 옛 메모리, 중요도순)
  RETURN QUERY
  SELECT
    m.id, m.category, m.content, m.importance, m.confidence,
    NULL::float AS similarity,
    m.created_at,
    'keyword'::text AS search_type
  FROM public.agent_memory m
  WHERE m.store_id = p_store_id
    AND m.archived_at IS NULL
    AND m.embedding IS NULL
    AND (m.expires_at IS NULL OR m.expires_at > now())
    AND (p_categories IS NULL OR m.category = ANY(p_categories))
  ORDER BY m.importance DESC, m.last_used_at DESC NULLS LAST
  LIMIT GREATEST(0, p_limit / 2);
END;
$func$ LANGUAGE plpgsql STABLE SECURITY DEFINER;


COMMENT ON FUNCTION public.search_memories_semantic IS
  'Phase 6: 임베딩 기반 의미적 메모리 검색 (cosine + 중요도 가중)';
COMMENT ON FUNCTION public.search_memories_hybrid IS
  'Phase 6: 의미 검색 + 키워드 fallback (옛 메모리 보장 노출)';
