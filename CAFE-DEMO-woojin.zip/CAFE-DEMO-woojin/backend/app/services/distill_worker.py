"""
Phase 6 #3: distill 자동화 백엔드 worker

Supabase pg_cron이 매주 월 04시 KST에 stores.agent_profile._distill_pending=true 플래그를
설정하면, 이 worker가 polling해서 실제 distill (Gemini 호출) 자동 수행.

설계:
- FastAPI startup event에서 백그라운드 task 시작
- 1시간마다 polling: agent_profile->>_distill_pending = 'true' 매장 조회
- 각 매장 distill 호출 → 성공 시 _distill_pending 플래그 제거
- Phase 3 운영 시간(KST 06~22) 안에서만 실행 (비용·무한 루프 방지)

호출:
  asyncio.create_task(distill_worker_loop()) — main.py startup에서
"""
import asyncio
from typing import Any

from app.services.gemini_service import _get_supabase
from app.middleware.agent_gate import is_within_operating_hours


POLL_INTERVAL_SECONDS = 3600  # 1시간


async def _process_pending_stores() -> int:
    """_distill_pending=true 매장 1회 스캔 + distill 실행. 처리 개수 반환."""
    sb = _get_supabase()
    if sb is None:
        return 0

    try:
        # JSONB 필드 검색: agent_profile->>'_distill_pending' = 'true'
        result = await asyncio.to_thread(
            lambda: sb.table("stores")
            .select("id, agent_profile")
            .eq("agent_learning_enabled", True)
            .execute()
        )
        candidates = [
            row for row in (result.data or [])
            if (row.get("agent_profile") or {}).get("_distill_pending") is True
        ]

        if not candidates:
            return 0

        from app.routers.agent_briefing import distill_profile, DistillRequest

        processed = 0
        for store in candidates:
            try:
                # 운영 시간 게이트 (Gemini 호출 보호)
                within, _, _, _ = await is_within_operating_hours(store["id"])
                if not within:
                    continue

                await distill_profile(DistillRequest(store_id=store["id"]))

                # Phase 6 #10: distill 후 메모리 압축도 자동 실행
                try:
                    from app.services.memory_compressor import run_compression_for_store
                    await run_compression_for_store(store["id"])
                except Exception as e:
                    print(f"[distill_worker] {store['id']} 압축 실패: {e}")

                # 플래그 제거 (distill_profile 내부에서 _distilled_at 갱신됨)
                profile: dict[str, Any] = store.get("agent_profile") or {}
                profile.pop("_distill_pending", None)
                await asyncio.to_thread(
                    lambda p=profile, sid=store["id"]: sb.table("stores")
                    .update({"agent_profile": p})
                    .eq("id", sid)
                    .execute()
                )
                processed += 1
            except Exception as e:
                print(f"[distill_worker] {store['id']} 실패: {e}")

        return processed
    except Exception as e:
        print(f"[distill_worker] scan 실패: {e}")
        return 0


async def distill_worker_loop():
    """
    백엔드 startup에서 호출. 무한 루프로 1시간마다 distill polling.
    """
    print("[distill_worker] 시작 — 1시간 polling")
    while True:
        try:
            count = await _process_pending_stores()
            if count > 0:
                print(f"[distill_worker] {count}개 매장 distill 완료")
        except Exception as e:
            print(f"[distill_worker] loop error: {e}")
        await asyncio.sleep(POLL_INTERVAL_SECONDS)
