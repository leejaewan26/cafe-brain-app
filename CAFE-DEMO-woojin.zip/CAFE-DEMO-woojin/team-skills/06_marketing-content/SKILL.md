---
name: marketing-content
description: This skill should be used when the user asks to write marketing copy, optimize landing pages, create email campaigns, improve conversions (CRO), run SEO audits on marketing pages, write cold emails, create social media content, plan launches, analyze pricing strategy, set up A/B tests, build referral programs, or perform any marketing-related task. Activates on phrases like "마케팅", "랜딩 페이지", "카피라이팅", "전환율", "이메일 시퀀스", "소셜 콘텐츠", "pricing", "launch", "copywriting", "CRO", "marketing".
version: 1.0.0
---

# Marketing Content Skill

Comprehensive marketing skill covering conversion optimization, copywriting, SEO, growth, and strategy for SaaS and digital products.

> Based on: https://github.com/coreyhaines31/marketingskills

## When This Skill Applies

Activate when the user needs help with:
- Writing or editing marketing copy (landing pages, emails, ads)
- Conversion Rate Optimization (CRO) for any page type
- SEO for marketing content
- Growth strategies, referral programs, churn prevention
- Launch planning, pricing strategy, competitive analysis
- Social media content, paid ads
- Sales enablement materials

## Core Principle: Start With Context

Before writing any marketing content, always establish:
1. **Product**: What does it do? What's the core value proposition?
2. **Audience**: Who are the target users? What pain do they feel?
3. **Positioning**: How is it different from alternatives?
4. **Stage**: Early-stage (finding ICP) vs. growth (scaling) vs. mature (retaining)?

---

## Conversion Rate Optimization (CRO)

### Landing Page CRO (`page-cro`)
- Above-the-fold: clear headline + subheadline + CTA within 5 seconds of reading
- Headline formula: [Who] + [Outcome] + [Time/Mechanism] without [Pain]
- Social proof placement: right after hero, before CTA, at bottom
- CTA copy: action-oriented ("Start free trial" > "Submit"), specific benefit
- Objection handling section: address top 3 objections explicitly
- Mobile-first: CTA visible without scroll on mobile

### Signup Flow CRO
- Reduce fields to minimum viable (name + email only if possible)
- Progress indicators for multi-step flows
- Error messages: specific and helpful, not generic
- Social login as primary option when possible

### Email CRO
- Subject line: curiosity gap OR specific benefit OR personalization
- Preview text: complement (not repeat) the subject line
- Single CTA per email
- Plain text often outperforms HTML for cold email

---

## Copywriting

### Frameworks
- **PAS**: Problem → Agitate → Solution
- **AIDA**: Attention → Interest → Desire → Action
- **Before/After/Bridge**: Current state → Desired state → Your product as bridge
- **Features → Benefits → Feelings**: Don't stop at features; connect to emotional outcome

### Tone Guidelines
- Match audience sophistication (developers: direct + technical; execs: ROI-focused)
- Active voice, short sentences
- Avoid: "best-in-class", "synergy", "leverage", "robust"
- Use: specific numbers, customer quotes, concrete outcomes

---

## SEO for Marketing Pages

### On-Page Essentials
- Target one primary keyword per page; support with 3-5 semantic variants
- Title tag: primary keyword near front, under 60 chars
- Meta description: benefit-driven, include keyword, 150-160 chars
- H1 = page topic (matches search intent), H2s = subtopics
- Internal linking: link to related features/use cases

### Content Quality (E-E-A-T)
- Experience: include real examples, case studies, data
- Expertise: author bios, citations, depth of coverage
- Authoritativeness: backlinks, brand mentions
- Trustworthiness: privacy policy, security badges, reviews

---

## Growth Strategies

### Referral Programs
- Incentive: dual-sided reward (referrer + referee both win)
- Friction: shareable link in dashboard, not hidden in settings
- Timing: trigger invite prompt at "aha moment" (first value delivery)

### Churn Prevention
- Exit survey: always capture reason (5 options max)
- Pause option: offer pause before cancel for seasonal users
- Win-back sequence: 3-email flow at 7, 14, 30 days post-churn

### Free Tool Strategy
- Tool must solve one specific problem for ICP
- SEO title: "[tool name] - free [category] tool"
- CTA: capture email before showing full results

---

## Launch Strategy

### Pre-Launch (4 weeks before)
- Build waitlist with referral mechanism
- Seed social proof (beta users, testimonials)
- Prepare launch assets: demo video, screenshots, PR kit

### Launch Day
- ProductHunt: launch at 12:01am PST, hunter with 1k+ followers
- Email: announce to waitlist first (before public)
- Social: schedule 3 posts (launch, midday update, evening recap)

### Post-Launch (week 1)
- Respond to every comment and review
- Collect and publish early testimonials
- Address top objections in a follow-up post

---

## Pricing Strategy

- Start with value-based pricing, not cost-plus
- 3-tier structure: Starter / Growth / Pro (middle tier is anchor)
- Annual discount: 15-20% effective (e.g., "2 months free")
- Free tier: limited by usage or features, not time
- Price anchoring: show highest plan first

---

## Available Skill Categories

| Category | Skills |
|----------|--------|
| CRO | page-cro, signup-flow-cro, onboarding-cro, form-cro, popup-cro, paywall-upgrade-cro |
| Content | copywriting, copy-editing, cold-email, email-sequence, social-content |
| SEO | seo-audit, ai-seo, programmatic-seo, site-architecture, schema-markup |
| Paid | paid-ads, ad-creative |
| Measurement | analytics-tracking, ab-test-setup |
| Growth | referral-program, free-tool-strategy, churn-prevention |
| Strategy | marketing-ideas, marketing-psychology, launch-strategy, pricing-strategy, content-strategy, customer-research |
| Sales | revops, sales-enablement |
