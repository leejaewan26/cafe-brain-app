// Launch A2 — 개인정보처리방침 (PIPA 준수)
// 한국 개인정보 보호법 + EU GDPR 양쪽을 고려한 표준 템플릿.
// Gemini, Supabase 등 위탁사 관계 명시.
import { Link } from 'react-router-dom'
import { ArrowLeft, Shield } from 'lucide-react'

const EFFECTIVE_DATE = '2026-05-03'
const COMPANY_NAME = '카페 브레인'
const CONTACT_EMAIL = 'privacy@cafe-brain.app'

export default function PrivacyPage() {
  return (
    <div className="min-h-screen bg-[#FAFAF8] py-8 px-4">
      <div className="max-w-3xl mx-auto">
        {/* 헤더 */}
        <Link to="/" className="inline-flex items-center gap-1 text-sm text-gray-500 hover:text-[#2C1810] mb-6 transition-colors">
          <ArrowLeft size={14} /> 홈으로
        </Link>

        <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-6 md:p-10">
          <div className="flex items-center gap-3 mb-2">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#D4A574] to-[#2C1810] flex items-center justify-center">
              <Shield size={18} className="text-white" />
            </div>
            <h1 className="text-2xl font-bold text-[#2C1810]">개인정보처리방침</h1>
          </div>
          <p className="text-xs text-gray-400 mb-6">시행일: {EFFECTIVE_DATE}</p>

          <p className="text-sm text-gray-700 leading-relaxed mb-6">
            {COMPANY_NAME}(이하 "회사")는 「개인정보 보호법」 등 관련 법령을 준수하며,
            이용자의 개인정보를 안전하게 처리하기 위해 본 방침을 수립·공개합니다.
          </p>

          {/* 1. 수집 항목 */}
          <Section title="1. 수집하는 개인정보 항목 및 방법">
            <Subsection title="가. 회원가입 시">
              <Bullets items={[
                '필수: 이메일, 비밀번호(해시), 매장명, 매장 주소, 매장 유형',
                '선택: 사업자 등록번호, 전화번호, 운영 시간',
              ]} />
            </Subsection>
            <Subsection title="나. 서비스 이용 중">
              <Bullets items={[
                '매출 데이터(일자·메뉴·금액·시간대), 메뉴 정보, 직원 스케줄',
                '리뷰 데이터(별점·내용), AI 채팅 대화 내역',
                '서비스 이용 기록, 접속 로그, IP 주소, 쿠키, 기기 정보',
              ]} />
            </Subsection>
            <Subsection title="다. 결제 시">
              <Bullets items={[
                '결제 대행사(토스페이먼츠 등)를 통한 결제 정보 처리',
                '회사는 카드 번호·CVC를 직접 보관하지 않으며, 결제 토큰만 사용합니다',
              ]} />
            </Subsection>
          </Section>

          {/* 2. 처리 목적 */}
          <Section title="2. 개인정보의 처리 목적">
            <Bullets items={[
              '회원 가입·관리, 본인 확인, 부정 이용 방지',
              'AI 인사이트(매출 분석·메뉴 추천·리뷰 답글) 제공',
              '맞춤형 알림·브리핑 발송, 서비스 개선',
              '결제·환불 처리, 청구서 발행, 조세 의무 이행',
              '법령 준수, 분쟁 조정, 민원 대응',
            ]} />
          </Section>

          {/* 3. 보유 기간 */}
          <Section title="3. 개인정보 보유 및 이용 기간">
            <p className="text-sm text-gray-700 leading-relaxed mb-2">
              회사는 회원 탈퇴 시 즉시 개인정보를 파기합니다. 단, 다음 정보는 관련 법령에 따라 일정 기간 보관합니다:
            </p>
            <Bullets items={[
              '계약·청약 철회 기록: 5년 (전자상거래법)',
              '대금 결제·재화 공급 기록: 5년 (전자상거래법)',
              '소비자 불만·분쟁 처리 기록: 3년 (전자상거래법)',
              '웹사이트 방문 기록: 3개월 (통신비밀보호법)',
            ]} />
          </Section>

          {/* 4. 제3자 제공 */}
          <Section title="4. 개인정보의 제3자 제공">
            <p className="text-sm text-gray-700 leading-relaxed mb-2">
              회사는 이용자의 개인정보를 동의 없이 제3자에게 제공하지 않습니다.
              단, 법령에 의거하거나 수사기관의 요청이 있는 경우 예외로 합니다.
            </p>
          </Section>

          {/* 5. 위탁 */}
          <Section title="5. 개인정보 처리 위탁">
            <p className="text-sm text-gray-700 leading-relaxed mb-3">
              회사는 서비스 제공을 위해 아래와 같이 개인정보 처리를 위탁하고 있습니다.
              모든 위탁사는 개인정보 보호를 위한 기술적·관리적 보호 조치를 취하고 있습니다.
            </p>
            <div className="overflow-x-auto">
              <table className="w-full text-xs border border-gray-200 rounded-lg">
                <thead className="bg-[#FAFAF8] text-gray-600">
                  <tr>
                    <th className="px-3 py-2 text-left border-b border-gray-200">수탁사</th>
                    <th className="px-3 py-2 text-left border-b border-gray-200">위탁 업무</th>
                    <th className="px-3 py-2 text-left border-b border-gray-200">국가</th>
                  </tr>
                </thead>
                <tbody className="text-gray-700">
                  <tr>
                    <td className="px-3 py-2 border-b border-gray-100">Google LLC (Gemini API)</td>
                    <td className="px-3 py-2 border-b border-gray-100">AI 응답 생성</td>
                    <td className="px-3 py-2 border-b border-gray-100">미국</td>
                  </tr>
                  <tr>
                    <td className="px-3 py-2 border-b border-gray-100">Supabase Inc.</td>
                    <td className="px-3 py-2 border-b border-gray-100">데이터베이스·인증·스토리지</td>
                    <td className="px-3 py-2 border-b border-gray-100">미국 / 싱가포르</td>
                  </tr>
                  <tr>
                    <td className="px-3 py-2 border-b border-gray-100">Vercel Inc.</td>
                    <td className="px-3 py-2 border-b border-gray-100">프론트엔드 호스팅·CDN</td>
                    <td className="px-3 py-2 border-b border-gray-100">미국</td>
                  </tr>
                  <tr>
                    <td className="px-3 py-2 border-b border-gray-100">Google Cloud Run</td>
                    <td className="px-3 py-2 border-b border-gray-100">백엔드 서버</td>
                    <td className="px-3 py-2 border-b border-gray-100">아시아 (서울)</td>
                  </tr>
                  <tr>
                    <td className="px-3 py-2 border-b border-gray-100">Sentry, Inc.</td>
                    <td className="px-3 py-2 border-b border-gray-100">오류 모니터링 (PII 마스킹)</td>
                    <td className="px-3 py-2 border-b border-gray-100">미국</td>
                  </tr>
                </tbody>
              </table>
            </div>
            <p className="text-xs text-gray-500 leading-relaxed mt-3">
              ※ AI 응답 생성 시 Gemini에 전송되는 매장 데이터는 PII 필터로 개인정보를 마스킹한 뒤 전송되며,
              Google은 본 데이터를 모델 학습에 사용하지 않도록 약정되어 있습니다.
            </p>
          </Section>

          {/* 6. 이용자 권리 */}
          <Section title="6. 이용자의 권리·의무">
            <Bullets items={[
              '본인의 개인정보 열람 요구 (서비스 내 [설정 > AI 학습] 탭에서 즉시 확인)',
              '개인정보 정정·삭제 요구 ("잊어줘" 버튼으로 즉시 삭제 가능)',
              '개인정보 처리 정지 요구 (학습 토글 OFF)',
              '회원 탈퇴 시 모든 개인정보 즉시 파기',
              '권리 행사는 이메일·채팅·전화로 요청 가능하며, 회사는 지체 없이 조치합니다',
            ]} />
          </Section>

          {/* 7. 보호 조치 */}
          <Section title="7. 개인정보 보호 조치">
            <Bullets items={[
              '암호화: 비밀번호 단방향 해시(bcrypt), 통신 구간 TLS 1.3',
              'Row Level Security: 매장별 데이터 격리 (Supabase RLS)',
              '접근 통제: 권한별 메모리(owner/manager) 분리',
              '감사 로그: 메모리 삭제·룰 변경 등 행위 자동 기록',
              '백업: 일별 자동 백업, 30일 보관',
            ]} />
          </Section>

          {/* 8. 쿠키 */}
          <Section title="8. 쿠키 사용">
            <p className="text-sm text-gray-700 leading-relaxed">
              회사는 인증 세션 유지를 위해 필수 쿠키만 사용합니다. 분석·광고 쿠키는 사용하지 않습니다.
              브라우저 설정에서 쿠키를 거부할 수 있으나, 일부 기능 사용에 제한이 있을 수 있습니다.
            </p>
          </Section>

          {/* 9. 책임자 */}
          <Section title="9. 개인정보 보호책임자">
            <div className="bg-[#FAFAF8] rounded-xl p-4 text-sm text-gray-700 leading-relaxed">
              <p>책임자: 개인정보 보호팀</p>
              <p>이메일: <a href={`mailto:${CONTACT_EMAIL}`} className="text-[#D4A574] hover:underline">{CONTACT_EMAIL}</a></p>
            </div>
          </Section>

          {/* 10. 변경 고지 */}
          <Section title="10. 방침 변경">
            <p className="text-sm text-gray-700 leading-relaxed">
              본 방침이 변경되는 경우 시행일 7일 전부터 서비스 내 공지사항을 통해 고지합니다.
              중요한 변경(수집 항목 추가, 제3자 제공 등)은 별도 동의를 받습니다.
            </p>
          </Section>

          <p className="text-xs text-gray-400 mt-8">시행일: {EFFECTIVE_DATE}</p>
        </div>
      </div>
    </div>
  )
}

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <section className="mb-6">
      <h2 className="font-bold text-[#2C1810] text-base mb-3">{title}</h2>
      {children}
    </section>
  )
}

function Subsection({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="mb-3">
      <p className="text-sm font-semibold text-[#2C1810] mb-1.5">{title}</p>
      {children}
    </div>
  )
}

function Bullets({ items }: { items: string[] }) {
  return (
    <ul className="list-disc pl-5 space-y-1 text-sm text-gray-700 leading-relaxed">
      {items.map((it, i) => <li key={i}>{it}</li>)}
    </ul>
  )
}
