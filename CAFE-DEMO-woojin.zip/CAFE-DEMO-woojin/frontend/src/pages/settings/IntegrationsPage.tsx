// H2 + H3 + H5 — 외부 연동 통합 페이지
//   네이버 (리뷰 / 예약), POS, Instagram, n8n
import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import {
  ChevronLeft, Search, Loader2, Check, Plus,
  Instagram, ShoppingBag, MapPin, Workflow,
  AlertCircle,
} from 'lucide-react'
import { useAuthStore } from '@/store/authStore'
import { cn } from '@/lib/utils'
import toast from 'react-hot-toast'

export default function IntegrationsPage() {
  const [tab, setTab] = useState<'naver' | 'pos' | 'social' | 'n8n'>('naver')
  return (
    <div className="min-h-screen bg-[#FAFAF8]">
      <header className="bg-white border-b border-gray-100 sticky top-0 z-10">
        <div className="max-w-3xl mx-auto px-4 py-3 flex items-center gap-3">
          <Link to="/settings" className="text-gray-400 hover:text-[#2C1810]"><ChevronLeft size={18} /></Link>
          <h1 className="text-base font-bold text-[#2C1810]">외부 연동</h1>
        </div>
        <nav className="max-w-3xl mx-auto px-4 flex gap-1 border-b border-gray-100 overflow-x-auto">
          {[
            { id: 'naver' as const, label: '네이버', icon: MapPin },
            { id: 'pos' as const, label: 'POS', icon: ShoppingBag },
            { id: 'social' as const, label: 'Instagram', icon: Instagram },
            { id: 'n8n' as const, label: 'n8n 멀티채널', icon: Workflow },
          ].map((t) => {
            const Icon = t.icon
            return (
              <button
                key={t.id}
                onClick={() => setTab(t.id)}
                className={cn(
                  'flex items-center gap-1.5 px-3 py-2.5 text-xs font-semibold transition-colors border-b-2 whitespace-nowrap',
                  tab === t.id
                    ? 'border-[#2C1810] text-[#2C1810]'
                    : 'border-transparent text-gray-400 hover:text-[#2C1810]'
                )}
              >
                <Icon size={13} /> {t.label}
              </button>
            )
          })}
        </nav>
      </header>
      <main className="max-w-3xl mx-auto px-4 py-5">
        {tab === 'naver' && <NaverTab />}
        {tab === 'pos' && <PosTab />}
        {tab === 'social' && <InstagramTab />}
        {tab === 'n8n' && <N8nTab />}
      </main>
    </div>
  )
}

// ═══════════════════════════════════════════════════════
// Naver
// ═══════════════════════════════════════════════════════

function NaverTab() {
  const user = useAuthStore((s) => s.user)
  const [query, setQuery] = useState('')
  const [candidates, setCandidates] = useState<Array<{ title: string; address: string; place_id_hint: string | null; road_address: string }>>([])
  const [loading, setLoading] = useState(false)

  const search = async () => {
    if (!query.trim()) return
    setLoading(true)
    try {
      const r = await fetch(`/api/v1/naver-reviews/search-place?query=${encodeURIComponent(query)}`)
      if (!r.ok) throw new Error('검색 실패')
      const data = await r.json()
      setCandidates(data.candidates || [])
      if (data.note) toast(data.note, { icon: 'ℹ️' })
    } catch (e) {
      toast.error(e instanceof Error ? e.message : '오류')
    } finally {
      setLoading(false)
    }
  }

  const linkPlace = async (c: { title: string; place_id_hint: string | null }) => {
    if (!user || !c.place_id_hint) {
      toast.error('place_id를 찾지 못했어요')
      return
    }
    const r = await fetch('/api/v1/naver-reviews/link-place', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        store_id: user.id,
        naver_place_id: c.place_id_hint,
        naver_place_name: c.title,
      }),
    })
    if (r.ok) toast.success(`매장 매핑 완료 — ${c.title}`)
    else toast.error('매핑 실패')
  }

  return (
    <div className="space-y-4">
      <div className="bg-white rounded-2xl border border-gray-100 p-5">
        <h2 className="text-sm font-bold text-[#2C1810] mb-2">네이버 매장 매핑</h2>
        <p className="text-xs text-gray-500 mb-3 leading-relaxed">
          매장명을 검색해서 본인 카페를 선택하면 네이버 리뷰가 자동으로 동기화됩니다.
        </p>
        <div className="flex gap-2">
          <input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && search()}
            placeholder="매장명 + 지역 (예: 카페 브레인 강남)"
            className="flex-1 px-3 py-2 border border-gray-200 rounded-lg text-sm focus:outline-none focus:border-[#2C1810]"
          />
          <button
            onClick={search}
            disabled={loading}
            className="px-4 py-2 bg-[#2C1810] text-white text-sm font-semibold rounded-lg disabled:opacity-50 flex items-center gap-1.5"
          >
            {loading ? <Loader2 size={14} className="animate-spin" /> : <Search size={14} />}
            검색
          </button>
        </div>
      </div>

      {candidates.length > 0 && (
        <div className="space-y-2">
          {candidates.map((c, i) => (
            <button
              key={i}
              onClick={() => linkPlace(c)}
              className="w-full text-left bg-white rounded-xl border border-gray-100 hover:border-[#2C1810] p-3 transition-colors"
            >
              <p className="font-bold text-sm text-[#2C1810]">{c.title}</p>
              <p className="text-xs text-gray-500 mt-0.5">{c.road_address || c.address}</p>
              {c.place_id_hint && (
                <p className="text-[10px] text-gray-400 mt-1">place_id: {c.place_id_hint}</p>
              )}
            </button>
          ))}
        </div>
      )}

      {/* 수동 import */}
      <div className="bg-amber-50 border border-amber-100 rounded-2xl p-4">
        <div className="flex items-start gap-2">
          <AlertCircle size={14} className="text-amber-600 mt-0.5 shrink-0" />
          <div className="text-xs text-amber-800 leading-relaxed">
            <strong>API 권한 없으신가요?</strong> 네이버 리뷰 페이지 URL과 본문을 직접 붙여넣으시면 등록해드려요.{' '}
            <Link to="/reviews" className="underline">리뷰 페이지에서 시도</Link>
          </div>
        </div>
      </div>
    </div>
  )
}

// ═══════════════════════════════════════════════════════
// POS
// ═══════════════════════════════════════════════════════

function PosTab() {
  const user = useAuthStore((s) => s.user)
  const [conns, setConns] = useState<Array<{ vendor: string; last_sync_at: string | null; is_active: boolean }>>([])
  const [vendor, setVendor] = useState<'toss_pos' | 'kis' | 'smart_bro'>('toss_pos')
  const [apiKey, setApiKey] = useState('')

  const load = async () => {
    if (!user) return
    const r = await fetch(`/api/v1/pos/connections/${user.id}`)
    if (r.ok) setConns((await r.json()).connections || [])
  }
  useEffect(() => { void load() }, [user])  // eslint-disable-line

  const connect = async () => {
    if (!user || !apiKey.trim()) return toast.error('API 키 필요')
    const r = await fetch('/api/v1/pos/connect', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ store_id: user.id, vendor, api_key: apiKey }),
    })
    if (r.ok) {
      toast.success(`${vendor} 연결됨`)
      setApiKey('')
      void load()
    } else toast.error('연결 실패')
  }

  return (
    <div className="space-y-4">
      <div className="bg-white rounded-2xl border border-gray-100 p-5">
        <h2 className="text-sm font-bold text-[#2C1810] mb-1">POS 자동 동기화</h2>
        <p className="text-xs text-gray-500 mb-3">매출 데이터가 5분마다 자동으로 가져와집니다.</p>
        <div className="grid grid-cols-3 gap-2 mb-3">
          <select
            value={vendor}
            onChange={(e) => setVendor(e.target.value as typeof vendor)}
            className="col-span-1 px-3 py-2 border border-gray-200 rounded-lg text-sm"
          >
            <option value="toss_pos">토스 POS</option>
            <option value="kis">KIS</option>
            <option value="smart_bro">스마트브로</option>
          </select>
          <input
            type="password"
            value={apiKey}
            onChange={(e) => setApiKey(e.target.value)}
            placeholder="API 키"
            className="col-span-2 px-3 py-2 border border-gray-200 rounded-lg text-sm font-mono"
          />
        </div>
        <button
          onClick={connect}
          className="w-full bg-[#2C1810] text-white py-2 rounded-lg text-sm font-semibold flex items-center justify-center gap-1.5"
        >
          <Plus size={13} /> 연결하기
        </button>
      </div>

      {conns.length > 0 && (
        <div className="space-y-2">
          {conns.map((c) => (
            <div key={c.vendor} className="bg-white rounded-xl border border-gray-100 p-3 flex items-center gap-3">
              <Check size={14} className="text-green-500" />
              <div className="flex-1">
                <p className="font-semibold text-sm text-[#2C1810]">{c.vendor}</p>
                <p className="text-[10px] text-gray-400">
                  마지막 동기화: {c.last_sync_at ? new Date(c.last_sync_at).toLocaleString('ko-KR') : '대기'}
                </p>
              </div>
              <span className={cn(
                'text-[10px] px-2 py-0.5 rounded-full',
                c.is_active ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-500'
              )}>
                {c.is_active ? '활성' : '비활성'}
              </span>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}

// ═══════════════════════════════════════════════════════
// Instagram
// ═══════════════════════════════════════════════════════

function InstagramTab() {
  const user = useAuthStore((s) => s.user)
  const [igId, setIgId] = useState('')
  const [token, setToken] = useState('')

  const connect = async () => {
    if (!user) return
    const r = await fetch('/api/v1/social/connect/instagram', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ store_id: user.id, ig_user_id: igId, access_token: token }),
    })
    if (r.ok) {
      const data = await r.json()
      toast.success(`Instagram 연결됨: @${data.username}`)
      setIgId('')
      setToken('')
    } else {
      toast.error('연결 실패 — 토큰을 확인하세요')
    }
  }

  return (
    <div className="space-y-4">
      <div className="bg-white rounded-2xl border border-gray-100 p-5">
        <h2 className="text-sm font-bold text-[#2C1810] mb-1">Instagram Business 연결</h2>
        <p className="text-xs text-gray-500 mb-3 leading-relaxed">
          Facebook 페이지 + Instagram Business 계정 + 장기 토큰이 필요합니다.{' '}
          <a href="https://developers.facebook.com/docs/instagram-api/getting-started" target="_blank" rel="noreferrer" className="text-[#D4A574] underline">
            가이드 →
          </a>
        </p>
        <input
          type="text"
          value={igId}
          onChange={(e) => setIgId(e.target.value)}
          placeholder="IG Business User ID (숫자)"
          className="w-full px-3 py-2 border border-gray-200 rounded-lg text-sm font-mono mb-2"
        />
        <input
          type="password"
          value={token}
          onChange={(e) => setToken(e.target.value)}
          placeholder="Long-lived Access Token"
          className="w-full px-3 py-2 border border-gray-200 rounded-lg text-sm font-mono mb-3"
        />
        <button
          onClick={connect}
          disabled={!igId || !token}
          className="w-full bg-gradient-to-r from-[#833AB4] to-[#FD1D1D] text-white py-2.5 rounded-lg text-sm font-semibold disabled:opacity-50 flex items-center justify-center gap-1.5"
        >
          <Instagram size={14} /> 연결하기
        </button>
      </div>
    </div>
  )
}

// ═══════════════════════════════════════════════════════
// n8n
// ═══════════════════════════════════════════════════════

function N8nTab() {
  return (
    <div className="space-y-4">
      <div className="bg-white rounded-2xl border border-gray-100 p-5">
        <h2 className="text-sm font-bold text-[#2C1810] mb-2">n8n 멀티채널 자동화</h2>
        <p className="text-xs text-gray-500 leading-relaxed mb-3">
          n8n을 셀프 호스팅하면 카페 브레인이 만든 콘텐츠를 Instagram, Threads, Facebook, X에 한 번에 게시할 수 있어요.
          OAuth는 n8n에서 한 번만 설정하면 됩니다.
        </p>
        <div className="bg-[#FAFAF8] rounded-xl p-4 text-xs text-gray-600 leading-relaxed space-y-2">
          <p><strong>1. n8n 설치</strong> — Docker 한 줄: <code className="bg-white px-1.5 py-0.5 rounded text-[10px]">docker run -p 5678:5678 n8nio/n8n</code></p>
          <p><strong>2. Webhook 노드</strong>로 시작하는 워크플로우 생성</p>
          <p><strong>3. 환경변수</strong> <code className="bg-white px-1.5 py-0.5 rounded text-[10px]">N8N_WEBHOOK_URL</code> 에 webhook URL 등록</p>
          <p><strong>4. 마케팅 페이지에서</strong> "n8n으로 분배" 버튼 활성화</p>
        </div>
        <a
          href="https://n8n.io/workflows/"
          target="_blank"
          rel="noreferrer"
          className="block mt-3 text-center text-xs text-[#D4A574] font-semibold hover:text-[#c4956a]"
        >
          공식 워크플로우 템플릿 →
        </a>
      </div>
    </div>
  )
}
