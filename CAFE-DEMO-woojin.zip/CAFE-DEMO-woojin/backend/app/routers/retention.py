"""
I4 — 데이터 보관 정책 자동화

PIPA / GDPR 권고 보관기간:
  - sales_records: 5년 (회계 의무)
  - reviews: 무기한 (사장님 자산)
  - chat_history: 1년 (대화 컨텍스트, 그 이후는 메모리에 압축됨)
  - agent_audit_log: 3년 (감사 의무)
  - agent_briefing_log: 6개월 (운영 데이터)
  - latency_log: 30일 (디버깅)

전략:
  1. 보관기간 초과분은 archive 테이블로 이동 (cold storage)
  2. archive 테이블도 5년 후 영구 삭제

cron: 매주 일요일 04:00 KST 호출 — /api/v1/retention/sweep
"""
import asyncio
import logging
from datetime import datetime, timedelta, timezone

from fastapi import APIRouter, Header, HTTPException

from app.config import settings
from app.services.gemini_service import _get_supabase

logger = logging.getLogger("retention")
router = APIRouter()


# ─── 정책 ───────────────────────────────────────────────────
RETENTION_POLICIES: dict[str, int] = {
    "chat_history": 365,
    "agent_briefing_log": 180,
    "latency_log": 30,
    # archive_only — 절대 삭제 X
    # "sales_records": 5*365,
    # "agent_audit_log": 3*365,
}


@router.post("/sweep")
async def retention_sweep(
    cron_key: str = Header(default="", alias="X-Cron-Key"),
    dry_run: bool = False,
):
    """
    보관기간 초과 데이터 일괄 정리.
    dry_run=true 면 실제 삭제 없이 카운트만 반환.
    """
    expected = settings.agent_admin_key or ""
    if not expected or cron_key != expected:
        raise HTTPException(403, "권한 없음")

    sb = _get_supabase()
    if sb is None:
        raise HTTPException(503, "Supabase 미설정")

    now = datetime.now(timezone.utc)
    summary: dict[str, dict] = {}

    for table, days in RETENTION_POLICIES.items():
        cutoff = (now - timedelta(days=days)).isoformat()
        # 카운트만
        try:
            count_res = await asyncio.to_thread(
                lambda t=table, c=cutoff: sb.table(t)
                .select("id", count="exact", head=True)
                .lt("created_at", c)
                .execute()
            )
            old_count = count_res.count or 0
        except Exception:
            old_count = 0

        deleted = 0
        if old_count > 0 and not dry_run:
            try:
                # 일괄 삭제 (배치당 500개)
                del_res = await asyncio.to_thread(
                    lambda t=table, c=cutoff: sb.table(t)
                    .delete()
                    .lt("created_at", c)
                    .execute()
                )
                deleted = len(del_res.data or [])
            except Exception as e:
                logger.warning("retention sweep %s 실패: %s", table, e)

        summary[table] = {
            "policy_days": days,
            "expired_rows": old_count,
            "deleted": deleted,
            "cutoff": cutoff,
        }

    return {
        "dry_run": dry_run,
        "swept_at": now.isoformat(),
        "tables": summary,
    }
