// 능동형 에이전트 브리핑 훅 (Issue #10 + Phase 3 게이트)
// 앱 진입 시 일일 브리핑 1회 호출 + 호출 결과를 chatStore에 합류
// 매일 1회만 호출되도록 localStorage에 last-briefing 저장
//
// Phase 3 — Gemini 비용 폭발 방지 게이트:
//  1. 클라이언트 1차 필터: KST 영업 시간(06~22) 밖이면 요청 자체 스킵
//  2. 백엔드도 미들웨어로 동일 게이트 (서버에서 한 번 더 차단)
//  3. 인증된 사용자 세션이 있어야만 호출 (user 없으면 스킵)
import { useCallback, useEffect, useRef } from 'react'
import { useAuthStore } from '@/store/authStore'
import { useChatStore } from '@/store/chatStore'
import { useProfileStore } from '@/store/profileStore'
import { supabase } from '@/lib/supabase'
import { useStoreContext } from './useStoreContext'
import { useTTS } from './useTTS'

const LAST_BRIEFING_KEY = 'cafe-brain-last-briefing'

// Phase 3: 클라이언트 측 운영 시간 (백엔드와 동일 — 06~22 KST)
const KST_OPEN_HOUR = 6
const KST_CLOSE_HOUR = 22

interface Briefing {
  briefing_id: string | null
  message: string
  trigger: string
  context_memories: Array<{ id: string; category: string; content: string }>
}

/**
 * 현재 시각이 KST 영업 시간 안인지 (사용자 브라우저 timezone 무관).
 */
function isWithinKstOperatingHours(): boolean {
  // UTC 기준 + 9시간 = KST. 브라우저가 어느 timezone이든 동일하게 계산.
  const kstNowMs = Date.now() + 9 * 3600 * 1000
  const kstHour = new Date(kstNowMs).getUTCHours()
  return kstHour >= KST_OPEN_HOUR && kstHour < KST_CLOSE_HOUR
}

export function useAgentBriefing() {
  const user = useAuthStore((s) => s.user)
  const { storeInfo, buildPromptContext } = useStoreContext()
  const activeProfile = useProfileStore((s) => s.activeProfile)
  const calledRef = useRef(false)
  // Bonus E3: autoplay 켜져 있으면 브리핑 도착 즉시 음성 재생
  const tts = useTTS()

  const fetchDailyBriefing = useCallback(async () => {
    if (!user) return
    // Phase 3: 클라이언트 1차 필터 — 영업 시간 밖이면 요청도 안 보냄
    if (!isWithinKstOperatingHours()) return

    try {
      // 인증된 호출임을 알리기 위해 Bearer 토큰 첨부
      const { data: { session } } = await supabase.auth.getSession()
      const token = session?.access_token
      if (!token) return // 토큰 없으면 게이트 통과 못 함 — 호출 X

      const res = await fetch('/api/v1/agent/briefing', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-Store-Id': user.id,
          'Authorization': `Bearer ${token}`,
        },
        body: JSON.stringify({
          store_id: user.id,
          trigger: 'daily_briefing',
          store_context: buildPromptContext(),
          active_role: activeProfile?.role ?? 'owner',  // Phase 6 #7: 권한별 메모리
        }),
      })
      // Phase 3: 게이트가 막은 경우 204 No Content — 조용히 종료
      if (res.status === 204) {
        const reason = res.headers.get('X-Agent-Skipped') ?? 'gated'
        console.info('[agent] briefing skipped:', reason)
        return
      }
      if (!res.ok) return
      const data: Briefing = await res.json()

      const chat = useChatStore.getState()
      let sessionId = chat.sessions.find((s) => s.title.includes('브리핑'))?.id
      if (!sessionId) {
        sessionId = chat.newSession()
      }

      // Phase 5/E: 참조 메모리를 메시지 footnote로 첨부 → 신뢰도·투명성 ↑
      const sourcesNote =
        data.context_memories && data.context_memories.length > 0
          ? '\n\n---\n_📚 참조한 학습 메모리: ' +
            data.context_memories
              .slice(0, 3)
              .map((m) => `${m.category} — ${m.content.slice(0, 50)}${m.content.length > 50 ? '…' : ''}`)
              .join(' / ') +
            '_'
          : ''

      // 메시지 추가 (에이전트의 능동 발화)
      chat.addMessage(sessionId, {
        role: 'assistant',
        content: data.message + sourcesNote,
      })
      chat.setActiveSession(sessionId)

      // Bonus E3: TTS autoplay — 출근길 듣기 모드
      if (tts.supported && tts.autoplay) {
        try { tts.speak(data.message) } catch { /* 조용히 */ }
      }

      // 로컬 마커: 오늘 호출 완료
      localStorage.setItem(LAST_BRIEFING_KEY, `${user.id}:${new Date().toISOString().split('T')[0]}`)
    } catch {
      // 실패해도 조용히 (사용자 주 플로우 방해 X)
    }
  }, [user, buildPromptContext, activeProfile, tts])

  useEffect(() => {
    if (calledRef.current || !user || !storeInfo) return

    // 오늘 이미 브리핑 받았으면 스킵
    const today = new Date().toISOString().split('T')[0]
    const last = localStorage.getItem(LAST_BRIEFING_KEY)
    if (last === `${user.id}:${today}`) return

    calledRef.current = true
    void fetchDailyBriefing()
  }, [user, storeInfo, fetchDailyBriefing])

  return { fetchDailyBriefing }
}
