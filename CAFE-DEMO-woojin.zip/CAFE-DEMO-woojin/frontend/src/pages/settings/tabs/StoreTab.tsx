// 설정 > 매장 정보 탭 (W1-A, Issue #15, 블로커 해제: Issue #1)
import { useState } from 'react'
import { Save, Coffee, Loader2, CheckCircle2, Lock, Clock } from 'lucide-react'
import toast from 'react-hot-toast'
import { supabase } from '@/lib/supabase'
import { useAuthStore } from '@/store/authStore'
import { useProfileStore, canAccess } from '@/store/profileStore'
import LogoUploader from '@/components/LogoUploader'

const DISTRICTS = ['주택가', '오피스', '대학가', '관광지', '복합'] as const

export default function StoreTab() {
  const { user, storeInfo, setStoreInfo } = useAuthStore()
  const activeProfile = useProfileStore((s) => s.activeProfile)
  const canEditFinancial = canAccess(activeProfile, 'financial_info')
  const [form, setForm] = useState({
    store_name: storeInfo?.store_name ?? '',
    owner_name: storeInfo?.owner_name ?? '',
    district_type: (storeInfo?.district_type ?? '주택가') as typeof DISTRICTS[number],
    menu_count: storeInfo?.menu_count ?? 10,
    employee_count: storeInfo?.employee_count ?? 2,
    avg_monthly_sales: storeInfo?.avg_monthly_sales ?? 7500000,
    monthly_fixed_cost: storeInfo?.monthly_fixed_cost ?? 3000000,
    target_labor_ratio: storeInfo?.target_labor_ratio ?? 0.25,
    // Phase 3: 영업 시간 (AI 에이전트 게이트)
    open_hour: storeInfo?.open_hour ?? 6,
    close_hour: storeInfo?.close_hour ?? 22,
  })
  const [saving, setSaving] = useState(false)

  const handleSave = async () => {
    if (!user || !storeInfo) return
    if (!form.store_name.trim() || !form.owner_name.trim()) {
      toast.error('매장명과 사장님 성함은 필수입니다')
      return
    }
    // Phase 3: 영업시간 무결성 검증
    if (form.close_hour <= form.open_hour) {
      toast.error('영업 종료 시간은 시작 시간보다 늦어야 합니다')
      return
    }

    setSaving(true)
    try {
      const { error } = await supabase
        .from('stores')
        .update(form)
        .eq('id', user.id)
      if (error) throw error

      setStoreInfo({ ...storeInfo, ...form })
      toast.success('매장 정보가 저장되었어요 ✨')
    } catch (e) {
      const msg = e instanceof Error ? e.message : '저장 실패'
      toast.error(msg)
    } finally {
      setSaving(false)
    }
  }

  return (
    <div className="space-y-6">
      {/* 로고 섹션 (Issue #15) */}
      <section className="bg-white rounded-2xl p-5 border border-gray-100 shadow-sm">
        <h3 className="font-bold text-[#2C1810] mb-4 flex items-center gap-2">
          <Coffee size={16} className="text-[#D4A574]" />
          매장 로고
        </h3>
        <LogoUploader />
        <p className="text-xs text-gray-400 mt-3">
          포스터·SNS 미리보기에 자동으로 반영됩니다
        </p>
      </section>

      {/* 기본 정보 */}
      <section className="bg-white rounded-2xl p-5 border border-gray-100 shadow-sm space-y-4">
        <h3 className="font-bold text-[#2C1810]">기본 정보</h3>

        <Field label="매장명" required>
          <input
            value={form.store_name}
            onChange={(e) => setForm({ ...form, store_name: e.target.value })}
            className="w-full px-3 py-2 rounded-xl border border-gray-200 text-sm focus:outline-none focus:ring-2 focus:ring-[#D4A574]"
          />
        </Field>

        <Field label="사장님 성함" required>
          <input
            value={form.owner_name}
            onChange={(e) => setForm({ ...form, owner_name: e.target.value })}
            className="w-full px-3 py-2 rounded-xl border border-gray-200 text-sm focus:outline-none focus:ring-2 focus:ring-[#D4A574]"
          />
        </Field>

        <Field label="상권">
          <div className="flex flex-wrap gap-2">
            {DISTRICTS.map((d) => (
              <button
                key={d}
                onClick={() => setForm({ ...form, district_type: d })}
                className={`px-3 py-1.5 rounded-full text-xs font-medium border transition-all duration-200 ${
                  form.district_type === d
                    ? 'bg-[#2C1810] text-white border-[#2C1810]'
                    : 'border-gray-200 text-gray-600 hover:border-gray-300'
                }`}
              >
                {d}
              </button>
            ))}
          </div>
        </Field>

        <div className="grid grid-cols-2 gap-3">
          <Field label="메뉴 수">
            <input
              type="number"
              value={form.menu_count}
              onChange={(e) => setForm({ ...form, menu_count: Number(e.target.value) || 0 })}
              className="w-full px-3 py-2 rounded-xl border border-gray-200 text-sm focus:outline-none focus:ring-2 focus:ring-[#D4A574]"
            />
          </Field>
          <Field label="직원 수">
            <input
              type="number"
              value={form.employee_count}
              onChange={(e) => setForm({ ...form, employee_count: Number(e.target.value) || 0 })}
              className="w-full px-3 py-2 rounded-xl border border-gray-200 text-sm focus:outline-none focus:ring-2 focus:ring-[#D4A574]"
            />
          </Field>
        </div>
      </section>

      {/* Phase 3: 영업 시간 (AI 에이전트 게이트와 연동) */}
      <section className="bg-white rounded-2xl p-5 border border-gray-100 shadow-sm space-y-4">
        <div>
          <h3 className="font-bold text-[#2C1810] flex items-center gap-2">
            <Clock size={16} className="text-[#D4A574]" />
            영업 시간
          </h3>
          <p className="text-xs text-gray-400 mt-0.5">
            AI 에이전트가 이 시간 안에서만 능동 알림·메모리 추출을 합니다 (토큰 비용 절약)
          </p>
        </div>

        <div className="grid grid-cols-2 gap-3">
          <Field label="시작 시간 (시)" hint="0–23">
            <input
              type="number"
              min={0}
              max={23}
              value={form.open_hour}
              onChange={(e) => {
                const v = Math.min(23, Math.max(0, Number(e.target.value) || 0))
                setForm({ ...form, open_hour: v })
              }}
              className="w-full px-3 py-2 rounded-xl border border-gray-200 text-sm focus:outline-none focus:ring-2 focus:ring-[#D4A574]"
            />
          </Field>
          <Field label="종료 시간 (시)" hint="1–24, 시작보다 커야 함">
            <input
              type="number"
              min={1}
              max={24}
              value={form.close_hour}
              onChange={(e) => {
                const v = Math.min(24, Math.max(1, Number(e.target.value) || 22))
                setForm({ ...form, close_hour: v })
              }}
              className="w-full px-3 py-2 rounded-xl border border-gray-200 text-sm focus:outline-none focus:ring-2 focus:ring-[#D4A574]"
            />
          </Field>
        </div>

        <div className="bg-[#FAFAF8] rounded-xl p-3 text-[11px] text-gray-500 leading-relaxed">
          <strong className="text-[#2C1810]">예시:</strong>{' '}
          {form.open_hour}시 ~ {form.close_hour}시 → 하루 {form.close_hour - form.open_hour}시간 동안 AI 능동 알림 ON.
          이 외 시간({24 - (form.close_hour - form.open_hour)}시간)에는 호출돼도 Gemini 호출 0 → 비용 절감.
        </div>
      </section>

      {/* 재무 정보 (Issue #1 BEP 게이지 블로커 해제) — 사장 전용 */}
      <section className="bg-white rounded-2xl p-5 border border-gray-100 shadow-sm space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="font-bold text-[#2C1810] flex items-center gap-2">
              재무 정보
              {!canEditFinancial && <Lock size={12} className="text-gray-400" />}
            </h3>
            <p className="text-xs text-gray-400 mt-0.5">
              {canEditFinancial
                ? 'BEP(손익분기점) 계산에 사용됩니다'
                : '사장 전용 — 편집 불가 (조회만 가능)'}
            </p>
          </div>
        </div>

        <Field label="월 평균 매출 (원)">
          <input
            type="number"
            disabled={!canEditFinancial}
            value={form.avg_monthly_sales}
            onChange={(e) => setForm({ ...form, avg_monthly_sales: Number(e.target.value) || 0 })}
            className="w-full px-3 py-2 rounded-xl border border-gray-200 text-sm focus:outline-none focus:ring-2 focus:ring-[#D4A574] disabled:bg-gray-50 disabled:text-gray-400 disabled:cursor-not-allowed"
          />
        </Field>

        <Field label="월 고정비 (임대료+인건비+관리비) (원)" hint="BEP 계산의 기준이 됩니다">
          <input
            type="number"
            disabled={!canEditFinancial}
            value={form.monthly_fixed_cost}
            onChange={(e) =>
              setForm({ ...form, monthly_fixed_cost: Number(e.target.value) || 0 })
            }
            className="w-full px-3 py-2 rounded-xl border border-gray-200 text-sm focus:outline-none focus:ring-2 focus:ring-[#D4A574] disabled:bg-gray-50 disabled:text-gray-400 disabled:cursor-not-allowed"
          />
        </Field>

        <Field label={`목표 인건비 비율 (${Math.round(form.target_labor_ratio * 100)}%)`}>
          <input
            type="range"
            min={10}
            max={50}
            step={1}
            disabled={!canEditFinancial}
            value={Math.round(form.target_labor_ratio * 100)}
            onChange={(e) =>
              setForm({ ...form, target_labor_ratio: Number(e.target.value) / 100 })
            }
            className="w-full accent-[#D4A574] disabled:opacity-50"
          />
        </Field>
      </section>

      {/* 저장 버튼 */}
      <div className="sticky bottom-4 z-10">
        <button
          onClick={handleSave}
          disabled={saving}
          className="w-full py-3 bg-gradient-to-r from-[#2C1810] to-[#D4A574] text-white rounded-xl font-semibold text-sm hover:opacity-90 transition-opacity duration-200 disabled:opacity-50 flex items-center justify-center gap-2 shadow-lg"
        >
          {saving ? (
            <>
              <Loader2 size={16} className="animate-spin" /> 저장 중...
            </>
          ) : (
            <>
              <Save size={16} /> 저장
            </>
          )}
        </button>
      </div>
    </div>
  )
}

// ─── 공용 필드 래퍼 ───
function Field({
  label,
  required,
  hint,
  children,
}: {
  label: string
  required?: boolean
  hint?: string
  children: React.ReactNode
}) {
  return (
    <div>
      <label className="block text-xs font-semibold text-gray-600 mb-1.5">
        {label}
        {required && <span className="text-red-400 ml-1">*</span>}
      </label>
      {children}
      {hint && <p className="text-xs text-gray-400 mt-1">{hint}</p>}
    </div>
  )
}

// 현재 미사용이지만 SettingsPage에서 useEffect의 완료 상태 표시용으로 export
export const SavedIndicator = CheckCircle2
