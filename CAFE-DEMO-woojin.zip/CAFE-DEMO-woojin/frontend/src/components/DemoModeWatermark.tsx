// N4 — 데모 모드 워터마크
// 데모 시드를 사용한 매장에 노출 — "이 데이터는 학습용 가짜입니다" 알림
// 실수로 운영 결정에 활용하지 않도록 시각적 경고
import { useEffect, useState } from 'react'
import { AlertCircle, X } from 'lucide-react'
import { useAuthStore } from '@/store/authStore'
import { supabase } from '@/lib/supabase'

const DISMISS_KEY = 'cafe-brain-demo-warning-dismissed'

export default function DemoModeWatermark() {
  const user = useAuthStore((s) => s.user)
  const [hasDemoData, setHasDemoData] = useState(false)
  const [dismissed, setDismissed] = useState(() => localStorage.getItem(DISMISS_KEY) === '1')

  useEffect(() => {
    if (!user || dismissed) return
    void (async () => {
      // 메모 (notes) 또는 source 컬럼에서 'OCR 자동 입력 (-)'·'데모 데이터' 마커 탐지
      const { data } = await supabase
        .from('ingredients')
        .select('id', { count: 'exact', head: true })
        .eq('store_id', user.id)
        .eq('notes', '데모 데이터')
      // 매출에도 source='manual' 기본이지만 데모 데이터 마커가 별도로 없으면 reviews.author='익명' + 정확히 20건 패턴으로 감지
      const { count: demoIngCount } = data
        ? (data as unknown as { count?: number })
        : ({ count: 0 } as { count?: number })
      // 단순화: ingredients의 notes='데모 데이터' 가 있으면 demo flag
      if ((demoIngCount ?? 0) > 0) {
        setHasDemoData(true)
      } else {
        // 차선책: ingredients의 supplier가 데모용 패턴
        const { data: ingData } = await supabase
          .from('ingredients')
          .select('supplier')
          .eq('store_id', user.id)
          .like('supplier', '%(데모)%')
          .limit(1)
        setHasDemoData(!!ingData && ingData.length > 0)
      }
    })()
  }, [user, dismissed])

  if (!hasDemoData || dismissed) return null

  return (
    <>
      {/* 화면 전체 회색 띠 — 인쇄 시에도 보임 */}
      <div className="fixed top-0 left-0 right-0 z-[60] bg-amber-100 border-b-2 border-amber-300 py-1.5 px-3 flex items-center gap-2">
        <AlertCircle size={13} className="text-amber-700 shrink-0" />
        <p className="text-xs font-semibold text-amber-900 flex-1">
          🧪 <strong>체험 모드</strong> — 이 매장은 데모 데이터로 채워져 있습니다.
          실제 운영 결정에 사용하지 마세요.
        </p>
        <button
          onClick={() => {
            localStorage.setItem(DISMISS_KEY, '1')
            setDismissed(true)
          }}
          className="p-1 text-amber-700 hover:text-amber-900"
          aria-label="닫기"
        >
          <X size={12} />
        </button>
      </div>
      {/* 페이지 상단 패딩 보정 */}
      <div className="h-7" />
    </>
  )
}
