// Bonus E6 — 오프라인 인디케이터
// navigator.onLine 모니터링. 오프라인 진입 시 상단 토스트 띄움.
// "캐시된 마지막 데이터를 보여드리고 있어요" 안내.
import { useEffect, useState } from 'react'
import { WifiOff } from 'lucide-react'
import { useOnlineStatus } from '@/hooks/usePWA'

export default function OfflineIndicator() {
  const online = useOnlineStatus()
  const [visible, setVisible] = useState(false)
  const [everOffline, setEverOffline] = useState(false)

  useEffect(() => {
    if (!online) {
      setVisible(true)
      setEverOffline(true)
      return
    }
    if (everOffline) {
      // 다시 온라인 됐을 때 잠깐 "다시 연결됨" 보여주고 숨기기
      const t = setTimeout(() => setVisible(false), 2000)
      return () => clearTimeout(t)
    }
  }, [online, everOffline])

  if (!visible) return null

  return (
    <div
      className={`fixed top-2 left-1/2 -translate-x-1/2 z-50 max-w-md w-[calc(100%-1rem)] rounded-xl shadow-lg px-4 py-2 text-xs font-semibold flex items-center gap-2 transition-all duration-300 ${
        online
          ? 'bg-green-50 border border-green-200 text-green-800'
          : 'bg-amber-50 border border-amber-200 text-amber-900'
      }`}
    >
      <WifiOff size={13} className={online ? 'text-green-600' : 'text-amber-600'} />
      {online ? (
        <span>다시 연결되었어요 ✓</span>
      ) : (
        <span>오프라인 모드 — 마지막으로 본 데이터를 보여드려요</span>
      )}
    </div>
  )
}
