// I8 — 모바일 풀-투-리프레시 훅
// 화면 상단에서 아래로 드래그 → 80px 넘으면 onRefresh 호출
// 데스크톱에선 작동 X (touchstart 없음)
import { useEffect, useRef, useState } from 'react'

interface Options {
  onRefresh: () => Promise<void> | void
  threshold?: number  // 기본 80px
  disabled?: boolean
}

export function usePullToRefresh({ onRefresh, threshold = 80, disabled = false }: Options) {
  const [pullDistance, setPullDistance] = useState(0)
  const [refreshing, setRefreshing] = useState(false)
  const startY = useRef<number | null>(null)
  const scrollableRef = useRef<HTMLElement | null>(null)

  useEffect(() => {
    if (disabled) return
    const target = scrollableRef.current ?? document.scrollingElement ?? document.body

    const onTouchStart = (e: TouchEvent) => {
      if (refreshing) return
      // 스크롤이 맨 위일 때만 시작
      const scrollTop = (target as HTMLElement).scrollTop
      if (scrollTop > 0) {
        startY.current = null
        return
      }
      startY.current = e.touches[0].clientY
    }

    const onTouchMove = (e: TouchEvent) => {
      if (startY.current === null || refreshing) return
      const delta = e.touches[0].clientY - startY.current
      if (delta > 0) {
        // 저항감 부여 (sqrt curve)
        const resisted = Math.min(threshold * 1.5, Math.sqrt(delta) * 8)
        setPullDistance(resisted)
        if (delta > 10) e.preventDefault()
      }
    }

    const onTouchEnd = async () => {
      if (startY.current === null) return
      startY.current = null
      if (pullDistance >= threshold && !refreshing) {
        setRefreshing(true)
        try {
          await onRefresh()
        } finally {
          setRefreshing(false)
        }
      }
      setPullDistance(0)
    }

    document.addEventListener('touchstart', onTouchStart, { passive: true })
    document.addEventListener('touchmove', onTouchMove, { passive: false })
    document.addEventListener('touchend', onTouchEnd)

    return () => {
      document.removeEventListener('touchstart', onTouchStart)
      document.removeEventListener('touchmove', onTouchMove)
      document.removeEventListener('touchend', onTouchEnd)
    }
  }, [onRefresh, threshold, disabled, pullDistance, refreshing])

  return {
    pullDistance,
    refreshing,
    bindScrollable: (el: HTMLElement | null) => {
      scrollableRef.current = el
    },
  }
}
