"""
스마트 스케줄링 라우터
- POST /api/schedule/validate: 주간 스케줄 노무 규정 검증
- POST /api/schedule/generate: AI 스케줄 자동 생성 (매출 패턴 + 직원 가용성 기반)
"""
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from typing import List
from app.services.gemini_service import generate_insight, generate_with_review
from app.services.feature_flags import is_enabled as flag_enabled

router = APIRouter()

# ─── 스키마 ───

class ShiftInput(BaseModel):
    """시프트 입력 스키마"""
    employee_id: str
    day_index: int        # 0=월 ~ 6=일
    start_hour: float
    end_hour: float


class EmployeeInput(BaseModel):
    """직원 정보 스키마"""
    id: str
    name: str
    hourly_rate: float
    max_weekly_hours: float
    unavailable_days: List[int]


class ValidateRequest(BaseModel):
    """스케줄 검증 요청 스키마"""
    employees: List[EmployeeInput]
    shifts: List[ShiftInput]
    estimated_revenue: float      # 해당 주 예상 매출
    labor_cost_cap_ratio: float   # 인건비 상한 비율 (기본 0.25)


class LaborWarning(BaseModel):
    """노무 규정 위반 경고"""
    employee_id: str
    day_index: int
    warning_type: str
    message: str


class ValidateResponse(BaseModel):
    """스케줄 검증 응답"""
    total_labor_cost: float
    juhusu_by_employee: dict     # {employee_id: amount}
    labor_cost_cap: float
    is_over_cap: bool
    warnings: List[LaborWarning]
    break_adjustments: dict      # {employee_id+day: break_minutes}


# ─── 유틸 ───

def calc_break_minutes(work_hours: float) -> int:
    """
    노동법 기준 휴게시간 계산
    - 4시간 이상: 30분
    - 8시간 이상: 60분
    """
    if work_hours >= 8:
        return 60
    elif work_hours >= 4:
        return 30
    return 0


def calc_juhusu(weekly_hours: float, daily_avg_hours: float, hourly_rate: float) -> float:
    """
    주휴수당 계산 (주 15시간 이상 근무 시)
    주휴수당 = 1일 평균근무시간 × 시급
    """
    if weekly_hours >= 15:
        return daily_avg_hours * hourly_rate
    return 0.0


# ─── 엔드포인트 ───

@router.post("/validate", response_model=ValidateResponse)
async def validate_schedule(req: ValidateRequest):
    """
    주간 스케줄 노무 규정 검증
    - 주 15시간 이상 → 주휴수당 계산
    - 4시간 근무 이상 → 30분 휴게 삽입
    - 인건비 총액 상한 체크
    """
    warnings: List[LaborWarning] = []
    juhusu_map: dict = {}
    break_map: dict = {}

    # 직원 맵
    emp_map = {e.id: e for e in req.employees}

    # 직원별 주간 집계
    emp_weekly: dict = {e.id: {'total_hours': 0.0, 'total_days': 0, 'shifts': []} for e in req.employees}

    total_labor_cost = 0.0

    for shift in req.shifts:
        emp = emp_map.get(shift.employee_id)
        if not emp:
            continue

        work_hours = shift.end_hour - shift.start_hour
        break_min = calc_break_minutes(work_hours)
        net_hours = work_hours - break_min / 60

        key = f"{shift.employee_id}-{shift.day_index}"
        break_map[key] = break_min

        # 불가 요일 위반 체크 (day_index는 0=월이므로 +1 후 %7)
        weekday = (shift.day_index + 1) % 7  # 월요일=1 → 일요일=0
        if weekday in emp.unavailable_days:
            warnings.append(LaborWarning(
                employee_id=shift.employee_id,
                day_index=shift.day_index,
                warning_type="unavailable_day",
                message=f"{emp.name}의 불가 요일에 배정되었습니다."
            ))

        emp_weekly[shift.employee_id]['total_hours'] += net_hours
        emp_weekly[shift.employee_id]['total_days'] += 1
        total_labor_cost += net_hours * emp.hourly_rate

    # 주휴수당 + 주 최대시간 초과 체크
    for emp_id, data in emp_weekly.items():
        emp = emp_map.get(emp_id)
        if not emp:
            continue

        weekly_h = data['total_hours']
        days = data['total_days']
        daily_avg = weekly_h / days if days > 0 else 0

        juhusu = calc_juhusu(weekly_h, daily_avg, emp.hourly_rate)
        juhusu_map[emp_id] = round(juhusu)
        total_labor_cost += juhusu

        if weekly_h > emp.max_weekly_hours:
            warnings.append(LaborWarning(
                employee_id=emp_id,
                day_index=-1,
                warning_type="over_max_hours",
                message=f"{emp.name}: 주 {weekly_h:.1f}시간 (최대 {emp.max_weekly_hours}시간 초과)"
            ))

    # 인건비 상한 체크
    labor_cost_cap = req.estimated_revenue * req.labor_cost_cap_ratio
    is_over_cap = total_labor_cost > labor_cost_cap

    if is_over_cap:
        warnings.append(LaborWarning(
            employee_id="all",
            day_index=-1,
            warning_type="over_labor_cap",
            message=f"총 인건비({total_labor_cost:,.0f}원)가 상한({labor_cost_cap:,.0f}원, 매출의 {req.labor_cost_cap_ratio*100:.0f}%)을 초과합니다."
        ))

    return ValidateResponse(
        total_labor_cost=round(total_labor_cost),
        juhusu_by_employee=juhusu_map,
        labor_cost_cap=round(labor_cost_cap),
        is_over_cap=is_over_cap,
        warnings=warnings,
        break_adjustments=break_map,
    )


# ─── AI 스케줄 자동 생성 ───

class SalesByHour(BaseModel):
    hour: int
    avg_revenue: float


class GenerateRequest(BaseModel):
    """AI 스케줄 자동 생성 요청"""
    employees: List[EmployeeInput]
    weekly_open_hours: dict      # {"open": 8, "close": 21} (영업시간)
    sales_by_day: dict           # {0: 500000, ..., 6: 200000} (요일별 평균 매출)
    sales_by_hour: List[SalesByHour]  # 시간대별 평균 매출
    target_labor_ratio: float    # 인건비 목표 비율 (기본 0.25)
    estimated_weekly_revenue: float
    store_name: str = ""


class GeneratedShift(BaseModel):
    employee_id: str
    employee_name: str
    day_index: int
    start_hour: int
    end_hour: int
    note: str = ""


class GenerateResponse(BaseModel):
    """AI 스케줄 생성 응답"""
    shifts: List[GeneratedShift]
    reasoning: str
    estimated_labor_cost: float
    labor_ratio: float


@router.post("/generate", response_model=GenerateResponse)
async def generate_schedule(req: GenerateRequest):
    """
    매출 패턴과 직원 가용성을 기반으로 최적 주간 스케줄 초안 생성
    노동법(주휴수당, 휴게시간, 최대 주 52시간) 자동 준수
    """
    DAY_NAMES = ['월', '화', '수', '목', '금', '토', '일']

    # 직원 정보 요약
    emp_summary = "\n".join([
        f"- {e.name} (시급 {e.hourly_rate:,.0f}원, 주최대 {e.max_weekly_hours}시간, 불가요일: {[DAY_NAMES[d] for d in e.unavailable_days] or '없음'})"
        for e in req.employees
    ])

    # 요일별 매출 요약
    day_summary = ", ".join([
        f"{DAY_NAMES[int(d)]}요일 {v:,.0f}원" for d, v in req.sales_by_day.items()
    ])

    # 피크타임 추출 (상위 3개 시간대)
    peak_hours = sorted(req.sales_by_hour, key=lambda x: x.avg_revenue, reverse=True)[:3]
    peak_summary = ", ".join([f"{h.hour}시~{h.hour+1}시" for h in peak_hours])

    open_h = req.weekly_open_hours.get("open", 8)
    close_h = req.weekly_open_hours.get("close", 21)
    labor_budget = req.estimated_weekly_revenue * req.target_labor_ratio

    prompt = f"""
당신은 카페 운영 전문가입니다. 아래 정보를 바탕으로 최적의 주간 근무 스케줄을 만들어주세요.

[매장 정보]
- 매장명: {req.store_name or '카페'}
- 영업시간: {open_h}시 ~ {close_h}시
- 주간 예상 매출: {req.estimated_weekly_revenue:,.0f}원
- 인건비 목표: 매출의 {req.target_labor_ratio*100:.0f}% 이하 (= {labor_budget:,.0f}원)

[직원 목록]
{emp_summary}

[매출 패턴]
- 요일별 평균 매출: {day_summary}
- 피크타임(상위 3): {peak_summary}

[요청사항]
1. 매출이 높은 시간대와 요일에 인원을 집중 배치
2. 노동법 준수: 4시간 이상 근무 시 30분 휴게, 8시간 이상 시 60분 휴게
3. 주 15시간 이상 직원은 주휴수당 발생 (예산에 포함해서 계산)
4. 각 직원의 불가 요일 반드시 제외
5. 총 인건비가 목표 예산을 초과하지 않도록 조정

아래 JSON 형식으로만 답하세요 (마크다운 코드블록 없이):
{{
  "shifts": [
    {{"employee_id": "직원ID", "employee_name": "직원명", "day_index": 0, "start_hour": 9, "end_hour": 17, "note": "피크타임 집중"}},
    ...
  ],
  "reasoning": "스케줄 배치 근거 2~3줄",
  "estimated_labor_cost": 1200000,
  "labor_ratio": 0.24
}}

day_index는 0=월요일 ~ 6=일요일입니다.
직원 ID 목록: {[e.id for e in req.employees]}
""".strip()

    try:
        import json
        raw = await generate_insight(prompt)
        # 워터마크 제거
        raw = raw.replace("\n\nⓘ AI가 생성한 콘텐츠입니다.", "").strip()
        # 코드블록 제거
        if '```' in raw:
            raw = raw.split('```')[1]
            if raw.startswith('json'):
                raw = raw[4:]
        data = json.loads(raw.strip())

        return GenerateResponse(
            shifts=[GeneratedShift(**s) for s in data.get("shifts", [])],
            reasoning=data.get("reasoning", ""),
            estimated_labor_cost=data.get("estimated_labor_cost", 0),
            labor_ratio=data.get("labor_ratio", 0),
        )
    except json.JSONDecodeError as e:
        raise HTTPException(status_code=503, detail=f"AI 스케줄 생성 파싱 실패: {str(e)}")
    except RuntimeError as e:
        raise HTTPException(status_code=503, detail=str(e))


# ─── Phase 2: 스케줄 AI 인사이트 (텍스트 조언) ───

from typing import Optional
from app.services.gemini_service import build_cache_key


class ScheduleInsightRequest(BaseModel):
    """주간 스케줄 + 인건비 상황 → AI 경영 조언 요청"""
    store_context: str            # 매장 기본 정보 (useStoreContext 주입)
    week_summary: str             # 주간 시프트·직원 시간 요약 텍스트
    estimated_revenue: float      # 해당 주 예상 매출
    total_labor_cost: float       # 총 인건비 (검증 결과 활용)
    labor_cost_ratio: float       # 인건비/매출 비율 (0~1)
    over_cap: bool                # 인건비 상한 초과 여부
    warnings_summary: Optional[str] = None  # 노무 경고 요약 (예: "직원2 주 60h 초과")
    peak_hours: Optional[str] = None        # 매출 피크 시간대 (예: "13시,14시")


class ScheduleInsightResponse(BaseModel):
    """스케줄 AI 인사이트 응답"""
    insight: str


@router.post("/ai-insight", response_model=ScheduleInsightResponse)
async def get_schedule_insight(req: ScheduleInsightRequest):
    """
    주간 스케줄·인건비 상황을 바탕으로 Gemini 경영 조언 생성.
    - 24시간 캐싱 (동일 매장·주간·인건비 조합 재사용)
    - PII 필터·Rate Limit 미들웨어 자동 적용
    """
    over_cap_text = "⚠️ 인건비 상한을 초과한 상태입니다." if req.over_cap else "인건비는 상한 이내입니다."
    warnings_text = req.warnings_summary or "노무 경고 없음"
    peak_text = req.peak_hours or "매출 피크 정보 미제공"

    prompt = f"""
당신은 10년 경력의 카페 경영 컨설턴트입니다.
아래 매장의 한 주 스케줄 상황을 분석하여, 사장님께 실질적인 인력 운영 조언 4~5줄을 한국어로 작성해주세요.

{req.store_context}

[주간 스케줄 요약]
{req.week_summary}

[비용 분석]
- 예상 주간 매출: {req.estimated_revenue:,.0f}원
- 총 인건비: {req.total_labor_cost:,.0f}원
- 인건비 비율: {req.labor_cost_ratio*100:.1f}%
- {over_cap_text}

[노무 경고]
{warnings_text}

[매출 패턴 힌트]
{peak_text}

조언 작성 가이드:
- 피크 시간대 인력 보강 / 한가한 시간대 축소
- 주휴수당 부담 줄이는 시프트 분배 (15시간 기준 신중히)
- 특정 직원의 과중 근무 분산 제안
- 인건비 비율이 25%를 넘는다면 메뉴·가격 측면 보완 제안
- 노무 경고가 있다면 그 항목을 가장 먼저 다루기

형식: 불릿(•) 없이 자연스러운 문장 4~5개. 반복 표현 금지.
""".strip()

    cache_key = build_cache_key(
        store_id=req.store_context[:100],
        template="schedule_insight",
        params={
            "week": req.week_summary[:300],
            "revenue": int(req.estimated_revenue),
            "labor": int(req.total_labor_cost),
            "ratio": round(req.labor_cost_ratio, 3),
            "over_cap": req.over_cap,
            "warnings": (req.warnings_summary or "")[:200],
        },
    )

    try:
        # M4 — schedule 인사이트는 인건비·근로기준법 정확성 중요
        if await flag_enabled("agent_self_correction"):
            text, _meta = await generate_with_review(
                prompt,
                question_for_review=f"스케줄 분석: 매출 {req.estimated_revenue:,}원, 인건비 {req.total_labor_cost:,}원",
            )
            return ScheduleInsightResponse(insight=text)
        insight = await generate_insight(prompt, cache_key=cache_key)
        return ScheduleInsightResponse(insight=insight)
    except RuntimeError as e:
        raise HTTPException(status_code=503, detail=str(e))
