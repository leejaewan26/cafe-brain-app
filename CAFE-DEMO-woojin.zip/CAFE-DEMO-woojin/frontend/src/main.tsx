import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import './index.css'
import App from './App.tsx'
import { initThemeOnBoot } from '@/hooks/useTheme'
import { registerServiceWorker } from '@/hooks/usePWA'
import { initSentry, SentryErrorBoundary } from '@/lib/sentry'
// H6: i18n 부팅 (ko/en)
import '@/lib/i18n'

// 앱 부팅 직후 테마 적용 (FOUC 방지: React 렌더링 전에 <html> 클래스 설정)
initThemeOnBoot()

// Launch A5: Sentry — DSN 있을 때만 활성, 프라이버시 마스킹 후 전송
initSentry()

// Bonus E5+E6: SW 등록 (오프라인 모드 + Push 수신용)
// 비동기 — 마운트는 기다리지 않음
void registerServiceWorker()

// React 앱 마운트 진입점
createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <SentryErrorBoundary
      fallback={({ error }) => (
        <div className="min-h-screen flex items-center justify-center bg-[#FAFAF8] p-6">
          <div className="max-w-sm bg-white rounded-2xl shadow-lg border border-gray-100 p-6 text-center">
            <p className="text-3xl mb-2">☕️</p>
            <p className="font-bold text-[#2C1810] mb-1">예상치 못한 오류가 발생했어요</p>
            <p className="text-xs text-gray-500 leading-relaxed mb-4">
              잠시 뒤 다시 시도해주세요. 문제가 계속되면 운영팀에 알려주세요.
            </p>
            <button
              onClick={() => window.location.reload()}
              className="w-full bg-[#2C1810] text-white text-sm font-semibold py-2 rounded-lg hover:bg-[#3A2519] transition-colors"
            >
              새로고침
            </button>
            {import.meta.env.DEV && (
              <pre className="text-[10px] text-left text-red-500 mt-3 overflow-auto max-h-40">
                {String(error)}
              </pre>
            )}
          </div>
        </div>
      )}
    >
      <App />
    </SentryErrorBoundary>
  </StrictMode>,
)
