// 설정 > 화면 설정 탭 (Issue #16 다크모드)
import { Sun, Moon, Monitor } from 'lucide-react'
import { useSettingsStore, type ThemeMode } from '@/store/settingsStore'

const THEME_OPTIONS: { id: ThemeMode; label: string; desc: string; icon: React.ElementType }[] = [
  { id: 'light', label: '라이트', desc: '밝고 선명한 기본 테마', icon: Sun },
  { id: 'dark', label: '다크', desc: '눈 피로 적은 어두운 테마', icon: Moon },
  { id: 'system', label: '시스템', desc: 'OS 설정을 자동으로 따라감', icon: Monitor },
]

export default function ThemeTab() {
  const { theme, setTheme } = useSettingsStore()

  return (
    <div className="space-y-6">
      <section className="bg-white rounded-2xl p-5 border border-gray-100 shadow-sm">
        <h3 className="font-bold text-[#2C1810] mb-1">테마</h3>
        <p className="text-xs text-gray-400 mb-4">
          야간 운영 시 다크모드로 눈의 피로를 줄일 수 있습니다
        </p>

        <div
          className="grid grid-cols-3 gap-3"
          role="radiogroup"
          aria-label="테마 선택"
        >
          {THEME_OPTIONS.map(({ id, label, desc, icon: Icon }) => {
            const active = theme === id
            return (
              <button
                key={id}
                onClick={() => setTheme(id)}
                role="radio"
                aria-checked={active}
                aria-label={`${label} 테마 — ${desc}${active ? ' (선택됨)' : ''}`}
                className={`flex flex-col items-center gap-2 p-4 rounded-xl border-2 transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-[#D4A574] ${
                  active
                    ? 'border-[#D4A574] bg-[#D4A574]/5 shadow-sm'
                    : 'border-gray-100 hover:border-gray-200'
                }`}
              >
                <div
                  className={`w-10 h-10 rounded-xl flex items-center justify-center ${
                    id === 'dark'
                      ? 'bg-gray-800 text-white'
                      : id === 'light'
                        ? 'bg-[#FAFAF8] text-[#D4A574] ring-1 ring-gray-200'
                        : 'bg-gradient-to-br from-[#FAFAF8] to-gray-800 text-[#D4A574]'
                  }`}
                >
                  <Icon size={18} aria-hidden="true" />
                </div>
                <div className="text-center">
                  <p className={`text-sm font-semibold ${active ? 'text-[#2C1810]' : 'text-gray-700'}`}>
                    {label}
                    {active && <span className="ml-1 text-[#D4A574]" aria-hidden="true">✓</span>}
                  </p>
                  <p className="text-[10px] text-gray-400 mt-0.5 leading-tight">{desc}</p>
                </div>
              </button>
            )
          })}
        </div>
      </section>
    </div>
  )
}
