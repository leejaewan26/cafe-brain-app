// 에러 바운더리 — 페이지 크래시를 앱 전체로 전파하지 않음
import { Component, type ReactNode, type ErrorInfo } from 'react'
import { RefreshCw, AlertTriangle } from 'lucide-react'

interface Props {
  children: ReactNode
  fallback?: ReactNode
}

interface State {
  hasError: boolean
  error: Error | null
}

export class ErrorBoundary extends Component<Props, State> {
  constructor(props: Props) {
    super(props)
    this.state = { hasError: false, error: null }
  }

  static getDerivedStateFromError(error: Error): State {
    return { hasError: true, error }
  }

  componentDidCatch(error: Error, info: ErrorInfo) {
    // 프로덕션에서는 Sentry 등으로 대체
    console.error('[ErrorBoundary]', error, info.componentStack)
  }

  render() {
    if (this.state.hasError) {
      if (this.props.fallback) return this.props.fallback

      return (
        <div className="min-h-[60vh] flex items-center justify-center px-4">
          <div className="text-center max-w-sm">
            <div className="w-16 h-16 rounded-2xl bg-red-50 flex items-center justify-center mx-auto mb-4">
              <AlertTriangle className="w-8 h-8 text-red-400" />
            </div>
            <h2 className="text-lg font-bold text-[#2C1810] mb-2">
              이 페이지에서 오류가 발생했습니다
            </h2>
            <p className="text-sm text-gray-500 mb-1">
              {this.state.error?.message ?? '알 수 없는 오류'}
            </p>
            <p className="text-xs text-gray-400 mb-6">
              다른 기능은 정상 작동합니다.
            </p>
            <button
              onClick={() => this.setState({ hasError: false, error: null })}
              className="flex items-center gap-2 mx-auto px-5 py-2.5 rounded-xl bg-[#2C1810] text-white text-sm font-semibold hover:bg-[#3d2418] transition-colors duration-200"
            >
              <RefreshCw size={14} />
              다시 시도
            </button>
          </div>
        </div>
      )
    }

    return this.props.children
  }
}
