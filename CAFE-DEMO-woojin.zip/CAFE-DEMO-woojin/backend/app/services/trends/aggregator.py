"""
7개 데이터 소스의 raw 결과 → Gemini가 종합 전략 보고서로 생성.

출력 형식: 마크다운 보고서 (사장님이 바로 읽을 수 있는 형태)
캐시: 매장 + 오늘 날짜 (24h)
"""
import json
from datetime import date
from typing import Any

from app.services.gemini_service import generate_insight, build_cache_key


def _format_naver_dl(payload: dict | None, max_lines: int = 10) -> str:
    if not payload:
        return "(Naver DataLab 미수집 — NAVER_CLIENT_ID/SECRET 환경변수 누락)"
    momentum = payload.get("momentum") or []
    if not momentum:
        return "(추출된 모멘텀 없음)"
    lines = [
        f"  - {m['keyword']}: 최근 7일 평균 {m['current_avg']} (vs 이전 7일 {m['prev_avg']}, "
        f"변화 {m['change_pct']:+.1f}%, {m['trend']})"
        for m in momentum[:max_lines]
    ]
    return "\n".join(lines)


def _format_naver_news(items: list | None, n: int = 8) -> str:
    if not items:
        return "(Naver 뉴스 미수집 — Naver 키 누락)"
    return "\n".join(
        f"  - [{i+1}] {it['title']} — {it.get('description','')[:80]}"
        for i, it in enumerate(items[:n])
    )


def _format_google_trends(data: dict | None) -> str:
    if not data:
        return "(Google Trends 미수집 — pytrends 실패 또는 미설치)"
    comp = data.get("comparison") or []
    if not comp:
        return "(비교 데이터 없음)"
    lines = []
    for c in comp:
        lines.append(
            f"  - {c['keyword']}: 글로벌 {c['global_score']} | 한국 {c['korea_score']} "
            f"| 갭 {c['gap']:+.1f} → {c['label']}"
        )
    return "\n".join(lines)


def _format_youtube(items: list | None, n: int = 5) -> str:
    if not items:
        return "(YouTube 미수집 — YOUTUBE_API_KEY 누락)"
    return "\n".join(
        f"  - {it['title']} ({it['channel']}, 조회 {it['view_count']:,})"
        for it in items[:n]
    )


def _format_newsapi(items: list | None, n: int = 5) -> str:
    if not items:
        return "(NewsAPI 미수집 — NEWSAPI_KEY 누락)"
    return "\n".join(
        f"  - [{it.get('source','')}] {it['title']}"
        for it in items[:n]
    )


def _format_google_news(items: list | None, n: int = 5) -> str:
    if not items:
        return "(Google News 미수집)"
    return "\n".join(
        f"  - [{it.get('source','')}] {it['title']}"
        for it in items[:n]
    )


def _format_grounding(data: dict | None) -> str:
    if not data:
        return "(Gemini Grounding 미수집)"
    text = (data.get("text") or "")[:1200]
    sources = data.get("sources") or []
    src_lines = "\n".join(f"    · {s.get('title','')} ({s.get('uri','')[:60]})" for s in sources[:5])
    return f"{text}\n  [출처]\n{src_lines}" if src_lines else text


def build_report_prompt(raw: dict[str, Any], store_context: dict) -> str:
    """7개 raw 데이터 → Gemini 프롬프트."""
    store_name = store_context.get("store_name", "내 카페")
    district = store_context.get("district_type", "복합")
    ambiance = ", ".join(store_context.get("ambiance_keywords") or []) or "감성"
    top_menus = ", ".join(store_context.get("top_menus") or []) or "아메리카노, 라떼"
    active = raw.get("active_sources") or []

    return f"""
당신은 한국 카페·외식업 시장 전문 애널리스트입니다.
아래 7개 데이터 소스 raw 결과를 종합 분석하여, '{store_name}' 사장님께 드릴
**전략 분석 보고서**를 마크다운으로 작성해주세요.

────────────────────────────────────────
[매장 컨텍스트]
- 매장명: {store_name}
- 상권: {district}
- 분위기: {ambiance}
- 주력 메뉴: {top_menus}

[활성 데이터 소스] {len(active)}/7
{', '.join(active) if active else '(없음 — 모든 외부 키 누락)'}

────────────────────────────────────────
[① Naver DataLab — 한국 검색량 모멘텀 (최근 7일 vs 이전 7일)]
{_format_naver_dl(raw.get('naver_datalab'))}

[② Naver 뉴스 — 한국 매체 최신 헤드라인]
{_format_naver_news(raw.get('naver_news'))}

[③ Google Trends — 한국 vs 글로벌 비교]
{_format_google_trends(raw.get('google_trends'))}

[④ YouTube — 카페·디저트 인기 영상 (최근 14일, 조회순)]
{_format_youtube(raw.get('youtube'))}

[⑤ NewsAPI — 글로벌 영문 뉴스 (최근 7일)]
{_format_newsapi(raw.get('newsapi'))}

[⑥ Google News RSS — 한국어 뉴스 추가]
{_format_google_news(raw.get('google_news'))}

[⑦ Gemini Search Grounding — 실시간 웹 종합]
{_format_grounding(raw.get('gemini_grounding'))}

────────────────────────────────────────
[보고서 작성 지시]
다음 7개 섹션을 순서대로 작성하세요. 각 섹션 헤더는 ## 사용.

## 1. 이번 주 핵심 요약
3~5문장. 가장 임팩트 있는 트렌드 1~3개를 짚고 우리 매장에 시사하는 바.

## 2. 한국 급상승 키워드 Top 5
표 형식 (| 키워드 | 변화율 | 출처 | ).
변화율은 Naver DataLab 모멘텀 우선, 보강 정보는 Naver 뉴스·Google News에서.

## 3. 해외 → 한국 선점 기회
Google Trends comparison에서 label="선점기회"인 항목 + Gemini Grounding에서 발견한 해외 트렌드.
각 항목별로 "왜 기회인가" 1-2문장 + "내 매장에서 시도하면" 구체적 제안.

## 4. 미디어 동향 Top 3
Naver 뉴스·Google News·NewsAPI 종합. 우리 업계에 의미 있는 헤드라인.

## 5. YouTube 화제 영상 Top 3
조회수 순 + 우리 매장 콘텐츠 전략 시사점.

## 6. 우리 매장 액션 5가지
구체적·실행 가능한 항목. 각 항목은 1) 무엇을, 2) 언제까지, 3) 왜 이 시점에.
매장 컨텍스트(상권 {district}, 분위기 {ambiance}, 메뉴 {top_menus})와 직접 연결.

## 7. 리스크 / 카운터 트렌드
끝물·하락 카테고리 + 우리 매장이 피해야 할 패턴 + 차별화 포인트.

────────────────────────────────────────
[규칙]
- 한국어. 마크다운만 출력 (코드블록 X).
- 모든 주장에 데이터 소스 표시 (예: "(Naver DataLab)").
- 일반론 금지. 매장 컨텍스트와 데이터에 기반한 구체적 분석.
- 길이: 1500~2500자. 너무 짧으면 안 됨.
- 마지막 줄: '_ⓘ AI가 7개 데이터 소스를 종합 분석한 결과입니다. 의사결정은 사장님 판단이 우선입니다._'
""".strip()


async def synthesize_strategic_report(
    raw: dict[str, Any],
    store_context: dict,
) -> str:
    """
    7개 raw 결과 + 매장 컨텍스트 → Gemini 전략 보고서.
    24시간 캐싱 (매장 + 날짜).
    """
    prompt = build_report_prompt(raw, store_context)

    cache_key = build_cache_key(
        store_id=store_context.get("store_id", "unknown"),
        template="trend_strategic_report",
        params={
            "date": date.today().isoformat(),
            "active": "|".join(sorted(raw.get("active_sources", []))),
            "ctx_hash": str(hash(json.dumps(store_context, sort_keys=True, ensure_ascii=False)))[:12],
        },
    )

    return await generate_insight(prompt, cache_key=cache_key)
