"""
Google News RSS 파싱 — 키 불필요.

URL 패턴: https://news.google.com/rss/search?q=<query>&hl=ko-KR&gl=KR&ceid=KR:ko

한국어/영어 둘 다 가능 — hl 변경.
무료 무제한 (단, Google이 rate limit 걸 수 있음).
"""
import asyncio
from datetime import datetime
from typing import Optional

import httpx


async def fetch_google_news(
    query: str,
    max_items: int = 15,
    lang: str = "ko",
    country: str = "KR",
) -> Optional[list[dict]]:
    """
    Google News RSS 검색.

    Args:
        query: 검색어
        max_items: 결과 개수
        lang: 'ko' | 'en' (인터페이스 언어)
        country: 'KR' | 'US' | ...

    Returns:
        [{"title", "link", "pub_date", "source"}] 또는 None
    """
    if not query:
        return None

    url = (
        f"https://news.google.com/rss/search"
        f"?q={query}&hl={lang}-{country}&gl={country}&ceid={country}:{lang}"
    )

    try:
        async with httpx.AsyncClient(timeout=15, follow_redirects=True) as client:
            r = await client.get(url, headers={"User-Agent": "CafeBrain/1.0"})
            r.raise_for_status()
            xml_text = r.text
    except Exception:
        return None

    def _parse():
        try:
            import feedparser
            feed = feedparser.parse(xml_text)
            items = []
            for entry in feed.entries[:max_items]:
                source = ""
                # entry.source 가 dict 이거나 str 일 수 있음
                src = getattr(entry, "source", None)
                if src:
                    source = src.get("title", "") if isinstance(src, dict) else str(src)
                items.append({
                    "title": entry.get("title", ""),
                    "link": entry.get("link", ""),
                    "pub_date": entry.get("published", ""),
                    "source": source or "Google News",
                })
            return items
        except Exception:
            return []

    return await asyncio.to_thread(_parse)
