// 데이터 내보내기 드롭다운 메뉴 (Day 4-1)
// CSV·Excel·PDF 3종 통합 UI — 매출·BEP·주문 등 어느 페이지에도 삽입 가능
import { useState, useRef, useEffect } from 'react'
import { Download, FileSpreadsheet, FileText, Printer, ChevronDown, Loader2 } from 'lucide-react'
import toast from 'react-hot-toast'
import {
  downloadCsv,
  downloadExcel,
  printReport,
  todayFilenameStamp,
} from '@/lib/dataExport'
import { cn } from '@/lib/utils'
import { track } from '@/lib/analytics'

interface ExportMenuProps {
  /** 내보낼 데이터 (dict 배열). 비어있으면 버튼 비활성화 */
  rows: Record<string, unknown>[]
  /** 파일명에 들어갈 제목 ('매출데이터', 'BEP계산' 등) */
  title: string
  /** 인쇄 시 대상 컨테이너 id (없으면 페이지 전체 인쇄) */
  printableId?: string
  /** 버튼 크기 */
  size?: 'sm' | 'md'
  /** 토글 버튼 라벨 커스터마이징 */
  label?: string
}

export default function ExportMenu({
  rows,
  title,
  printableId,
  size = 'md',
  label = '내보내기',
}: ExportMenuProps) {
  const [open, setOpen] = useState(false)
  const [busy, setBusy] = useState<'csv' | 'xlsx' | 'print' | null>(null)
  const ref = useRef<HTMLDivElement>(null)

  // 바깥 클릭 시 닫기
  useEffect(() => {
    const h = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false)
    }
    if (open) document.addEventListener('mousedown', h)
    return () => document.removeEventListener('mousedown', h)
  }, [open])

  // Esc 키 닫기 (접근성)
  useEffect(() => {
    const h = (e: KeyboardEvent) => { if (e.key === 'Escape') setOpen(false) }
    if (open) document.addEventListener('keydown', h)
    return () => document.removeEventListener('keydown', h)
  }, [open])

  const filename = `카페브레인_${title}_${todayFilenameStamp()}`
  const isEmpty = rows.length === 0

  const handleCsv = () => {
    if (isEmpty) { toast.error('내보낼 데이터가 없어요'); return }
    setBusy('csv')
    try {
      downloadCsv(rows, { filename })
      toast.success(`${rows.length}건 CSV로 내보냈어요`)
      track('export_csv', { title, row_count: rows.length })
      setOpen(false)
    } catch (e) {
      toast.error(e instanceof Error ? e.message : 'CSV 내보내기 실패')
    } finally {
      setBusy(null)
    }
  }

  const handleExcel = async () => {
    if (isEmpty) { toast.error('내보낼 데이터가 없어요'); return }
    setBusy('xlsx')
    try {
      await downloadExcel(rows, { filename, sheetName: title })
      toast.success(`${rows.length}건 Excel로 내보냈어요`)
      track('export_excel', { title, row_count: rows.length })
      setOpen(false)
    } catch (e) {
      toast.error(e instanceof Error ? e.message : 'Excel 내보내기 실패')
    } finally {
      setBusy(null)
    }
  }

  const handlePrint = () => {
    setBusy('print')
    try {
      printReport(printableId)
      toast.success('인쇄 창을 열었어요 (PDF로 저장하려면 대상을 "PDF"로 변경)')
      track('export_pdf', { title, row_count: rows.length })
      setOpen(false)
    } finally {
      setBusy(null)
    }
  }

  const btnSize = size === 'sm' ? 'px-3 py-1.5 text-xs' : 'px-4 py-2 text-sm'

  return (
    <div ref={ref} className="relative inline-block no-print">
      <button
        onClick={() => setOpen((v) => !v)}
        className={cn(
          btnSize,
          'inline-flex items-center gap-1.5 rounded-xl border border-gray-200 dark:border-gray-700',
          'bg-white dark:bg-gray-800 text-[#2C1810] dark:text-gray-100 font-semibold',
          'hover:bg-[#FAFAF8] dark:hover:bg-gray-700 transition-colors',
          'focus:outline-none focus-visible:ring-2 focus-visible:ring-[#D4A574] focus-visible:ring-offset-1',
          isEmpty && 'opacity-50 cursor-not-allowed',
        )}
        aria-haspopup="menu"
        aria-expanded={open}
        disabled={isEmpty}
      >
        <Download size={size === 'sm' ? 12 : 14} />
        {label}
        <ChevronDown size={size === 'sm' ? 12 : 14} className={cn('transition-transform', open && 'rotate-180')} />
      </button>

      {open && (
        <div
          role="menu"
          className={cn(
            'absolute right-0 mt-2 w-56 rounded-xl border border-gray-200 dark:border-gray-700',
            'bg-white dark:bg-gray-800 shadow-xl z-50 overflow-hidden',
            'animate-in fade-in slide-in-from-top-2 duration-150',
          )}
        >
          <MenuItem
            icon={<FileText size={14} />}
            label="CSV 파일"
            hint=".csv · 엑셀·Numbers 호환"
            onClick={handleCsv}
            busy={busy === 'csv'}
          />
          <MenuItem
            icon={<FileSpreadsheet size={14} />}
            label="Excel 파일"
            hint=".xlsx · 서식 포함"
            onClick={handleExcel}
            busy={busy === 'xlsx'}
          />
          <MenuItem
            icon={<Printer size={14} />}
            label="인쇄 / PDF"
            hint="프린터·PDF로 저장"
            onClick={handlePrint}
            busy={busy === 'print'}
          />
          <div className="px-4 py-2 text-[10px] text-gray-400 dark:text-gray-500 bg-gray-50 dark:bg-gray-900 border-t border-gray-100 dark:border-gray-700">
            총 <span className="font-bold">{rows.length}</span>건 · {filename}
          </div>
        </div>
      )}
    </div>
  )
}

function MenuItem({
  icon, label, hint, onClick, busy,
}: {
  icon: React.ReactNode
  label: string
  hint: string
  onClick: () => void
  busy: boolean
}) {
  return (
    <button
      role="menuitem"
      onClick={onClick}
      disabled={busy}
      className="w-full flex items-center gap-3 px-4 py-2.5 text-left hover:bg-[#FAFAF8] dark:hover:bg-gray-700 transition-colors disabled:opacity-60 focus:outline-none focus-visible:bg-[#FAFAF8] dark:focus-visible:bg-gray-700"
    >
      <span className="text-[#D4A574]">{busy ? <Loader2 size={14} className="animate-spin" /> : icon}</span>
      <div className="flex-1">
        <div className="text-sm font-semibold text-[#2C1810] dark:text-gray-100">{label}</div>
        <div className="text-[10px] text-gray-500 dark:text-gray-400">{hint}</div>
      </div>
    </button>
  )
}
