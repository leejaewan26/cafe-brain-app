// 메뉴·레시피 & 교육 매뉴얼 타입 정의

// ─── 재료 항목 ───
export interface Ingredient {
  id: string
  name: string       // 재료명
  unitPrice: number  // 단가 (원/g 또는 원/ml)
  amount: number     // 사용량
  unit: string       // 단위 (g, ml, 개)
}

// ─── 메뉴 카테고리 ───
export type MenuCategory = 'coffee' | 'non_coffee' | 'dessert' | 'food' | 'other'

export const CATEGORY_LABELS: Record<MenuCategory, string> = {
  coffee: '☕ 커피',
  non_coffee: '🧃 논커피',
  dessert: '🍰 디저트',
  food: '🥐 푸드',
  other: '📦 기타',
}

// ─── 메뉴 항목 ───
export interface MenuItem {
  id: string
  name: string              // 메뉴명
  category: MenuCategory    // 카테고리
  ingredients: Ingredient[] // 재료 목록
  totalCost: number         // 재료비 합계 (자동 계산)
  salePrice: number         // 판매가
  photoUrl?: string         // 이미지 URL (base64 or URL)
  recipe?: string           // AI 생성 레시피 문서
  notes?: string            // 메모
  createdAt: string
}

// ─── 교육 매뉴얼 타입 ───
export type ManualType =
  | 'open_checklist'      // 오픈 체크리스트
  | 'close_checklist'     // 마감 체크리스트
  | 'barista_guide'       // 신입 바리스타 교육 가이드
  | 'customer_scenario'   // 고객 응대 시나리오
  | 'machine_trouble'     // 머신 트러블슈팅

export const MANUAL_TYPE_LABELS: Record<ManualType, string> = {
  open_checklist: '🌅 오픈 체크리스트',
  close_checklist: '🌙 마감 체크리스트',
  barista_guide: '☕ 신입 바리스타 교육 가이드',
  customer_scenario: '💬 고객 응대 시나리오',
  machine_trouble: '🔧 머신 트러블슈팅',
}

// ─── 출력 형식 ───
export type OutputFormat = 'checklist' | 'table' | 'step_guide'
