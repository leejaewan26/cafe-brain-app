// 요금제·결제 페이지 (Day 3-1)
// 7일 무료 체험 + 월/연 구독 선택 + 토스페이먼츠 위젯 연동
// /ultrareview U06·U26: "가격 정보 없음" 해결 → 앱 내 업그레이드 진입점 제공
import { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { Check, Sparkles, Zap, Loader2, Shield, XCircle, CreditCard, RotateCcw } from 'lucide-react'
import toast from 'react-hot-toast'
import { useAuth } from '@/hooks/useAuth'
import { cn, formatCurrency } from '@/lib/utils'
import { track } from '@/lib/analytics'

interface Plan {
  id: 'monthly' | 'yearly'
  name: string
  price_krw: number
  description: string
  features: string[]
  recommended: boolean
  discount_percent: number
}

interface Subscription {
  status: 'trial' | 'active' | 'past_due' | 'canceled' | 'none'
  plan_id?: string
  trial_ends_at?: string
  days_remaining: number
  can_upgrade: boolean
}

export default function BillingPage() {
  const navigate = useNavigate()
  const { user, storeInfo } = useAuth()
  const [plans, setPlans] = useState<Plan[]>([])
  const [selected, setSelected] = useState<'monthly' | 'yearly'>('yearly')
  const [subscription, setSubscription] = useState<Subscription | null>(null)
  const [loading, setLoading] = useState(false)

  useEffect(() => {
    // Day 7-1: 가격 페이지 뷰 이벤트
    track('pricing_view', { source: 'billing_page' })
    // 플랜·구독 병렬 로드
    const load = async () => {
      try {
        const [plansRes, subRes] = await Promise.all([
          fetch('/api/v1/billing/plans'),
          user?.id ? fetch(`/api/v1/billing/subscription/${user.id}`) : null,
        ])
        if (plansRes.ok) {
          setPlans(await plansRes.json())
        }
        if (subRes?.ok) {
          setSubscription(await subRes.json())
        }
      } catch {
        toast.error('플랜 정보를 불러오지 못했어요')
      }
    }
    void load()
  }, [user?.id])

  const handleCheckout = async (planId: 'monthly' | 'yearly') => {
    if (!user?.id) {
      toast.error('로그인이 필요합니다')
      return
    }
    // Day 7-1: 결제 시작 이벤트 (전환 깔때기 핵심)
    track('checkout_start', { store_id: user.id, plan_id: planId })
    setLoading(true)
    try {
      const res = await fetch('/api/v1/billing/checkout', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          plan_id: planId,
          store_id: user.id,
          customer_email: user.email ?? '',
          customer_name: storeInfo?.owner_name ?? '사장님',
        }),
      })
      if (!res.ok) throw new Error(`서버 오류 ${res.status}`)
      const data = await res.json()

      // 토스페이먼츠 위젯 동적 로드
      await loadTossPaymentsScript()
      // @ts-expect-error — TossPayments는 CDN으로 로드됨
      const toss = window.TossPayments(data.client_key)
      const widgets = toss.widgets({ customerKey: data.customer_key })

      await widgets.setAmount({ currency: 'KRW', value: data.amount })

      // 카드 등록 UI를 body에 삽입 (모달 스타일 팝오버는 다음 이터레이션)
      await widgets.renderPaymentMethods({
        selector: '#toss-payment-methods',
        variantKey: 'DEFAULT',
      })
      await widgets.renderAgreement({
        selector: '#toss-agreement',
      })

      await widgets.requestPayment({
        orderId: data.order_id,
        orderName: `${data.plan_name} — 카페 브레인`,
        successUrl: window.location.origin + data.success_url.replace(/^https?:\/\/[^/]+/, ''),
        failUrl: window.location.origin + data.fail_url.replace(/^https?:\/\/[^/]+/, ''),
        customerEmail: user.email,
        customerName: storeInfo?.owner_name ?? '사장님',
      })
    } catch (e) {
      const msg = e instanceof Error ? e.message : '결제 준비 실패'
      toast.error(msg)
      // Day 7-1: 결제 실패 이벤트 (이탈 분석)
      track('checkout_fail', { store_id: user?.id, plan_id: planId, reason: msg.slice(0, 80) })
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-[#FAFAF8] dark:bg-gray-900 py-10 px-4">
      <div className="max-w-4xl mx-auto">
        {/* 헤더 */}
        <div className="text-center mb-10">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#D4A574]/15 text-[#D4A574] text-xs font-bold mb-3">
            <Sparkles size={12} />
            소형 카페 전용 요금제
          </div>
          <h1 className="text-3xl font-bold text-[#2C1810] dark:text-gray-100 mb-2">
            카페 브레인 요금제
          </h1>
          <p className="text-gray-500 dark:text-gray-400 text-sm">
            7일 무료 체험 후 구독. 언제든 해지할 수 있어요.
          </p>
        </div>

        {/* 구독 상태 배너 */}
        {subscription?.status === 'trial' && (
          <div className="mb-6 bg-gradient-to-r from-[#D4A574]/20 to-[#D4A574]/5 border border-[#D4A574] rounded-2xl p-4 flex items-center gap-3">
            <Zap className="w-6 h-6 text-[#D4A574] shrink-0" />
            <div className="flex-1">
              <p className="font-bold text-[#2C1810] dark:text-gray-100">
                체험 기간 {subscription.days_remaining}일 남음
              </p>
              <p className="text-xs text-gray-600 dark:text-gray-300 mt-0.5">
                지금 업그레이드하면 체험 기간 종료 후 자동 전환되며, 첫 달은 끊김 없이 이어집니다.
              </p>
            </div>
          </div>
        )}

        {/* 플랜 카드 2개 */}
        <div className="grid md:grid-cols-2 gap-4 mb-8">
          {plans.map((plan) => (
            <button
              key={plan.id}
              onClick={() => setSelected(plan.id)}
              className={cn(
                'text-left rounded-2xl p-6 border-2 transition-all duration-200 relative',
                selected === plan.id
                  ? 'border-[#D4A574] bg-white dark:bg-gray-800 shadow-xl scale-[1.01]'
                  : 'border-gray-200 dark:border-gray-700 bg-white/60 dark:bg-gray-800/60 hover:border-[#D4A574]/60'
              )}
              aria-pressed={selected === plan.id}
            >
              {plan.recommended && (
                <div className="absolute -top-3 right-6 px-3 py-1 rounded-full bg-[#2C1810] text-[#D4A574] text-[10px] font-bold">
                  ⭐ 추천
                </div>
              )}

              <h3 className="text-lg font-bold text-[#2C1810] dark:text-gray-100 mb-1">
                {plan.name}
              </h3>
              <div className="flex items-baseline gap-1 mb-3">
                <span className="text-3xl font-black text-[#2C1810] dark:text-gray-100">
                  {formatCurrency(plan.price_krw)}
                </span>
                <span className="text-xs text-gray-400">
                  /{plan.id === 'monthly' ? '월' : '년'}
                </span>
                {plan.discount_percent > 0 && (
                  <span className="ml-2 px-2 py-0.5 rounded-full bg-red-100 text-red-700 text-[10px] font-bold">
                    {plan.discount_percent}% 할인
                  </span>
                )}
              </div>
              <p className="text-xs text-gray-500 dark:text-gray-400 mb-4">
                {plan.description}
              </p>

              <ul className="space-y-1.5">
                {plan.features.map((f, i) => (
                  <li key={i} className="flex items-start gap-2 text-xs text-gray-700 dark:text-gray-300">
                    <Check size={14} className="text-[#D4A574] mt-0.5 shrink-0" />
                    <span>{f}</span>
                  </li>
                ))}
              </ul>
            </button>
          ))}
        </div>

        {/* 결제 버튼 */}
        <button
          onClick={() => handleCheckout(selected)}
          disabled={loading || subscription?.status === 'active'}
          className="w-full py-4 rounded-2xl bg-gradient-to-r from-[#2C1810] to-[#D4A574] text-white font-bold text-base shadow-lg hover:opacity-95 disabled:opacity-50 transition-opacity flex items-center justify-center gap-2"
        >
          {loading ? <Loader2 className="w-5 h-5 animate-spin" /> : <Shield size={18} />}
          {loading
            ? '결제창 준비 중...'
            : subscription?.status === 'active'
            ? '이미 구독 중입니다'
            : '토스로 안전 결제하기'}
        </button>

        {/* H1+K1+K3: 활성/past_due 상태에서 노출 */}
        {(subscription?.status === 'active' || subscription?.status === 'past_due') && user?.id && (
          <div className="mt-4 grid grid-cols-2 gap-2">
            {/* K3: 카드 변경 */}
            <button
              onClick={async () => {
                if (!confirm('새 카드 등록 화면으로 이동합니다. 새 카드 등록 후 자동으로 구독에 적용됩니다.')) return
                // 카드 변경은 새 빌링키 발급 — issue-billing-key 다시 호출
                // Toss 위젯 빌링키 모드로 재진입 필요 — 여기선 안내 toast
                toast('카드 변경: Toss 카드 등록 위젯이 별도 창에서 열립니다 (구현 중 — 현재는 운영팀 문의)')
              }}
              className="py-2.5 border border-gray-200 rounded-xl text-sm font-medium text-gray-700 hover:bg-gray-50 flex items-center justify-center gap-1.5"
            >
              <CreditCard size={14} /> 카드 변경
            </button>
            {/* K1: 환불 (30일 이내) */}
            <button
              onClick={async () => {
                const reason = prompt(
                  '환불 사유를 입력해주세요. 7일 이내는 100%, 7~30일은 사용분 차감 후 환불됩니다.'
                )
                if (!reason || reason.length < 2) return
                // 마지막 결제 paymentKey 조회 → 환불
                try {
                  const subRes = await fetch(`/api/v1/billing/subscription/${user.id}`)
                  const subData = await subRes.json()
                  // current_period_end 등에 paymentKey가 없으니 백엔드에서 처리해야 — 임시로 alert
                  toast('환불은 운영팀 문의: support@cafe-brain.app (자동 환불 UI는 곧 출시)')
                  console.log('Subscription:', subData)
                } catch (e) {
                  toast.error(e instanceof Error ? e.message : '오류')
                }
              }}
              className="py-2.5 border border-amber-200 rounded-xl text-sm font-medium text-amber-700 hover:bg-amber-50 flex items-center justify-center gap-1.5"
            >
              <RotateCcw size={14} /> 환불
            </button>
            {/* H1: 해지 */}
            <button
              onClick={async () => {
                const reason = prompt(
                  '해지 사유를 알려주세요 (선택). 다음 결제일까지는 모든 기능을 계속 사용할 수 있어요.'
                )
                if (reason === null) return
                try {
                  const r = await fetch('/api/v1/billing/cancel', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ store_id: user.id, reason }),
                  })
                  if (!r.ok) throw new Error('해지 실패')
                  toast.success('해지 신청 완료')
                  window.location.reload()
                } catch (e) {
                  toast.error(e instanceof Error ? e.message : '해지 실패')
                }
              }}
              className="col-span-2 py-2.5 border border-red-200 rounded-xl text-sm font-medium text-red-600 hover:bg-red-50 flex items-center justify-center gap-1.5"
            >
              <XCircle size={14} /> 구독 해지
            </button>
          </div>
        )}

        {/* K4: 세금계산서 요청 (활성 구독 사장님) */}
        {subscription?.status === 'active' && user?.id && (
          <button
            onClick={() => {
              const win = window.confirm('사업자세요? 세금계산서 발행을 신청합니다. (개인 사장님은 [현금영수증] 메뉴 사용)')
              if (!win) return
              window.location.href = '/billing/tax-invoice'
            }}
            className="w-full mt-3 py-2 text-xs font-medium text-gray-500 hover:text-[#2C1810] underline"
          >
            세금계산서 발행 신청
          </button>
        )}

        <p className="text-[11px] text-gray-400 text-center mt-3 leading-relaxed">
          결제는 토스페이먼츠 보안 시스템으로 처리되며, 카드 정보는 카페 브레인 서버에 저장되지 않습니다.
          <br />
          <button
            onClick={() => navigate('/dashboard')}
            className="underline hover:text-gray-600 mt-1"
          >
            나중에 결제하기
          </button>
        </p>

        {/* 토스 위젯이 렌더되는 슬롯 (모달로 띄울 예정) */}
        <div id="toss-payment-methods" className="mt-6" />
        <div id="toss-agreement" className="mt-2" />
      </div>
    </div>
  )
}

// ─── 토스페이먼츠 SDK 동적 로더 ─────────────────
let tossScriptPromise: Promise<void> | null = null
function loadTossPaymentsScript(): Promise<void> {
  if (tossScriptPromise) return tossScriptPromise
  tossScriptPromise = new Promise((resolve, reject) => {
    // @ts-expect-error — global check
    if (typeof window.TossPayments !== 'undefined') {
      resolve()
      return
    }
    const script = document.createElement('script')
    script.src = 'https://js.tosspayments.com/v2/standard'
    script.async = true
    script.onload = () => resolve()
    script.onerror = () => reject(new Error('토스페이먼츠 SDK 로드 실패'))
    document.head.appendChild(script)
  })
  return tossScriptPromise
}
