// 설정 > 알림 탭 (Issue #19 Push 알림 — Wave 5D 실제 구현)
import { Bell, BellOff, AlertCircle, CheckCircle2, Loader2, Send } from 'lucide-react'
import toast from 'react-hot-toast'
import { useWebPush } from '@/hooks/useWebPush'

export default function NotifyTab() {
  const { permission, subscribed, busy, subscribe, unsubscribe, notifyLocal } = useWebPush()

  const handleRequest = async () => {
    const ok = await subscribe()
    if (ok) {
      toast.success(subscribed ? '알림이 켜져있어요' : '알림이 켜졌어요 📢')
      notifyLocal('카페 브레인', '알림 설정 완료 — 테스트 알림이에요 ☕', 'welcome')
    } else {
      toast.error('알림 설정 실패 — 브라우저 설정 확인 필요')
    }
  }

  const handleUnsubscribe = async () => {
    if (!confirm('알림을 끄시겠어요? 앱 외부에서 중요 이벤트를 받지 못하게 됩니다.')) return
    const ok = await unsubscribe()
    if (ok) toast.success('알림이 꺼졌어요')
    else toast.error('구독 해제 실패')
  }

  const permissionMeta: Record<string, { icon: React.ElementType; label: string; color: string }> = {
    granted: { icon: CheckCircle2, label: '허용됨', color: 'text-green-600' },
    denied: { icon: BellOff, label: '차단됨 — 브라우저 설정 필요', color: 'text-red-500' },
    default: { icon: Bell, label: '아직 권한 요청 안 함', color: 'text-gray-500' },
    unsupported: { icon: AlertCircle, label: '이 브라우저는 미지원', color: 'text-gray-400' },
  }
  const meta = permissionMeta[permission] ?? permissionMeta.default
  const Icon = meta.icon

  return (
    <div className="space-y-6">
      {/* 권한 상태 */}
      <section className="bg-white rounded-2xl p-5 border border-gray-100 shadow-sm">
        <h3 className="font-bold text-[#2C1810] mb-3 flex items-center gap-2">
          <Bell size={16} className="text-[#D4A574]" />
          푸시 알림
        </h3>

        <div className="flex items-center gap-3 p-3 bg-[#FAFAF8] rounded-xl mb-4">
          <Icon size={18} className={meta.color} />
          <span className={`text-sm font-medium ${meta.color}`}>{meta.label}</span>
        </div>

        {permission === 'default' && (
          <button
            onClick={handleRequest}
            disabled={busy}
            className="w-full py-2.5 bg-[#2C1810] text-white rounded-xl text-sm font-semibold hover:bg-[#3d2418] transition-colors disabled:opacity-50 flex items-center justify-center gap-2"
          >
            {busy ? <><Loader2 size={14} className="animate-spin" /> 설정 중...</> : <><Bell size={14} /> 알림 허용하기</>}
          </button>
        )}

        {permission === 'granted' && !subscribed && (
          <button
            onClick={handleRequest}
            disabled={busy}
            className="w-full py-2.5 bg-[#D4A574] text-white rounded-xl text-sm font-semibold disabled:opacity-50 flex items-center justify-center gap-2"
          >
            {busy ? <><Loader2 size={14} className="animate-spin" /> 구독 중...</> : <><Send size={14} /> Push 구독 시작</>}
          </button>
        )}

        {permission === 'granted' && subscribed && (
          <div className="space-y-2">
            <div className="flex items-center gap-2 p-2.5 bg-green-50 rounded-xl text-xs text-green-700">
              <CheckCircle2 size={13} /> 푸시 구독 활성 — 앱 닫혀있어도 알림 받음
            </div>
            <button
              onClick={() => notifyLocal('테스트 알림', '알림이 정상 작동 중입니다 🎉', 'test')}
              className="w-full py-2 border border-gray-200 rounded-xl text-xs text-gray-600 hover:bg-gray-50"
            >
              테스트 알림 발송
            </button>
            <button
              onClick={handleUnsubscribe}
              disabled={busy}
              className="w-full py-2 border border-red-200 rounded-xl text-xs text-red-500 hover:bg-red-50 disabled:opacity-50"
            >
              구독 해제
            </button>
          </div>
        )}

        {permission === 'denied' && (
          <div className="text-xs text-gray-500 p-3 bg-red-50 rounded-xl leading-relaxed">
            💡 브라우저 주소창 왼쪽의 🔒 아이콘 → 알림 → '허용'으로 변경해주세요.
          </div>
        )}
      </section>

      {/* 알림 항목별 (MVP: UI만, 저장은 Phase 2) */}
      {permission === 'granted' && (
        <section className="bg-white rounded-2xl p-5 border border-gray-100 shadow-sm space-y-3">
          <h3 className="font-bold text-[#2C1810] text-sm">알림 항목</h3>
          {[
            { key: 'sales_anomaly', label: '매출 급락 감지', desc: '평소 대비 20% 이상 떨어지면 즉시' },
            { key: 'new_review', label: '새 리뷰 등록', desc: '특히 부정 리뷰(1-2점)' },
            { key: 'order_pending', label: '발주 승인 요청', desc: '점장 발주 → 사장 대기' },
            { key: 'bep_reached', label: 'BEP 달성', desc: '이번 달 목표 달성 시' },
            { key: 'daily_briefing', label: '일일 브리핑', desc: '매일 아침 운영 요약' },
          ].map((item) => (
            <div key={item.key} className="flex items-center justify-between py-2 border-b border-gray-50 last:border-0">
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium text-[#2C1810]">{item.label}</p>
                <p className="text-xs text-gray-400 mt-0.5">{item.desc}</p>
              </div>
              <label className="relative inline-flex items-center cursor-pointer shrink-0 ml-3">
                <input type="checkbox" defaultChecked className="sr-only peer" />
                <div className="w-10 h-5 bg-gray-200 peer-focus:ring-2 peer-focus:ring-[#D4A574]/30 rounded-full peer peer-checked:after:translate-x-5 after:content-[''] after:absolute after:top-0.5 after:left-0.5 after:bg-white after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-[#2C1810]" />
              </label>
            </div>
          ))}
          <p className="text-[10px] text-gray-400 mt-2">
            💡 현재는 브라우저 로컬 알림만 지원합니다. 앱을 닫고도 받는 서버 푸시는 곧 업데이트됩니다.
          </p>
        </section>
      )}
    </div>
  )
}
