"""
재료 공급처 비용 절감 제안 (Issue #9)

MVP: Gemini에게 현재 재료 목록을 주고 시중 대안 제안을 요청.
실제 웹 스크래핑은 법률·안정성 리스크로 Phase 2로 미룸.
대신 Gemini의 학습된 지식 + '시세 조사' 프롬프트로 대체.

결과는 accepted/rejected_suggestion memory로 피드백 수집 → 학습.
"""
from typing import List

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field

from app.services.gemini_service import generate_insight_cached, build_cache_key

router = APIRouter()


class IngredientInput(BaseModel):
    name: str
    unit: str
    current_unit_price: float = 0
    current_supplier: str = ""


class CostSavingRequest(BaseModel):
    store_id: str
    store_context: str
    ingredients: List[IngredientInput] = Field(..., min_items=1, max_items=20)


class SavingSuggestion(BaseModel):
    ingredient: str
    current: str              # 현재 상태 요약
    alternatives: list[str]   # 대안 2~3개
    estimated_savings: str    # 예상 절감
    confidence: str           # 신뢰도 (참고 수준)


class CostSavingResponse(BaseModel):
    suggestions: list[SavingSuggestion]
    disclaimer: str


@router.post("/cost-savings", response_model=CostSavingResponse)
async def suggest_cost_savings(req: CostSavingRequest):
    """
    재료별 비용 절감 대안 제안.
    Gemini가 시세 참고 + 대체 공급처 제안.
    """
    ing_list = "\n".join(
        f"  - {i.name} ({i.unit}): 현재 단가 {i.current_unit_price}원"
        + (f", 공급처 {i.current_supplier}" if i.current_supplier else "")
        for i in req.ingredients
    )

    prompt = f"""
당신은 카페·요식업 재료 구매 컨설턴트입니다. 아래 매장의 재료 리스트를 검토하고
온라인 오픈마켓(쿠팡·지마켓·B2B 플랫폼) 시세를 참고해 비용 절감 대안을 제안해주세요.

{req.store_context}

[현재 재료 목록]
{ing_list}

[응답 형식 — 각 재료당]
재료명: ...
현재: (간단 요약)
대안:
  1. [제안 1 — 플랫폼/브랜드 + 예상 단가 + 장점]
  2. [제안 2]
예상 절감: (월 기준 대략 %)
신뢰도: (높음/중간/낮음 — 정보 근거)

[중요 주의사항 강조 문구 포함]
- "AI가 일반 시세 지식을 기반으로 제안한 참고 자료입니다.
   실제 가격·재고는 반드시 해당 플랫폼에서 직접 확인하세요."

재료 1개당 3줄 이내로 간결하게. 최대 5개 재료만 우선 분석:
""".strip()

    cache_key = build_cache_key(
        store_id=req.store_id,
        template="supplier_savings",
        params={
            "ing_hash": ",".join(sorted(i.name for i in req.ingredients))[:200],
        },
    )

    try:
        raw = await generate_insight_cached(
            prompt, cache_key=cache_key, ttl_hours=72, show_watermark=False
        )
    except RuntimeError as e:
        raise HTTPException(status_code=503, detail=str(e))

    # 간단한 파싱 — 구조화 실패 시 전체를 단일 suggestion으로
    suggestions: list[SavingSuggestion] = []
    try:
        # "재료명:" 기준으로 블록 분할
        blocks = [b.strip() for b in raw.split('재료명:') if b.strip()]
        for block in blocks[:10]:
            lines = [ln.strip() for ln in block.split('\n') if ln.strip()]
            if not lines:
                continue
            name = lines[0]
            current = next((ln.replace('현재:', '').strip() for ln in lines if ln.startswith('현재:')), '')
            alternatives = [ln.strip() for ln in lines if ln.startswith(('1.', '2.', '3.', '-'))]
            savings = next((ln.replace('예상 절감:', '').strip() for ln in lines if ln.startswith('예상 절감:')), '정보 부족')
            confidence = next((ln.replace('신뢰도:', '').strip() for ln in lines if ln.startswith('신뢰도:')), '중간')
            if alternatives:
                suggestions.append(SavingSuggestion(
                    ingredient=name,
                    current=current or '정보 없음',
                    alternatives=alternatives[:3],
                    estimated_savings=savings,
                    confidence=confidence,
                ))
    except Exception:
        pass

    if not suggestions:
        # 파싱 실패 시 전체 텍스트를 단일 제안으로
        suggestions.append(SavingSuggestion(
            ingredient='전체',
            current='AI 분석 결과',
            alternatives=[raw[:500]],
            estimated_savings='참고 필요',
            confidence='낮음',
        ))

    return CostSavingResponse(
        suggestions=suggestions,
        disclaimer='⚠️ AI가 일반 시세 지식으로 제안한 참고 자료입니다. 실제 가격·재고는 각 플랫폼에서 직접 확인하세요.',
    )
