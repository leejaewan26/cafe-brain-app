// useAuth 훅 - Supabase Auth 상태 관리 및 인증 함수 제공
import { useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import { supabase } from '@/lib/supabase'
import { useAuthStore } from '@/store/authStore'
import { useProfileStore } from '@/store/profileStore'
import { setSentryUser } from '@/lib/sentry'
import { clearApiCache } from '@/hooks/usePWA'

export function useAuth() {
  const navigate = useNavigate()
  const { user, session, storeInfo, isOnboarded, setUser, setSession, setIsOnboarded, setStoreInfo, reset } =
    useAuthStore()

  // Supabase stores 테이블에서 매장 정보 복원
  const fetchStoreInfo = async (userId: string) => {
    const { data } = await supabase
      .from('stores')
      .select('*')
      .eq('id', userId)
      .single()
    if (data) {
      setStoreInfo(data)
      setIsOnboarded(true)
    }
  }

  // Supabase 세션 변경 감지 (앱 초기화 시)
  useEffect(() => {
    // 현재 세션 가져오기
    supabase.auth.getSession().then(({ data: { session } }) => {
      setSession(session)
      setUser(session?.user ?? null)
      // Launch A5: Sentry 사용자 ID 설정 (로그인 상태에서만)
      setSentryUser(session?.user?.id ?? null)
      // 세션이 있는데 storeInfo가 없으면 DB에서 복원
      if (session?.user) {
        fetchStoreInfo(session.user.id)
      }
    })

    // 세션 변경 구독 (로그인/로그아웃/토큰 갱신)
    const {
      data: { subscription },
    } = supabase.auth.onAuthStateChange((event, session) => {
      setSession(session)
      setUser(session?.user ?? null)
      setSentryUser(session?.user?.id ?? null)
      // 로그인 이벤트 시 매장 정보 복원
      if (event === 'SIGNED_IN' && session?.user) {
        fetchStoreInfo(session.user.id)
      }
    })

    return () => subscription.unsubscribe()
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [setSession, setUser, setStoreInfo, setIsOnboarded])

  // 이메일/비번 회원가입
  const signUp = async (email: string, password: string) => {
    const { data, error } = await supabase.auth.signUp({ email, password })
    if (error) throw error
    // G4: 환영 메일 trigger (실패해도 무시 — 가입 흐름 막지 않음)
    if (data.user?.id) {
      void fetch('/api/v1/notification-cron/welcome', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ store_id: data.user.id }),
      }).catch(() => {})
    }
    return data
  }

  // 이메일/비번 로그인
  const signIn = async (email: string, password: string) => {
    const { data, error } = await supabase.auth.signInWithPassword({ email, password })
    if (error) throw error
    return data
  }

  // 로그아웃 — Critical C3: authStore + profileStore 동시 reset
  // Bonus E6: SW API 캐시 비우기 (다음 사용자 데이터 누출 방지)
  // Launch A5: Sentry 사용자 컨텍스트 클리어
  const signOut = async () => {
    await supabase.auth.signOut()
    reset()
    useProfileStore.getState().reset()
    setSentryUser(null)
    void clearApiCache()
    navigate('/login')
  }

  return {
    user,
    session,
    storeInfo,
    isOnboarded,
    isAuthenticated: !!user,
    signUp,
    signIn,
    signOut,
    setIsOnboarded,
    setStoreInfo,
  }
}
