// Supabase + 백엔드 API 목킹 헬퍼
// Playwright page.route()로 모든 HTTP 요청을 가로채 테스트용 응답 반환
import type { Page, Route } from '@playwright/test'
import {
  MOCK_SESSION,
  MOCK_STORE,
  MOCK_OWNER_PROFILE,
  MOCK_MANAGER_PROFILE,
  MOCK_AI_INSIGHT,
  MOCK_REVIEW_REPLY,
  MOCK_BRIEFING,
} from './mockData'

interface MockOptions {
  profiles?: typeof MOCK_OWNER_PROFILE[]
  extraSalesInsight?: string
  extraBriefing?: string
}

/**
 * 모든 Supabase + /api/* 요청을 가로채 fake 응답 반환.
 * 각 테스트 시작 시 `await setupApiMocks(page)` 호출.
 */
export async function setupApiMocks(page: Page, opts: MockOptions = {}) {
  const profiles = opts.profiles ?? [MOCK_OWNER_PROFILE]

  // ─── Supabase Auth ───
  await page.route('**/auth/v1/**', (route) => routeAuth(route))

  // ─── Supabase REST (stores, profiles, agent_memory, ingredients, etc.) ───
  await page.route('**/rest/v1/**', (route) => routeRest(route, profiles))

  // ─── 백엔드 API (FastAPI) ───
  await page.route('**/api/sales/ai-insight', (route) => {
    route.fulfill({
      status: 200,
      contentType: 'application/json',
      body: JSON.stringify({
        insight: opts.extraSalesInsight ?? MOCK_AI_INSIGHT,
      }),
    })
  })

  await page.route('**/api/reviews/reply', (route) => {
    route.fulfill({
      status: 200,
      contentType: 'application/json',
      body: JSON.stringify({ reply: MOCK_REVIEW_REPLY }),
    })
  })

  await page.route('**/api/agent/briefing', (route) => {
    route.fulfill({
      status: 200,
      contentType: 'application/json',
      body: JSON.stringify({
        briefing_id: 'briefing-test-001',
        message: opts.extraBriefing ?? MOCK_BRIEFING,
        trigger: 'daily_briefing',
        context_memories: [
          { id: 'm1', category: 'business_pattern', content: '점심시간 11-13시 회전율 피크' },
        ],
      }),
    })
  })

  await page.route('**/api/agent/memory*', (route) => {
    route.fulfill({
      status: 200,
      contentType: 'application/json',
      body: JSON.stringify({
        memories: [
          {
            id: 'm1',
            category: 'business_pattern',
            content: '점심시간 11-13시 회전율 피크',
            importance: 7,
            confidence: 0.9,
            created_at: new Date().toISOString(),
          },
        ],
        total: 1,
      }),
    })
  })

  await page.route('**/api/agent/feedback', (route) => {
    route.fulfill({
      status: 200,
      contentType: 'application/json',
      body: JSON.stringify({
        feedback_id: 'feedback-test-001',
        learning_signal: '👍 유용한 제안 더 자주 드릴게요',
      }),
    })
  })

  await page.route('**/api/chat/message', (route) => {
    route.fulfill({
      status: 200,
      contentType: 'application/json',
      body: JSON.stringify({
        reply: '사장님 질문에 대한 AI 답변입니다.\n\nⓘ AI가 생성한 콘텐츠입니다.',
      }),
    })
  })

  await page.route('**/api/learning/**', (route) => {
    route.fulfill({
      status: 200,
      contentType: 'application/json',
      body: JSON.stringify({ memories_created: 2, details: { sales_anomaly: 1, bep_milestone: 1 } }),
    })
  })

  await page.route('**/api/push/**', (route) => {
    route.fulfill({
      status: 200,
      contentType: 'application/json',
      body: JSON.stringify({ publicKey: '', configured: false }),
    })
  })

  await page.route('**/api/marketing/generate', (route) => {
    route.fulfill({
      status: 200,
      contentType: 'application/json',
      body: JSON.stringify({
        drafts: [
          { content: '오늘도 따뜻한 한 잔 ☕ 직장인 점심 피크타임에 최적.', hashtags: ['#카페', '#아메리카노'], char_count: 40 },
          { content: '당신의 하루에 여유 한 잔 더해드려요.', hashtags: ['#일상', '#커피'], char_count: 25 },
          { content: '매일 새로운 원두 블렌드, 이 주는 에티오피아.', hashtags: ['#스페셜티'], char_count: 30 },
        ],
      }),
    })
  })

  // Day 3-1: Billing 엔드포인트 (E2E 테스트가 TrialBanner·BillingPage 통과하려면 mock 필요)
  await page.route('**/api/billing/plans', (route) => {
    route.fulfill({
      status: 200,
      contentType: 'application/json',
      body: JSON.stringify([
        { id: 'monthly', name: '월 구독', price_krw: 30000, description: '매월 자동 결제',
          features: ['AI 매출 분석', '리뷰 답글 무제한'], recommended: false, discount_percent: 0 },
        { id: 'yearly', name: '연 구독', price_krw: 300000, description: '17% 할인',
          features: ['월 구독 +', '연 2회 컨설팅'], recommended: true, discount_percent: 17 },
      ]),
    })
  })

  await page.route('**/api/billing/subscription/**', (route) => {
    route.fulfill({
      status: 200,
      contentType: 'application/json',
      body: JSON.stringify({
        store_id: MOCK_STORE.id,
        status: 'trial',
        days_remaining: 5,
        trial_ends_at: new Date(Date.now() + 5 * 86400 * 1000).toISOString(),
        can_upgrade: true,
      }),
    })
  })

  await page.route('**/api/billing/checkout', (route) => {
    route.fulfill({
      status: 200,
      contentType: 'application/json',
      body: JSON.stringify({
        order_id: 'test_order_001',
        amount: 30000,
        plan_name: '월 구독',
        client_key: 'test_ck_mock',
        customer_key: 'cust_test',
        success_url: '/billing/success',
        fail_url: '/billing/fail',
      }),
    })
  })

  // Day 7-1: PostHog (외부 호출 차단 — 테스트 환경에서 실 호출 방지)
  await page.route('**://*.posthog.com/**', (route) => {
    route.fulfill({ status: 200, body: '' })
  })

  // Day 6-1: Canva 외부 링크 차단 (window.open은 어차피 새 탭이라 영향 없음)
  // OCR 엔드포인트
  await page.route('**/api/sales/ocr-receipt', (route) => {
    route.fulfill({
      status: 200,
      contentType: 'application/json',
      body: JSON.stringify({
        rows: [
          { sale_date: '2026-04-25', menu_name: '아메리카노', quantity: 3, revenue: 13500,
            cost: 0, hour_slot: 11, discount: 0, confidence: 0.95 },
        ],
        warnings: [],
        receipt_type: 'pos_receipt',
        raw_text: '테스트 영수증',
      }),
    })
  })
}

// ─── Supabase Auth 라우팅 ───
function routeAuth(route: Route) {
  const url = route.request().url()
  if (url.includes('/auth/v1/token')) {
    route.fulfill({
      status: 200,
      contentType: 'application/json',
      body: JSON.stringify(MOCK_SESSION),
    })
    return
  }
  if (url.includes('/auth/v1/logout')) {
    route.fulfill({ status: 204, body: '' })
    return
  }
  route.fulfill({
    status: 200,
    contentType: 'application/json',
    body: JSON.stringify({ user: MOCK_SESSION.user }),
  })
}

// ─── Supabase REST 라우팅 ───
function routeRest(route: Route, profiles: typeof MOCK_OWNER_PROFILE[]) {
  const url = new URL(route.request().url())
  const method = route.request().method()
  const table = url.pathname.split('/rest/v1/')[1]?.split('?')[0] ?? ''

  // stores
  if (table === 'stores') {
    if (method === 'GET' || method === 'HEAD') {
      route.fulfill({
        status: 200,
        contentType: 'application/json',
        body: JSON.stringify([MOCK_STORE]),
      })
      return
    }
    if (method === 'PATCH' || method === 'POST') {
      route.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify([MOCK_STORE]) })
      return
    }
  }

  // profiles
  if (table === 'profiles') {
    if (method === 'GET' || method === 'HEAD') {
      route.fulfill({
        status: 200,
        contentType: 'application/json',
        body: JSON.stringify(profiles),
      })
      return
    }
    if (method === 'POST') {
      route.fulfill({
        status: 201,
        contentType: 'application/json',
        body: JSON.stringify([profiles[0]]),
      })
      return
    }
    route.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify(profiles) })
    return
  }

  // 나머지 테이블은 빈 배열
  route.fulfill({
    status: 200,
    contentType: 'application/json',
    body: JSON.stringify([]),
  })
}

/**
 * 인증된 상태로 스토어·프로필 pre-hydration.
 * 로그인 → 온보딩 스킵 시 사용.
 */
export async function signInAsOwner(page: Page) {
  await page.addInitScript(
    ({ session, store, profile }) => {
      // authStore (zustand persist)
      localStorage.setItem(
        'cafe-brain-auth',
        JSON.stringify({
          state: { storeInfo: store, isOnboarded: true },
          version: 0,
        }),
      )
      // profileStore
      localStorage.setItem(
        'cafe-brain-profile',
        JSON.stringify({
          state: { activeProfile: profile },
          version: 0,
        }),
      )
      // Supabase 세션 (로컬)
      localStorage.setItem(
        `sb-${location.hostname}-auth-token`,
        JSON.stringify(session),
      )
    },
    { session: MOCK_SESSION, store: MOCK_STORE, profile: MOCK_OWNER_PROFILE },
  )
}

export async function signInAsManager(page: Page) {
  await page.addInitScript(
    ({ session, store, profile }) => {
      localStorage.setItem(
        'cafe-brain-auth',
        JSON.stringify({ state: { storeInfo: store, isOnboarded: true }, version: 0 }),
      )
      localStorage.setItem(
        'cafe-brain-profile',
        JSON.stringify({ state: { activeProfile: profile }, version: 0 }),
      )
      localStorage.setItem(
        `sb-${location.hostname}-auth-token`,
        JSON.stringify(session),
      )
    },
    { session: MOCK_SESSION, store: MOCK_STORE, profile: MOCK_MANAGER_PROFILE },
  )
}
