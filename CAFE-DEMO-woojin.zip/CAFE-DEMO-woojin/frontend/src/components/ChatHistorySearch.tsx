// I3 — 대화 이력 전체 검색 (모든 세션 횡단)
// 채팅 사이드바에 검색 입력 → 매칭 메시지 + 세션 컨텍스트로 점프
import { useMemo, useState } from 'react'
import { Search, MessageCircle, X } from 'lucide-react'
import { useChatStore } from '@/store/chatStore'
import { cn } from '@/lib/utils'

interface SearchHit {
  sessionId: string
  sessionTitle: string
  messageIdx: number
  role: 'user' | 'assistant'
  content: string
  highlight: string
}

export default function ChatHistorySearch({
  onSelect,
  onClose,
}: {
  onSelect: (sessionId: string, messageIdx: number) => void
  onClose: () => void
}) {
  const sessions = useChatStore((s) => s.sessions)
  const [query, setQuery] = useState('')

  const hits = useMemo<SearchHit[]>(() => {
    if (query.trim().length < 2) return []
    const q = query.toLowerCase()
    const results: SearchHit[] = []
    for (const sess of sessions) {
      sess.messages.forEach((m, idx) => {
        const content = (m.content || '').toLowerCase()
        if (content.includes(q)) {
          // 매칭 부분 ±40자 컨텍스트로 highlight 추출
          const pos = content.indexOf(q)
          const start = Math.max(0, pos - 40)
          const end = Math.min(content.length, pos + q.length + 40)
          const snippet = (start > 0 ? '…' : '') + m.content.slice(start, end) + (end < content.length ? '…' : '')
          results.push({
            sessionId: sess.id,
            sessionTitle: sess.title || '제목 없음',
            messageIdx: idx,
            role: m.role,
            content: m.content,
            highlight: snippet,
          })
        }
      })
    }
    return results.slice(0, 50)
  }, [query, sessions])

  return (
    <div className="fixed inset-0 z-[60] bg-black/50 flex items-start justify-center pt-16 px-4">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-xl max-h-[70vh] flex flex-col overflow-hidden">
        {/* 검색 바 */}
        <div className="flex items-center gap-2 p-3 border-b border-gray-100">
          <Search size={16} className="text-gray-400" />
          <input
            autoFocus
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="모든 대화에서 검색…"
            className="flex-1 outline-none text-sm"
          />
          <button onClick={onClose} className="p-1 text-gray-400 hover:text-[#2C1810]">
            <X size={14} />
          </button>
        </div>

        {/* 결과 */}
        <div className="flex-1 overflow-y-auto">
          {query.trim().length < 2 && (
            <div className="p-8 text-center text-sm text-gray-400">
              <MessageCircle size={24} className="mx-auto mb-2 opacity-30" />
              2자 이상 입력해주세요
            </div>
          )}
          {query.trim().length >= 2 && hits.length === 0 && (
            <div className="p-8 text-center text-sm text-gray-400">
              "{query}" 매칭되는 대화가 없어요
            </div>
          )}
          {hits.length > 0 && (
            <div className="divide-y divide-gray-50">
              {hits.map((h, i) => (
                <button
                  key={`${h.sessionId}-${h.messageIdx}-${i}`}
                  onClick={() => {
                    onSelect(h.sessionId, h.messageIdx)
                    onClose()
                  }}
                  className="w-full text-left px-4 py-3 hover:bg-[#FAFAF8] transition-colors"
                >
                  <div className="flex items-center gap-2 mb-1">
                    <span className={cn(
                      'text-[10px] font-bold px-1.5 py-0.5 rounded',
                      h.role === 'user' ? 'bg-[#D4A574]/20 text-[#2C1810]' : 'bg-blue-100 text-blue-700'
                    )}>
                      {h.role === 'user' ? '👤 나' : '🤖 AI'}
                    </span>
                    <span className="text-xs text-gray-500 truncate">{h.sessionTitle}</span>
                  </div>
                  <p
                    className="text-sm text-gray-700 leading-snug"
                    dangerouslySetInnerHTML={{
                      __html: highlightMatch(h.highlight, query),
                    }}
                  />
                </button>
              ))}
            </div>
          )}
        </div>

        <div className="px-3 py-2 bg-[#FAFAF8] border-t border-gray-100 text-[10px] text-gray-400 flex items-center justify-between">
          <span>{hits.length}건 (최대 50)</span>
          <span>ESC로 닫기</span>
        </div>
      </div>
    </div>
  )
}

function highlightMatch(text: string, query: string): string {
  const escaped = query.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')
  return text.replace(
    new RegExp(escaped, 'gi'),
    (m) => `<mark class="bg-[#D4A574]/40 text-[#2C1810] font-semibold">${m}</mark>`
  )
}
