"""
Naver 뉴스 검색 API.

API: https://developers.naver.com/docs/serviceapi/search/news/news.md
- 한국 뉴스 매체 헤드라인·요약 (네이버 뉴스 인덱스)
- 무료 티어: 일 25,000건

키 없으면 None.
"""
import os
import re
from typing import Optional

import httpx

NEWS_URL = "https://openapi.naver.com/v1/search/news.json"

# Naver는 응답에 <b>...</b> 태그 포함 → 제거
_TAG_RE = re.compile(r"<[^>]+>")


def _clean(s: str) -> str:
    """HTML 태그·엔티티 정리."""
    s = _TAG_RE.sub("", s or "")
    return (s.replace("&quot;", '"')
             .replace("&amp;", "&")
             .replace("&lt;", "<")
             .replace("&gt;", ">")
             .replace("&apos;", "'")).strip()


async def search_news(
    query: str,
    display: int = 20,
    sort: str = "date",
) -> Optional[list[dict]]:
    """
    Naver 뉴스 검색.

    Args:
        query: 검색어 (예: '카페 신메뉴')
        display: 결과 개수 (1~100)
        sort: 'date' (최신순) | 'sim' (정확도순)

    Returns:
        [{"title", "description", "link", "pub_date", "originallink"}] 또는 None
    """
    cid = os.getenv("NAVER_CLIENT_ID", "")
    csec = os.getenv("NAVER_CLIENT_SECRET", "")
    if not cid or not csec or not query:
        return None

    headers = {
        "X-Naver-Client-Id": cid,
        "X-Naver-Client-Secret": csec,
    }
    params = {"query": query, "display": min(100, display), "sort": sort}

    try:
        async with httpx.AsyncClient(timeout=15) as client:
            r = await client.get(NEWS_URL, params=params, headers=headers)
            r.raise_for_status()
            items = r.json().get("items", [])
            return [
                {
                    "title": _clean(it.get("title", "")),
                    "description": _clean(it.get("description", "")),
                    "link": it.get("link", ""),
                    "originallink": it.get("originallink", ""),
                    "pub_date": it.get("pubDate", ""),
                }
                for it in items
            ]
    except Exception:
        return None
