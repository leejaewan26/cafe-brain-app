"""
능동형 AI 에이전트 브리핑 엔진 (Issue #10)

Memory Foundation (Batch 2) + 이벤트 캡처 (Batch 3) 위에 구축되는 실제 에이전트.
사용자 데이터로부터 학습해 개인화된 브리핑·알림 생성.

트리거 유형:
- daily_briefing: 일일 아침 브리핑 (pg_cron 또는 앱 진입 시 호출)
- sales_anomaly: 매출 이상 감지 (DB 함수 선행)
- bep_milestone: BEP 달성·근접
- manual: 사용자 수동 호출

A+C 조합:
- A: Cloud Scheduler/pg_cron → /api/agent/briefing 주기 호출 (정기)
- C: DB Triggers → agent_memory 이벤트 → 주기 호출 시 함께 반영 (즉시)

엔드포인트:
- POST /api/agent/briefing: 브리핑 생성 + chat_history INSERT
- GET  /api/agent/profile: 증류된 매장 프로필 조회 (투명성)
- POST /api/agent/distill: 메모리 → agent_profile JSON 증류 (주 1회)
"""
import asyncio
from datetime import datetime, timedelta, timezone
from typing import Any, Literal, Optional

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field

from app.services import memory_service
from app.services.gemini_service import (
    _get_supabase,
    generate_insight_cached,
    build_cache_key,
)

router = APIRouter()

BriefingTrigger = Literal[
    "daily_briefing",
    "sales_anomaly",
    "bep_milestone",
    "review_surge",
    "reorder_reminder",
    "manual",
]


# ═══════════════════════════════════════════════════════
# 스키마
# ═══════════════════════════════════════════════════════


class BriefingRequest(BaseModel):
    """능동 브리핑 요청"""
    store_id: str = Field(..., description="매장 UUID")
    trigger: BriefingTrigger = Field(default="daily_briefing")
    store_context: str = Field(..., description="매장 기본 정보 (useStoreContext)")
    additional_context: Optional[str] = Field(
        default=None, description="추가 컨텍스트 (트리거별 상세)"
    )
    active_role: str = Field(
        default="owner",
        description="Phase 6 #7: 활성 프로필 역할 (owner | manager) — 메모리 권한 필터",
    )
    self_review: bool = Field(
        default=True,
        description="Bonus E1: 자기 답변 검증 후 자체 수정 (브리핑 품질 ↑, 토큰 2배)",
    )


class BriefingResponse(BaseModel):
    briefing_id: Optional[str]
    message: str
    context_memories: list[dict[str, Any]]  # 참고한 메모리 (투명성)
    trigger: BriefingTrigger
    review_meta: Optional[dict[str, Any]] = None  # E1: 검증 결과 (revised, issues)


class ProfileResponse(BaseModel):
    agent_profile: dict[str, Any]
    memory_count: int
    learning_enabled: bool


class DistillRequest(BaseModel):
    store_id: str


# ═══════════════════════════════════════════════════════
# 브리핑 생성 (핵심 엔드포인트)
# ═══════════════════════════════════════════════════════


TRIGGER_INSTRUCTIONS: dict[str, str] = {
    "daily_briefing": (
        "일일 아침 브리핑을 작성하세요. 어제 매출 요약 + 오늘 주목할 포인트 + 운영 팁을 자연스럽게. "
        "과거 패턴에서 교훈 있으면 '지난번 ~했을 때...' 형태로 언급하세요."
    ),
    "sales_anomaly": (
        "매출 이상이 감지됐어요. 사장님께 침착하게 알리고 가능한 원인과 대응책을 2~3개 제시하세요. "
        "과거 비슷한 사례가 있으면 참고해서 구체적으로."
    ),
    "bep_milestone": (
        "BEP 달성을 축하하는 메시지! 이번 달 성과를 구체적 숫자로 인정하고, 남은 기간 추가 목표 제안."
    ),
    "review_surge": (
        "리뷰 급증을 알리고, 긍정/부정 비율과 공통 키워드를 요약하세요."
    ),
    "reorder_reminder": (
        "재주문 시점이 가까워졌음을 알리고, 지난 발주 기준으로 추천 품목을 제안하세요."
    ),
    "manual": "사장님 질문·요청에 맞게 개인화된 응답을 작성하세요.",
}


@router.post("/briefing", response_model=BriefingResponse)
async def generate_briefing(req: BriefingRequest):
    """
    능동 에이전트 브리핑 생성.
    매장 메모리 + 프로필 + 현재 상태 → 개인화된 메시지.
    """
    # 1. 관련 메모리 검색 (중요도·최신성 랭킹) — 권한 필터 적용 (Phase 6 #7)
    memories = await memory_service.search_memories(
        store_id=req.store_id,
        categories=None,
        limit=8,
        active_role=req.active_role,
    )

    # Phase 6 #14: daily_briefing 시 사용자 정의 이상치 룰 자동 평가
    triggered_rules: list[dict] = []
    if req.trigger == "daily_briefing":
        try:
            from app.services import anomaly_evaluator
            triggered_rules = await anomaly_evaluator.evaluate_store_rules(req.store_id)
        except Exception:
            triggered_rules = []

    rule_alert = ""
    if triggered_rules:
        bullets = []
        for t in triggered_rules[:3]:  # 한 번에 최대 3개
            base = f"  - {t['name']}"
            if t.get("evaluated") is not None and t.get("baseline") is not None:
                base += f" (현재 {t['current_value']:.1f}, 기준 {t['baseline']:.1f}, 평가 {t['evaluated']:.1f})"
            bullets.append(base)
        rule_alert = "\n[사장님이 설정한 이상치 룰 트리거]\n" + "\n".join(bullets)

    # 2. 매장 프로필 조회
    profile = await memory_service.get_store_agent_profile(req.store_id)

    # 3. 프롬프트 구성
    memory_lines = (
        "\n".join(
            f"  - [{m['category']}] {m['content']} (중요도 {m['importance']})"
            for m in memories
        )
        if memories
        else "  - (아직 학습된 메모리가 없어요 — 데이터가 쌓일수록 개인화됩니다)"
    )

    profile_json = (
        ", ".join(f"{k}={v}" for k, v in profile.items()) if profile else "(증류된 프로필 없음)"
    )

    instruction = TRIGGER_INSTRUCTIONS.get(req.trigger, TRIGGER_INSTRUCTIONS["manual"])

    prompt = f"""
당신은 '카페 브레인' 능동형 AI 어시스턴트입니다. 이 사장님만을 위한 개인 비서.

[매장 컨텍스트]
{req.store_context}

[증류된 매장 프로필 — 이 사장님의 학습된 성향·패턴]
{profile_json}

[과거에 학습한 메모리 (랭킹 상위 {len(memories)}개)]
{memory_lines}

[현재 트리거 & 추가 컨텍스트]
트리거: {req.trigger}
{req.additional_context or ''}{rule_alert}

[지시사항]
{instruction}

[규칙]
1. 과거 메모리를 참고해 "저번에 ~했었죠" 같은 개인화된 표현 적극 사용
2. 일반론 금지 — 이 매장·이 사장님에만 해당하는 구체적 조언
3. 거부한 제안(rejected_suggestion 카테고리)은 다시 제안하지 말 것
4. 길이: 2~4문장 이내 (채팅 메시지 형식)
5. 따뜻하고 전문적인 톤, 호들갑 X
6. 마지막 줄에 '(ⓘ AI)' 작게 표시

지금 바로 브리핑만 작성해주세요:
""".strip()

    # 4. Gemini 호출 (캐싱 X — 브리핑은 항상 최신 컨텍스트 반영)
    cache_key = build_cache_key(
        store_id=req.store_id,
        template=f"briefing_{req.trigger}",
        params={
            "ctx_hash": str(hash(req.store_context))[:12],
            "memory_count": len(memories),
            "ts": datetime.now(timezone.utc).strftime("%Y-%m-%d-%H"),  # 시간 단위 캐시
        },
    )

    review_meta: Optional[dict[str, Any]] = None
    try:
        # Bonus E1: self_review=true일 때만 비평 패스 추가 (캐시 우회 — 비평은 매번 새로)
        if req.self_review:
            from app.services.gemini_service import generate_with_review
            message, review_meta = await generate_with_review(
                prompt,
                question_for_review=f"{req.trigger} 브리핑",
                show_watermark=False,
            )
        else:
            message = await generate_insight_cached(
                prompt, cache_key=cache_key, ttl_hours=1, show_watermark=False
            )

        # Bonus E2: 메모리·룰을 인용으로 부착
        try:
            from app.services.gemini_service import attach_citations
            cites: list[dict] = []
            for m in memories[:3]:
                cat = m.get("category", "")
                cites.append({"label": f"{cat} 메모리", "kind": "memory"})
            if triggered_rules:
                cites.append({
                    "label": f"트리거된 룰 {len(triggered_rules)}개",
                    "kind": "trend",
                })
            if cites:
                message = attach_citations(message, cites)
        except Exception:
            pass
    except RuntimeError as e:
        raise HTTPException(status_code=503, detail=str(e))

    # 5. 참고 메모리 use_count 증가
    memory_ids = [m["id"] for m in memories]
    if memory_ids:
        await memory_service.mark_memories_used(memory_ids)

    # 6. 브리핑 로그 저장
    briefing_id = await memory_service.log_briefing(
        store_id=req.store_id,
        trigger_type=req.trigger,
        response=message,
        context_memory_ids=memory_ids,
        prompt_snapshot=prompt[:2000],  # 감사용 스냅샷 (용량 제한)
    )

    return BriefingResponse(
        briefing_id=briefing_id,
        message=message,
        context_memories=[
            {"id": m["id"], "category": m["category"], "content": m["content"]}
            for m in memories
        ],
        trigger=req.trigger,
        review_meta=review_meta,
    )


# ═══════════════════════════════════════════════════════
# 매장 프로필 조회 (투명성)
# ═══════════════════════════════════════════════════════


@router.get("/profile", response_model=ProfileResponse)
async def get_profile(store_id: str):
    """
    AI가 이 매장에 대해 알고 있는 것을 투명하게 공개.
    사용자가 '왜 이런 제안?' 클릭 시 활용.
    """
    sb = _get_supabase()
    if sb is None:
        return ProfileResponse(agent_profile={}, memory_count=0, learning_enabled=False)

    # stores에서 프로필 + 학습 플래그
    store_row = await asyncio.to_thread(
        lambda: sb.table("stores")
        .select("agent_profile, agent_learning_enabled")
        .eq("id", store_id)
        .limit(1)
        .execute()
    )
    profile = {}
    learning = True
    if store_row.data:
        profile = store_row.data[0].get("agent_profile") or {}
        learning = store_row.data[0].get("agent_learning_enabled", True)

    # 활성 메모리 개수
    count_row = await asyncio.to_thread(
        lambda: sb.table("agent_memory")
        .select("id", count="exact")
        .eq("store_id", store_id)
        .is_("archived_at", "null")
        .execute()
    )
    memory_count = count_row.count or 0

    return ProfileResponse(
        agent_profile=profile,
        memory_count=memory_count,
        learning_enabled=learning,
    )


# ═══════════════════════════════════════════════════════
# 메모리 → 프로필 증류 (주기적 요약, pg_cron 주간)
# ═══════════════════════════════════════════════════════


@router.post("/distill", response_model=ProfileResponse)
async def distill_profile(req: DistillRequest):
    """
    매장의 수집된 메모리를 분석해 agent_profile JSON으로 증류.
    주 1회 주기 호출 권장 (Cloud Scheduler / pg_cron).
    """
    # 1. 카테고리별 메모리 샘플링
    categories_to_distill = [
        "business_pattern",
        "customer_insight",
        "preference",
        "accepted_suggestion",
    ]

    samples: dict[str, list[str]] = {}
    for cat in categories_to_distill:
        mems = await memory_service.search_memories(
            store_id=req.store_id, categories=[cat], limit=10  # type: ignore[list-item]
        )
        samples[cat] = [m["content"] for m in mems]

    # 2. Gemini로 프로필 증류
    sample_text = "\n\n".join(
        f"[{cat}]\n" + "\n".join(f"  - {c}" for c in items)
        for cat, items in samples.items()
        if items
    )

    if not sample_text.strip():
        return ProfileResponse(
            agent_profile={}, memory_count=0, learning_enabled=True
        )

    distill_prompt = f"""
아래는 어느 카페 매장의 AI가 수집한 메모리 샘플입니다.
이 매장만의 특성·성향·패턴을 JSON으로 증류해주세요.

{sample_text}

출력: 아래 스키마의 JSON만. 해당 없으면 null 또는 빈 배열.
{{
  "busy_days": ["금", "토"],                    // 바쁜 요일
  "peak_hours": [11, 14, 19],                   // 피크 시간대
  "top_menus": ["아이스 아메리카노", "크로플"],  // 인기 메뉴
  "customer_concerns": ["대기시간", "좌석"],    // 고객 반복 불만
  "owner_priorities": ["인건비 절감", "SNS"],   // 사장 관심사
  "responds_well_to": ["할인 제안", "이벤트"],  // 수용 잘하는 제안 유형
  "avoids": ["주휴수당 포함 스케줄"],            // 거부한 제안 유형
  "tone_preference": "polite"                   // 선호 어조
}}

JSON만 출력하세요 (코드블록 없이):
""".strip()

    sb = _get_supabase()
    if sb is None:
        raise HTTPException(status_code=503, detail="Supabase 미설정")

    try:
        from app.services.gemini_service import generate_insight

        raw = await generate_insight(distill_prompt, show_watermark=False)
        # JSON 파싱 (앞뒤 공백·코드블록 제거)
        import json as _json
        import re as _re

        cleaned = _re.sub(r"```(?:json)?\s*|\s*```", "", raw).strip()
        parsed = _json.loads(cleaned)

        # stores.agent_profile 업데이트
        await asyncio.to_thread(
            lambda: sb.table("stores")
            .update({"agent_profile": parsed})
            .eq("id", req.store_id)
            .execute()
        )

        return ProfileResponse(
            agent_profile=parsed,
            memory_count=sum(len(v) for v in samples.values()),
            learning_enabled=True,
        )
    except Exception as e:
        raise HTTPException(status_code=503, detail=f"증류 실패: {str(e)}")
