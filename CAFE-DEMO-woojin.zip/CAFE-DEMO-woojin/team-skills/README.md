# Cafe Brain — 팀 스킬 공유 폴더
> Claude Code 스킬 파일 모음 · 팀원 공유용  
> 마지막 업데이트: 2026-04-14

---

## 스킬이란?

Claude Code에서 `/스킬명` 으로 호출하면 해당 전문 작업을 자동으로 수행하는 **플러그인 단위**입니다.  
스킬 파일(`SKILL.md`)을 설치하면 Claude가 그 분야 전문가처럼 동작합니다.

---

## 설치 방법

### 방법 A — 파일 복사 (로컬 스킬)
```bash
# 스킬 파일을 Claude 글로벌 스킬 디렉토리에 복사
# macOS / Linux
mkdir -p ~/.claude/skills/<스킬명>
cp SKILL.md ~/.claude/skills/<스킬명>/SKILL.md

# Windows
mkdir "%USERPROFILE%\.claude\skills\<스킬명>"
copy SKILL.md "%USERPROFILE%\.claude\skills\<스킬명>\SKILL.md"
```

### 방법 B — Claude Code 내 설치 명령
```
/install-skill <스킬명>
```

---

## 스킬 목록

| 번호 | 폴더 | 스킬명 | 용도 요약 | 호출 예시 |
|------|------|--------|---------|---------|
| 01 | `01_claude-ai-recipes` | claude-ai-recipes | Claude API 코드 레시피 (RAG, tool use, vision 등) | "RAG 구현해줘", "tool calling 예시" |
| 02 | `02_claude-usage-guide` | claude-usage-guide | Claude Code 기능 가이드 (hooks, 메모리, MCP 등) | "hooks 설정법", "CLAUDE.md 어떻게 써?" |
| 03 | `03_dev-workflow-superpowers` | dev-workflow-superpowers | 기능 개발 워크플로 (계획→TDD→리뷰→검증) | "기능 개발 계획부터 짜줘", "TDD로 구현" |
| 04 | `04_frontend-design` | frontend-design | 프로덕션급 UI 컴포넌트·페이지 제작 | "이 페이지 디자인 만들어줘", "UI 개선" |
| 05 | `05_icon-lucide` | icon-lucide | Lucide 아이콘 라이브러리 가이드·추천 | "이 버튼에 맞는 아이콘 뭐야?", "아이콘 추가" |
| 06 | `06_marketing-content` | marketing-content | 마케팅 카피·랜딩 페이지·이메일·전환율 최적화 | "랜딩 페이지 카피 써줘", "이메일 시퀀스" |
| 07 | `07_seo-optimization` | seo-optimization | SEO 감사·기술 SEO 수정·스키마·키워드 | "SEO 감사해줘", "메타태그 최적화" |
| 08 | `08_validate-mvp__remote` | validate-mvp (원격) | MVP·사업 아이디어 가상 페르소나 시장 검증 | "이거 될까?", "MVP 검수해줘" |

---

## 스킬별 상세

---

### 01 · claude-ai-recipes
**언제 써야 하나**: Claude API로 뭔가를 만들 때, AI 기능 구현 레시피가 필요할 때

**주요 기능**
- Claude API 호출 패턴 (스트리밍, 멀티턴, tool use)
- RAG 시스템 구현 (벡터 DB 연동)
- 이미지 분석 (vision), 분류/요약/추출
- Prompt Caching, Batch API
- AI 에이전트 / 서브에이전트 패턴

**발동 키워드**: `Claude API`, `RAG`, `tool use`, `도구 호출`, `prompt caching`, `vision`, `subagent`

---

### 02 · claude-usage-guide
**언제 써야 하나**: Claude Code 기능을 최대한 활용하고 싶을 때

**주요 기능**
- Slash command / 스킬 설정법
- 메모리 시스템 (conversation → project → global)
- Hooks 자동화 (pre/post tool 실행)
- MCP 서버 연동
- 서브에이전트 / 병렬 작업

**발동 키워드**: `Claude Code 사용법`, `slash command`, `hooks`, `MCP`, `메모리 설정`

---

### 03 · dev-workflow-superpowers
**언제 써야 하나**: 새 기능 개발 시 계획 없이 바로 코딩하면 안 될 것 같을 때

**주요 기능**
- 구현 전 설계 검토 (아키텍처 결정)
- TDD 사이클 (Red → Green → Refactor)
- 단계별 작업 분해 + 진행 추적
- 단계 간 코드 리뷰
- git worktree 병렬 개발

**발동 키워드**: `계획 먼저`, `TDD`, `기능 개발`, `작업 분해`, `plan before code`

---

### 04 · frontend-design
**언제 써야 하나**: UI 컴포넌트나 페이지를 만들 때 "AI가 만든 것처럼 생긴" 결과물이 싫을 때

**주요 기능**
- 프로덕션급 컴포넌트 (버튼, 카드, 모달, 폼, 테이블)
- 전체 페이지 (대시보드, 랜딩, 설정, 프로필)
- 반응형 레이아웃, 데이터 시각화
- 접근성(a11y) + 모바일 최적화
- 디자인 시스템 / 토큰 기반 스타일

**발동 키워드**: `UI 만들어`, `컴포넌트 디자인`, `페이지 레이아웃`, `design component`

---

### 05 · icon-lucide
**언제 써야 하나**: UI에 아이콘이 필요한데 어떤 이름인지 모를 때, 아이콘 라이브러리를 교체하고 싶을 때

**주요 기능**
- 1,000+ 오픈소스 SVG 아이콘 검색 · 추천
- React / Vue / Svelte / Angular 설치법
- 기존 Font Awesome · Heroicons 마이그레이션
- Figma 플러그인 연동
- 커스텀 크기 · 색상 · stroke width 가이드

**발동 키워드**: `아이콘`, `icon`, `lucide`, `lucide-react`, `svg icon`

---

### 06 · marketing-content
**언제 써야 하나**: 마케팅 카피, 이메일, 소셜 콘텐츠, 랜딩 페이지 전환율을 높이고 싶을 때

**주요 기능**
- 랜딩 페이지 CRO (전환율 최적화)
- 카피라이팅 (AIDA, PAS, Before-After-Bridge)
- 이메일 시퀀스 (웰컴, 온보딩, 재활성화)
- 소셜 미디어 콘텐츠 (인스타, X, LinkedIn)
- 런칭 전략, 가격 전략, 리퍼럴 프로그램

**발동 키워드**: `마케팅`, `랜딩 페이지`, `카피라이팅`, `전환율`, `이메일`, `launch`

---

### 07 · seo-optimization
**언제 써야 하나**: 사이트 검색 순위를 높이거나 기술적 SEO 문제를 수정하고 싶을 때

**주요 기능**
- 전체 사이트 SEO 감사 (기술·콘텐츠·백링크)
- Core Web Vitals 수정 (LCP, CLS, FID)
- Schema 마크업 생성·검증
- Google AI Overviews(SGE) 최적화
- 로컬 SEO, Search Console / GA4 설정

**발동 키워드**: `SEO`, `검색 최적화`, `구글 순위`, `메타태그`, `PageSpeed`, `키워드`

---

### 08 · validate-mvp (원격 스킬)
**언제 써야 하나**: 만든 것을 런칭하기 전 "이게 실제로 팔릴까?" 검증하고 싶을 때

> ⚠️ 이 스킬은 **원격 스킬**입니다. 로컬 파일이 없으며 `/install-skill anthropic-skills:validate-mvp` 로 설치합니다.

**주요 기능**
- 전문가 팀 시뮬레이션 (UX, 백엔드, 마케팅, 보안 등)
- 타깃 사용자 페르소나 3인 실사용 시뮬레이션
- 라운드별 피드백 → 수정 → 재검증 사이클
- 최종 런칭 판정 (중단 / 수정 후 / 조건부 / 즉시)

**Cafe Brain 프로젝트 실사용 결과**
```
R1 → R3 : ⭐⭐⭐ → ⭐⭐⭐⭐½
판정: ⚡ 조건부 베타 런칭 가능
```

---

## 빠른 설치 스크립트 (Windows)

```powershell
# PowerShell에서 실행 — 7개 로컬 스킬 한번에 설치
$skills = @(
    "01_claude-ai-recipes:claude-ai-recipes",
    "02_claude-usage-guide:claude-usage-guide",
    "03_dev-workflow-superpowers:dev-workflow-superpowers",
    "04_frontend-design:frontend-design",
    "05_icon-lucide:icon-lucide",
    "06_marketing-content:marketing-content",
    "07_seo-optimization:seo-optimization"
)

$skillsDir = "$env:USERPROFILE\.claude\skills"

foreach ($entry in $skills) {
    $folder, $name = $entry -split ":"
    $dest = "$skillsDir\$name"
    New-Item -ItemType Directory -Force -Path $dest | Out-Null
    $src = ".\team-skills\$folder\SKILL.md"
    Copy-Item $src "$dest\SKILL.md" -Force
    Write-Host "✅ 설치됨: $name"
}

Write-Host "`n모든 스킬 설치 완료. Claude Code를 재시작하세요."
```

---

## 빠른 설치 스크립트 (macOS / Linux)

```bash
#!/bin/bash
# team-skills 폴더에서 실행

SKILLS_DIR="$HOME/.claude/skills"
declare -A SKILLS=(
    ["01_claude-ai-recipes"]="claude-ai-recipes"
    ["02_claude-usage-guide"]="claude-usage-guide"
    ["03_dev-workflow-superpowers"]="dev-workflow-superpowers"
    ["04_frontend-design"]="frontend-design"
    ["05_icon-lucide"]="icon-lucide"
    ["06_marketing-content"]="marketing-content"
    ["07_seo-optimization"]="seo-optimization"
)

for folder in "${!SKILLS[@]}"; do
    name="${SKILLS[$folder]}"
    mkdir -p "$SKILLS_DIR/$name"
    cp "$folder/SKILL.md" "$SKILLS_DIR/$name/SKILL.md"
    echo "✅ 설치됨: $name"
done

echo -e "\n모든 스킬 설치 완료. Claude Code를 재시작하세요."
```

---

## 폴더 구조

```
team-skills/
├── README.md                          ← 이 파일
│
├── 01_claude-ai-recipes/
│   └── SKILL.md                       ← Claude API 코드 레시피
│
├── 02_claude-usage-guide/
│   └── SKILL.md                       ← Claude Code 기능 가이드
│
├── 03_dev-workflow-superpowers/
│   └── SKILL.md                       ← TDD · 기능 개발 워크플로
│
├── 04_frontend-design/
│   └── SKILL.md                       ← 프로덕션 UI 컴포넌트 제작
│
├── 05_icon-lucide/
│   └── SKILL.md                       ← Lucide 아이콘 가이드
│
├── 06_marketing-content/
│   └── SKILL.md                       ← 마케팅 카피 · 전환율 최적화
│
├── 07_seo-optimization/
│   └── SKILL.md                       ← SEO 감사 · 기술 SEO
│
└── 08_validate-mvp__remote/
    └── SKILL_INFO.md                  ← 원격 스킬 설치 안내 (파일 없음)
```
