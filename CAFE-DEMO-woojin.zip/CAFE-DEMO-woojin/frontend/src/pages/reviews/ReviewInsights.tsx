// 리뷰 인사이트 레포트 (Issue #4)
// 플랫폼별 별점 분포 + 주/월별 추이 + 키워드 분석 + 레포트 다운로드
import { useMemo } from 'react'
import {
  BarChart, Bar, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip as RechartsTooltip,
  ResponsiveContainer, PieChart, Pie, Cell, Legend,
} from 'recharts'
import { Download, TrendingUp, TrendingDown, Tag, Star } from 'lucide-react'
import type { Review } from '@/types/review'
import { extractPolarKeywords } from '@/lib/koreanTokenizer'
import { useChartColors, tooltipStyle } from '@/lib/chartTheme'

interface ReviewInsightsProps {
  reviews: Review[]
}

export default function ReviewInsights({ reviews }: ReviewInsightsProps) {
  const chart = useChartColors()
  // ─── 플랫폼별 집계 ───
  const platformStats = useMemo(() => {
    const map = new Map<string, { count: number; totalRating: number }>()
    for (const r of reviews) {
      const p = r.platform ?? '기타'
      const prev = map.get(p) ?? { count: 0, totalRating: 0 }
      prev.count += 1
      prev.totalRating += r.rating
      map.set(p, prev)
    }
    return Array.from(map.entries()).map(([platform, { count, totalRating }]) => ({
      platform,
      count,
      avgRating: count > 0 ? +(totalRating / count).toFixed(2) : 0,
    }))
  }, [reviews])

  // ─── 긍정/부정 비율 ───
  const sentiment = useMemo(() => {
    const positive = reviews.filter((r) => r.rating >= 4).length
    const neutral = reviews.filter((r) => r.rating === 3).length
    const negative = reviews.filter((r) => r.rating <= 2).length
    return [
      { name: '긍정 (4-5점)', value: positive, color: '#5A9E6F' },
      { name: '중립 (3점)', value: neutral, color: '#D4A574' },
      { name: '부정 (1-2점)', value: negative, color: '#E07A5F' },
    ]
  }, [reviews])

  // ─── 월별 별점 추이 ───
  const monthlyTrend = useMemo(() => {
    const map = new Map<string, { sum: number; count: number }>()
    for (const r of reviews) {
      const month = r.date.slice(0, 7)
      const prev = map.get(month) ?? { sum: 0, count: 0 }
      prev.sum += r.rating
      prev.count += 1
      map.set(month, prev)
    }
    return Array.from(map.entries())
      .sort(([a], [b]) => a.localeCompare(b))
      .map(([month, { sum, count }]) => ({
        month,
        avgRating: +(sum / count).toFixed(2),
        count,
      }))
  }, [reviews])

  // ─── 긍정·부정 키워드 (Wave 5F: 한국어 형태소 정규화) ───
  const { positive: positiveKeywords, negative: negativeKeywords } = useMemo(
    () => extractPolarKeywords(reviews),
    [reviews]
  )

  // ─── CSV 다운로드 ───
  const downloadCsv = () => {
    const rows = [
      ['항목', '값'],
      ['총 리뷰 수', String(reviews.length)],
      ['평균 별점', reviews.length ? (reviews.reduce((s, r) => s + r.rating, 0) / reviews.length).toFixed(2) : '0'],
      ['긍정 리뷰 수', String(sentiment[0].value)],
      ['중립 리뷰 수', String(sentiment[1].value)],
      ['부정 리뷰 수', String(sentiment[2].value)],
      [''],
      ['플랫폼', '개수', '평균 별점'],
      ...platformStats.map((p) => [p.platform, String(p.count), String(p.avgRating)]),
      [''],
      ['월', '평균 별점', '리뷰 수'],
      ...monthlyTrend.map((m) => [m.month, String(m.avgRating), String(m.count)]),
      [''],
      ['긍정 키워드 TOP 10'],
      ...positiveKeywords.slice(0, 10).map((k) => [k.word, String(k.count)]),
      [''],
      ['부정 키워드 TOP 10'],
      ...negativeKeywords.slice(0, 10).map((k) => [k.word, String(k.count)]),
    ]
    const csv = rows.map((r) => r.map((c) => `"${c.replace(/"/g, '""')}"`).join(',')).join('\n')
    const blob = new Blob(['\uFEFF' + csv], { type: 'text/csv;charset=utf-8;' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `review_insights_${new Date().toISOString().split('T')[0]}.csv`
    a.click()
    URL.revokeObjectURL(url)
  }

  if (reviews.length === 0) {
    return (
      <div className="bg-white rounded-2xl p-10 border border-gray-100 shadow-sm text-center text-gray-400">
        <Star size={32} className="mx-auto mb-2 opacity-30" />
        <p className="text-sm">아직 분석할 리뷰가 없어요</p>
      </div>
    )
  }

  return (
    <div className="space-y-4">
      {/* 상단 헤더 + 다운로드 */}
      <div className="flex items-center justify-between flex-wrap gap-2">
        <div>
          <h2 className="text-sm font-bold text-[#2C1810]">리뷰 인사이트 ({reviews.length}건)</h2>
          <p className="text-xs text-gray-400 mt-0.5">플랫폼별 현황 + 키워드 분석</p>
        </div>
        <button
          onClick={downloadCsv}
          className="flex items-center gap-1.5 px-3 py-1.5 bg-[#2C1810] text-white rounded-lg text-xs font-medium hover:bg-[#3d2418] transition-colors"
        >
          <Download size={12} /> 레포트 다운로드 (.csv)
        </button>
      </div>

      {/* 플랫폼별 분포 */}
      <div className="bg-white rounded-2xl p-4 border border-gray-100 shadow-sm">
        <h3 className="text-sm font-bold text-[#2C1810] mb-3">📱 플랫폼별 현황</h3>
        <ResponsiveContainer width="100%" height={180}>
          <BarChart data={platformStats}>
            <CartesianGrid strokeDasharray="3 3" stroke={chart.grid} />
            <XAxis dataKey="platform" tick={{ fontSize: 11, fill: chart.tick }} />
            <YAxis tick={{ fontSize: 11, fill: chart.tick }} />
            <RechartsTooltip contentStyle={tooltipStyle(chart)} />
            <Bar dataKey="count" name="리뷰 수" fill={chart.accent} radius={[8, 8, 0, 0]} />
          </BarChart>
        </ResponsiveContainer>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 mt-3">
          {platformStats.map((p) => (
            <div key={p.platform} className="bg-[#FAFAF8] rounded-xl p-2.5 text-center">
              <p className="text-xs text-gray-400">{p.platform}</p>
              <p className="text-sm font-bold text-[#2C1810] mt-1">⭐ {p.avgRating} ({p.count}건)</p>
            </div>
          ))}
        </div>
      </div>

      {/* 감정 분포 — 라벨 간소화 */}
      <div className="bg-white rounded-2xl p-4 border border-gray-100 shadow-sm">
        <h3 className="text-sm font-bold text-[#2C1810] mb-3">💭 긍정/부정 비율</h3>
        <ResponsiveContainer width="100%" height={240}>
          <PieChart margin={{ top: 5, right: 5, bottom: 25, left: 5 }}>
            <Pie
              data={sentiment}
              cx="50%"
              cy="45%"
              labelLine={false}
              label={({ percent }) =>
                (percent ?? 0) > 0.06 ? `${Math.round((percent ?? 0) * 100)}%` : ''
              }
              outerRadius={75}
              innerRadius={38}
              paddingAngle={2}
              dataKey="value"
            >
              {sentiment.map((entry, i) => (
                <Cell key={i} fill={entry.color} stroke="none" />
              ))}
            </Pie>
            <RechartsTooltip
              formatter={(v) => `${v}건`}
              contentStyle={{ background: 'var(--bg-card)', border: '1px solid var(--border-hair)', borderRadius: 12, fontSize: 12 }}
            />
            <Legend
              iconType="circle"
              wrapperStyle={{ fontSize: 11, paddingTop: 12 }}
              verticalAlign="bottom"
              height={32}
            />
          </PieChart>
        </ResponsiveContainer>
      </div>

      {/* 월별 추이 */}
      {monthlyTrend.length > 1 && (
        <div className="bg-white rounded-2xl p-4 border border-gray-100 shadow-sm">
          <h3 className="text-sm font-bold text-[#2C1810] mb-3">📈 월별 별점 추이</h3>
          <ResponsiveContainer width="100%" height={200}>
            <LineChart data={monthlyTrend}>
              <CartesianGrid strokeDasharray="3 3" stroke={chart.grid} />
              <XAxis dataKey="month" tick={{ fontSize: 11, fill: chart.tick }} />
              <YAxis domain={[0, 5]} tick={{ fontSize: 11, fill: chart.tick }} />
              <RechartsTooltip contentStyle={tooltipStyle(chart)} />
              <Line type="monotone" dataKey="avgRating" name="평균 별점" stroke={chart.accent} strokeWidth={2} dot={{ fill: chart.accent }} />
            </LineChart>
          </ResponsiveContainer>
        </div>
      )}

      {/* 키워드 분석 */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* 긍정 키워드 */}
        <div className="bg-white rounded-2xl p-4 border border-green-100 shadow-sm">
          <h3 className="text-sm font-bold text-green-700 mb-3 flex items-center gap-2">
            <TrendingUp size={14} /> 긍정 리뷰 키워드
          </h3>
          {positiveKeywords.length === 0 ? (
            <p className="text-xs text-gray-400 text-center py-4">긍정 리뷰가 아직 없어요</p>
          ) : (
            <div className="flex flex-wrap gap-1.5">
              {positiveKeywords.map((k) => (
                <span
                  key={k.word}
                  className="bg-green-50 text-green-700 text-xs px-2.5 py-1 rounded-full font-medium"
                  style={{ fontSize: `${Math.min(14, 10 + k.count)}px` }}
                >
                  {k.word} {k.count > 1 && <em className="text-green-400 not-italic text-[10px]">×{k.count}</em>}
                </span>
              ))}
            </div>
          )}
        </div>

        {/* 부정 키워드 */}
        <div className="bg-white rounded-2xl p-4 border border-red-100 shadow-sm">
          <h3 className="text-sm font-bold text-red-700 mb-3 flex items-center gap-2">
            <TrendingDown size={14} /> 부정 리뷰 키워드
          </h3>
          {negativeKeywords.length === 0 ? (
            <p className="text-xs text-gray-400 text-center py-4">부정 리뷰가 없어요 🎉</p>
          ) : (
            <div className="flex flex-wrap gap-1.5">
              {negativeKeywords.map((k) => (
                <span
                  key={k.word}
                  className="bg-red-50 text-red-700 text-xs px-2.5 py-1 rounded-full font-medium"
                  style={{ fontSize: `${Math.min(14, 10 + k.count)}px` }}
                >
                  {k.word} {k.count > 1 && <em className="text-red-400 not-italic text-[10px]">×{k.count}</em>}
                </span>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* 안내 */}
      <div className="bg-blue-50/50 border border-blue-100 rounded-xl p-3 text-xs text-blue-700 flex items-start gap-2">
        <Tag size={13} className="mt-0.5 shrink-0" />
        <div>
          키워드는 리뷰 본문의 빈도 분석 결과입니다. 반복 언급되는 키워드는 메뉴·서비스 개선의 신호로 활용하세요.
        </div>
      </div>
    </div>
  )
}
