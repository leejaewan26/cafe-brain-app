// 스마트 스케줄링 모듈 타입 정의
export type EmploymentType = 'full_time' | 'part_time' | 'daily'

// 직원 정보
export interface Employee {
  id: string
  name: string
  employment_type: EmploymentType
  hourly_rate: number          // 시급 (원)
  preferred_start: number      // 선호 시작 시간 (0-23)
  preferred_end: number        // 선호 종료 시간 (0-23)
  max_weekly_hours: number     // 주당 최대 근무시간
  unavailable_days: number[]   // 불가능한 요일 (0=일, 1=월, ..., 6=토)
  color: string                // 캘린더 표시 색상
}

// 개별 근무 시프트 (1일)
export interface Shift {
  id: string
  employee_id: string
  week_start: string           // 해당 주 월요일 ISO 날짜 'YYYY-MM-DD'
  day_index: number            // 0=월, 1=화, ..., 6=일
  start_hour: number           // 근무 시작 시간 (0-23)
  end_hour: number             // 근무 종료 시간 (1-24)
  break_minutes: number        // 휴게시간 (분) - 자동 계산
  is_off: boolean              // 휴무
  warnings: string[]           // 노무 규정 위반 경고 목록
}

// 주별 인건비 분석
export interface WeeklyLaborReport {
  week_start: string
  total_labor_cost: number     // 총 인건비
  estimated_revenue: number    // 예상 매출 (매출 분석에서 연동)
  labor_cost_ratio: number     // 인건비 비율 (%)
  labor_cost_cap: number       // 인건비 상한 (예상 매출 × 설정 비율)
  employee_breakdown: EmployeeLaborBreakdown[]
  is_over_cap: boolean         // 상한 초과 여부
}

// 직원별 인건비 내역
export interface EmployeeLaborBreakdown {
  employee_id: string
  employee_name: string
  total_hours: number
  regular_pay: number          // 기본 인건비
  juhusu: number               // 주휴수당 (주 15시간 이상 시 적용)
  total_pay: number
  qualifies_for_juhusu: boolean
}

// 노무 규정 검증 결과
export interface LaborValidation {
  is_valid: boolean
  warnings: LaborWarning[]
}

export interface LaborWarning {
  employee_id: string
  day_index: number
  type: 'over_max_hours' | 'missing_break' | 'over_labor_cap' | 'unavailable_day'
  message: string
}

// 자동 스케줄 생성 설정
export interface AutoScheduleConfig {
  week_start: string
  min_daily_staff: number      // 최소 인원 (비피크)
  max_daily_staff: number      // 최대 인원 (피크)
  labor_cost_ratio_cap: number // 인건비 상한 비율 (default 0.25 = 25%)
  // Issue #6: 인건비 절약 모드
  juhusu_mode: 'include' | 'minimize'
  // 'include': 주 15시간 이상 자유 배치 (주휴수당 포함)
  // 'minimize': 전 직원 주 15시간 미만 유지 (주휴수당 최소화)
}

// Issue #6: 인건비 절약 모드 검증 결과
export interface JuhusuModeWarning {
  type: 'insufficient_staff' | 'over_capacity'
  message: string
  additional_staff_needed: number
}
