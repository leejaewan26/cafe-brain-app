// useTheme — 다크모드 적용 훅 (Issue #16)
// 동작:
//  1) settingsStore.theme 값 (light/dark/system) 감지
//  2) system이면 prefers-color-scheme 미디어 쿼리 구독
//  3) <html> 엘리먼트에 `.dark` 또는 `.light` 클래스 토글
//  4) 테마 변경 시 부드러운 전환 (CSS에서 transition 처리)
import { useEffect } from 'react'
import { useSettingsStore } from '@/store/settingsStore'

/**
 * 실제 적용될 테마를 계산 (system인 경우 OS 설정 반영)
 */
function resolveTheme(mode: 'light' | 'dark' | 'system'): 'light' | 'dark' {
  if (mode === 'system') {
    if (typeof window === 'undefined') return 'light'
    return window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light'
  }
  return mode
}

/**
 * 테마를 DOM에 적용 (html 클래스 + data 속성 토글)
 */
function applyTheme(resolved: 'light' | 'dark') {
  if (typeof document === 'undefined') return
  const root = document.documentElement
  root.classList.toggle('dark', resolved === 'dark')
  root.dataset.theme = resolved
}

/**
 * 앱 부트 시 한 번 호출 (main.tsx에서)
 * StrictMode 이중 실행에 안전하도록 순수 DOM 조작만 수행.
 */
export function initThemeOnBoot() {
  try {
    const raw = localStorage.getItem('cafe-brain-settings')
    const mode = (raw ? (JSON.parse(raw).state?.theme ?? 'system') : 'system') as
      'light' | 'dark' | 'system'
    applyTheme(resolveTheme(mode))
  } catch {
    applyTheme('light')
  }
}

/**
 * 컴포넌트에서 테마 변경을 구독
 */
export function useTheme() {
  const mode = useSettingsStore((s) => s.theme)

  useEffect(() => {
    const resolved = resolveTheme(mode)
    applyTheme(resolved)

    // system 모드일 때만 OS 테마 변경 구독
    if (mode !== 'system' || typeof window === 'undefined') return

    const mq = window.matchMedia('(prefers-color-scheme: dark)')
    const onChange = () => applyTheme(mq.matches ? 'dark' : 'light')
    mq.addEventListener('change', onChange)
    return () => mq.removeEventListener('change', onChange)
  }, [mode])

  return { mode, resolved: resolveTheme(mode) }
}
