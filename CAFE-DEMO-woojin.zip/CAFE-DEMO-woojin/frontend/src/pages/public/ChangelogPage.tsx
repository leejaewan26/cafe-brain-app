// J1 — 공개 변경 이력 페이지
// SEO 친화 + 사용자 신뢰 (활발한 개발 노출)
import { Link } from 'react-router-dom'
import { ChevronLeft, Sparkles, Tag, GitBranch } from 'lucide-react'
import { cn } from '@/lib/utils'

interface ChangelogEntry {
  version: string
  date: string
  highlight?: boolean
  added?: string[]
  improved?: string[]
  fixed?: string[]
}

const CHANGELOG: ChangelogEntry[] = [
  {
    version: '1.3.0',
    date: '2026-05-06',
    highlight: true,
    added: [
      '🆕 송장·세금계산서 OCR 자동 입력 — 사진 한 장으로 매입 데이터 등록',
      '🆕 다단계 전략 분해 (Multi-step Plan) — "분기 매출 10% 끌어올릴 전략" 같은 복잡한 목표를 4~5단계로 자동 분해',
      '🆕 A/B 옵션 비교 — "할인 50% vs 1+1" 같은 의사결정에 점수 + pros/cons',
      '🆕 의미적 메모리 검색 — pgvector 기반 자연어 검색 ("고객 불만"으로 "민원" "악평" 함께 매칭)',
      '🆕 데이터 ZIP 다운로드 (PIPA 데이터 이동권)',
      '🆕 14일 무료 체험 + 구독 카운트다운',
      '🆕 데모 데이터 시더 (30일치 가짜 매출·메뉴·리뷰 자동 생성)',
      '🆕 음성 입력 (STT) — AI 어시스턴트에 마이크 버튼',
      '🆕 운영자 admin 대시보드 (전체 매장 상태 모니터링)',
      '🆕 트랜잭션 이메일 (Resend)',
      '🆕 Toss Payments 정기결제 + 웹훅 + 자동 갱신 + 해지',
      '🆕 네이버 매장 매핑 + 리뷰 동기화 (3중 fallback)',
      '🆕 POS 자동 동기화 (Toss POS / KIS / 스마트브로 + CSV)',
      '🆕 Instagram 자동 게시 (Graph API + n8n 멀티채널 우회)',
      '🆕 다국어 (한 ↔ 영)',
      '🆕 변경 이력 + 공개 로드맵 페이지',
      '🆕 청결 점수 OCR (매장 사진으로 위생 진단)',
      '🆕 직원 교육 퀴즈 자동 생성',
      '🆕 음성 메모 → 자동 정리',
      '🆕 동종업계 익명 벤치마크',
    ],
    improved: [
      '🔧 API /api/v1/* 버전 prefix 도입 (legacy /api/* 는 deprecated)',
      '🔧 OpenAPI docs 정리 — description, examples, contact',
      '🔧 모바일 풀-투-리프레시 제스처',
      '🔧 Tool Use 도구 3개 추가 (재고 부족, 오늘 일정, 회계 요약)',
      '🔧 Self-correction 매출 인사이트로 확대 (E1 → 매출 분석)',
      '🔧 풀 텍스트 대화 검색 (모든 세션 횡단)',
      '🔧 i18next chunk 분리로 초기 로딩 속도 개선',
      '🔧 데이터 보관 cron (chat 1년 / 브리핑 6개월 / 레이턴시 30일)',
      '🔧 Feature flags (자체 OSS, 매장별 override)',
      '🔧 감사로그 전체 화면 + CSV export',
    ],
  },
  {
    version: '1.2.0',
    date: '2026-04-15',
    added: [
      '🆕 7-source 시장 트렌드 분석 (인스타·네이버·유튜브·뉴스 등)',
      '🆕 Vision 첨부 (사진으로 음료·메뉴 분석)',
      '🆕 능동 브리핑 (아침마다 AI가 먼저 인사이트 제시)',
      '🆕 이상치 룰 빌더 (사장님이 직접 알림 조건 정의)',
    ],
    improved: [
      '🔧 메모리 압축 — 30일 이상 메모리 자동 요약',
      '🔧 SLO 트래커 + 매장별 p95/p99 응답시간',
    ],
  },
  {
    version: '1.1.0',
    date: '2026-03-01',
    added: [
      '🆕 멀티 프로필 (사장/매니저/직원 권한 분리)',
      '🆕 발주 관리 + 공급처 절감 AI',
      '🆕 회계·손익 모듈',
      '🆕 PWA 설치 + 오프라인 모드',
      '🆕 다크모드',
    ],
    fixed: [
      '🐛 메모리 중복 생성 버그 (동일 카테고리 → 병합)',
      '🐛 BEP 게이지 음수 표시 오류',
    ],
  },
  {
    version: '1.0.0',
    date: '2026-01-15',
    highlight: true,
    added: [
      '🎉 정식 출시!',
      '매출 분석 + 리뷰 자동 답글 + 메뉴 관리 + AI 어시스턴트',
    ],
  },
]

export default function ChangelogPage() {
  return (
    <div className="min-h-screen bg-[#FAFAF8]">
      <header className="bg-white border-b border-gray-100 sticky top-0 z-10">
        <div className="max-w-3xl mx-auto px-4 py-3 flex items-center gap-3">
          <Link to="/" className="text-gray-400 hover:text-[#2C1810]">
            <ChevronLeft size={18} />
          </Link>
          <div className="flex items-center gap-2">
            <GitBranch size={16} className="text-[#D4A574]" />
            <h1 className="text-base font-bold text-[#2C1810]">변경 이력</h1>
          </div>
          <Link
            to="/roadmap"
            className="ml-auto text-xs text-[#D4A574] hover:text-[#c4956a] font-semibold"
          >
            로드맵 보기 →
          </Link>
        </div>
      </header>

      <main className="max-w-3xl mx-auto px-4 py-8 space-y-6">
        <p className="text-sm text-gray-500 leading-relaxed">
          카페 브레인은 매주 업데이트됩니다. 새 기능 제안은{' '}
          <a href="mailto:support@cafe-brain.app" className="text-[#D4A574] underline">support@cafe-brain.app</a> 으로
          알려주세요.
        </p>

        {CHANGELOG.map((entry) => (
          <article
            key={entry.version}
            className={cn(
              'bg-white rounded-2xl border shadow-sm p-5',
              entry.highlight ? 'border-[#D4A574]' : 'border-gray-100'
            )}
          >
            <header className="flex items-baseline gap-3 mb-4">
              <span className={cn(
                'inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-bold',
                entry.highlight
                  ? 'bg-[#D4A574] text-[#2C1810]'
                  : 'bg-gray-100 text-gray-600'
              )}>
                {entry.highlight && <Sparkles size={11} />}
                <Tag size={11} /> v{entry.version}
              </span>
              <time className="text-xs text-gray-400">{entry.date}</time>
            </header>

            {entry.added && entry.added.length > 0 && (
              <Section title="추가" entries={entry.added} color="#22C55E" />
            )}
            {entry.improved && entry.improved.length > 0 && (
              <Section title="개선" entries={entry.improved} color="#4A90A4" />
            )}
            {entry.fixed && entry.fixed.length > 0 && (
              <Section title="수정" entries={entry.fixed} color="#E07A5F" />
            )}
          </article>
        ))}
      </main>

      <footer className="max-w-3xl mx-auto px-4 py-12 text-center text-xs text-gray-400">
        © 2026 Cafe Brain. 작은 카페에 큰 도움이 되겠습니다.
      </footer>
    </div>
  )
}

function Section({ title, entries, color }: { title: string; entries: string[]; color: string }) {
  return (
    <div className="mb-3 last:mb-0">
      <h3 className="text-xs font-bold mb-1.5" style={{ color }}>
        {title}
      </h3>
      <ul className="space-y-1">
        {entries.map((e, i) => (
          <li key={i} className="text-sm text-gray-700 leading-relaxed pl-1">
            {e}
          </li>
        ))}
      </ul>
    </div>
  )
}
