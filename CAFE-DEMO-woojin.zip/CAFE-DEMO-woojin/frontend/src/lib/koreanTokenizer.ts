// 한국어 간이 토크나이저 + 조사·어미 제거 (Wave 5F)
// konlpy 같은 완전 형태소 분석기는 Phase 2, MVP는 규칙 기반.

// 주요 조사 (뒤에 붙는 것) — 긴 것부터 매칭
const PARTICLES = [
  '에서는', '에서의', '에서', '부터는', '까지는', '으로는', '으로부터',
  '에게서', '에게로', '에게는', '에게',
  '으로써', '으로서', '으로', '로써', '로서',
  '이라는', '라는', '이라고', '라고', '이란', '란',
  '이랑', '랑', '하고', '과는', '와는',
  '도요', '요는', '처럼', '보다', '마다', '까지', '조차', '마저', '뿐이', '뿐만',
  '이고', '이며', '이면', '이나', '이든', '이랑',
  '까지', '부터', '마다',
  '는', '은', '이', '가', '을', '를', '에', '의', '도', '만', '과', '와', '나', '든', '야', '요',
]

// 동사·형용사 어미 (활용형)
const ENDINGS = [
  '습니다', '입니다', '했습니다', '했어요', '했네요', '합니다', '해요', '해서', '하는데', '하면',
  '있어요', '있습니다', '없어요', '없습니다', '같아요', '같습니다',
  '네요', '군요', '거든요', '더라고요', '더라구요', '었어요', '었네요',
  '이에요', '이예요', '예요', '이야', '이었', '였어',
  '는데', '으면', '어서', '아서',
  '어요', '아요', '었', '였',
]

// 불용어 (의미 없는 일반어)
const STOPWORDS = new Set([
  '그리고', '하지만', '그런데', '그래서', '그러나', '그런', '그거', '이거', '저거',
  '정말', '너무', '조금', '많이', '진짜', '완전', '되게', '엄청', '약간',
  '같아', '같은', '같이', '같은데', '있고', '없고',
  '것', '수', '때', '곳', '분', '번', '개', '건', '데',
  '저', '제', '그', '이', '저희', '저는', '제가',
  '게', '겁니다', '거든요',
  '뭐', '무엇', '어떤', '어느', '어떻게', '어디',
  '그게', '이게', '저게', '그건', '이건', '저건',
  '여기', '거기', '저기',
])

/**
 * 토큰에서 조사·어미 제거 시도.
 * "아메리카노를" → "아메리카노"
 * "맛있었어요" → "맛있"
 */
function stripSuffix(token: string): string {
  if (token.length <= 2) return token
  for (const suffix of [...PARTICLES, ...ENDINGS]) {
    if (token.endsWith(suffix) && token.length - suffix.length >= 2) {
      return token.slice(0, -suffix.length)
    }
  }
  return token
}

/**
 * 텍스트 배열에서 키워드 빈도 추출.
 * 조사·어미 정규화 후 빈도 집계.
 *
 * @param texts 분석할 텍스트 배열
 * @param minLength 최소 토큰 길이 (기본 2)
 * @param topN 반환할 상위 N개
 */
export function extractKeywords(
  texts: string[],
  minLength = 2,
  topN = 20,
): { word: string; count: number }[] {
  const counts = new Map<string, number>()

  for (const text of texts) {
    const tokens = text
      .toLowerCase()
      .replace(/[^\w가-힣ㄱ-ㅎㅏ-ㅣ\s]/g, ' ')
      .split(/\s+/)
      .filter((t) => t.length >= minLength && !STOPWORDS.has(t))

    // 각 토큰에서 조사·어미 제거
    for (const token of tokens) {
      const normalized = stripSuffix(token)
      if (normalized.length < minLength) continue
      if (STOPWORDS.has(normalized)) continue
      counts.set(normalized, (counts.get(normalized) ?? 0) + 1)
    }
  }

  return Array.from(counts.entries())
    .map(([word, count]) => ({ word, count }))
    .sort((a, b) => b.count - a.count)
    .slice(0, topN)
}

/** 긍정·부정 별도로 키워드 추출 (ReviewInsights용) */
export function extractPolarKeywords<T extends { content: string; rating: number }>(
  items: T[],
) {
  const positive = extractKeywords(
    items.filter((i) => i.rating >= 4).map((i) => i.content),
    2,
    15,
  )
  const negative = extractKeywords(
    items.filter((i) => i.rating <= 2).map((i) => i.content),
    2,
    15,
  )
  return { positive, negative }
}
