// 5단계 온보딩 위자드 — Day 3-2: 빠른 시작(Quick Start) 플로우 추가
// /ultrareview U15·U22 피드백: 8칸 입력 후 포기 → 필수 2칸(매장명·대표자명)만 받고
// 나머지는 합리적 기본값으로 즉시 대시보드 진입. 설정에서 나중에 보완 가능.
import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { supabase } from '@/lib/supabase'
import { useAuth } from '@/hooks/useAuth'
import { useAuthStore } from '@/store/authStore'
import { useProfileStore } from '@/store/profileStore'
import type { OnboardingData } from '@/types/store'
import {
  Coffee, MapPin, BarChart2, Palette, CheckCircle2, ChevronRight, ChevronLeft, Loader2,
  Zap,
} from 'lucide-react'
import { cn } from '@/lib/utils'
import { track, identify } from '@/lib/analytics'

// 온보딩 단계 정보
const STEPS = [
  { id: 1, title: '매장 기본 정보', icon: Coffee },
  { id: 2, title: '상권 유형', icon: MapPin },
  { id: 3, title: '운영 현황', icon: BarChart2 },
  { id: 4, title: '매장 분위기', icon: Palette },
  { id: 5, title: '설정 완료', icon: CheckCircle2 },
]

// 상권 유형 옵션
const DISTRICT_OPTIONS = [
  { value: '주택가', emoji: '🏘️', desc: '주민 단골 중심' },
  { value: '오피스', emoji: '🏢', desc: '직장인 런치·테이크아웃' },
  { value: '대학가', emoji: '🎓', desc: '학생·카공족 중심' },
  { value: '관광지', emoji: '🗺️', desc: '관광객·인스타 스팟' },
  { value: '복합', emoji: '🌆', desc: '다양한 고객층 혼재' },
] as const

// 메뉴 수 옵션
const MENU_COUNT_OPTIONS = [5, 10, 15, 20, 30]

// 직원 수 옵션
const EMPLOYEE_COUNT_OPTIONS = [1, 2, 3, 5, 10]

// 월 매출 범위 옵션
const MONTHLY_SALES_OPTIONS = [
  { label: '500만원 미만', value: 3000000 },
  { label: '500~1,000만원', value: 7500000 },
  { label: '1,000~2,000만원', value: 15000000 },
  { label: '2,000~3,000만원', value: 25000000 },
  { label: '3,000만원 이상', value: 35000000 },
]

// 분위기 키워드 옵션
const AMBIANCE_OPTIONS = [
  '모던', '우드톤', '레트로', '미니멀', '빈티지', '내추럴',
  '아늑한', '감성적', '시크', '밝은', '조용한', '개방적',
]

export default function OnboardingPage() {
  const navigate = useNavigate()
  const { user, setIsOnboarded } = useAuth()
  const { setStoreInfo } = useAuthStore()

  const [currentStep, setCurrentStep] = useState(1)
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState('')

  // 온보딩 데이터 상태
  const [data, setData] = useState<Partial<OnboardingData>>({
    store_name: '',
    owner_name: '',
    district_type: undefined,
    menu_count: 10,
    employee_count: 2,
    avg_monthly_sales: 7500000,
    ambiance_keywords: [],
  })

  // 다음 단계로 이동
  const goNext = () => {
    if (currentStep < 5) setCurrentStep((s) => s + 1)
  }

  // 이전 단계로 이동
  const goPrev = () => {
    if (currentStep > 1) setCurrentStep((s) => s - 1)
  }

  // 분위기 키워드 토글
  const toggleKeyword = (keyword: string) => {
    const keywords = data.ambiance_keywords ?? []
    if (keywords.includes(keyword)) {
      setData({ ...data, ambiance_keywords: keywords.filter((k) => k !== keyword) })
    } else if (keywords.length < 3) {
      setData({ ...data, ambiance_keywords: [...keywords, keyword] })
    }
  }

  // Day 3-2: 빠른 시작 — 필수 2칸만 받고 합리적 기본값으로 대시보드 진입
  // 사장님은 "설정 > 매장 정보"에서 나중에 보완 가능
  const handleQuickStart = async () => {
    if (!user) return
    if (!data.store_name?.trim() || !data.owner_name?.trim()) {
      setError('매장명과 대표자명만 입력하시면 바로 시작할 수 있어요.')
      return
    }
    setError('')
    setIsLoading(true)
    try {
      const storeData = {
        id: user.id,
        store_name: data.store_name.trim(),
        owner_name: data.owner_name.trim(),
        district_type: '복합' as const,   // 가장 포괄적인 기본값
        menu_count: 10,
        employee_count: 2,
        avg_monthly_sales: 7500000,
        ambiance_keywords: ['아늑한', '모던', '감성적'],
        target_labor_ratio: 0.25,
      }
      const { error: dbError } = await supabase
        .from('stores')
        .upsert(storeData, { onConflict: 'id' })
      if (dbError) throw dbError

      // 기본 owner 프로필 생성
      const { data: existing } = await supabase
        .from('profiles').select('*').eq('store_id', user.id).limit(1)
      let profile = existing?.[0]
      if (!profile) {
        const { data: created } = await supabase.from('profiles').insert({
          store_id: user.id, name: storeData.owner_name, role: 'owner',
          avatar_emoji: '👨‍💼', avatar_color: '#D4A574',
        }).select().single()
        profile = created
      }

      setStoreInfo({ ...storeData, created_at: new Date().toISOString() })
      setIsOnboarded(true)
      if (profile) useProfileStore.getState().setActiveProfile(profile)
      // Day 7-1: 빠른 시작 이벤트
      identify(user.id, { signup_method: 'quick_start', district: storeData.district_type })
      track('onboarding_quick_start', { store_id: user.id })
      track('onboarding_complete', { store_id: user.id, fast_track: true })
      navigate('/dashboard?welcome=1') // 환영 투어 트리거
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : '저장 중 오류가 발생했습니다.')
    } finally {
      setIsLoading(false)
    }
  }

  // 온보딩 완료 - Supabase stores 테이블에 저장
  const handleComplete = async () => {
    if (!user) return
    setError('')
    setIsLoading(true)
    try {
      const storeData = {
        id: user.id,
        store_name: data.store_name!,
        owner_name: data.owner_name!,
        district_type: data.district_type!,
        menu_count: data.menu_count!,
        employee_count: data.employee_count!,
        avg_monthly_sales: data.avg_monthly_sales!,
        ambiance_keywords: data.ambiance_keywords!,
        target_labor_ratio: 0.25, // 기본값 25%
      }

      const { error: dbError } = await supabase
        .from('stores')
        .upsert(storeData, { onConflict: 'id' })

      if (dbError) throw dbError

      // Critical C2: 기본 owner 프로필 자동 생성 (Issue #5)
      // 이미 있으면 무시 (005 마이그레이션의 자동 생성과 idempotent)
      const { data: existingProfiles } = await supabase
        .from('profiles')
        .select('id, name, role, store_id, avatar_emoji, avatar_color, created_at')
        .eq('store_id', user.id)
        .limit(1)

      let activeProfileData = existingProfiles?.[0]

      if (!activeProfileData) {
        const { data: created, error: profileErr } = await supabase
          .from('profiles')
          .insert({
            store_id: user.id,
            name: data.owner_name!,
            role: 'owner',
            avatar_emoji: '👨‍💼',
            avatar_color: '#D4A574',
          })
          .select()
          .single()
        if (profileErr) {
          // 프로필 생성 실패해도 온보딩은 진행 (사용자가 /profile-select에서 추가 가능)
          console.error('기본 프로필 생성 실패:', profileErr.message)
        } else {
          activeProfileData = created
        }
      }

      // 전역 상태 업데이트
      setStoreInfo({ ...storeData, created_at: new Date().toISOString() })
      setIsOnboarded(true)
      if (activeProfileData) {
        useProfileStore.getState().setActiveProfile(activeProfileData)
      }
      // Day 7-1: 정식 온보딩 완료 이벤트
      identify(user.id, { signup_method: 'full', district: storeData.district_type })
      track('onboarding_complete', {
        store_id: user.id,
        fast_track: false,
        menu_count: storeData.menu_count,
        employee_count: storeData.employee_count,
      })
      navigate('/dashboard')
    } catch (err: unknown) {
      const message = err instanceof Error ? err.message : '저장 중 오류가 발생했습니다.'
      setError(message)
    } finally {
      setIsLoading(false)
    }
  }

  // 단계별 유효성 검사
  const isStepValid = () => {
    switch (currentStep) {
      case 1: return !!(data.store_name?.trim() && data.owner_name?.trim())
      case 2: return !!data.district_type
      case 3: return !!(data.menu_count && data.employee_count && data.avg_monthly_sales)
      case 4: return (data.ambiance_keywords?.length ?? 0) >= 1 // Day 3-2: 1개만 필수
      default: return true
    }
  }

  return (
    <div className="min-h-screen bg-[#FAFAF8] flex items-center justify-center px-4 py-8">
      <div className="w-full max-w-lg">
        {/* 헤더 */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-12 h-12 rounded-xl bg-[#2C1810] mb-3">
            <Coffee className="w-6 h-6 text-[#D4A574]" />
          </div>
          <h1 className="text-2xl font-bold text-[#2C1810]">카페 브레인 설정</h1>
          <p className="text-gray-500 text-sm mt-1">AI가 내 카페를 이해할 수 있도록 알려주세요</p>
        </div>

        {/* 진행 표시바 */}
        <div className="flex items-center mb-8">
          {STEPS.map((step, idx) => (
            <div key={step.id} className="flex items-center flex-1 last:flex-none">
              <div
                className={cn(
                  'w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold transition-all duration-300 shrink-0',
                  currentStep > step.id
                    ? 'bg-[#D4A574] text-white'
                    : currentStep === step.id
                    ? 'bg-[#2C1810] text-white ring-4 ring-[#2C1810]/20'
                    : 'bg-gray-200 text-gray-400'
                )}
              >
                {currentStep > step.id ? '✓' : step.id}
              </div>
              {idx < STEPS.length - 1 && (
                <div
                  className={cn(
                    'flex-1 h-0.5 mx-1 transition-all duration-300',
                    currentStep > step.id ? 'bg-[#D4A574]' : 'bg-gray-200'
                  )}
                />
              )}
            </div>
          ))}
        </div>

        {/* 카드 */}
        <div className="bg-white rounded-2xl shadow-xl p-8 border border-gray-100 min-h-[360px] flex flex-col">
          <div className="flex-1">
            {/* Step 1: 매장 기본 정보 + 빠른 시작 (Day 3-2) */}
            {currentStep === 1 && (
              <div className="space-y-5 animate-in fade-in slide-in-from-right-4 duration-300">
                <h2 className="text-xl font-bold text-[#2C1810]">매장 기본 정보</h2>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1.5">매장명 *</label>
                  <input
                    type="text"
                    value={data.store_name}
                    onChange={(e) => setData({ ...data, store_name: e.target.value })}
                    placeholder="예: 브라운브루잉 카페"
                    className="w-full px-4 py-2.5 rounded-xl border border-gray-200 text-sm focus:outline-none focus:ring-2 focus:ring-[#D4A574] transition-all duration-200"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1.5">대표자명 *</label>
                  <input
                    type="text"
                    value={data.owner_name}
                    onChange={(e) => setData({ ...data, owner_name: e.target.value })}
                    placeholder="예: 김카페"
                    className="w-full px-4 py-2.5 rounded-xl border border-gray-200 text-sm focus:outline-none focus:ring-2 focus:ring-[#D4A574] transition-all duration-200"
                  />
                </div>

                {/* 빠른 시작 CTA — U15·U22 이탈 방지 */}
                <div className="mt-6 pt-5 border-t border-dashed border-gray-200">
                  <button
                    onClick={handleQuickStart}
                    disabled={isLoading || !data.store_name?.trim() || !data.owner_name?.trim()}
                    className="w-full flex items-center justify-center gap-2 px-4 py-3 rounded-xl bg-gradient-to-r from-[#D4A574]/20 to-[#D4A574]/5 border-2 border-[#D4A574] text-[#2C1810] text-sm font-semibold hover:from-[#D4A574]/30 hover:to-[#D4A574]/10 transition-all duration-200 disabled:opacity-40 disabled:cursor-not-allowed"
                  >
                    {isLoading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Zap size={16} className="text-[#D4A574]" />}
                    30초 만에 바로 시작하기
                  </button>
                  <p className="text-[11px] text-gray-400 text-center mt-2 leading-relaxed">
                    나머지 설정은 나중에 <strong>설정 &gt; 매장 정보</strong>에서 보완할 수 있어요
                  </p>
                </div>
              </div>
            )}

            {/* Step 2: 상권 유형 */}
            {currentStep === 2 && (
              <div className="space-y-4 animate-in fade-in slide-in-from-right-4 duration-300">
                <h2 className="text-xl font-bold text-[#2C1810]">우리 카페의 상권은?</h2>
                <div className="space-y-2">
                  {DISTRICT_OPTIONS.map((opt) => (
                    <button
                      key={opt.value}
                      onClick={() => setData({ ...data, district_type: opt.value })}
                      className={cn(
                        'w-full flex items-center gap-3 px-4 py-3 rounded-xl border-2 text-left transition-all duration-200',
                        data.district_type === opt.value
                          ? 'border-[#2C1810] bg-[#2C1810]/5 text-[#2C1810]'
                          : 'border-gray-200 hover:border-[#D4A574] text-gray-700'
                      )}
                    >
                      <span className="text-2xl">{opt.emoji}</span>
                      <div>
                        <div className="font-semibold text-sm">{opt.value}</div>
                        <div className="text-xs text-gray-500">{opt.desc}</div>
                      </div>
                      {data.district_type === opt.value && (
                        <CheckCircle2 className="ml-auto w-5 h-5 text-[#2C1810]" />
                      )}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Step 3: 운영 현황 */}
            {currentStep === 3 && (
              <div className="space-y-5 animate-in fade-in slide-in-from-right-4 duration-300">
                <h2 className="text-xl font-bold text-[#2C1810]">운영 현황</h2>

                {/* 메뉴 수 */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    평균 메뉴 수
                  </label>
                  <div className="flex gap-2 flex-wrap">
                    {MENU_COUNT_OPTIONS.map((n) => (
                      <button
                        key={n}
                        onClick={() => setData({ ...data, menu_count: n })}
                        className={cn(
                          'px-4 py-2 rounded-xl border-2 text-sm font-medium transition-all duration-200',
                          data.menu_count === n
                            ? 'border-[#2C1810] bg-[#2C1810] text-white'
                            : 'border-gray-200 text-gray-700 hover:border-[#D4A574]'
                        )}
                      >
                        {n}개
                      </button>
                    ))}
                  </div>
                </div>

                {/* 직원 수 */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">직원 수</label>
                  <div className="flex gap-2 flex-wrap">
                    {EMPLOYEE_COUNT_OPTIONS.map((n) => (
                      <button
                        key={n}
                        onClick={() => setData({ ...data, employee_count: n })}
                        className={cn(
                          'px-4 py-2 rounded-xl border-2 text-sm font-medium transition-all duration-200',
                          data.employee_count === n
                            ? 'border-[#2C1810] bg-[#2C1810] text-white'
                            : 'border-gray-200 text-gray-700 hover:border-[#D4A574]'
                        )}
                      >
                        {n}명
                      </button>
                    ))}
                  </div>
                </div>

                {/* 월 매출 */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    월 평균 매출
                  </label>
                  <div className="space-y-1.5">
                    {MONTHLY_SALES_OPTIONS.map((opt) => (
                      <button
                        key={opt.value}
                        onClick={() => setData({ ...data, avg_monthly_sales: opt.value })}
                        className={cn(
                          'w-full px-4 py-2 rounded-xl border-2 text-sm font-medium text-left transition-all duration-200',
                          data.avg_monthly_sales === opt.value
                            ? 'border-[#2C1810] bg-[#2C1810]/5 text-[#2C1810]'
                            : 'border-gray-200 text-gray-700 hover:border-[#D4A574]'
                        )}
                      >
                        {opt.label}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {/* Step 4: 매장 분위기 키워드 */}
            {currentStep === 4 && (
              <div className="space-y-4 animate-in fade-in slide-in-from-right-4 duration-300">
                <div>
                  <h2 className="text-xl font-bold text-[#2C1810]">매장 분위기 키워드</h2>
                  <p className="text-sm text-gray-500 mt-1">
                    AI가 콘텐츠 생성 시 활용합니다. 1~3개를 선택하세요.
                    <span className="font-semibold text-[#2C1810] ml-1">
                      ({data.ambiance_keywords?.length ?? 0}/3)
                    </span>
                  </p>
                </div>
                <div className="flex flex-wrap gap-2">
                  {AMBIANCE_OPTIONS.map((kw) => {
                    const selected = data.ambiance_keywords?.includes(kw)
                    const disabled = !selected && (data.ambiance_keywords?.length ?? 0) >= 3
                    return (
                      <button
                        key={kw}
                        onClick={() => toggleKeyword(kw)}
                        disabled={disabled}
                        className={cn(
                          'px-4 py-2 rounded-xl border-2 text-sm font-medium transition-all duration-200',
                          selected
                            ? 'border-[#D4A574] bg-[#D4A574] text-white'
                            : disabled
                            ? 'border-gray-100 text-gray-300 cursor-not-allowed'
                            : 'border-gray-200 text-gray-700 hover:border-[#D4A574]'
                        )}
                      >
                        {kw}
                      </button>
                    )
                  })}
                </div>
              </div>
            )}

            {/* Step 5: 완료 */}
            {currentStep === 5 && (
              <div className="text-center py-6 animate-in fade-in slide-in-from-right-4 duration-300">
                <div className="w-20 h-20 rounded-full bg-[#D4A574]/20 flex items-center justify-center mx-auto mb-4">
                  <CheckCircle2 className="w-10 h-10 text-[#D4A574]" />
                </div>
                <h2 className="text-xl font-bold text-[#2C1810] mb-2">설정 완료!</h2>
                <p className="text-gray-500 text-sm mb-6">
                  <strong className="text-[#2C1810]">{data.store_name}</strong>의 AI 경영 파트너,
                  <br />카페 브레인이 준비되었습니다.
                </p>
                <div className="bg-[#FAFAF8] rounded-xl p-4 text-left space-y-2 text-sm text-gray-600">
                  <div className="flex justify-between">
                    <span>매장명</span>
                    <span className="font-medium text-[#2C1810]">{data.store_name}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>상권</span>
                    <span className="font-medium text-[#2C1810]">{data.district_type}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>분위기</span>
                    <span className="font-medium text-[#2C1810]">{data.ambiance_keywords?.join(', ')}</span>
                  </div>
                </div>
                {error && (
                  <div className="mt-4 p-3 rounded-xl bg-red-50 border border-red-100 text-red-600 text-sm">
                    {error}
                  </div>
                )}
              </div>
            )}
          </div>

          {/* 버튼 영역 */}
          <div className="flex justify-between mt-6 pt-6 border-t border-gray-100">
            <button
              onClick={goPrev}
              disabled={currentStep === 1}
              className="flex items-center gap-1.5 px-4 py-2.5 rounded-xl border border-gray-200 text-sm font-medium text-gray-600 hover:bg-gray-50 transition-all duration-200 disabled:opacity-30 disabled:cursor-not-allowed"
            >
              <ChevronLeft size={16} />
              이전
            </button>

            {currentStep < 5 ? (
              <button
                onClick={goNext}
                disabled={!isStepValid()}
                className="flex items-center gap-1.5 px-6 py-2.5 rounded-xl bg-[#2C1810] text-white text-sm font-semibold hover:bg-[#3d2418] transition-all duration-200 disabled:opacity-40 disabled:cursor-not-allowed"
              >
                다음
                <ChevronRight size={16} />
              </button>
            ) : (
              <button
                onClick={handleComplete}
                disabled={isLoading}
                className="flex items-center gap-2 px-6 py-2.5 rounded-xl bg-[#D4A574] text-white text-sm font-semibold hover:bg-[#c4956a] transition-all duration-200 disabled:opacity-50"
              >
                {isLoading && <Loader2 className="w-4 h-4 animate-spin" />}
                🚀 대시보드 시작
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}
