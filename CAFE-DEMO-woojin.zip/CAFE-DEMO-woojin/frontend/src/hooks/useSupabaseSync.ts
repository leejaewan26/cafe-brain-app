/**
 * Supabase ↔ Zustand 동기화 훅
 *
 * 전략:
 * - 로그인 후 최초 1회: DB → 로컬 스토어 로드 (fetchAll)
 * - 명시적 push 함수: 로컬 스토어 → DB 업서트 (syncToCloud)
 * - 에러는 조용히 무시 (localStorage가 항상 폴백)
 *
 * 사용처: App.tsx 루트 or ProtectedRoute
 */
import { useEffect, useCallback, useState } from 'react'
import toast from 'react-hot-toast'
import { useAuthStore } from '@/store/authStore'
import { useSalesStore } from '@/store/salesStore'
import { useReviewStore } from '@/store/reviewStore'
import { useMenuStore } from '@/store/menuStore'
import {
  fetchSalesRecords, upsertSalesRecords,
  upsertReviews,
  fetchMenus, upsertMenu,
} from '@/lib/db'

export function useSupabaseSync() {
  const { user, storeInfo } = useAuthStore()
  const { records, addRecords } = useSalesStore()
  const { reviews } = useReviewStore()
  const { menus } = useMenuStore()
  const [isSyncing, setIsSyncing] = useState(false)
  const [lastSynced, setLastSynced] = useState<Date | null>(null)
  const [syncError, setSyncError] = useState('')

  const storeId = user?.id

  // ─── 로그인 시 DB → 로컬 로드 ───
  useEffect(() => {
    if (!storeId || !storeInfo) return

    const loadFromDb = async () => {
      try {
        const [dbSales, dbMenus] = await Promise.allSettled([
          fetchSalesRecords(storeId),
          fetchMenus(storeId),
        ])

        // 매출: DB에 있고 로컬에 없는 것만 추가
        if (dbSales.status === 'fulfilled' && dbSales.value.length > 0) {
          const localIds = new Set(records.map(r => r.id))
          const newRecords = dbSales.value.filter(r => !localIds.has(r.id))
          if (newRecords.length > 0) {
            addRecords(newRecords)
          }
        }

        // 메뉴: DB 데이터가 있으면 로컬 샘플 데이터를 DB 데이터로 교체
        // (샘플 ID가 'menu-0X' 형태인 경우만 교체 대상)
        if (dbMenus.status === 'fulfilled' && dbMenus.value.length > 0) {
          const { menus: localMenus } = useMenuStore.getState()
          const hasOnlySamples = localMenus.every(m => m.id.startsWith('menu-0'))
          if (hasOnlySamples) {
            useMenuStore.setState({ menus: dbMenus.value })
          }
        }
      } catch {
        // 동기화 실패는 조용히 무시 - localStorage가 폴백
      }
    }

    loadFromDb()
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [storeId, storeInfo?.store_name])

  // ─── 로컬 → DB 전체 push ───
  const syncToCloud = useCallback(async () => {
    if (!storeId) return
    setIsSyncing(true)
    setSyncError('')
    try {
      await Promise.allSettled([
        upsertSalesRecords(storeId, records),
        upsertReviews(storeId, reviews),
        ...menus
          .filter(m => !m.id.startsWith('menu-0')) // 샘플 제외
          .map(m => upsertMenu(storeId, m)),
      ])
      const now = new Date()
      setLastSynced(now)
      toast.success(`클라우드에 저장됐습니다 ☁️`, { duration: 3000 })
    } catch {
      setSyncError('클라우드 동기화에 실패했습니다.')
      toast.error('동기화에 실패했습니다. 다시 시도해주세요.')
    } finally {
      setIsSyncing(false)
    }
  }, [storeId, records, reviews, menus])

  return { isSyncing, lastSynced, syncError, syncToCloud }
}
