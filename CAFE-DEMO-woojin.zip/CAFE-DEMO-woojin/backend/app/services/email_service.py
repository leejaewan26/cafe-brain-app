"""
G4 — 트랜잭션 이메일 서비스 (Resend 기반).

Resend API: https://resend.com/docs/api-reference/emails/send-email
무료 tier: 3000건/월, 도메인 인증 시 발송자 본인 도메인 사용 가능.

원칙:
- RESEND_API_KEY 없으면 no-op (graceful)
- 모든 이메일은 한국어 + 매장 컨텍스트
- HTML + plain text 동시 발송
- 실패는 조용히 (트랜잭션 막으면 안 됨)
"""
import asyncio
import logging
from typing import Optional

import httpx

from app.config import settings
from app.services.gemini_service import _get_supabase

logger = logging.getLogger("email_service")


async def get_store_email(store_id: str) -> Optional[tuple[str, str]]:
    """
    매장의 사장님 이메일 + 매장명 조회.
    auth.users는 service_role 필요 — Supabase Admin SDK 사용.
    return (email, store_name) or None.
    """
    sb = _get_supabase()
    if sb is None:
        return None
    try:
        # 매장명
        store_res = await asyncio.to_thread(
            lambda: sb.table("stores")
            .select("name")
            .eq("id", store_id)
            .single()
            .execute()
        )
        store_name = (store_res.data or {}).get("name") or "사장님"

        # 이메일은 auth admin으로
        # supabase-py v2: client.auth.admin.get_user_by_id()
        user_res = await asyncio.to_thread(
            lambda: sb.auth.admin.get_user_by_id(store_id)
        )
        email = getattr(user_res.user, "email", None) if hasattr(user_res, "user") else None
        if not email:
            return None
        return email, store_name
    except Exception as e:
        logger.debug("get_store_email 실패 store=%s: %s", store_id[:8], e)
        return None


async def send_email(
    to: str,
    subject: str,
    html: str,
    text: Optional[str] = None,
    reply_to: Optional[str] = None,
) -> bool:
    """
    Resend로 이메일 발송. 성공 시 True, 실패/미설정 시 False.
    """
    api_key = getattr(settings, "resend_api_key", "") or ""
    from_addr = getattr(settings, "email_from", "") or "Cafe Brain <onboarding@resend.dev>"

    if not api_key:
        logger.info("Resend 미설정 — 이메일 발송 스킵 (to=%s, subject=%s)", to, subject)
        return False

    payload = {
        "from": from_addr,
        "to": [to],
        "subject": subject,
        "html": html,
    }
    if text:
        payload["text"] = text
    if reply_to:
        payload["reply_to"] = reply_to

    try:
        async with httpx.AsyncClient(timeout=10.0) as client:
            r = await client.post(
                "https://api.resend.com/emails",
                json=payload,
                headers={
                    "Authorization": f"Bearer {api_key}",
                    "Content-Type": "application/json",
                },
            )
            if r.status_code in (200, 201):
                return True
            logger.warning("Resend 실패 %s: %s", r.status_code, r.text[:200])
    except Exception as e:
        logger.warning("Resend 호출 예외: %s", str(e)[:200])
    return False


# ─── 템플릿 ────────────────────────────────────────────────


async def send_welcome_email(to: str, store_name: str = "사장님") -> bool:
    """가입 환영 메일."""
    html = f"""<!DOCTYPE html>
<html lang="ko">
<body style="font-family: 'Pretendard', sans-serif; background: #FAFAF8; padding: 20px;">
  <div style="max-width: 560px; margin: 0 auto; background: white; border-radius: 16px; padding: 32px; border: 1px solid #E5E4DF;">
    <div style="text-align:center; margin-bottom: 24px;">
      <span style="font-size: 28px;">☕️</span>
      <h1 style="color: #2C1810; margin: 8px 0; font-size: 24px;">카페 브레인에 오신 걸 환영합니다</h1>
    </div>
    <p style="color: #3D3D3A; font-size: 16px; line-height: 1.6;">
      <strong>{store_name}</strong>, 안녕하세요! 👋<br><br>
      카페 브레인 가입을 환영합니다. 이제 <strong>14일간 모든 기능을 무료로</strong> 사용하실 수 있어요.
    </p>
    <h3 style="color: #2C1810; margin-top: 24px;">먼저 해보시면 좋아요</h3>
    <ul style="color: #3D3D3A; line-height: 1.8;">
      <li>POS 매출 CSV 업로드 (or 영수증 사진)</li>
      <li>AI 어시스턴트와 첫 대화</li>
      <li>알림 받을 시간대 설정</li>
    </ul>
    <a href="https://cafe-brain.app/dashboard" style="display:inline-block; margin-top: 16px; background: #2C1810; color: white; padding: 12px 24px; border-radius: 12px; text-decoration: none; font-weight: bold;">시작하기 →</a>
    <p style="color: #87867F; font-size: 12px; margin-top: 32px; padding-top: 16px; border-top: 1px solid #F5F4EE;">
      문의: <a href="mailto:support@cafe-brain.app">support@cafe-brain.app</a><br>
      이 메일은 카페 브레인에 가입하신 사장님께 발송됩니다.
    </p>
  </div>
</body>
</html>"""

    text = f"""안녕하세요 {store_name}님,

카페 브레인 가입을 환영합니다.
14일간 모든 기능을 무료로 사용하실 수 있어요.

먼저 해보시면 좋아요:
• POS 매출 CSV 업로드 (또는 영수증 사진)
• AI 어시스턴트와 첫 대화
• 알림 받을 시간대 설정

시작하기: https://cafe-brain.app/dashboard

문의: support@cafe-brain.app
"""

    return await send_email(to, "카페 브레인에 오신 걸 환영합니다 ☕", html, text)


async def send_trial_expiring_email(to: str, store_name: str, days_left: int) -> bool:
    """무료 체험 만료 임박 알림 (3일 전)."""
    html = f"""<!DOCTYPE html>
<html lang="ko">
<body style="font-family: 'Pretendard', sans-serif; background: #FAFAF8; padding: 20px;">
  <div style="max-width: 560px; margin: 0 auto; background: white; border-radius: 16px; padding: 32px; border: 1px solid #E5E4DF;">
    <h1 style="color: #2C1810;">무료 체험이 {days_left}일 남았어요</h1>
    <p style="color: #3D3D3A; font-size: 16px; line-height: 1.6;">
      {store_name}, 그동안 사용해주셔서 감사합니다.
      지금까지 학습된 매장 메모리와 데이터를 그대로 이어가시려면 <strong>구독을 시작</strong>해주세요.
    </p>
    <div style="background: #FAFAF8; border-radius: 12px; padding: 16px; margin: 16px 0;">
      <p style="margin: 0; color: #2C1810; font-weight: bold;">💡 데이터는 그대로 유지돼요</p>
      <p style="margin: 8px 0 0; color: #87867F; font-size: 14px;">학습된 메모리, 매출 기록, 메뉴 설정 등 모든 데이터가 보존됩니다.</p>
    </div>
    <a href="https://cafe-brain.app/billing" style="display:inline-block; background: #D4A574; color: #2C1810; padding: 12px 24px; border-radius: 12px; text-decoration: none; font-weight: bold;">구독 시작 →</a>
  </div>
</body>
</html>"""
    return await send_email(to, f"⏰ 무료 체험 {days_left}일 남음 — 카페 브레인", html)


async def send_payment_success_email(to: str, store_name: str, amount: int, plan: str) -> bool:
    """결제 성공 영수증."""
    html = f"""<!DOCTYPE html>
<html lang="ko">
<body style="font-family: 'Pretendard', sans-serif; background: #FAFAF8; padding: 20px;">
  <div style="max-width: 560px; margin: 0 auto; background: white; border-radius: 16px; padding: 32px;">
    <h1 style="color: #2C1810;">결제가 완료되었습니다 ✨</h1>
    <p>{store_name}, 카페 브레인 <strong>{plan}</strong> 구독이 시작되었어요.</p>
    <table style="width:100%; margin-top: 16px; border-collapse: collapse;">
      <tr><td style="padding: 8px; color: #87867F;">플랜</td><td style="padding: 8px;">{plan}</td></tr>
      <tr><td style="padding: 8px; color: #87867F;">결제 금액</td><td style="padding: 8px; font-weight: bold;">₩{amount:,}</td></tr>
    </table>
    <p style="color: #87867F; font-size: 12px; margin-top: 16px;">
      세금 영수증은 영업일 1~2일 내 발송됩니다.
    </p>
  </div>
</body>
</html>"""
    return await send_email(to, "[카페 브레인] 결제 완료", html)
