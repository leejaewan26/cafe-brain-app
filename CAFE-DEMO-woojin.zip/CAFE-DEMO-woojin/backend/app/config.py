"""
Pydantic Settings 기반 환경변수 설정
- .env 파일 자동 로드
- API 키 절대 하드코딩 금지 (Rule 1 준수)
"""
from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    """환경변수 스키마"""
    gemini_api_key: str = ""
    supabase_url: str = ""
    supabase_service_key: str = ""
    # Issue #19: Web Push VAPID 키 (프로덕션)
    vapid_public_key: str = ""
    vapid_private_key: str = ""
    vapid_subject: str = "mailto:admin@cafe-brain.app"
    # Day 2-2: Sentry 에러 모니터링 (프로덕션 전용, 로컬은 빈 문자열)
    sentry_dsn: str = ""
    sentry_environment: str = "development"  # development | staging | production
    sentry_sample_rate: float = 1.0          # 에러는 전체 수집
    sentry_traces_sample_rate: float = 0.1   # 트레이스는 10% 샘플
    # 앱 버전 (릴리즈 추적용)
    app_version: str = "1.2.0"
    # Phase 3: Agent Gate — Gemini 토큰 비용 폭발 방지
    # 운영 시간 (KST 기준) + 인증된 호출만 능동 에이전트 허용
    agent_hour_open: int = 6      # KST 06시부터 게이트 통과
    agent_hour_close: int = 22    # KST 22시까지 게이트 통과
    agent_admin_key: str = ""     # 백그라운드 cron이 게이트 통과 시 사용 (X-Admin-Key 헤더)

    # Phase 4: 트렌드 데이터 소스 API 키 (전부 옵셔널 — 키 없으면 graceful degradation)
    naver_client_id: str = ""        # Naver DataLab + 뉴스 검색 공통
    naver_client_secret: str = ""
    youtube_api_key: str = ""        # YouTube Data API v3
    newsapi_key: str = ""            # NewsAPI.org (글로벌 뉴스)
    # Gemini Search Grounding은 GEMINI_API_KEY 그대로 사용 (별도 키 X)

    # Launch A1: CORS — 프로덕션은 specific origin, 로컬은 * 자동 허용
    # 콤마 구분 (예: "https://cafe-brain.vercel.app,https://cafe-brain.app")
    # "*"이면 모든 origin 허용 (개발 모드)
    cors_allow_origins: str = "*"

    # Launch A7: 헬스 프로브 환경 (cloud_run | local)
    deployment_env: str = "local"     # production / staging / local

    # G4 — Resend 이메일 트랜잭션 (없으면 no-op)
    resend_api_key: str = ""
    email_from: str = "Cafe Brain <onboarding@resend.dev>"

    # H2 — 네이버 검색·예약 API (없으면 graceful)
    naver_client_id: str = ""
    naver_client_secret: str = ""
    naver_reservation_token: str = ""

    # H5 — n8n 셀프호스팅 multi-channel publish webhook
    n8n_webhook_url: str = ""

    class Config:
        env_file = ".env"
        env_file_encoding = "utf-8"
        case_sensitive = False

    @property
    def cors_origins_list(self) -> list[str]:
        """CORS allow_origins를 list로 파싱 (콤마 구분)."""
        raw = (self.cors_allow_origins or "*").strip()
        if raw == "*":
            return ["*"]
        return [o.strip() for o in raw.split(",") if o.strip()]


# 싱글톤 설정 인스턴스
settings = Settings()
