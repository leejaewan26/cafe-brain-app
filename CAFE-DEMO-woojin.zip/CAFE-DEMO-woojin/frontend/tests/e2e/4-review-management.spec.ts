// QA 시나리오 4: 리뷰 관리 — 업로드 → AI 답글 → 어조 변경 → 인사이트 키워드
import { test, expect } from '@playwright/test'
import { setupApiMocks, signInAsOwner } from './fixtures/apiMock'

test.describe('시나리오 4 — 리뷰 관리', () => {
  test('리뷰 목록 탭 → AI 답글 생성 → 어조 드롭다운', async ({ page }) => {
    await setupApiMocks(page)
    await signInAsOwner(page)

    // 리뷰 pre-hydration
    await page.addInitScript(() => {
      const reviews = [
        {
          id: 'rv1',
          nickname: '단골손님',
          content: '아메리카노 진하고 좋아요. 다음에도 올게요.',
          rating: 5,
          date: '2026-04-15',
          platform: '네이버',
          ai_reply: '',
          reply_status: 'pending',
          is_selected: false,
        },
        {
          id: 'rv2',
          nickname: '까칠한고객',
          content: '아이스 아메리카노 너무 미지근했어요. 실망.',
          rating: 2,
          date: '2026-04-16',
          platform: '카카오',
          ai_reply: '',
          reply_status: 'pending',
          is_selected: false,
        },
      ]
      localStorage.setItem('cafe-brain-reviews', JSON.stringify({ state: { reviews }, version: 0 }))
    })

    await page.goto('/reviews')

    // 리뷰 카드 2개 보이는지
    await expect(page.getByText('단골손님')).toBeVisible()
    await expect(page.getByText('까칠한고객')).toBeVisible()

    // 어조 드롭다운
    const toneSelects = page.locator('select').filter({ hasText: /정중|친근|유머/ })
    await expect(toneSelects.first()).toBeVisible()

    // AI 답글 생성 버튼 클릭
    const genBtn = page.getByRole('button', { name: /AI 답글 생성/ }).first()
    await genBtn.click()

    // 답글 결과 영역
    await expect(page.getByText(/AI가 생성한 답글|감사드립니다|카페 방문해주셔서/)).toBeVisible({ timeout: 10_000 })
  })

  test('인사이트 탭: 플랫폼별 통계 + 긍정/부정 키워드', async ({ page }) => {
    await setupApiMocks(page)
    await signInAsOwner(page)

    // 부정 리뷰 여러 개로 키워드 빈도 테스트
    await page.addInitScript(() => {
      const reviews = Array.from({ length: 12 }, (_, i) => ({
        id: `rv-${i}`,
        nickname: `고객${i}`,
        content: i % 3 === 0
          ? '커피 정말 맛있어요. 직원도 친절해요.'
          : i % 3 === 1
            ? '대기시간이 너무 길어요. 대기시간 개선 필요합니다.'
            : '아메리카노가 진하고 향이 좋아요',
        rating: i % 3 === 1 ? 2 : 5,
        date: `2026-04-${String(1 + (i % 28)).padStart(2, '0')}`,
        platform: ['네이버', '카카오', '구글'][i % 3],
        ai_reply: '',
        reply_status: 'pending',
        is_selected: false,
      }))
      localStorage.setItem('cafe-brain-reviews', JSON.stringify({ state: { reviews }, version: 0 }))
    })

    await page.goto('/reviews')
    await page.getByRole('button', { name: /인사이트/ }).click()

    // 플랫폼별 현황
    await expect(page.getByText(/플랫폼별 현황/)).toBeVisible()
    // 긍정·부정 비율 차트
    await expect(page.getByText(/긍정\/부정 비율/)).toBeVisible()
    // 키워드 분석
    await expect(page.getByText(/긍정 리뷰 키워드|부정 리뷰 키워드/)).toBeVisible()

    // CSV 다운로드 버튼
    await expect(page.getByRole('button', { name: /레포트 다운로드/ })).toBeVisible()
  })
})
