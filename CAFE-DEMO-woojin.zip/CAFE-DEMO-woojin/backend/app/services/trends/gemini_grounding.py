"""
Gemini Search Grounding — 실시간 웹 검색 + 응답.

Gemini API의 google_search_retrieval tool 활성화하면 응답 전 실제 구글 검색.
응답에 grounding_metadata 포함 (출처 URL).

키: GEMINI_API_KEY 재사용. 추가 비용은 검색 query 당 ~$35/1k.
"""
import asyncio
from typing import Optional

import google.generativeai as genai

from app.config import settings


async def grounded_research(query: str, max_chars: int = 1500) -> Optional[dict]:
    """
    Gemini 2.5 Flash + Google Search Grounding.

    Args:
        query: 자연어 질의 (예: "최근 일주일 한국·해외 카페 신메뉴 트렌드")
        max_chars: 응답 텍스트 최대 길이

    Returns:
        {"text": str, "sources": [{"uri", "title"}]} 또는 None
    """
    if not settings.gemini_api_key:
        return None

    def _sync_call() -> Optional[dict]:
        try:
            genai.configure(api_key=settings.gemini_api_key)

            # google_search_retrieval tool 활성화 (구버전 호환을 위해 fallback)
            try:
                model = genai.GenerativeModel(
                    "gemini-2.5-flash",
                    tools=[{"google_search_retrieval": {}}],
                )
                response = model.generate_content(query)
            except Exception:
                # Grounding 미지원 환경 fallback — 일반 호출
                model = genai.GenerativeModel("gemini-2.5-flash")
                response = model.generate_content(query)

            text = (response.text or "").strip()[:max_chars]

            sources: list[dict] = []
            try:
                cand = response.candidates[0]
                gm = getattr(cand, "grounding_metadata", None)
                if gm:
                    chunks = getattr(gm, "grounding_chunks", []) or []
                    for ch in chunks:
                        web = getattr(ch, "web", None)
                        if web:
                            sources.append({
                                "uri": getattr(web, "uri", ""),
                                "title": getattr(web, "title", ""),
                            })
            except (AttributeError, IndexError):
                pass

            return {"text": text, "sources": sources[:8]}
        except Exception:
            return None

    return await asyncio.to_thread(_sync_call)
