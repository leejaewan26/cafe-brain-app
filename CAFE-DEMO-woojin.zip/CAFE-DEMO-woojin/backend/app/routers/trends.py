"""
외식업 트렌드·키워드 감지 라우터 (Phase 4 강화)

엔드포인트:
- GET  /api/trends/sources   : 활성 데이터 소스 헬스 체크 (어떤 키 설정됨)
- POST /api/trends/report    : 7개 소스 + Gemini 전략 보고서 (24h 캐시)
- POST /api/trends/briefing  : (레거시) 단순 Gemini 트렌드 브리핑 (주간 캐시)

Phase 4 핵심:
  사용자 호출 시 7개 데이터 소스 병렬 수집 → Gemini가 전략 보고서로 종합.
  키 없는 소스는 graceful degradation (보고서에 "(미수집)" 표시).
"""
import hashlib
from datetime import date
from typing import Any, Optional

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field

from app.config import settings
from app.services.gemini_service import generate_insight, build_cache_key, generate_with_review
from app.services.feature_flags import is_enabled as flag_enabled
from app.services.trends import collect_all_sources, synthesize_strategic_report

router = APIRouter()


# ═══════════════════════════════════════════════════════
# 1. 소스 헬스 체크 — 어떤 데이터 소스 활성화됐나
# ═══════════════════════════════════════════════════════


class SourceStatus(BaseModel):
    name: str
    active: bool
    note: str


class SourcesResponse(BaseModel):
    sources: list[SourceStatus]
    active_count: int
    total: int


@router.get("/sources", response_model=SourcesResponse)
async def list_sources():
    """
    7개 데이터 소스 활성 상태 (키 설정 여부) 조회.
    프론트의 트렌드 페이지가 "어떤 소스가 비활성인지" 보여줄 때 사용.
    """
    naver_ok = bool(settings.naver_client_id and settings.naver_client_secret)
    sources = [
        SourceStatus(
            name="naver_datalab",
            active=naver_ok,
            note="한국 검색량 정량 (Naver DataLab API)" if naver_ok else "NAVER_CLIENT_ID/SECRET 누락",
        ),
        SourceStatus(
            name="naver_news",
            active=naver_ok,
            note="한국 뉴스 (Naver 검색)" if naver_ok else "NAVER_CLIENT_ID/SECRET 누락",
        ),
        SourceStatus(
            name="google_trends",
            active=True,
            note="한국 vs 글로벌 비교 (pytrends, 키 X)",
        ),
        SourceStatus(
            name="youtube",
            active=bool(settings.youtube_api_key),
            note="푸드 인플루언서 영상 (YouTube Data API)" if settings.youtube_api_key else "YOUTUBE_API_KEY 누락",
        ),
        SourceStatus(
            name="newsapi",
            active=bool(settings.newsapi_key),
            note="글로벌 영문 뉴스 (NewsAPI.org)" if settings.newsapi_key else "NEWSAPI_KEY 누락",
        ),
        SourceStatus(
            name="google_news_rss",
            active=True,
            note="Google News RSS (키 X)",
        ),
        SourceStatus(
            name="gemini_grounding",
            active=bool(settings.gemini_api_key),
            note="Gemini + 실시간 웹 검색" if settings.gemini_api_key else "GEMINI_API_KEY 누락",
        ),
    ]
    return SourcesResponse(
        sources=sources,
        active_count=sum(1 for s in sources if s.active),
        total=len(sources),
    )


# ═══════════════════════════════════════════════════════
# 2. 전략 보고서 — 7개 소스 종합
# ═══════════════════════════════════════════════════════


class TrendReportRequest(BaseModel):
    """7개 데이터 소스 + Gemini 전략 보고서 요청"""
    store_id: str = Field(..., description="매장 UUID (캐시 키 + 컨텍스트)")
    store_name: str = ""
    district_type: str = "복합"
    ambiance_keywords: list[str] = []
    top_menus: list[str] = []
    custom_keywords_kr: Optional[list[str]] = None  # 매장별 한국어 키워드 (없으면 시드)
    custom_keywords_en: Optional[list[str]] = None  # 영문 키워드


class TrendReportResponse(BaseModel):
    report: str                    # 마크다운 전략 보고서
    active_sources: list[str]      # 실제 수집된 소스
    raw: dict[str, Any]            # 원본 데이터 (UI 차트용)
    collected_at: str
    cache_hit: bool = False


@router.post("/report", response_model=TrendReportResponse)
async def get_trend_report(req: TrendReportRequest):
    """
    7개 데이터 소스 동시 수집 → Gemini가 전략 보고서로 종합.

    응답:
    - report: 마크다운 보고서 (사장님이 바로 읽음)
    - raw: 원본 차트 데이터 (UI에서 시각화)
    - active_sources: 실제 활성 소스 리스트

    캐시: 매장 + 활성 소스 + 오늘 날짜 (24h)
    """
    # 1. 7개 소스 병렬 수집
    raw = await collect_all_sources(
        custom_keywords_kr=req.custom_keywords_kr,
        custom_keywords_en=req.custom_keywords_en,
    )

    # 2. Gemini 전략 보고서 생성
    store_context = {
        "store_id": req.store_id,
        "store_name": req.store_name or "내 카페",
        "district_type": req.district_type,
        "ambiance_keywords": req.ambiance_keywords,
        "top_menus": req.top_menus,
    }

    try:
        report = await synthesize_strategic_report(raw, store_context)
    except Exception as e:
        raise HTTPException(status_code=503, detail=f"전략 보고서 생성 실패: {str(e)}")

    return TrendReportResponse(
        report=report,
        active_sources=raw.get("active_sources", []),
        raw=raw,
        collected_at=raw.get("collected_at", str(date.today())),
    )


# ═══════════════════════════════════════════════════════
# 3. (레거시) 단순 Gemini 브리핑 — 외부 API 없이 빠른 답변
# ═══════════════════════════════════════════════════════


class TrendBriefingRequest(BaseModel):
    store_name: str = ""
    district_type: str = "복합"
    ambiance_keywords: list[str] = []
    top_menus: list[str] = []


class TrendKeyword(BaseModel):
    keyword: str
    trend: str
    relevance: str


class TrendBriefingResponse(BaseModel):
    keywords: list[TrendKeyword]
    briefing: str
    action_items: list[str]
    week_label: str


@router.post("/briefing", response_model=TrendBriefingResponse)
async def get_trend_briefing(req: TrendBriefingRequest):
    """
    [레거시] 외부 API 없이 Gemini 자체 지식 기반 트렌드 브리핑.
    주간 캐시. /report 가 본격 7-source 분석.
    """
    today = date.today()
    week_key = f"{today.isocalendar()[0]}-W{today.isocalendar()[1]:02d}"
    cache_key = build_cache_key(
        "global",
        "trend_briefing_legacy",
        {
            "week": week_key,
            "district": req.district_type,
            "menus_hash": hashlib.md5(str(sorted(req.top_menus)).encode()).hexdigest()[:6],
        },
    )

    menus_str = ", ".join(req.top_menus[:5]) if req.top_menus else "아메리카노, 라떼"
    ambiance_str = ", ".join(req.ambiance_keywords) if req.ambiance_keywords else "감성적"

    prompt = f"""
당신은 한국 외식업·카페 트렌드 전문 애널리스트입니다.
현재 날짜 기준({today.strftime('%Y년 %m월 %d일')}) 카페·외식업 최신 트렌드를 분석해주세요.

[분석 대상 매장]
- 상권: {req.district_type}
- 분위기: {ambiance_str}
- 주력 메뉴: {menus_str}

아래 JSON 형식으로만 답하세요 (마크다운 없이):
{{
  "keywords": [
    {{"keyword": "...", "trend": "rising", "relevance": "..."}},
    {{"keyword": "...", "trend": "stable", "relevance": "..."}},
    {{"keyword": "...", "trend": "declining", "relevance": "..."}}
  ],
  "briefing": "이번 주 카페 업계 트렌드 요약 3~5문장",
  "action_items": ["제안 1", "제안 2", "제안 3"]
}}

키워드 5개, trend는 rising/stable/declining 중 하나, action_items 3개.
""".strip()

    try:
        import json
        raw = await generate_insight(prompt, cache_key=cache_key)
        raw = raw.replace("\n\nⓘ AI가 생성한 콘텐츠입니다.", "").strip()
        if "```" in raw:
            raw = raw.split("```")[1]
            if raw.startswith("json"):
                raw = raw[4:]
        data = json.loads(raw.strip())

        iso = today.isocalendar()
        return TrendBriefingResponse(
            keywords=[TrendKeyword(**k) for k in data.get("keywords", [])],
            briefing=data.get("briefing", ""),
            action_items=data.get("action_items", []),
            week_label=f"{iso[0]}년 {iso[1]}주차",
        )
    except Exception as e:
        raise HTTPException(status_code=503, detail=f"트렌드 분석 실패: {str(e)}")
