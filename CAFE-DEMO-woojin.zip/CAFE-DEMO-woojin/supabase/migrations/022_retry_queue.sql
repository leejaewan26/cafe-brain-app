-- L7 — 재시도 큐
CREATE TABLE IF NOT EXISTS retry_queue (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  kind            TEXT NOT NULL,
  payload         JSONB NOT NULL,
  store_id        UUID,
  status          TEXT NOT NULL DEFAULT 'pending'
                   CHECK (status IN ('pending','processing','done','dead')),
  attempts        INT NOT NULL DEFAULT 0,
  next_attempt_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  last_error      TEXT,
  completed_at    TIMESTAMPTZ,
  created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_retry_queue_pending
  ON retry_queue(status, next_attempt_at)
  WHERE status = 'pending';
CREATE INDEX IF NOT EXISTS idx_retry_queue_store ON retry_queue(store_id, created_at DESC);

ALTER TABLE retry_queue ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "retry_queue_service_only" ON retry_queue;
CREATE POLICY "retry_queue_service_only" ON retry_queue
  FOR ALL USING (auth.role() = 'service_role');

COMMENT ON TABLE retry_queue IS 'L7 — 외부 API 호출 재시도 큐. exponential backoff 1m/5m/15m/1h/6h.';
