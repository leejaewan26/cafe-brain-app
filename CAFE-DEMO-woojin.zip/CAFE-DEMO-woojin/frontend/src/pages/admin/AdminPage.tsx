// G6 — 운영자 admin 대시보드 (X-Admin-Key 인증)
// 매장 사장님은 못 보고, 운영팀이 전체 사용 현황을 보는 화면
import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import {
  ChevronLeft, Users, Activity, Database, DollarSign,
  Loader2, Lock,
} from 'lucide-react'
import toast from 'react-hot-toast'

const ADMIN_KEY_STORAGE = 'cafe-brain-admin-key'

interface Overview {
  stores: { total: number; new_7d: number; active_24h: number }
  memories: { total: number }
  cache: { hits: number; misses: number; hit_rate: number; saved_krw_estimate: number }
  tokens: { total_calls: number; estimated_cost_krw: number; total_input_tokens: number; total_output_tokens: number }
  deployment_env: string
}

interface SLOEntry {
  endpoint: string
  total_calls: number
  cache_hit_rate: number
  p50_ms: number
  p95_ms: number
  p99_ms: number
}

interface StoreRow {
  id_short: string
  name: string
  created_at: string
  subscription_status: string | null
  agent_learning_enabled: boolean
}

interface BizMetrics {
  mrr_krw: number
  arr_krw: number
  active_subscriptions: number
  arpu_krw: number
  estimated_ltv_krw: number
  churn_rate_30d: number
  trial_to_paid_conversion: number
  canceled_30d: number
  new_paid_30d: number
}

export default function AdminPage() {
  const [adminKey, setAdminKey] = useState(() => localStorage.getItem(ADMIN_KEY_STORAGE) || '')
  const [authed, setAuthed] = useState(false)
  const [overview, setOverview] = useState<Overview | null>(null)
  const [slo, setSlo] = useState<SLOEntry[]>([])
  const [stores, setStores] = useState<StoreRow[]>([])
  const [metrics, setMetrics] = useState<BizMetrics | null>(null)
  const [loading, setLoading] = useState(false)

  const authenticate = async () => {
    if (!adminKey.trim()) {
      toast.error('Admin 키를 입력해주세요')
      return
    }
    setLoading(true)
    try {
      const r = await fetch('/api/v1/admin/overview', {
        headers: { 'X-Admin-Key': adminKey },
      })
      if (r.status === 403) {
        toast.error('잘못된 키')
        setAuthed(false)
        return
      }
      if (!r.ok) {
        toast.error('인증 실패')
        return
      }
      setOverview(await r.json())
      localStorage.setItem(ADMIN_KEY_STORAGE, adminKey)
      setAuthed(true)
      // SLO + 매장 목록 + 비즈니스 메트릭 동시 로드
      const [sloRes, storesRes, metricsRes] = await Promise.all([
        fetch('/api/v1/admin/slo?window_days=7', { headers: { 'X-Admin-Key': adminKey } }),
        fetch('/api/v1/admin/recent-stores?limit=30', { headers: { 'X-Admin-Key': adminKey } }),
        fetch('/api/v1/admin/metrics', { headers: { 'X-Admin-Key': adminKey } }),
      ])
      if (sloRes.ok) setSlo((await sloRes.json()).endpoints ?? [])
      if (storesRes.ok) setStores((await storesRes.json()).stores ?? [])
      if (metricsRes.ok) setMetrics(await metricsRes.json())
    } finally {
      setLoading(false)
    }
  }

  // 자동 시도 (이미 키 저장됐으면)
  useEffect(() => {
    if (adminKey && !authed) void authenticate()
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  if (!authed) {
    return (
      <div className="min-h-screen bg-[#FAFAF8] flex items-center justify-center px-4">
        <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-6 max-w-sm w-full">
          <div className="flex items-center gap-2 mb-4">
            <Lock size={18} className="text-[#D4A574]" />
            <h1 className="text-lg font-bold text-[#2C1810]">운영자 인증</h1>
          </div>
          <p className="text-xs text-gray-500 mb-4 leading-relaxed">
            카페 브레인 운영팀 전용 화면입니다. 사장님은 접근 권한이 없습니다.
          </p>
          <input
            type="password"
            value={adminKey}
            onChange={(e) => setAdminKey(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && authenticate()}
            placeholder="Admin 키"
            className="w-full px-3 py-2 border border-gray-200 rounded-lg text-sm font-mono mb-3 focus:outline-none focus:border-[#2C1810]"
          />
          <button
            onClick={authenticate}
            disabled={loading}
            className="w-full bg-[#2C1810] text-white py-2 rounded-lg text-sm font-semibold hover:bg-[#3A2519] disabled:opacity-50 flex items-center justify-center gap-2"
          >
            {loading ? <Loader2 size={14} className="animate-spin" /> : <Lock size={14} />}
            인증
          </button>
          <Link to="/" className="block text-center text-xs text-gray-400 mt-3 hover:text-[#2C1810]">
            ← 홈으로
          </Link>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-[#FAFAF8]">
      <header className="bg-white border-b border-gray-100 sticky top-0 z-10">
        <div className="max-w-5xl mx-auto px-4 py-3 flex items-center gap-3">
          <Link to="/" className="text-gray-400 hover:text-[#2C1810]">
            <ChevronLeft size={18} />
          </Link>
          <h1 className="text-base font-bold text-[#2C1810]">운영 대시보드</h1>
          <span className="ml-auto text-xs px-2 py-0.5 bg-[#D4A574]/20 text-[#2C1810] rounded-full">
            {overview?.deployment_env}
          </span>
        </div>
      </header>

      <main className="max-w-5xl mx-auto px-4 py-5 space-y-5">
        {/* 핵심 지표 */}
        {overview && (
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            <StatCard icon={Users} label="총 매장" value={overview.stores.total.toLocaleString()} sub={`+${overview.stores.new_7d} 이번주`} color="#4A90A4" />
            <StatCard icon={Activity} label="활성 (24h)" value={overview.stores.active_24h.toLocaleString()} color="#22C55E" />
            <StatCard icon={Database} label="메모리" value={overview.memories.total.toLocaleString()} color="#7B6CB0" />
            <StatCard icon={DollarSign} label="추정 비용" value={`₩${overview.tokens.estimated_cost_krw.toLocaleString()}`} sub={`캐시 ${(overview.cache.hit_rate * 100).toFixed(1)}%`} color="#D4A574" />
          </div>
        )}

        {/* M7: 비즈니스 메트릭 */}
        {metrics && (
          <section className="bg-white rounded-2xl border border-gray-100 p-5">
            <h2 className="font-bold text-[#2C1810] mb-3 flex items-center gap-2">
              <DollarSign size={15} className="text-[#22C55E]" /> 비즈니스 메트릭
            </h2>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
              <StatCard icon={DollarSign} label="MRR" value={`₩${metrics.mrr_krw.toLocaleString()}`} sub={`ARR ₩${metrics.arr_krw.toLocaleString()}`} color="#22C55E" />
              <StatCard icon={Users} label="활성 구독" value={metrics.active_subscriptions.toLocaleString()} sub={`ARPU ₩${metrics.arpu_krw.toLocaleString()}`} color="#4A90A4" />
              <StatCard icon={Activity} label="LTV (추정)" value={`₩${metrics.estimated_ltv_krw.toLocaleString()}`} sub={`이탈률 ${metrics.churn_rate_30d}%`} color="#D4A574" />
              <StatCard icon={Database} label="전환률 (30d)" value={`${metrics.trial_to_paid_conversion}%`} sub={`+${metrics.new_paid_30d} 신규 / -${metrics.canceled_30d} 해지`} color="#7B6CB0" />
            </div>
          </section>
        )}

        {/* SLO */}
        <section className="bg-white rounded-2xl border border-gray-100 p-5">
          <h2 className="font-bold text-[#2C1810] mb-3 flex items-center gap-2">
            <Activity size={15} className="text-[#7B6CB0]" />
            전체 SLO (최근 7일)
          </h2>
          <table className="w-full text-xs">
            <thead className="text-gray-400 border-b border-gray-100">
              <tr>
                <th className="text-left px-2 py-1.5">엔드포인트</th>
                <th className="text-right px-2 py-1.5">호출</th>
                <th className="text-right px-2 py-1.5">p50</th>
                <th className="text-right px-2 py-1.5">p95</th>
                <th className="text-right px-2 py-1.5">p99</th>
                <th className="text-right px-2 py-1.5">캐시</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {slo.slice(0, 12).map((s) => (
                <tr key={s.endpoint} className="hover:bg-[#FAFAF8]">
                  <td className="px-2 py-1.5 font-medium text-[#2C1810]">{s.endpoint.replace('/api/', '')}</td>
                  <td className="text-right px-2 py-1.5 tabular-nums">{s.total_calls.toLocaleString()}</td>
                  <td className="text-right px-2 py-1.5 tabular-nums">{Math.round(s.p50_ms)}ms</td>
                  <td className={`text-right px-2 py-1.5 tabular-nums ${s.p95_ms > 5000 ? 'text-red-500' : s.p95_ms > 2000 ? 'text-amber-500' : ''}`}>
                    {Math.round(s.p95_ms)}ms
                  </td>
                  <td className="text-right px-2 py-1.5 tabular-nums">{Math.round(s.p99_ms)}ms</td>
                  <td className="text-right px-2 py-1.5 tabular-nums text-green-600">
                    {(s.cache_hit_rate * 100).toFixed(0)}%
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </section>

        {/* 매장 목록 */}
        <section className="bg-white rounded-2xl border border-gray-100 p-5">
          <h2 className="font-bold text-[#2C1810] mb-3">최근 가입 매장 ({stores.length})</h2>
          <table className="w-full text-xs">
            <thead className="text-gray-400 border-b border-gray-100">
              <tr>
                <th className="text-left px-2 py-1.5 w-20">ID</th>
                <th className="text-left px-2 py-1.5">매장명</th>
                <th className="text-left px-2 py-1.5">가입일</th>
                <th className="text-left px-2 py-1.5">구독</th>
                <th className="text-left px-2 py-1.5">학습</th>
                <th className="text-left px-2 py-1.5 w-12">액션</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {stores.map((s) => (
                <tr key={s.id_short} className="hover:bg-[#FAFAF8]">
                  <td className="px-2 py-1.5 font-mono text-gray-400">{s.id_short}</td>
                  <td className="px-2 py-1.5 font-medium text-[#2C1810]">{s.name || '—'}</td>
                  <td className="px-2 py-1.5 text-gray-500">
                    {new Date(s.created_at).toLocaleDateString('ko-KR')}
                  </td>
                  <td className="px-2 py-1.5">
                    <span className={`text-[10px] px-1.5 py-0.5 rounded ${
                      s.subscription_status === 'active'
                        ? 'bg-green-100 text-green-700'
                        : s.subscription_status === 'past_due'
                        ? 'bg-red-100 text-red-700'
                        : s.subscription_status === 'suspended'
                        ? 'bg-red-200 text-red-900'
                        : 'bg-gray-100 text-gray-500'
                    }`}>
                      {s.subscription_status || 'trial'}
                    </span>
                  </td>
                  <td className="px-2 py-1.5">
                    <span className={`w-2 h-2 inline-block rounded-full ${s.agent_learning_enabled ? 'bg-green-500' : 'bg-gray-300'}`} />
                  </td>
                  <td className="px-2 py-1.5">
                    {s.subscription_status !== 'suspended' && (
                      <button
                        onClick={async () => {
                          const reason = prompt(`매장 [${s.name || s.id_short}] 정지 사유:`)
                          if (!reason) return
                          // store_id는 id_short만 있어서 full ID가 필요 — backend가 lookup 가능하도록 store_id 필드 사용
                          const r = await fetch('/api/v1/admin/suspend-store', {
                            method: 'POST',
                            headers: { 'Content-Type': 'application/json', 'X-Admin-Key': adminKey },
                            body: JSON.stringify({ store_id: s.id_short, reason }),
                          })
                          if (r.ok) {
                            toast.success('매장 정지됨')
                            window.location.reload()
                          } else toast.error('정지 실패 (full store_id 필요)')
                        }}
                        className="text-[10px] text-red-500 hover:underline"
                      >
                        정지
                      </button>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </section>
      </main>
    </div>
  )
}

function StatCard({ icon: Icon, label, value, sub, color }: {
  icon: React.ElementType
  label: string
  value: string
  sub?: string
  color: string
}) {
  return (
    <div className="bg-white rounded-2xl border border-gray-100 p-4">
      <Icon size={16} style={{ color }} className="mb-2" />
      <p className="text-2xl font-bold text-[#2C1810] tabular-nums">{value}</p>
      <p className="text-[10px] text-gray-400 mt-0.5">{label}</p>
      {sub && <p className="text-[10px] text-gray-500 mt-0.5">{sub}</p>}
    </div>
  )
}
