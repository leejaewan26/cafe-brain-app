// Bonus E3 — Web Speech API TTS 훅
// 카운터·출근길에서 브리핑을 음성으로 들을 수 있게 해주는 가벼운 래퍼
// - 한국어 우선 voice 자동 선택
// - 마크다운/이모지/footnote 제거 후 발화
// - 동시에 1개만 재생 (재생 중 다른 호출은 stop 후 시작)
// - localStorage에 자동 재생 선호도 저장
import { useCallback, useEffect, useRef, useState } from 'react'

const AUTOPLAY_KEY = 'cafe-brain-tts-autoplay'

interface SpeakOptions {
  rate?: number      // 0.1 ~ 10, 기본 1.05 (한국어 살짝 빠르게)
  pitch?: number     // 0 ~ 2, 기본 1
  volume?: number    // 0 ~ 1, 기본 1
}

/**
 * 음성 합성용으로 텍스트 정제.
 * - 이모지·마크다운·footnote(📎) 제거
 * - 코드블록·링크 제거
 * - 워터마크 "ⓘ AI…" 제거
 */
function sanitizeForSpeech(text: string): string {
  return text
    .replace(/```[\s\S]*?```/g, '')                  // 코드블록
    .replace(/!\[.*?\]\(.*?\)/g, '')                  // 이미지
    .replace(/\[(.+?)\]\((.+?)\)/g, '$1')             // 링크 → 텍스트
    .replace(/\n\n📎.*$/s, '')                        // citation footnote
    .replace(/ⓘ.*?(콘텐츠입니다\.?|검증 통과\)?|수정됨\)?)/g, '')  // 워터마크
    .replace(/[#*_~`>]/g, '')                         // 마크다운 강조
    .replace(/[📊📈📉🎯🍽️🏪🧠💬📚🌙✨👍🔇📎ⓘ]/g, '')   // 흔한 이모지
    .replace(/\s+/g, ' ')
    .trim()
}

function pickKoreanVoice(voices: SpeechSynthesisVoice[]): SpeechSynthesisVoice | null {
  if (voices.length === 0) return null
  // 한국어 우선
  const ko = voices.filter((v) => v.lang.toLowerCase().startsWith('ko'))
  if (ko.length > 0) {
    // 선호: Microsoft·Google·Apple 자연 음성
    const natural = ko.find((v) => /natural|wavenet|neural|enhanced/i.test(v.name))
    return natural ?? ko[0]
  }
  return voices[0]
}

export function useTTS() {
  const [supported, setSupported] = useState(false)
  const [speaking, setSpeaking] = useState(false)
  const [autoplay, setAutoplayState] = useState<boolean>(() => {
    if (typeof window === 'undefined') return false
    return localStorage.getItem(AUTOPLAY_KEY) === '1'
  })
  const voiceRef = useRef<SpeechSynthesisVoice | null>(null)

  useEffect(() => {
    if (typeof window === 'undefined' || !('speechSynthesis' in window)) {
      setSupported(false)
      return
    }
    setSupported(true)

    // 음성 목록 로드 (Chrome은 비동기)
    const loadVoices = () => {
      const voices = window.speechSynthesis.getVoices()
      voiceRef.current = pickKoreanVoice(voices)
    }
    loadVoices()
    window.speechSynthesis.addEventListener('voiceschanged', loadVoices)
    return () => {
      window.speechSynthesis.removeEventListener('voiceschanged', loadVoices)
      try { window.speechSynthesis.cancel() } catch { /* ignore */ }
    }
  }, [])

  const stop = useCallback(() => {
    if (!supported) return
    try { window.speechSynthesis.cancel() } catch { /* ignore */ }
    setSpeaking(false)
  }, [supported])

  const speak = useCallback((text: string, opts: SpeakOptions = {}) => {
    if (!supported) return
    const cleaned = sanitizeForSpeech(text)
    if (!cleaned) return
    // 진행 중이면 중단
    try { window.speechSynthesis.cancel() } catch { /* ignore */ }

    const utter = new SpeechSynthesisUtterance(cleaned)
    utter.lang = 'ko-KR'
    utter.rate = opts.rate ?? 1.05
    utter.pitch = opts.pitch ?? 1
    utter.volume = opts.volume ?? 1
    if (voiceRef.current) utter.voice = voiceRef.current

    utter.onstart = () => setSpeaking(true)
    utter.onend = () => setSpeaking(false)
    utter.onerror = () => setSpeaking(false)

    try {
      window.speechSynthesis.speak(utter)
    } catch {
      setSpeaking(false)
    }
  }, [supported])

  const setAutoplay = useCallback((next: boolean) => {
    setAutoplayState(next)
    try {
      localStorage.setItem(AUTOPLAY_KEY, next ? '1' : '0')
    } catch { /* ignore */ }
  }, [])

  return { supported, speaking, autoplay, setAutoplay, speak, stop }
}
