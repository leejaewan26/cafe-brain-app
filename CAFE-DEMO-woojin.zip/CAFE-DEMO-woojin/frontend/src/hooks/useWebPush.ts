// Web Push 실제 구현 (Issue #19, Wave 5D)
// Service Worker 등록 + PushManager 구독 + 백엔드 등록
// VAPID 키 미설정 시 로컬 Notification만 동작 (폴백)
import { useCallback, useEffect, useState } from 'react'
import { useAuthStore } from '@/store/authStore'
import { useProfileStore } from '@/store/profileStore'

export type NotificationPermissionState = 'default' | 'granted' | 'denied' | 'unsupported'

function getInitialPermission(): NotificationPermissionState {
  if (typeof window === 'undefined' || typeof Notification === 'undefined') return 'unsupported'
  return Notification.permission as NotificationPermissionState
}

// base64url → ArrayBuffer (VAPID 공개키 변환, PushManager.subscribe가 BufferSource 기대)
function urlBase64ToArrayBuffer(base64String: string): ArrayBuffer {
  const padding = '='.repeat((4 - (base64String.length % 4)) % 4)
  const base64 = (base64String + padding).replace(/-/g, '+').replace(/_/g, '/')
  const raw = atob(base64)
  const buf = new ArrayBuffer(raw.length)
  const view = new Uint8Array(buf)
  for (let i = 0; i < raw.length; i++) view[i] = raw.charCodeAt(i)
  return buf
}

export function useWebPush() {
  const user = useAuthStore((s) => s.user)
  const activeProfile = useProfileStore((s) => s.activeProfile)
  const [permission, setPermission] = useState<NotificationPermissionState>(getInitialPermission)
  const [subscribed, setSubscribed] = useState(false)
  const [busy, setBusy] = useState(false)

  // Service Worker 등록 (앱 부팅 시)
  useEffect(() => {
    if (typeof window === 'undefined' || !('serviceWorker' in navigator)) return
    navigator.serviceWorker
      .register('/sw.js', { scope: '/' })
      .catch(() => {
        // 등록 실패해도 앱 자체는 동작
      })
  }, [])

  // 현재 구독 상태 체크
  useEffect(() => {
    if (typeof window === 'undefined' || !('serviceWorker' in navigator)) return
    navigator.serviceWorker.ready
      .then((reg) => reg.pushManager.getSubscription())
      .then((sub) => setSubscribed(!!sub))
      .catch(() => setSubscribed(false))
  }, [permission])

  /** 권한 요청 + Push 구독 */
  const subscribe = useCallback(async (): Promise<boolean> => {
    if (!user) return false
    if (typeof Notification === 'undefined') {
      setPermission('unsupported')
      return false
    }

    setBusy(true)
    try {
      // 1. 알림 권한
      const p = await Notification.requestPermission()
      setPermission(p as NotificationPermissionState)
      if (p !== 'granted') return false

      if (!('serviceWorker' in navigator) || !('PushManager' in window)) {
        // Push 미지원이지만 로컬 Notification은 가능
        return true
      }

      // 2. VAPID 공개키 조회
      const vapidRes = await fetch('/api/v1/push/vapid-public-key')
      const vapidData = await vapidRes.json()

      if (!vapidData.configured || !vapidData.publicKey) {
        // VAPID 미설정 환경 — 로컬 알림만 가능 (일관된 성공 반환)
        return true
      }

      // 3. Service Worker ready
      const reg = await navigator.serviceWorker.ready

      // 4. 기존 구독 있으면 재사용
      let sub = await reg.pushManager.getSubscription()
      if (!sub) {
        sub = await reg.pushManager.subscribe({
          userVisibleOnly: true,
          applicationServerKey: urlBase64ToArrayBuffer(vapidData.publicKey),
        })
      }

      // 5. 백엔드에 구독 정보 등록
      const subJson = sub.toJSON()
      await fetch('/api/v1/push/subscribe', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-Store-Id': user.id,
        },
        body: JSON.stringify({
          store_id: user.id,
          profile_id: activeProfile?.id ?? null,
          subscription: {
            endpoint: subJson.endpoint,
            keys: {
              p256dh: subJson.keys?.p256dh ?? '',
              auth: subJson.keys?.auth ?? '',
            },
          },
          user_agent: navigator.userAgent,
        }),
      })

      setSubscribed(true)
      return true
    } catch {
      return false
    } finally {
      setBusy(false)
    }
  }, [user, activeProfile])

  /** 구독 해제 */
  const unsubscribe = useCallback(async (): Promise<boolean> => {
    if (typeof window === 'undefined' || !('serviceWorker' in navigator)) return false
    setBusy(true)
    try {
      const reg = await navigator.serviceWorker.ready
      const sub = await reg.pushManager.getSubscription()
      if (sub) {
        const endpoint = sub.endpoint
        await sub.unsubscribe()
        await fetch('/api/v1/push/unsubscribe', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ endpoint }),
        })
      }
      setSubscribed(false)
      return true
    } catch {
      return false
    } finally {
      setBusy(false)
    }
  }, [])

  /** 로컬 테스트 알림 (구독 후 동작 확인용) */
  const notifyLocal = useCallback((title: string, body: string, tag?: string) => {
    if (permission !== 'granted' || typeof Notification === 'undefined') return
    try {
      new Notification(title, { body, tag: tag ?? 'cafe-brain', icon: '/favicon.svg' })
    } catch { /* silent */ }
  }, [permission])

  return { permission, subscribed, busy, subscribe, unsubscribe, notifyLocal }
}

// 알림 트리거 타입별 제목·본문 템플릿 (기존 유지)
export const NOTIFY_TEMPLATES: Record<string, { title: string; bodyFn: (ctx?: string) => string }> = {
  sales_anomaly: {
    title: '📉 매출 급락 감지',
    bodyFn: (ctx) => `평소보다 매출이 크게 떨어졌어요. ${ctx ?? ''}`,
  },
  new_review: {
    title: '⭐ 새 리뷰',
    bodyFn: (ctx) => `새 리뷰가 등록됐어요. ${ctx ?? ''}`,
  },
  order_pending: {
    title: '📥 발주 승인 요청',
    bodyFn: (ctx) => `점장이 발주를 요청했어요. ${ctx ?? ''}`,
  },
  bep_reached: {
    title: '🎉 BEP 달성!',
    bodyFn: (ctx) => `이번 달 BEP를 달성했어요! ${ctx ?? ''}`,
  },
  daily_briefing: {
    title: '🌅 오늘의 브리핑',
    bodyFn: (ctx) => ctx ?? '오늘의 매장 운영 인사이트가 준비됐어요',
  },
}
