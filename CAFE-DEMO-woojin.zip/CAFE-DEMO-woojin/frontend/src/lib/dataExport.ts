// 데이터 내보내기 유틸리티 (Day 4-1)
// CSV, Excel (.xlsx), 인쇄 PDF 3종 내보내기
// /ultrareview: 해지 시 고객 데이터 락인 반감, xlsx 이미 설치됨
//
// 설계:
//   - CSV: 순수 브라우저 Blob (라이브러리 X)
//   - Excel: xlsx 동적 import (번들 최적화)
//   - PDF: window.print() + @media print CSS (별도 라이브러리 X)
//
// 모든 파일명은 "카페브레인_{제목}_{YYYYMMDD}.{ext}" 규격

export interface ExportOptions {
  filename: string         // 확장자 제외 ("매출데이터_2026-04-24")
  sheetName?: string       // Excel 시트명 (기본: 'Sheet1')
}

/**
 * 한글·쉼표·따옴표 안전한 CSV 셀 인용 처리
 * RFC 4180 규격 — 쉼표·줄바꿈·따옴표 포함 시 쌍따옴표로 감싸고 내부 따옴표는 이스케이프
 */
function csvEscape(value: unknown): string {
  if (value === null || value === undefined) return ''
  const s = String(value)
  // 숫자는 그대로 (지수표기 변환 방지 목적으로 0으로 시작하는 문자는 보호)
  if (/^-?\d+\.?\d*$/.test(s)) return s
  // 특수 문자 포함 시 인용
  if (/[",\n\r]/.test(s)) {
    return `"${s.replace(/"/g, '""')}"`
  }
  return s
}

/**
 * 객체 배열을 CSV 문자열로 변환.
 * 첫 객체의 키 순서를 헤더로 사용.
 */
export function rowsToCsv<T extends Record<string, unknown>>(rows: T[]): string {
  if (rows.length === 0) return ''
  const headers = Object.keys(rows[0])
  const lines = [
    headers.map(csvEscape).join(','),
    ...rows.map((r) => headers.map((h) => csvEscape(r[h])).join(',')),
  ]
  // Excel 한글 깨짐 방지 BOM + CRLF
  return '\ufeff' + lines.join('\r\n')
}

/**
 * CSV 다운로드 트리거.
 */
export function downloadCsv<T extends Record<string, unknown>>(
  rows: T[],
  opts: ExportOptions,
): void {
  const csv = rowsToCsv(rows)
  const blob = new Blob([csv], { type: 'text/csv;charset=utf-8' })
  triggerDownload(blob, `${opts.filename}.csv`)
}

/**
 * Excel (.xlsx) 다운로드. xlsx 패키지 동적 로드로 번들 최적화.
 */
export async function downloadExcel<T extends Record<string, unknown>>(
  rows: T[],
  opts: ExportOptions,
): Promise<void> {
  if (rows.length === 0) {
    throw new Error('내보낼 데이터가 없어요')
  }
  const XLSX = await import('xlsx')
  const worksheet = XLSX.utils.json_to_sheet(rows)
  const workbook = XLSX.utils.book_new()
  XLSX.utils.book_append_sheet(workbook, worksheet, opts.sheetName ?? 'Sheet1')
  // 컬럼 폭 자동 (한글 평균 12자)
  const headers = Object.keys(rows[0])
  worksheet['!cols'] = headers.map(() => ({ wch: 14 }))
  XLSX.writeFile(workbook, `${opts.filename}.xlsx`)
}

/**
 * 인쇄 대화상자 띄우기 (PDF 저장 가능).
 * 사장님이 "PDF로 저장" 옵션을 선택하면 자동 PDF 다운로드.
 *
 * printableId: 인쇄할 컨테이너의 id (예: 'print-sales-report')
 *              CSS의 @media print에서 해당 영역만 노출.
 */
export function printReport(printableId?: string): void {
  // printable 영역이 지정된 경우 body에 임시 클래스 부여해서 해당 영역만 노출
  if (printableId) {
    document.body.setAttribute('data-print-target', printableId)
  }
  window.print()
  // 인쇄 다이얼로그 닫힌 뒤 정리 (비동기)
  setTimeout(() => {
    document.body.removeAttribute('data-print-target')
  }, 500)
}

/**
 * 파일 다운로드 트리거 (공통 헬퍼).
 */
function triggerDownload(blob: Blob, filename: string): void {
  const url = URL.createObjectURL(blob)
  const a = document.createElement('a')
  a.href = url
  a.download = filename
  document.body.appendChild(a)
  a.click()
  document.body.removeChild(a)
  // 메모리 해제
  setTimeout(() => URL.revokeObjectURL(url), 1000)
}

/**
 * 오늘 날짜를 YYYY-MM-DD 형식으로 반환 (파일명용).
 */
export function todayFilenameStamp(): string {
  const d = new Date()
  const yy = d.getFullYear()
  const mm = String(d.getMonth() + 1).padStart(2, '0')
  const dd = String(d.getDate()).padStart(2, '0')
  return `${yy}-${mm}-${dd}`
}
