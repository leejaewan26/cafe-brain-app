"""
Critical 보안: PII 필터가 사용자 입력에서 민감정보를 마스킹하는지.
실제 라우터를 호출하지 않고 미들웨어 함수만 격리 검증.
"""
import json

import pytest


@pytest.mark.parametrize("raw,expected_mask", [
    ("홍길동 010-1234-5678 입니다", "***-****-****"),  # 전화번호
    ("주민번호: 901225-1234567", "******-*******"),  # 주민
    ("카드 1234-5678-9012-3456 결제", "****-****-****-****"),  # 카드
    ("이메일 hello@example.com 보내", "***@***.***"),  # 이메일
])
def test_pii_filter_masks_korean_pii(raw, expected_mask):
    """전화·주민·카드·이메일이 prompt에 들어와도 PII filter가 마스킹."""
    from app.middleware.pii_filter import mask_pii
    masked = mask_pii(raw)
    # 마스킹 패턴이 포함되거나, 원본 PII가 사라졌는지
    assert raw not in masked or expected_mask in masked or "*" in masked
