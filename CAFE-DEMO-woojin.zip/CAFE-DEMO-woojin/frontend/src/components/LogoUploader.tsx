// 매장 로고 업로드 컴포넌트 (Issue #15)
// Supabase Storage `store-logos` 버킷에 업로드 → public URL을 stores.logo_url에 저장
// 용량 제한: 2MB / 허용 포맷: PNG, JPG, WebP, SVG
import { useRef, useState } from 'react'
import { Upload, X, Loader2, AlertCircle, ImageIcon } from 'lucide-react'
import toast from 'react-hot-toast'
import { supabase } from '@/lib/supabase'
import { useAuthStore } from '@/store/authStore'
import { cn } from '@/lib/utils'

const MAX_SIZE_MB = 2
const ALLOWED_TYPES = ['image/png', 'image/jpeg', 'image/jpg', 'image/webp', 'image/svg+xml']
const BUCKET = 'store-logos'
const MAX_DIMENSION = 512  // 로고는 512px 이상 필요 없음
const OUTPUT_QUALITY = 0.85 // JPG/WebP 품질

/**
 * 이미지 브라우저 리사이징 (Canvas 기반)
 * - 긴 변이 MAX_DIMENSION 넘으면 비율 유지하며 축소
 * - PNG·JPEG은 WebP로 변환 (더 작은 용량)
 * - SVG는 그대로 반환
 */
async function optimizeImage(file: File): Promise<Blob> {
  if (file.type === 'image/svg+xml') return file

  const img = await new Promise<HTMLImageElement>((resolve, reject) => {
    const i = new Image()
    i.onload = () => resolve(i)
    i.onerror = reject
    i.src = URL.createObjectURL(file)
  })

  const longer = Math.max(img.width, img.height)
  const scale = longer > MAX_DIMENSION ? MAX_DIMENSION / longer : 1
  const width = Math.round(img.width * scale)
  const height = Math.round(img.height * scale)

  const canvas = document.createElement('canvas')
  canvas.width = width
  canvas.height = height
  const ctx = canvas.getContext('2d')
  if (!ctx) return file

  ctx.drawImage(img, 0, 0, width, height)
  URL.revokeObjectURL(img.src)

  // WebP 우선, 브라우저 미지원 시 PNG
  const type = 'image/webp'
  return new Promise<Blob>((resolve) => {
    canvas.toBlob(
      (blob) => resolve(blob ?? file),
      type,
      OUTPUT_QUALITY,
    )
  })
}

interface LogoUploaderProps {
  className?: string
}

export default function LogoUploader({ className }: LogoUploaderProps) {
  const { user, storeInfo, setStoreInfo } = useAuthStore()
  const fileRef = useRef<HTMLInputElement>(null)
  const [uploading, setUploading] = useState(false)
  const [error, setError] = useState('')

  const logoUrl = storeInfo?.logo_url ?? null

  // ─── 검증 ───
  const validate = (file: File): string | null => {
    if (!ALLOWED_TYPES.includes(file.type)) {
      return 'PNG, JPG, WebP, SVG 형식만 업로드 가능합니다'
    }
    if (file.size > MAX_SIZE_MB * 1024 * 1024) {
      return `파일 크기는 ${MAX_SIZE_MB}MB 이하여야 합니다`
    }
    return null
  }

  // ─── 업로드 처리 ───
  const handleFile = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file || !user) return
    setError('')

    const validationError = validate(file)
    if (validationError) {
      setError(validationError)
      return
    }

    setUploading(true)
    try {
      // Wave 5F: 클라이언트 리사이징·WebP 변환 (용량 대폭 감소)
      let uploadBlob: Blob = file
      let ext = file.name.split('.').pop()?.toLowerCase() ?? 'png'
      try {
        const optimized = await optimizeImage(file)
        if (optimized.size < file.size) {
          uploadBlob = optimized
          ext = file.type === 'image/svg+xml' ? 'svg' : 'webp'
        }
      } catch {
        // 리사이징 실패 시 원본 사용
      }

      const path = `${user.id}/logo_${Date.now()}.${ext}`

      // 기존 로고 삭제 시도 (실패해도 무시 — 업로드 진행)
      if (logoUrl) {
        const oldPath = extractPath(logoUrl)
        if (oldPath) {
          await supabase.storage.from(BUCKET).remove([oldPath])
        }
      }

      // 업로드
      const { error: uploadError } = await supabase.storage
        .from(BUCKET)
        .upload(path, uploadBlob, {
          cacheControl: '3600',
          upsert: false,
          contentType: uploadBlob.type || file.type,
        })
      if (uploadError) throw uploadError

      // Public URL 생성
      const { data: publicData } = supabase.storage.from(BUCKET).getPublicUrl(path)
      const publicUrl = publicData.publicUrl

      // stores 테이블 업데이트
      const { error: dbError } = await supabase
        .from('stores')
        .update({ logo_url: publicUrl })
        .eq('id', user.id)
      if (dbError) throw dbError

      // 로컬 상태 동기화
      if (storeInfo) {
        setStoreInfo({ ...storeInfo, logo_url: publicUrl })
      }

      toast.success('로고가 업로드되었어요 ✨')
    } catch (e) {
      const msg = e instanceof Error ? e.message : '업로드 실패'
      setError(msg)
      toast.error('로고 업로드에 실패했습니다')
    } finally {
      setUploading(false)
      if (fileRef.current) fileRef.current.value = ''
    }
  }

  // ─── 삭제 처리 ───
  const handleRemove = async () => {
    if (!logoUrl || !user || !storeInfo) return
    if (!confirm('로고를 삭제하시겠어요?')) return

    setUploading(true)
    try {
      const path = extractPath(logoUrl)
      if (path) {
        await supabase.storage.from(BUCKET).remove([path])
      }
      await supabase.from('stores').update({ logo_url: null }).eq('id', user.id)
      setStoreInfo({ ...storeInfo, logo_url: null })
      toast.success('로고가 삭제되었어요')
    } catch {
      toast.error('삭제 실패')
    } finally {
      setUploading(false)
    }
  }

  return (
    <div className={cn('space-y-3', className)}>
      <div className="flex items-center gap-4">
        {/* 미리보기 */}
        <div
          className={cn(
            'w-24 h-24 rounded-2xl flex items-center justify-center shrink-0 overflow-hidden',
            logoUrl
              ? 'bg-white border border-gray-200'
              : 'bg-gray-50 border-2 border-dashed border-gray-300'
          )}
        >
          {logoUrl ? (
            <img
              src={logoUrl}
              alt="매장 로고"
              className="w-full h-full object-contain"
              onError={() => setError('로고 이미지를 불러올 수 없습니다')}
            />
          ) : (
            <ImageIcon size={28} className="text-gray-300" />
          )}
        </div>

        {/* 버튼 그룹 */}
        <div className="flex-1 space-y-2">
          <button
            onClick={() => fileRef.current?.click()}
            disabled={uploading}
            className="flex items-center gap-1.5 px-4 py-2 bg-[#2C1810] text-white rounded-xl text-sm font-medium hover:bg-[#3d2418] transition-colors duration-200 disabled:opacity-50"
          >
            {uploading ? (
              <>
                <Loader2 size={14} className="animate-spin" /> 업로드 중...
              </>
            ) : (
              <>
                <Upload size={14} /> {logoUrl ? '로고 교체' : '로고 업로드'}
              </>
            )}
          </button>
          {logoUrl && (
            <button
              onClick={handleRemove}
              disabled={uploading}
              className="flex items-center gap-1 px-3 py-1.5 text-sm text-red-500 hover:bg-red-50 rounded-lg transition-colors duration-200"
            >
              <X size={13} /> 삭제
            </button>
          )}
          <p className="text-xs text-gray-400">
            PNG · JPG · WebP · SVG / 최대 {MAX_SIZE_MB}MB
          </p>
        </div>

        <input
          ref={fileRef}
          type="file"
          accept={ALLOWED_TYPES.join(',')}
          onChange={handleFile}
          className="hidden"
        />
      </div>

      {error && (
        <div className="flex items-center gap-2 p-2.5 bg-orange-50 border border-orange-200 rounded-xl text-xs text-orange-700">
          <AlertCircle size={13} />
          <span>{error}</span>
        </div>
      )}
    </div>
  )
}

/** Supabase Storage public URL에서 버킷 내부 경로만 추출 */
function extractPath(publicUrl: string): string | null {
  const match = publicUrl.match(new RegExp(`${BUCKET}/(.+)$`))
  return match ? match[1].split('?')[0] : null
}
