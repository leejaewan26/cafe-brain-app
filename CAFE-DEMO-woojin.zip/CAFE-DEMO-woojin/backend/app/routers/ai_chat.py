"""
AI 어시스턴트 채팅 라우터
- Gemini 기반 멀티턴 대화
- 매장 컨텍스트 시스템 프롬프트 통합
- 캐싱 미적용: 멀티턴 대화는 동일 질문도 맥락에 따라 응답이 달라야 함
- Wave 5C: 대화에서 자동 메모리 추출 (학습 루프)
"""
import asyncio
from fastapi import APIRouter
from pydantic import BaseModel
from typing import List, Optional, Any
from app.services.gemini_service import generate_insight, generate_with_tools
from app.services import memory_service

router = APIRouter()


# ─── 스키마 ───

class ChatMessage(BaseModel):
    role: str     # "user" | "assistant"
    content: str


class ChatRequest(BaseModel):
    message: str
    system_context: str
    history: List[ChatMessage] = []
    store_id: Optional[str] = None  # Wave 5C: 메모리 추출용
    tone: Optional[str] = None       # Day 6-2: 사장님 선호 어조 (polite|friendly|humor)
    enable_tools: bool = True        # Phase 6: Gemini function calling (매장 데이터 자동 조회)
    # Phase 6 #8: Vision — 이미지 첨부 분석 (data:image/...;base64,XXX 또는 순수 base64)
    image_base64: Optional[str] = None
    image_mime: Optional[str] = None  # "image/jpeg" | "image/png" | "image/webp"


class ChatResponse(BaseModel):
    reply: str
    tool_calls: List[dict] = []      # Phase 6: 호출된 도구 + 결과 (투명성)


# Day 6-2: 어조 프리셋 — 시스템 프롬프트에 주입
TONE_INSTRUCTIONS: dict[str, str] = {
    "polite":   "격식 있고 정중한 존댓말로 답변하세요. '~습니다/드립니다' 체를 사용합니다.",
    "friendly": "친근하고 따뜻한 반말-존댓말 혼합으로 답변하세요. '~해요/~답니다' 체로 편안하게.",
    "humor":    "재치 있고 유머러스한 어조로 답변하세요. 상황에 맞는 이모지를 1-2개 사용해도 좋습니다.",
}


# ─── 메모리 추출 프롬프트 (백그라운드) ───

MEMORY_EXTRACT_PROMPT = """
아래는 카페 사장님과 AI의 대화입니다. 이 대화에서 향후 AI가 이 매장을 돕는 데
유용할 장기 메모리로 저장할 만한 정보가 있는지 판단하세요.

기준:
- 매장 운영 패턴 (요일·시간·시즌 특성)
- 고객 반복 피드백 키워드
- 사장님의 결정 (가격·메뉴·정책 변경)
- 사장님의 선호·성향
- 목표·KPI
- 주목할 이벤트

JSON 형식으로 출력 (없으면 빈 배열). 최대 3개:
[
  {{"category": "business_pattern", "content": "...", "importance": 5}},
  ...
]

category는 다음 중 하나: business_pattern, customer_insight, decision_history,
preference, event, goal, accepted_suggestion, rejected_suggestion

[대화]
사장님: {user_msg}
AI: {ai_reply}

JSON 배열만 출력 (코드블록 없이):
""".strip()


async def _extract_memories_bg(store_id: str, user_msg: str, ai_reply: str):
    """
    백그라운드: 대화에서 memory 추출 (비동기, 실패해도 무시).
    Phase 3: 운영 시간 밖이면 추출 스킵 (Gemini 토큰 절약).
    """
    # Phase 3: 운영 시간 게이트 — 매장별 영업 시간 밖이면 메모리 추출 안 함
    from app.middleware.agent_gate import is_within_operating_hours
    within, _, _, _ = await is_within_operating_hours(store_id)
    if not within:
        return

    try:
        prompt = MEMORY_EXTRACT_PROMPT.format(
            user_msg=user_msg[:500],
            ai_reply=ai_reply[:800],
        )
        raw = await generate_insight(prompt, show_watermark=False, max_retries=0)

        import json as _json
        import re as _re

        cleaned = _re.sub(r"```(?:json)?\s*|\s*```", "", raw).strip()
        items = _json.loads(cleaned)
        if not isinstance(items, list):
            return
        for item in items[:3]:
            cat = item.get("category")
            content = item.get("content")
            importance = int(item.get("importance", 5))
            if cat and content and len(content) > 10:
                await memory_service.insert_memory(
                    store_id=store_id,
                    category=cat,
                    content=content,
                    importance=min(10, max(1, importance)),
                    confidence=0.6,  # 자동 추출이므로 중간 신뢰도
                    source_type="chat_extraction",
                )
    except Exception:
        # 메모리 추출 실패는 조용히
        pass


# ─── 엔드포인트 ───

@router.post("/message", response_model=ChatResponse)
async def chat_message(req: ChatRequest):
    """
    AI 어시스턴트 멀티턴 대화
    - 매장 컨텍스트를 시스템 프롬프트로 주입
    - 이전 대화 이력 포함 (최근 10턴)
    - Wave 5C: 대화 후 자동 메모리 추출 (백그라운드)
    """
    history_text = ""
    if req.history:
        history_lines = []
        for msg in req.history[-10:]:
            role_label = "사장님" if msg.role == "user" else "AI"
            history_lines.append(f"{role_label}: {msg.content}")
        history_text = "\n".join(history_lines)
        history_text = f"\n\n[이전 대화]\n{history_text}\n"

    # Day 6-2: 사장님 선호 어조 주입 (화이트리스트만 허용 → 프롬프트 인젝션 방어)
    tone_hint = ""
    if req.tone and req.tone in TONE_INSTRUCTIONS:
        tone_hint = f"\n[어조 지침]\n{TONE_INSTRUCTIONS[req.tone]}\n"

    prompt = f"""{req.system_context}{tone_hint}
{history_text}
사장님: {req.message}

AI:"""

    # Phase 6 #8: Vision — 이미지 첨부 시 Gemini Vision으로 우선 호출
    tool_calls: List[dict] = []
    if req.image_base64:
        try:
            # K7: 공통 Vision 함수 사용 (이전 inline 구현 제거)
            from app.services.gemini_service import generate_insight_from_image
            reply_text = await generate_insight_from_image(
                prompt=prompt,
                image_base64=req.image_base64,
                mime_type=req.image_mime or "image/jpeg",
                show_watermark=False,
            )
        except Exception as e:
            reply_text = f"⚠️ 이미지 분석 실패: {str(e)[:120]}\n\n텍스트만으로 다시 시도해주세요."
    elif req.store_id and req.enable_tools:
        # Tool Use — store_id + tools 활성
        try:
            reply_text, tool_calls = await generate_with_tools(prompt, req.store_id)
            reply_text = reply_text.strip()
            # Bonus E2: 호출된 도구에서 인용 자동 도출 → footnote 부착
            try:
                from app.services.gemini_service import (
                    attach_citations,
                    derive_citations_from_tool_calls,
                )
                cites = derive_citations_from_tool_calls(tool_calls)
                if cites:
                    reply_text = attach_citations(reply_text, cites)
            except Exception:
                pass
        except Exception:
            reply_text = (await generate_insight(prompt)).strip()
    else:
        reply_text = (await generate_insight(prompt)).strip()

    # 백그라운드로 메모리 추출 (응답 블록 X)
    if req.store_id:
        asyncio.create_task(_extract_memories_bg(req.store_id, req.message, reply_text))

    return ChatResponse(reply=reply_text, tool_calls=tool_calls)
