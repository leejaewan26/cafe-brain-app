-- ═══════════════════════════════════════════════════════════════
-- 카페 브레인 통합 마이그레이션 (002 ~ 010)
-- Supabase Dashboard > SQL Editor 전체 복붙 후 RUN
-- 안전: IF NOT EXISTS + DROP POLICY IF EXISTS 기반 (재실행 OK)
-- ═══════════════════════════════════════════════════════════════

-- 기존 001의 정책 재실행 안전화 (중복 에러 방지)
DROP POLICY IF EXISTS "stores: 본인 데이터만 조회" ON public.stores;
DROP POLICY IF EXISTS "stores: 본인 데이터만 삽입" ON public.stores;
DROP POLICY IF EXISTS "stores: 본인 데이터만 수정" ON public.stores;
DROP POLICY IF EXISTS "stores: 본인 데이터만 삭제" ON public.stores;
DROP POLICY IF EXISTS "chat_history: 본인 데이터만 접근" ON public.chat_history;

CREATE POLICY "stores: 본인 데이터만 조회" ON public.stores FOR SELECT USING (auth.uid() = id);
CREATE POLICY "stores: 본인 데이터만 삽입" ON public.stores FOR INSERT WITH CHECK (auth.uid() = id);
CREATE POLICY "stores: 본인 데이터만 수정" ON public.stores FOR UPDATE USING (auth.uid() = id);
CREATE POLICY "stores: 본인 데이터만 삭제" ON public.stores FOR DELETE USING (auth.uid() = id);


-- ════════════════════════════════════════════════
-- 📄 002_sales_schema.sql
-- ════════════════════════════════════════════════
-- 매출 기록 테이블
CREATE TABLE IF NOT EXISTS public.sales_records (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  store_id uuid NOT NULL REFERENCES public.stores(id) ON DELETE CASCADE,
  sale_date date NOT NULL,
  hour_slot integer NOT NULL DEFAULT 9 CHECK (hour_slot BETWEEN 0 AND 23),
  day_of_week integer NOT NULL CHECK (day_of_week BETWEEN 0 AND 6),
  menu_name text NOT NULL,
  quantity integer NOT NULL DEFAULT 1,
  revenue numeric NOT NULL DEFAULT 0,
  cost numeric NOT NULL DEFAULT 0,
  discount numeric NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now()
);

-- 인덱스: 자주 쓰는 필터 기준
CREATE INDEX IF NOT EXISTS idx_sales_records_store_date ON public.sales_records(store_id, sale_date);
CREATE INDEX IF NOT EXISTS idx_sales_records_menu ON public.sales_records(store_id, menu_name);

-- RLS: 본인 매장 데이터만 접근
ALTER TABLE public.sales_records ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "sales_records: 본인 매장만 접근" ON public.sales_records;
CREATE POLICY "sales_records: 본인 매장만 접근" ON public.sales_records
  FOR ALL USING (store_id = auth.uid());


-- ════════════════════════════════════════════════
-- 📄 003_settings_and_storage.sql
-- ════════════════════════════════════════════════
-- Wave 1 마이그레이션
-- 1) stores 테이블에 Issue #15·#1 필드 추가
-- 2) store-logos 스토리지 버킷 + RLS 정책

-- ─── stores 테이블 확장 ───
ALTER TABLE public.stores
  ADD COLUMN IF NOT EXISTS logo_url text;

ALTER TABLE public.stores
  ADD COLUMN IF NOT EXISTS monthly_fixed_cost numeric DEFAULT 3000000
    CHECK (monthly_fixed_cost >= 0);

COMMENT ON COLUMN public.stores.logo_url IS 'Issue #15: 매장 로고 (Supabase Storage public URL)';
COMMENT ON COLUMN public.stores.monthly_fixed_cost IS 'Issue #1: BEP 계산용 월 고정비 (임대료+인건비+관리비)';

-- ─── Storage 버킷 생성 (공개 읽기, 본인만 쓰기) ───
INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES (
  'store-logos',
  'store-logos',
  true,
  2097152,  -- 2MB
  ARRAY['image/png', 'image/jpeg', 'image/jpg', 'image/webp', 'image/svg+xml']
)
ON CONFLICT (id) DO UPDATE SET
  public = EXCLUDED.public,
  file_size_limit = EXCLUDED.file_size_limit,
  allowed_mime_types = EXCLUDED.allowed_mime_types;

-- ─── Storage RLS 정책 ───
-- 경로 규칙: {user_id}/logo_{timestamp}.{ext}
-- storage.foldername(name)[1] = 최상위 폴더명 = user_id

-- 공개 읽기 (누구나 로고 볼 수 있음)
DROP POLICY IF EXISTS "store-logos 공개 읽기" ON storage.objects;
CREATE POLICY "store-logos 공개 읽기"
  ON storage.objects FOR SELECT
  USING (bucket_id = 'store-logos');

-- 본인 폴더에만 업로드
DROP POLICY IF EXISTS "store-logos 본인 업로드" ON storage.objects;
CREATE POLICY "store-logos 본인 업로드"
  ON storage.objects FOR INSERT
  WITH CHECK (
    bucket_id = 'store-logos'
    AND auth.uid()::text = (storage.foldername(name))[1]
  );

-- 본인 파일만 교체
DROP POLICY IF EXISTS "store-logos 본인 업데이트" ON storage.objects;
CREATE POLICY "store-logos 본인 업데이트"
  ON storage.objects FOR UPDATE
  USING (
    bucket_id = 'store-logos'
    AND auth.uid()::text = (storage.foldername(name))[1]
  );

-- 본인 파일만 삭제
DROP POLICY IF EXISTS "store-logos 본인 삭제" ON storage.objects;
CREATE POLICY "store-logos 본인 삭제"
  ON storage.objects FOR DELETE
  USING (
    bucket_id = 'store-logos'
    AND auth.uid()::text = (storage.foldername(name))[1]
  );


-- ════════════════════════════════════════════════
-- 📄 004_agent_memory.sql
-- ════════════════════════════════════════════════
-- Batch 2 Sub-2A: 능동형 에이전트 개인 학습 메모리 시스템
-- Issue #10 대비 Foundation — 지금부터 데이터 축적, 런칭 시점엔 풍부한 매장 프로필 확보
-- 상세 설계: docs/agent-personalization.md 참조

-- ══════════════════════════════════════════════════════════
-- 1. agent_memory — 구조화된 장기 기억
-- ══════════════════════════════════════════════════════════
CREATE TABLE IF NOT EXISTS public.agent_memory (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  store_id uuid NOT NULL REFERENCES public.stores(id) ON DELETE CASCADE,

  -- 메모리 카테고리 (검색·필터용)
  category text NOT NULL CHECK (category IN (
    'business_pattern',     -- 요일/시간/시즌 패턴
    'customer_insight',     -- 고객 피드백 반복 키워드
    'decision_history',     -- 가격·메뉴·정책 변경 이력
    'preference',           -- 사장님 성향·선호 스타일
    'event',                -- 특이 이벤트 (매출 급락, 리뷰 폭증)
    'goal',                 -- 목표·KPI
    'accepted_suggestion',  -- 수용한 AI 제안 (+ 실제 효과)
    'rejected_suggestion'   -- 거부한 제안 (반복 방지)
  )),

  -- 자연어 메모리 내용 (1-3줄)
  content text NOT NULL CHECK (char_length(content) <= 1000),

  -- 랭킹용 메타데이터
  importance int NOT NULL DEFAULT 5 CHECK (importance BETWEEN 1 AND 10),
  confidence numeric NOT NULL DEFAULT 0.7 CHECK (confidence BETWEEN 0 AND 1),

  -- 사용 추적 (더 자주 쓰일수록 강화)
  use_count int NOT NULL DEFAULT 0,
  last_used_at timestamptz,
  last_reinforced_at timestamptz NOT NULL DEFAULT now(),

  -- 원천 추적 (설명 가능성)
  source_type text,       -- 'sales_anomaly', 'user_feedback', 'chat_extraction', 'review_trend'
  source_ref text,        -- 참조 레코드 ID (sales_records, chat_history 등)

  -- 라이프사이클
  created_at timestamptz NOT NULL DEFAULT now(),
  expires_at timestamptz,  -- null=영구
  archived_at timestamptz  -- 사용자 "잊어줘" or 노후화 시 설정
);

CREATE INDEX IF NOT EXISTS idx_memory_store_active
  ON public.agent_memory(store_id, importance DESC, last_used_at DESC NULLS LAST)
  WHERE archived_at IS NULL;

CREATE INDEX IF NOT EXISTS idx_memory_category
  ON public.agent_memory(store_id, category)
  WHERE archived_at IS NULL;

-- RLS: 본인 매장 메모리만 조회·수정 가능
ALTER TABLE public.agent_memory ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "agent_memory: 본인 매장만 접근" ON public.agent_memory;
CREATE POLICY "agent_memory: 본인 매장만 접근" ON public.agent_memory
  FOR ALL USING (store_id = auth.uid());

COMMENT ON TABLE public.agent_memory IS
  'Issue #10: 능동형 에이전트가 매장별로 축적하는 개인 맞춤 장기 기억. 시간이 쌓일수록 응답이 개인화됨.';


-- ══════════════════════════════════════════════════════════
-- 2. agent_feedback — AI 제안에 대한 사용자 반응
-- ══════════════════════════════════════════════════════════
CREATE TABLE IF NOT EXISTS public.agent_feedback (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  store_id uuid NOT NULL REFERENCES public.stores(id) ON DELETE CASCADE,

  -- 어떤 AI 출력에 대한 피드백인지
  source_type text NOT NULL,  -- 'sales_insight', 'review_reply', 'marketing_draft', 'agent_briefing', 'chat_message'
  source_ref text NOT NULL,   -- 해당 출력 식별자

  -- 반응 (4가지 + 선택적 코멘트)
  reaction text NOT NULL CHECK (reaction IN (
    'helpful',     -- 👍 유용했어요
    'irrelevant',  -- 👎 관련 없어요
    'applied',     -- ✨ 실제로 적용했어요
    'muted'        -- 🔇 이런 알림·제안 꺼주세요
  )),
  note text,

  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_feedback_store
  ON public.agent_feedback(store_id, created_at DESC);

CREATE INDEX IF NOT EXISTS idx_feedback_source
  ON public.agent_feedback(source_type, source_ref);

ALTER TABLE public.agent_feedback ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "agent_feedback: 본인 매장만 접근" ON public.agent_feedback;
CREATE POLICY "agent_feedback: 본인 매장만 접근" ON public.agent_feedback
  FOR ALL USING (store_id = auth.uid());

COMMENT ON TABLE public.agent_feedback IS
  '사용자의 AI 제안 반응. 학습 루프의 신호 — 어떤 제안이 효과적이었는지 축적.';


-- ══════════════════════════════════════════════════════════
-- 3. agent_briefing_log — 능동 에이전트 발화 이력
-- ══════════════════════════════════════════════════════════
CREATE TABLE IF NOT EXISTS public.agent_briefing_log (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  store_id uuid NOT NULL REFERENCES public.stores(id) ON DELETE CASCADE,

  -- 트리거 유형 (Batch 4에서 활용)
  trigger_type text NOT NULL CHECK (trigger_type IN (
    'daily_briefing',      -- 일일 아침 브리핑
    'sales_anomaly',       -- 매출 이상 감지
    'bep_milestone',       -- BEP 달성·근접
    'review_surge',        -- 리뷰 폭증
    'reorder_reminder',    -- 재주문 시점
    'manual'               -- 수동 호출
  )),

  -- 참고한 메모리 (설명 가능성)
  context_memories uuid[] DEFAULT '{}'::uuid[],

  -- 프롬프트·응답 스냅샷 (디버깅·감사 추적)
  prompt_snapshot text,
  response text NOT NULL,

  -- 사용자 반응 (나중에 업데이트됨)
  user_reaction text,

  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_briefing_store_time
  ON public.agent_briefing_log(store_id, created_at DESC);

ALTER TABLE public.agent_briefing_log ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "agent_briefing_log: 본인 매장만 접근" ON public.agent_briefing_log;
CREATE POLICY "agent_briefing_log: 본인 매장만 접근" ON public.agent_briefing_log
  FOR ALL USING (store_id = auth.uid());


-- ══════════════════════════════════════════════════════════
-- 4. stores.agent_profile — 메모리 증류 요약 (프롬프트 주입용)
-- ══════════════════════════════════════════════════════════
ALTER TABLE public.stores
  ADD COLUMN IF NOT EXISTS agent_profile jsonb NOT NULL DEFAULT '{}'::jsonb;

ALTER TABLE public.stores
  ADD COLUMN IF NOT EXISTS agent_learning_enabled boolean NOT NULL DEFAULT true;

COMMENT ON COLUMN public.stores.agent_profile IS
  'agent_memory에서 주기적으로 증류된 매장 프로필 요약. 프롬프트 컨텍스트로 주입됨.';

COMMENT ON COLUMN public.stores.agent_learning_enabled IS
  '사용자 제어: AI 학습 on/off (프라이버시 권리)';


-- ══════════════════════════════════════════════════════════
-- 5. 유틸 함수: 관련 메모리 검색 (에이전트에서 호출)
-- ══════════════════════════════════════════════════════════
CREATE OR REPLACE FUNCTION public.search_relevant_memories(
  p_store_id uuid,
  p_categories text[] DEFAULT NULL,  -- null이면 전체
  p_limit int DEFAULT 10
)
RETURNS TABLE (
  id uuid,
  category text,
  content text,
  importance int,
  confidence numeric,
  created_at timestamptz
) AS $$
BEGIN
  RETURN QUERY
  SELECT m.id, m.category, m.content, m.importance, m.confidence, m.created_at
  FROM public.agent_memory m
  WHERE m.store_id = p_store_id
    AND m.archived_at IS NULL
    AND (m.expires_at IS NULL OR m.expires_at > now())
    AND (p_categories IS NULL OR m.category = ANY(p_categories))
  ORDER BY
    -- 랭킹 공식: 중요도(70%) + 최신성(30%)
    (m.importance * 0.7 +
     CASE
       WHEN m.last_reinforced_at > now() - interval '7 days' THEN 3.0
       WHEN m.last_reinforced_at > now() - interval '30 days' THEN 1.5
       ELSE 0.5
     END * 0.3
    ) * m.confidence DESC,
    m.last_used_at DESC NULLS LAST
  LIMIT p_limit;

  -- 조회된 메모리의 use_count·last_used_at 업데이트 (별도 UPDATE로)
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;


-- ══════════════════════════════════════════════════════════
-- 6. 유틸 함수: 메모리 사용 기록 (에이전트 발화 후 호출)
-- ══════════════════════════════════════════════════════════
CREATE OR REPLACE FUNCTION public.mark_memories_used(
  p_memory_ids uuid[]
) RETURNS void AS $$
BEGIN
  UPDATE public.agent_memory
  SET use_count = use_count + 1,
      last_used_at = now()
  WHERE id = ANY(p_memory_ids);
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;


-- ════════════════════════════════════════════════
-- 📄 005_multi_profile.sql
-- ════════════════════════════════════════════════
-- Issue #5: 멀티 프로필 시스템 (계정 1개 → 프로필 최대 3개)
-- 사장 / 점장·매니저 2단계 역할
-- 데이터는 store_id 기준 공유 (프로필 간 격리 X), 기능 접근만 역할별 제한

CREATE TABLE IF NOT EXISTS public.profiles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  store_id uuid NOT NULL REFERENCES public.stores(id) ON DELETE CASCADE,

  -- 프로필 기본 정보
  name text NOT NULL CHECK (char_length(name) BETWEEN 1 AND 20),
  role text NOT NULL CHECK (role IN ('owner', 'manager')),

  -- 선택적 PIN (4-6자리 숫자)
  pin_hash text,  -- 해시된 PIN (보안상 평문 저장 금지)

  -- 시각 구분
  avatar_emoji text DEFAULT '☕',
  avatar_color text DEFAULT '#D4A574',

  -- 생성/사용
  created_at timestamptz NOT NULL DEFAULT now(),
  last_active_at timestamptz
);

-- 스토어당 최대 3개 프로필 제약
CREATE OR REPLACE FUNCTION enforce_max_profiles_per_store()
RETURNS TRIGGER AS $$
BEGIN
  IF (SELECT count(*) FROM public.profiles WHERE store_id = NEW.store_id) >= 3 THEN
    RAISE EXCEPTION '한 매장당 최대 3개의 프로필만 생성 가능합니다';
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_max_profiles ON public.profiles;
CREATE TRIGGER trg_max_profiles
  BEFORE INSERT ON public.profiles
  FOR EACH ROW EXECUTE FUNCTION enforce_max_profiles_per_store();

-- 스토어당 최소 1명의 owner 유지
CREATE OR REPLACE FUNCTION enforce_at_least_one_owner()
RETURNS TRIGGER AS $$
BEGIN
  IF OLD.role = 'owner' AND TG_OP IN ('DELETE', 'UPDATE') THEN
    IF NOT EXISTS (
      SELECT 1 FROM public.profiles
      WHERE store_id = OLD.store_id
        AND role = 'owner'
        AND id != OLD.id
    ) THEN
      RAISE EXCEPTION '매장에 최소 1명의 사장 프로필은 있어야 합니다';
    END IF;
  END IF;
  RETURN OLD;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_keep_owner ON public.profiles;
CREATE TRIGGER trg_keep_owner
  BEFORE UPDATE OR DELETE ON public.profiles
  FOR EACH ROW EXECUTE FUNCTION enforce_at_least_one_owner();

-- 인덱스
CREATE INDEX IF NOT EXISTS idx_profiles_store ON public.profiles(store_id);

-- RLS: 본인 매장 프로필만 접근
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "profiles: 본인 매장 프로필 접근" ON public.profiles;
-- (중복 방지 DROP은 005에 이미 있음)
CREATE POLICY "profiles: 본인 매장 프로필 접근" ON public.profiles
  FOR ALL USING (store_id = auth.uid());

COMMENT ON TABLE public.profiles IS
  'Issue #5: 계정 1개에 최대 3개 프로필. 사장/점장 2단계 권한. 데이터는 공유, 접근만 제한.';


-- ══════════════════════════════════════════════════════════
-- 기존 매장에 기본 owner 프로필 자동 생성 (마이그레이션 안전)
-- ══════════════════════════════════════════════════════════
INSERT INTO public.profiles (store_id, name, role, avatar_emoji)
SELECT id, owner_name, 'owner', '👨‍💼'
FROM public.stores
WHERE NOT EXISTS (
  SELECT 1 FROM public.profiles p WHERE p.store_id = public.stores.id
)
ON CONFLICT DO NOTHING;


-- ════════════════════════════════════════════════
-- 📄 006_orders.sql
-- ════════════════════════════════════════════════
-- Issue #8: 발주 관리 시스템
-- 점장이 요청 → 사장이 승인 → 이력 저장 → 파일 다운로드

-- 발주 헤더
CREATE TABLE IF NOT EXISTS public.orders (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  store_id uuid NOT NULL REFERENCES public.stores(id) ON DELETE CASCADE,

  -- 작성·승인 추적 (profile 참조, nullable은 프로필 삭제 대비)
  requested_by_profile_id uuid REFERENCES public.profiles(id) ON DELETE SET NULL,
  requested_by_name text NOT NULL,  -- 스냅샷 (프로필 삭제돼도 이력 유지)
  approved_by_profile_id uuid REFERENCES public.profiles(id) ON DELETE SET NULL,
  approved_by_name text,

  -- 상태
  status text NOT NULL DEFAULT 'pending' CHECK (status IN (
    'pending',    -- 요청 대기
    'approved',   -- 승인 (발주 준비)
    'rejected',   -- 반려
    'ordered',    -- 실제 발주 완료 (수기 업데이트)
    'received'    -- 수령 완료
  )),

  -- 발주처 정보
  supplier_name text NOT NULL,
  supplier_phone text,
  notes text,

  -- 시간 추적
  requested_at timestamptz NOT NULL DEFAULT now(),
  approved_at timestamptz,
  rejected_reason text,
  ordered_at timestamptz,
  received_at timestamptz,

  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_orders_store_status
  ON public.orders(store_id, status, requested_at DESC);

-- 발주 항목 (라인 아이템)
CREATE TABLE IF NOT EXISTS public.order_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  order_id uuid NOT NULL REFERENCES public.orders(id) ON DELETE CASCADE,

  ingredient_name text NOT NULL,
  quantity numeric NOT NULL CHECK (quantity > 0),
  unit text NOT NULL,                   -- 'kg', 'g', '개', 'L' 등
  estimated_unit_price numeric,         -- 단가 추정 (선택)
  estimated_total numeric,              -- 예상 합계 (선택)
  item_notes text,

  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_order_items_order
  ON public.order_items(order_id);

-- RLS: 본인 매장만 접근
ALTER TABLE public.orders ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.order_items ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "orders: 본인 매장" ON public.orders;
CREATE POLICY "orders: 본인 매장" ON public.orders
  FOR ALL USING (store_id = auth.uid());

DROP POLICY IF EXISTS "order_items: 본인 매장" ON public.order_items;
CREATE POLICY "order_items: 본인 매장" ON public.order_items
  FOR ALL USING (
    EXISTS (SELECT 1 FROM public.orders o WHERE o.id = order_id AND o.store_id = auth.uid())
  );

COMMENT ON TABLE public.orders IS 'Issue #8: 발주 관리. 점장 요청 → 사장 승인 워크플로우.';


-- ════════════════════════════════════════════════
-- 📄 007_memory_triggers.sql
-- ════════════════════════════════════════════════
-- Issue #10 Foundation 2단계: 이벤트 캡처 DB 트리거
-- 주요 이벤트(리뷰·발주·매출)를 agent_memory로 자동 수집
-- Batch 4 능동 에이전트가 풍부한 학습 데이터를 갖도록

-- ══════════════════════════════════════════════════════════
-- 1. 리뷰 INSERT 트리거 (reviews 테이블은 Frontend 기반이지만
--    서버 저장으로 전환 시 대비해 INSERT 훅 준비)
-- ══════════════════════════════════════════════════════════

-- 나쁜 리뷰(1-2점) 신규 등록 → event 메모리 생성
-- (현재 reviews 테이블은 없지만 향후 확장 대비 함수만 준비)
CREATE OR REPLACE FUNCTION public.capture_review_event()
RETURNS TRIGGER AS $$
BEGIN
  IF NEW.rating <= 2 THEN
    INSERT INTO public.agent_memory (
      store_id, category, content, importance, confidence,
      source_type, source_ref
    ) VALUES (
      NEW.store_id,
      'customer_insight',
      format('부정 리뷰 (%s점): %s', NEW.rating,
        substring(COALESCE(NEW.content, '') FROM 1 FOR 150)),
      7,  -- 부정 리뷰는 중요도 높게
      0.9,
      'review_new',
      NEW.id::text
    );
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;


-- ══════════════════════════════════════════════════════════
-- 2. 발주 승인 트리거 — decision_history 메모리 자동 생성
-- ══════════════════════════════════════════════════════════

CREATE OR REPLACE FUNCTION public.capture_order_decision()
RETURNS TRIGGER AS $$
DECLARE
  item_summary text;
BEGIN
  -- status가 pending → approved 로 전환된 경우만
  IF OLD.status = 'pending' AND NEW.status = 'approved' THEN
    -- 발주 품목 요약
    SELECT string_agg(ingredient_name || '(' || quantity || unit || ')', ', ')
      INTO item_summary
      FROM public.order_items
      WHERE order_id = NEW.id
      LIMIT 10;

    INSERT INTO public.agent_memory (
      store_id, category, content, importance, confidence,
      source_type, source_ref
    ) VALUES (
      NEW.store_id,
      'decision_history',
      format('%s 발주 승인 — %s',
        NEW.supplier_name,
        COALESCE(substring(item_summary FROM 1 FOR 200), '품목 정보 없음')),
      6,
      1.0,
      'order_approved',
      NEW.id::text
    );
  END IF;

  -- 반려도 학습 신호로 기록
  IF OLD.status = 'pending' AND NEW.status = 'rejected' THEN
    INSERT INTO public.agent_memory (
      store_id, category, content, importance, confidence,
      source_type, source_ref
    ) VALUES (
      NEW.store_id,
      'rejected_suggestion',
      format('발주 반려: %s (사유: %s)',
        NEW.supplier_name,
        COALESCE(NEW.rejected_reason, '미지정')),
      5,
      0.9,
      'order_rejected',
      NEW.id::text
    );
  END IF;

  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

DROP TRIGGER IF EXISTS trg_capture_order_decision ON public.orders;
CREATE TRIGGER trg_capture_order_decision
  AFTER UPDATE ON public.orders
  FOR EACH ROW
  EXECUTE FUNCTION public.capture_order_decision();


-- ══════════════════════════════════════════════════════════
-- 3. 매출 이상 감지 함수 — pg_cron 또는 Edge Function에서 주기 호출
-- ══════════════════════════════════════════════════════════

-- 특정 매장의 오늘 매출과 최근 7일 평균 비교, -20% 이하면 event 메모리 생성
-- 리턴: 감지된 이벤트 수
CREATE OR REPLACE FUNCTION public.detect_sales_anomaly(p_store_id uuid)
RETURNS int AS $$
DECLARE
  today_revenue numeric;
  week_avg numeric;
  drop_pct numeric;
  memory_count int := 0;
BEGIN
  -- 오늘 매출 합계
  SELECT COALESCE(SUM(revenue), 0) INTO today_revenue
    FROM public.sales_records
    WHERE store_id = p_store_id
      AND sale_date = CURRENT_DATE;

  -- 최근 7일 평균 (오늘 제외)
  SELECT COALESCE(AVG(daily_sum), 0) INTO week_avg
    FROM (
      SELECT sale_date, SUM(revenue) AS daily_sum
        FROM public.sales_records
        WHERE store_id = p_store_id
          AND sale_date BETWEEN CURRENT_DATE - 7 AND CURRENT_DATE - 1
        GROUP BY sale_date
    ) daily;

  -- 최소 3일 이상 데이터 + 오늘 매출 존재 시만 판단
  IF week_avg > 0 AND today_revenue > 0 THEN
    drop_pct := ((today_revenue - week_avg) / week_avg) * 100;

    IF drop_pct <= -20 THEN
      INSERT INTO public.agent_memory (
        store_id, category, content, importance, confidence,
        source_type, source_ref
      ) VALUES (
        p_store_id,
        'event',
        format('매출 급락 감지 — 오늘 %s원 (최근 7일 평균 %s원 대비 %s%%)',
          round(today_revenue)::text,
          round(week_avg)::text,
          round(drop_pct, 1)::text),
        8,  -- 급락은 중요도 높게
        0.85,
        'sales_anomaly',
        CURRENT_DATE::text
      );
      memory_count := memory_count + 1;
    END IF;
  END IF;

  RETURN memory_count;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;


-- ══════════════════════════════════════════════════════════
-- 4. BEP 달성 감지 함수 — 월 BEP 도달 시 goal 메모리
-- ══════════════════════════════════════════════════════════

CREATE OR REPLACE FUNCTION public.detect_bep_milestone(p_store_id uuid)
RETURNS int AS $$
DECLARE
  monthly_fixed numeric;
  month_revenue numeric;
  month_cost numeric;
  bep_amount numeric;
  contribution_rate numeric;
  existing_count int;
BEGIN
  -- 이번 달 BEP 이미 감지된 이벤트 있는지 확인 (중복 방지)
  SELECT count(*) INTO existing_count
    FROM public.agent_memory
    WHERE store_id = p_store_id
      AND category = 'goal'
      AND source_type = 'bep_reached'
      AND source_ref = to_char(CURRENT_DATE, 'YYYY-MM')
      AND archived_at IS NULL;

  IF existing_count > 0 THEN RETURN 0; END IF;

  -- 매장 월 고정비
  SELECT monthly_fixed_cost INTO monthly_fixed
    FROM public.stores
    WHERE id = p_store_id;

  IF monthly_fixed IS NULL OR monthly_fixed <= 0 THEN RETURN 0; END IF;

  -- 이번 달 매출·원가
  SELECT
    COALESCE(SUM(revenue), 0),
    COALESCE(SUM(cost), 0)
    INTO month_revenue, month_cost
    FROM public.sales_records
    WHERE store_id = p_store_id
      AND date_trunc('month', sale_date) = date_trunc('month', CURRENT_DATE);

  -- 공헌이익률
  IF month_revenue > 0 THEN
    contribution_rate := (month_revenue - month_cost) / month_revenue;
    IF contribution_rate > 0 THEN
      bep_amount := monthly_fixed / contribution_rate;

      IF month_revenue >= bep_amount THEN
        INSERT INTO public.agent_memory (
          store_id, category, content, importance, confidence,
          source_type, source_ref
        ) VALUES (
          p_store_id,
          'goal',
          format('%s월 BEP 달성! 매출 %s원 / 목표 %s원',
            EXTRACT(MONTH FROM CURRENT_DATE)::text,
            round(month_revenue)::text,
            round(bep_amount)::text),
          9,
          1.0,
          'bep_reached',
          to_char(CURRENT_DATE, 'YYYY-MM')
        );
        RETURN 1;
      END IF;
    END IF;
  END IF;

  RETURN 0;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;


-- ══════════════════════════════════════════════════════════
-- 5. 통합 체크 함수 — Batch 4 pg_cron 5분마다 호출 예정
-- ══════════════════════════════════════════════════════════

CREATE OR REPLACE FUNCTION public.run_daily_memory_capture(p_store_id uuid)
RETURNS TABLE(event_type text, count int) AS $$
BEGIN
  RETURN QUERY
    SELECT 'sales_anomaly'::text, public.detect_sales_anomaly(p_store_id)
    UNION ALL
    SELECT 'bep_milestone'::text, public.detect_bep_milestone(p_store_id);
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

COMMENT ON FUNCTION public.run_daily_memory_capture IS
  'Batch 4 pg_cron에서 매장별 주기 호출. 이상 감지·마일스톤을 memory로 자동 수집.';


-- ════════════════════════════════════════════════
-- 📄 008_ingredients_and_accounting.sql
-- ════════════════════════════════════════════════
-- Issue #18: 재료 단가 DB + 메뉴 연결
-- Issue #20: 회계 (월별 손익 집계용 고정비 항목)

-- ══════════════════════════════════════════════════════════
-- Issue #18: 재료 단가 마스터 테이블
-- ══════════════════════════════════════════════════════════
CREATE TABLE IF NOT EXISTS public.ingredients (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  store_id uuid NOT NULL REFERENCES public.stores(id) ON DELETE CASCADE,

  name text NOT NULL,                     -- 재료명 ("원두", "우유" 등)
  unit text NOT NULL,                     -- 기본 단위 ("g", "ml", "kg", "L", "개")
  unit_price numeric NOT NULL DEFAULT 0 CHECK (unit_price >= 0),
  supplier text,                          -- 공급처 (옵션)
  notes text,

  updated_at timestamptz NOT NULL DEFAULT now(),
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_ingredients_store ON public.ingredients(store_id);
CREATE UNIQUE INDEX IF NOT EXISTS idx_ingredients_name_store
  ON public.ingredients(store_id, name);

ALTER TABLE public.ingredients ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "ingredients: 본인 매장" ON public.ingredients;
CREATE POLICY "ingredients: 본인 매장" ON public.ingredients
  FOR ALL USING (store_id = auth.uid());

COMMENT ON TABLE public.ingredients IS
  'Issue #18: 재료 단가 마스터. 단가 변경 시 메뉴 원가 자동 재계산의 기준.';


-- ══════════════════════════════════════════════════════════
-- Issue #20: 회계 — 월별 고정비 항목
-- (stores.monthly_fixed_cost는 총액만 있었음. 세부 분류 추가)
-- ══════════════════════════════════════════════════════════
CREATE TABLE IF NOT EXISTS public.accounting_fixed_costs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  store_id uuid NOT NULL REFERENCES public.stores(id) ON DELETE CASCADE,

  category text NOT NULL CHECK (category IN (
    'rent',          -- 임대료
    'labor',         -- 인건비 (자동 계산 가능하지만 고정 계약분)
    'utilities',     -- 공과금 (전기·가스·수도)
    'communication', -- 통신비
    'insurance',     -- 보험
    'loan',          -- 대출 상환
    'tax',           -- 세금
    'other'          -- 기타
  )),
  label text NOT NULL,                    -- 항목 이름 ("임대료", "KT 인터넷" 등)
  monthly_amount numeric NOT NULL CHECK (monthly_amount >= 0),
  notes text,

  active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_fixed_costs_store
  ON public.accounting_fixed_costs(store_id)
  WHERE active = true;

ALTER TABLE public.accounting_fixed_costs ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "accounting_fixed_costs: 본인 매장" ON public.accounting_fixed_costs;
CREATE POLICY "accounting_fixed_costs: 본인 매장" ON public.accounting_fixed_costs
  FOR ALL USING (store_id = auth.uid());


-- 월별 P&L 뷰 (매출 - 원재료 - 고정비)
CREATE OR REPLACE VIEW public.monthly_pnl AS
SELECT
  s.store_id,
  to_char(s.sale_date, 'YYYY-MM') AS month,
  SUM(s.revenue) AS total_revenue,
  SUM(s.cost) AS total_cost_of_goods,
  SUM(s.revenue - s.cost) AS gross_profit,
  SUM(s.revenue - s.cost) - COALESCE(
    (SELECT SUM(monthly_amount)
      FROM public.accounting_fixed_costs f
      WHERE f.store_id = s.store_id AND f.active = true),
    0
  ) AS net_profit,
  count(DISTINCT s.sale_date) AS operating_days
FROM public.sales_records s
GROUP BY s.store_id, to_char(s.sale_date, 'YYYY-MM');

COMMENT ON VIEW public.monthly_pnl IS
  'Issue #20: 월별 손익 요약. 순이익 = 매출 - 원재료 - 고정비(활성).';


-- ════════════════════════════════════════════════
-- 📄 009_security_hardening.sql
-- ════════════════════════════════════════════════
-- Wave 5A: 보안 강화
-- 1) monthly_pnl 뷰에 SECURITY INVOKER 적용 (RLS 상속)
-- 2) profiles 테이블에 active 컬럼 (비활성화 가능)
-- 3) 사장만 타 프로필 수정 가능 RLS 강화

-- ═══════════════════════════════════════════════════════
-- 1. monthly_pnl 뷰 보안 (RLS 상속)
-- ═══════════════════════════════════════════════════════
DROP VIEW IF EXISTS public.monthly_pnl;

CREATE VIEW public.monthly_pnl WITH (security_invoker = true) AS
SELECT
  s.store_id,
  to_char(s.sale_date, 'YYYY-MM') AS month,
  SUM(s.revenue) AS total_revenue,
  SUM(s.cost) AS total_cost_of_goods,
  SUM(s.revenue - s.cost) AS gross_profit,
  SUM(s.revenue - s.cost) - COALESCE(
    (SELECT SUM(monthly_amount)
      FROM public.accounting_fixed_costs f
      WHERE f.store_id = s.store_id AND f.active = true),
    0
  ) AS net_profit,
  count(DISTINCT s.sale_date) AS operating_days
FROM public.sales_records s
GROUP BY s.store_id, to_char(s.sale_date, 'YYYY-MM');

COMMENT ON VIEW public.monthly_pnl IS
  'Issue #20 월별 손익. SECURITY INVOKER로 RLS 상속 — 본인 매장만 조회.';

-- ═══════════════════════════════════════════════════════
-- 2. profiles 활성화 플래그 (비활성 프로필은 로그인 불가)
-- ═══════════════════════════════════════════════════════
ALTER TABLE public.profiles
  ADD COLUMN IF NOT EXISTS active boolean NOT NULL DEFAULT true;

COMMENT ON COLUMN public.profiles.active IS
  '사장이 점장·매니저 프로필을 일시 비활성화 가능 (해고·휴직 대응)';

-- ═══════════════════════════════════════════════════════
-- 3. 프로필 권한 세분화 (사장이 점장의 세부 기능 on/off 가능)
-- ═══════════════════════════════════════════════════════
ALTER TABLE public.profiles
  ADD COLUMN IF NOT EXISTS permissions jsonb NOT NULL DEFAULT '{}'::jsonb;

COMMENT ON COLUMN public.profiles.permissions IS
  '프로필별 세부 권한 오버라이드. 기본: role 기준. 사장이 {"can_create_order": true} 등으로 커스텀.';

-- ═══════════════════════════════════════════════════════
-- 4. pg_cron 등록 헬퍼 (매장별 매일 메모리 캡처)
-- ═══════════════════════════════════════════════════════
-- 주의: pg_cron extension은 Supabase Dashboard에서 먼저 활성화 필요

CREATE OR REPLACE FUNCTION public.run_all_stores_memory_capture()
RETURNS int AS $$
DECLARE
  store_row record;
  total_events int := 0;
  result_row record;
BEGIN
  FOR store_row IN SELECT id FROM public.stores WHERE agent_learning_enabled = true
  LOOP
    FOR result_row IN SELECT * FROM public.run_daily_memory_capture(store_row.id)
    LOOP
      total_events := total_events + COALESCE(result_row.count, 0);
    END LOOP;
  END LOOP;
  RETURN total_events;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

COMMENT ON FUNCTION public.run_all_stores_memory_capture IS
  'pg_cron용: 매일 모든 매장의 메모리 캡처 실행. 반환: 감지된 총 이벤트 수.';

-- pg_cron 스케줄 예시 (Supabase Dashboard에서 활성화 후 실행):
-- SELECT cron.schedule(
--   'daily-memory-capture',
--   '0 8 * * *',  -- 매일 오전 8시 (KST)
--   $$SELECT public.run_all_stores_memory_capture()$$
-- );


-- ════════════════════════════════════════════════
-- 📄 010_push_subscriptions.sql
-- ════════════════════════════════════════════════
-- Issue #19: Web Push 구독 저장
-- 사용자가 여러 기기에서 구독 가능 → 1:N

CREATE TABLE IF NOT EXISTS public.push_subscriptions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  store_id uuid NOT NULL REFERENCES public.stores(id) ON DELETE CASCADE,
  profile_id uuid REFERENCES public.profiles(id) ON DELETE CASCADE,

  -- Web Push 프로토콜 구독 정보
  endpoint text NOT NULL,
  p256dh_key text NOT NULL,   -- 공개키
  auth_key text NOT NULL,     -- 인증 비밀

  -- 디바이스 식별 (UA 요약)
  user_agent text,

  -- 알림 항목별 on/off
  enabled_channels jsonb NOT NULL DEFAULT '{
    "sales_anomaly": true,
    "new_review": true,
    "order_pending": true,
    "bep_reached": true,
    "daily_briefing": true
  }'::jsonb,

  created_at timestamptz NOT NULL DEFAULT now(),
  last_active_at timestamptz NOT NULL DEFAULT now()
);

CREATE UNIQUE INDEX IF NOT EXISTS idx_push_subs_endpoint
  ON public.push_subscriptions(endpoint);

CREATE INDEX IF NOT EXISTS idx_push_subs_store
  ON public.push_subscriptions(store_id);

ALTER TABLE public.push_subscriptions ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "push_subs: 본인 매장" ON public.push_subscriptions;
CREATE POLICY "push_subs: 본인 매장" ON public.push_subscriptions
  FOR ALL USING (store_id = auth.uid());

