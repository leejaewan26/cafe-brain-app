// FAQ 페이지 (Day 6-3)
// /ultrareview 운영 준비: 55 → 88 개선을 위한 고객 지원 기반
// 사장님이 가장 많이 묻는 질문 10개 + 검색 + 카테고리 필터
import { useMemo, useState } from 'react'
import { Link } from 'react-router-dom'
import {
  ChevronLeft, HelpCircle, Search, ChevronDown, MessageCircle,
  Mail, Phone, BookOpen,
} from 'lucide-react'
import { cn } from '@/lib/utils'

type FaqCategory = '가입·요금' | '사용법' | 'AI 기능' | '데이터·보안' | '기타'

interface FaqItem {
  q: string
  a: React.ReactNode
  category: FaqCategory
}

const FAQS: FaqItem[] = [
  // ── 가입·요금 ──
  {
    category: '가입·요금',
    q: '7일 체험이 끝나면 어떻게 되나요?',
    a: <>7일 후 자동 결제가 되지 않으며, <strong>무료 계정으로 전환</strong>됩니다.
        체험 기간 동안 업로드하신 매출·리뷰 데이터는 30일간 보존되며, 언제든 결제하시면 바로 복구됩니다.</>,
  },
  {
    category: '가입·요금',
    q: '연 구독이 정말 17% 저렴한가요?',
    a: <>네. 월 구독 ₩30,000 × 12개월 = ₩360,000인데 연 구독은 <strong>₩300,000</strong>으로,
        ₩60,000(17%) 할인됩니다. 월 평균 ₩25,000입니다.</>,
  },
  {
    category: '가입·요금',
    q: '언제든 해지할 수 있나요?',
    a: <>네, 언제든 설정 &gt; 계정에서 해지 가능합니다. 해지 시 다음 결제 주기부터 요금이 청구되지 않으며,
        이미 결제한 기간은 끝까지 정상 이용 가능합니다.</>,
  },
  {
    category: '가입·요금',
    q: '카드 정보는 어디에 저장되나요?',
    a: <><strong>카페 브레인 서버에는 저장되지 않습니다.</strong> 결제는 토스페이먼츠의 PCI-DSS 인증 보안 시스템으로만 처리되며,
        우리가 받는 정보는 결제 성공 여부와 고유 식별자뿐입니다.</>,
  },

  // ── 사용법 ──
  {
    category: '사용법',
    q: 'CSV 파일이 없는데 매출 입력이 가능한가요?',
    a: <>네! <strong>영수증 사진 한 장이면 충분합니다.</strong>
        매출 페이지의 "📸 사진으로 매출 입력"에서 POS 영수증·일일 마감·손글씨 장부를 업로드하면
        AI가 자동으로 메뉴·수량·금액을 읽어 정리해줍니다.</>,
  },
  {
    category: '사용법',
    q: '직원과 계정을 공유해도 되나요?',
    a: <>별도 로그인 없이 <strong>프로필만 분리</strong>하시면 됩니다.
        설정 &gt; 프로필 관리에서 최대 3명의 프로필(사장/매니저/알바)을 만들 수 있고,
        권한에 따라 매출·인건비 등 민감 정보 접근을 제한할 수 있습니다.</>,
  },
  {
    category: '사용법',
    q: '매일 브리핑을 꺼두고 싶어요',
    a: <>설정 &gt; 알림 탭에서 <strong>"능동형 AI 브리핑"</strong>을 OFF 하시면 됩니다.
        대시보드 진입 시 자동 분석도 함께 꺼집니다.</>,
  },

  // ── AI 기능 ──
  {
    category: 'AI 기능',
    q: 'AI가 쓴 답글을 어떻게 알아볼 수 있나요?',
    a: <>리뷰 답글 하단에 "ⓘ AI가 생성한 답글입니다" 문구가 자동으로 표시됩니다.
        AI 기본법상 고객에게 AI 사용 사실을 고지하는 것이 권장되어 기본값은 <strong>표시</strong>로 설정되어 있습니다.
        설정 &gt; AI 설정에서 끌 수 있지만 법률 자문을 받아보시기를 권합니다.</>,
  },
  {
    category: 'AI 기능',
    q: 'AI 호출에 제한이 있나요?',
    a: <>분당 10회 제한이 있어 비정상적 사용을 방지합니다. 사장님이 일상적으로 쓰실 때는 거의 닿지 않는 선입니다.
        또한 <strong>동일한 질문은 24시간 캐시</strong>되어 빠르게 응답하며, 이때는 호출 수에 포함되지 않습니다.</>,
  },
  {
    category: 'AI 기능',
    q: 'AI 답글 어조를 바꾸고 싶어요',
    a: <>설정 &gt; AI 설정에서 <strong>정중한 존댓말 / 친근한 반말 / 유머·위트</strong> 3가지 중 선택할 수 있습니다.
        답글 작성 시에도 개별 변경이 가능합니다.</>,
  },

  // ── 데이터·보안 ──
  {
    category: '데이터·보안',
    q: '내 매장 데이터가 다른 매장 AI에 학습되나요?',
    a: <>아니요. <strong>매장별 데이터는 완전히 격리</strong>됩니다. Supabase RLS(Row Level Security)로
        사장님 계정의 데이터는 사장님 본인만 접근 가능합니다. Gemini 호출 시에도 store_id 단위로 캐시가 분리됩니다.</>,
  },
  {
    category: '데이터·보안',
    q: '고객 전화번호·이름이 AI에 전달되나요?',
    a: <>아니요. PII 필터 미들웨어가 <strong>전화번호·카드번호·주민번호를 자동으로 마스킹</strong>한 후 Gemini로 보냅니다.
        또한 영수증 OCR 이미지는 Gemini로 전송되지만 저장되지 않습니다.</>,
  },
  {
    category: '데이터·보안',
    q: '계정을 지우면 데이터는 어떻게 되나요?',
    a: <>해지 후 30일간 복구 가능하도록 보존된 뒤 <strong>영구 삭제</strong>됩니다.
        언제든 설정에서 CSV/Excel/PDF로 전체 데이터를 내보내실 수 있습니다 (해지 전 백업 권장).</>,
  },

  // ── 기타 ──
  {
    category: '기타',
    q: '다크모드가 지원되나요?',
    a: <>네. 설정 &gt; 화면에서 <strong>라이트/다크/시스템</strong> 3가지 중 선택할 수 있습니다.
        시스템으로 두시면 OS 테마에 자동으로 따라갑니다.</>,
  },
  {
    category: '기타',
    q: '앱으로 설치할 수 있나요?',
    a: <>네, 웹 앱(PWA)으로 바로 설치됩니다. 홈 화면의 QR 코드 안내 또는 브라우저의 "앱 설치" 버튼을 탭하세요.
        Android Chrome·iOS Safari 모두 지원합니다.</>,
  },
  {
    category: '기타',
    q: '장애·버그를 어떻게 신고하나요?',
    a: <>카카오 채널 <strong>@카페브레인</strong>으로 메시지 보내주시거나, 아래 이메일
        <code className="mx-1 px-1.5 py-0.5 bg-gray-100 dark:bg-gray-700 rounded text-xs">support@cafebrain.app</code>
        으로 연락 부탁드립니다. 근무일 기준 24시간 내 답변드립니다.</>,
  },
]

const CATEGORIES: FaqCategory[] = ['가입·요금', '사용법', 'AI 기능', '데이터·보안', '기타']

export default function FaqPage() {
  const [search, setSearch] = useState('')
  const [category, setCategory] = useState<FaqCategory | 'all'>('all')
  const [openIndex, setOpenIndex] = useState<number | null>(0)

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase()
    return FAQS.filter((f) => {
      if (category !== 'all' && f.category !== category) return false
      if (!q) return true
      // 텍스트 검색: 질문 + (ReactNode를 문자열화하면 복잡하므로 질문 중심)
      return f.q.toLowerCase().includes(q)
    })
  }, [search, category])

  return (
    <div className="min-h-screen bg-[#FAFAF8] dark:bg-[#1A1A1A]">
      {/* 헤더 */}
      <header className="bg-[#2C1810] text-white px-4 py-3 flex items-center gap-3 sticky top-0 z-20">
        <Link to="/dashboard" className="hover:text-[#D4A574] transition-colors"
              aria-label="대시보드로 돌아가기">
          <ChevronLeft size={20} />
        </Link>
        <HelpCircle size={18} className="text-[#D4A574]" />
        <h1 className="font-bold text-base flex-1">자주 묻는 질문 (FAQ)</h1>
      </header>

      <main className="max-w-2xl mx-auto px-4 py-6 pb-24">
        {/* 검색 */}
        <div className="relative mb-4">
          <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
          <input
            type="search"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="질문 검색... (예: 결제, OCR, 다크모드)"
            className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 text-sm focus:outline-none focus:ring-2 focus:ring-[#D4A574]"
            aria-label="FAQ 검색"
          />
        </div>

        {/* 카테고리 필터 */}
        <div className="flex gap-1.5 mb-4 overflow-x-auto scrollbar-hide pb-1">
          <CatChip active={category === 'all'} onClick={() => setCategory('all')} label={`전체 (${FAQS.length})`} />
          {CATEGORIES.map((c) => {
            const count = FAQS.filter((f) => f.category === c).length
            return (
              <CatChip
                key={c}
                active={category === c}
                onClick={() => setCategory(c)}
                label={`${c} (${count})`}
              />
            )
          })}
        </div>

        {/* FAQ 리스트 */}
        <div className="space-y-2">
          {filtered.length === 0 ? (
            <div className="bg-white dark:bg-gray-800 rounded-2xl p-8 text-center">
              <BookOpen size={32} className="text-gray-300 mx-auto mb-3" />
              <p className="text-sm text-gray-500">검색 결과가 없어요. 아래 고객 지원으로 문의해주세요.</p>
            </div>
          ) : filtered.map((faq, i) => (
            <details
              key={i}
              open={openIndex === i}
              onToggle={(e) => {
                if ((e.target as HTMLDetailsElement).open) setOpenIndex(i)
                else if (openIndex === i) setOpenIndex(null)
              }}
              className="bg-white dark:bg-gray-800 rounded-2xl border border-gray-100 dark:border-gray-700 overflow-hidden group"
            >
              <summary className="flex items-center gap-3 px-4 py-3.5 cursor-pointer list-none hover:bg-[#FAFAF8] dark:hover:bg-gray-700 transition-colors focus:outline-none focus-visible:ring-2 focus-visible:ring-[#D4A574] focus-visible:ring-inset">
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-[#D4A574]/15 text-[#D4A574] shrink-0">
                  {faq.category}
                </span>
                <p className="flex-1 text-sm font-semibold text-[#2C1810] dark:text-gray-100">
                  {faq.q}
                </p>
                <ChevronDown size={16} className="text-gray-400 shrink-0 transition-transform group-open:rotate-180" />
              </summary>
              <div className="px-4 pb-4 pt-1 text-sm text-gray-700 dark:text-gray-300 leading-relaxed border-t border-gray-100 dark:border-gray-700">
                {faq.a}
              </div>
            </details>
          ))}
        </div>

        {/* 고객 지원 CTA */}
        <div className="mt-10 bg-gradient-to-br from-[#2C1810] to-[#3d2418] rounded-2xl p-6 text-white">
          <h3 className="font-bold text-base mb-1 flex items-center gap-2">
            <MessageCircle size={18} className="text-[#D4A574]" />
            답을 못 찾으셨나요?
          </h3>
          <p className="text-white/70 text-xs mb-4 leading-relaxed">
            근무일 기준 <strong className="text-[#D4A574]">24시간 내</strong> 답변드려요. 편한 채널로 연락주세요.
          </p>
          <div className="grid grid-cols-2 gap-2">
            <a
              href="https://pf.kakao.com/cafebrain"
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center justify-center gap-2 py-3 rounded-xl bg-[#FEE500] text-[#3C1E1E] font-bold text-sm hover:bg-[#FEE500]/90 transition-colors"
            >
              <MessageCircle size={14} />
              카카오 채널
            </a>
            <a
              href="mailto:support@cafebrain.app"
              className="flex items-center justify-center gap-2 py-3 rounded-xl bg-white/10 text-white font-bold text-sm hover:bg-white/20 transition-colors border border-white/20"
            >
              <Mail size={14} />
              이메일 문의
            </a>
          </div>
          <p className="text-[10px] text-white/40 mt-3 text-center">
            <Phone size={10} className="inline mr-1" />
            긴급 상황: 02-1234-5678 (평일 9-18시)
          </p>
        </div>
      </main>
    </div>
  )
}

function CatChip({ active, onClick, label }: { active: boolean; onClick: () => void; label: string }) {
  return (
    <button
      onClick={onClick}
      className={cn(
        'shrink-0 px-3 py-1.5 rounded-full text-xs font-semibold border transition-colors focus:outline-none focus-visible:ring-2 focus-visible:ring-[#D4A574]',
        active
          ? 'bg-[#2C1810] text-white border-[#2C1810]'
          : 'bg-white dark:bg-gray-800 text-gray-600 dark:text-gray-300 border-gray-200 dark:border-gray-700 hover:bg-[#FAFAF8] dark:hover:bg-gray-700'
      )}
    >
      {label}
    </button>
  )
}
