// 공유 앱 레이아웃 — 데스크톱 사이드바 + 모바일 하단 탭바
// Rule 1: Pretendard 폰트, 카페 브라운 팔레트 유지
// Issue #5: 활성 프로필 표시 + 전환 버튼
import { useState } from 'react'
import { NavLink, Outlet, useNavigate } from 'react-router-dom'
import { useAuth } from '@/hooks/useAuth'
import { useStoreContext } from '@/hooks/useStoreContext'
import { useProfileStore } from '@/store/profileStore'
import { useTranslation } from 'react-i18next'
import {
  Coffee, LayoutDashboard, BarChart2, Users, Star,
  Megaphone, BookOpen, MessageCircle, Settings,
  LogOut, MoreHorizontal, X, ChevronRight, UserCog,
  ShoppingCart, Package, Wallet, Truck, TrendingUp, Sparkles,
} from 'lucide-react'
import LanguageSwitcher from '@/components/LanguageSwitcher'
import { cn } from '@/lib/utils'

// ─── 네비게이션 항목 정의 (i18n 적용) ───
// label은 t() 함수로 변환 — 실제 사용 시점에 useTranslation 호출
const PRIMARY_NAV = [
  { to: '/dashboard', i18nKey: 'nav.home',      icon: LayoutDashboard },
  { to: '/sales',     i18nKey: 'nav.analytics', icon: BarChart2 },
  { to: '/schedule',  i18nKey: 'nav.schedule',  icon: Users },
  { to: '/reviews',   i18nKey: 'nav.reviews',   icon: Star },
] as const

const MORE_NAV = [
  { to: '/trends',      i18nKey: 'nav.trends',      icon: TrendingUp,    color: '#06B6D4' },
  { to: '/marketing',   i18nKey: 'nav.marketing',   icon: Megaphone,     color: '#7B6CB0' },
  { to: '/menu',        i18nKey: 'nav.menu',        icon: BookOpen,      color: '#5A9E6F' },
  { to: '/ingredients', i18nKey: 'nav.ingredients', icon: Package,       color: '#8B5CF6' },
  { to: '/orders',      i18nKey: 'nav.orders',      icon: ShoppingCart,  color: '#D4A574' },
  { to: '/accounting',  i18nKey: 'nav.accounting',  icon: Wallet,        color: '#22C55E' },
  { to: '/supplier',    i18nKey: 'nav.supplier',    icon: Truck,         color: '#F59E0B' },
  { to: '/chat',        i18nKey: 'nav.chat',        icon: MessageCircle, color: '#E07A5F' },
  { to: '/agent-tools', i18nKey: 'nav.agentTools',  icon: Sparkles,      color: '#D4A574' },
  { to: '/lab',         i18nKey: 'nav.lab',         icon: Sparkles,      color: '#7B6CB0' },
  { to: '/settings',    i18nKey: 'nav.settings',    icon: Settings,      color: '#9B9B9B' },
] as const

const ALL_SIDEBAR = [...PRIMARY_NAV, ...MORE_NAV]

// ─── 데스크톱 사이드바 ───
function Sidebar() {
  const { signOut } = useAuth()
  const { storeInfo } = useStoreContext()
  const activeProfile = useProfileStore((s) => s.activeProfile)
  const navigate = useNavigate()
  const { t } = useTranslation()

  return (
    <aside className="hidden md:flex flex-col w-60 shrink-0 bg-[#2C1810] h-screen sticky top-0 z-30">
      {/* 로고 & 매장명 */}
      <div className="px-5 py-5 border-b border-white/10">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-[#D4A574] flex items-center justify-center shrink-0">
            <Coffee size={18} className="text-[#2C1810]" />
          </div>
          <div className="min-w-0">
            <p className="text-white font-bold text-sm leading-tight">카페 브레인</p>
            <p className="text-[#D4A574] text-xs truncate">{storeInfo?.store_name ?? '내 카페'}</p>
          </div>
        </div>
      </div>

      {/* 활성 프로필 표시 (Issue #5) */}
      {activeProfile && (
        <button
          onClick={() => navigate('/profile-select')}
          className="mx-3 mt-3 flex items-center gap-2.5 px-3 py-2 rounded-xl bg-white/5 hover:bg-white/10 transition-colors duration-200 text-left"
          title="프로필 전환"
        >
          <div
            className="w-8 h-8 rounded-lg flex items-center justify-center text-base shrink-0"
            style={{ backgroundColor: activeProfile.avatar_color }}
          >
            {activeProfile.avatar_emoji}
          </div>
          <div className="min-w-0 flex-1">
            <p className="text-white text-xs font-medium truncate">{activeProfile.name}</p>
            <p className="text-[#D4A574] text-[10px]">
              {activeProfile.role === 'owner' ? '사장' : '점장·매니저'}
            </p>
          </div>
          <UserCog size={12} className="text-white/40 shrink-0" />
        </button>
      )}

      {/* 메인 메뉴 */}
      <nav className="flex-1 overflow-y-auto py-4 px-3 space-y-0.5">
        {ALL_SIDEBAR.map(({ to, i18nKey, icon: Icon }) => (
          <NavLink
            key={to}
            to={to}
            className={({ isActive }) => cn(
              'flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-all duration-200',
              isActive
                ? 'bg-[#D4A574] text-[#2C1810] shadow-md'
                : 'text-white/70 hover:bg-white/10 hover:text-white'
            )}
          >
            <Icon size={17} />
            {t(i18nKey)}
          </NavLink>
        ))}
      </nav>

      {/* 하단 로그아웃 + 언어 */}
      <div className="p-3 border-t border-white/10 space-y-2">
        <div className="flex items-center justify-between">
          <button
            onClick={signOut}
            className="flex items-center gap-2 px-3 py-2 rounded-xl text-sm text-white/50 hover:text-white hover:bg-white/10 transition-all duration-200"
          >
            <LogOut size={15} />
            <span className="text-xs">{t('nav.logout', '로그아웃')}</span>
          </button>
          {/* H6: 언어 토글 — 다크 사이드바용 인라인 스타일 */}
          <LanguageSwitcher className="!bg-white/5 !text-white/60 hover:!text-white hover:!bg-white/10" />
        </div>
      </div>
    </aside>
  )
}

// ─── 모바일 하단 탭바 ───
function BottomTabBar() {
  const [showMore, setShowMore] = useState(false)
  const { signOut } = useAuth()
  const navigate = useNavigate()
  const { t } = useTranslation()

  return (
    <>
      {/* 하단 탭바 */}
      <nav className="md:hidden fixed bottom-0 left-0 right-0 z-40 bg-white border-t border-gray-100 shadow-lg">
        <div className="flex items-stretch h-16">
          {PRIMARY_NAV.map(({ to, i18nKey, icon: Icon }) => (
            <NavLink
              key={to}
              to={to}
              className={({ isActive }) => cn(
                'flex-1 flex flex-col items-center justify-center gap-0.5 text-[10px] font-medium transition-colors duration-200',
                isActive ? 'text-[#2C1810]' : 'text-gray-400'
              )}
            >
              {({ isActive }) => (
                <>
                  <Icon size={20} className={isActive ? 'text-[#D4A574]' : ''} />
                  {t(i18nKey)}
                </>
              )}
            </NavLink>
          ))}
          {/* 더보기 */}
          <button
            onClick={() => setShowMore(true)}
            className="flex-1 flex flex-col items-center justify-center gap-0.5 text-[10px] font-medium text-gray-400 hover:text-[#2C1810] transition-colors"
          >
            <MoreHorizontal size={20} />
            더보기
          </button>
        </div>
      </nav>

      {/* 더보기 시트 */}
      {showMore && (
        <>
          <div
            className="md:hidden fixed inset-0 z-50 bg-black/40"
            onClick={() => setShowMore(false)}
          />
          <div className="md:hidden fixed bottom-0 left-0 right-0 z-50 bg-white rounded-t-3xl shadow-2xl animate-in slide-in-from-bottom duration-300">
            <div className="flex items-center justify-between px-5 pt-4 pb-3 border-b border-gray-100">
              <p className="text-sm font-bold text-[#2C1810]">더보기</p>
              <button onClick={() => setShowMore(false)} className="p-1.5 rounded-full hover:bg-gray-100">
                <X size={16} className="text-gray-400" />
              </button>
            </div>
            <div className="p-4 space-y-2">
              {MORE_NAV.map(({ to, i18nKey, icon: Icon, color }) => (
                <button
                  key={to}
                  onClick={() => { navigate(to); setShowMore(false) }}
                  className="w-full flex items-center gap-4 px-4 py-3.5 rounded-2xl hover:bg-gray-50 transition-colors text-left"
                >
                  <div className="w-10 h-10 rounded-xl flex items-center justify-center shrink-0" style={{ backgroundColor: `${color}20` }}>
                    <Icon size={20} style={{ color }} />
                  </div>
                  <span className="text-sm font-semibold text-[#2C1810] flex-1">{t(i18nKey)}</span>
                  <ChevronRight size={15} className="text-gray-300" />
                </button>
              ))}
              <div className="border-t border-gray-100 pt-2 mt-2">
                <button
                  onClick={() => { signOut(); setShowMore(false) }}
                  className="w-full flex items-center gap-4 px-4 py-3 rounded-2xl hover:bg-red-50 transition-colors text-left"
                >
                  <div className="w-10 h-10 rounded-xl flex items-center justify-center bg-red-50">
                    <LogOut size={18} className="text-red-400" />
                  </div>
                  <span className="text-sm font-semibold text-red-500">로그아웃</span>
                </button>
              </div>
            </div>
            <div className="h-safe-area-inset-bottom pb-4" />
          </div>
        </>
      )}
    </>
  )
}

// ─── 메인 AppLayout ───
import { useSupabaseSync } from '@/hooks/useSupabaseSync'
import { useAgentBriefing } from '@/hooks/useAgentBriefing'
import { useAgentRealtime } from '@/hooks/useAgentRealtime'
import PWAInstallBanner from '@/components/PWAInstallBanner'
import OfflineIndicator from '@/components/OfflineIndicator'
import OnboardingTour from '@/components/OnboardingTour'
import DemoModeWatermark from '@/components/DemoModeWatermark'

export default function AppLayout() {
  // 로그인 후 DB → 로컬 스토어 자동 로드
  useSupabaseSync()
  // 능동 에이전트 일일 브리핑 — 모든 인증 페이지에서 활성 (영업시간 + 인증 게이트로 보호)
  useAgentBriefing()
  // Phase 6 #2: 새 메모리(매출이상·BEP 등) Supabase Realtime 즉시 푸시
  useAgentRealtime()

  return (
    <div className="flex min-h-screen bg-[#FAFAF8]">
      <Sidebar />
      <div className="flex-1 flex flex-col min-w-0">
        <main className="flex-1 overflow-auto pb-20 md:pb-0">
          <Outlet />
        </main>
      </div>
      <BottomTabBar />
      {/* Bonus E5+E6: PWA 설치 권유 + 오프라인 인디케이터 */}
      <PWAInstallBanner />
      <OfflineIndicator />
      {/* G1: 첫 로그인 온보딩 투어 (한 번만 표시) */}
      <OnboardingTour />
      {/* N4: 데모 모드 워터마크 (가짜 데이터일 때만) */}
      <DemoModeWatermark />
    </div>
  )
}
