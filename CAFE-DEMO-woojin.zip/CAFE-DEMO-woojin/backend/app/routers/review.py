"""
리뷰 AI 답글 생성 라우터
규칙: 닉네임 포함, 메뉴 언급, 긍정/부정별 톤, 이모지, AI 생성 표시
Issue #17: 어조 선택 옵션 (정중한 존댓말 / 친근한 반말 / 유머·위트)
"""
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field
from typing import List, Literal
from app.services.gemini_service import generate_insight_cached, build_cache_key

router = APIRouter()


# ─── 어조 옵션 (Issue #17) ───
ToneLiteral = Literal["polite", "friendly", "humor"]

TONE_GUIDES: dict[str, str] = {
    "polite": (
        "정중한 존댓말로 격식 있게 응대하세요. "
        "'~습니다/~드립니다' 어조로 매너있고 프로페셔널하게 작성. "
        "과도한 이모지는 피하고 존중의 태도를 유지하세요."
    ),
    "friendly": (
        "사장님이 친구에게 말하듯 친근한 반말 어조로 편안하게 응대하세요. "
        "'~이야/~했구나/~해줘서 고마워' 같은 따뜻한 말투. "
        "고객을 가까운 단골로 대하는 느낌이 들도록 작성."
    ),
    "humor": (
        "재치 있고 유머러스한 어조로 위트 있게 응대하세요. "
        "가벼운 농담이나 말장난을 센스있게 섞되, 무례하거나 비아냥대는 느낌은 절대 금지. "
        "부정 리뷰에는 유머보다 공감을 우선 — 진지해야 할 곳에선 정중하게."
    ),
}


class ReplyRequest(BaseModel):
    """AI 답글 생성 요청 스키마"""
    nickname: str
    content: str
    rating: int                                 # 1~5
    store_name: str                             # 매장명 (useStoreContext 주입)
    menu_list: List[str]                        # 매장 메뉴 목록
    tone: ToneLiteral = Field(                  # Issue #17: 어조 (한국 정서 고려 기본 polite)
        default="polite",
        description="답글 어조: polite(정중) | friendly(친근) | humor(유머)",
    )
    show_watermark: bool = Field(               # Critical C1: 워터마크 사용자 설정 연결
        default=True,
        description="AI 생성 표시 워터마크 여부",
    )


class ReplyResponse(BaseModel):
    """AI 답글 응답 스키마"""
    reply: str


def build_system_prompt(
    nickname: str,
    content: str,
    rating: int,
    store_name: str,
    menu_list: List[str],
    tone: str,
) -> str:
    """
    리뷰 답글 생성 시스템 프롬프트 구성
    - 닉네임 포함, 메뉴 언급, 긍정/부정 톤 분기
    - 사장님이 선택한 어조(tone) 반영 (Issue #17)
    """
    is_positive = rating >= 4
    is_short = len(content) < 20
    menu_str = ', '.join(menu_list[:8]) if menu_list else '아메리카노, 라떼, 크로플'

    # 긍정/부정 톤 분기
    emotion_guide = ""
    if is_positive:
        emotion_guide = "감사 인사로 시작하고, 재방문을 자연스럽게 유도하세요."
    else:
        emotion_guide = (
            "고객의 불편에 진심으로 공감하고, 책임을 인정하고, "
            "구체적인 개선 의지를 표현하세요. 변명은 절대 하지 마세요."
        )

    # 짧은 리뷰 보강
    short_guide = (
        "리뷰가 짧으므로 고객이 미처 말하지 못한 부분을 센스있게 채워 풍부하게 답글을 작성하세요."
        if is_short else ""
    )

    # 어조 가이드 (사장님이 선택)
    tone_guide = TONE_GUIDES.get(tone, TONE_GUIDES["friendly"])

    prompt = f"""
당신은 '{store_name}' 카페의 사장님입니다. 아래 고객 리뷰에 대한 답글을 한국어로 작성해주세요.

[어조 가이드 — 사장님이 선택한 톤]
{tone_guide}

[답글 작성 규칙]
1. 첫 문장에 고객 닉네임 '{nickname}'님을 자연스럽게 포함
2. 리뷰에 언급된 메뉴나 키워드를 콕 집어 반응하기
3. 우리 카페 메뉴 중 하나를 자연스럽게 추천: {menu_str}
4. {emotion_guide}
5. {short_guide}
6. 이모지는 전체 답글에서 2~3개만 분산 배치 (너무 많으면 안 됨)
7. 매장명은 '우리 {store_name}'으로 통일
8. 같은 표현 반복 금지 (예: '감사합니다' 2번 이상 사용 금지)
9. 분량: 3~5문장 (짧은 리뷰는 4~6문장)
10. 마지막 줄에 반드시: 'ⓘ AI가 생성한 답글입니다.' 추가

[고객 리뷰 정보]
- 닉네임: {nickname}
- 별점: {'⭐' * rating} ({rating}점)
- 리뷰 내용: {content}

지금 바로 답글만 작성해주세요 (설명이나 번호 없이):
""".strip()
    return prompt


@router.post("/reply", response_model=ReplyResponse)
async def generate_reply(req: ReplyRequest):
    """
    리뷰 AI 답글 생성
    - 닉네임 자연 포함
    - 긍정/부정/짧은 리뷰 톤 자동 분기
    - 메뉴 컨텍스트 주입으로 실제 메뉴명 추천
    - Issue #17: 어조 옵션 (정중/친근/유머)
    - 24시간 캐싱 적용 (동일 리뷰+어조 조합)
    """
    prompt = build_system_prompt(
        nickname=req.nickname,
        content=req.content,
        rating=req.rating,
        store_name=req.store_name,
        menu_list=req.menu_list,
        tone=req.tone,
    )

    # 캐시 키: 매장 + 리뷰 식별자 + 어조로 구성
    cache_key = build_cache_key(
        store_id=req.store_name,
        template="review_reply",
        params={
            "nickname": req.nickname,
            "content": req.content[:200],  # 긴 리뷰도 처음 200자로 키 안정화
            "rating": req.rating,
            "tone": req.tone,
        },
    )

    try:
        # 리뷰 답글은 일반 워터마크 대신 '답글입니다' 워터마크를 쓰므로 일반 워터마크 Off
        reply = await generate_insight_cached(prompt, cache_key=cache_key, show_watermark=False)
        # 리뷰 답글 전용 워터마크 (사용자 설정에 따라)
        if req.show_watermark and 'ⓘ AI가 생성한 답글입니다.' not in reply:
            reply += '\n\nⓘ AI가 생성한 답글입니다.'
        return ReplyResponse(reply=reply)
    except RuntimeError as e:
        raise HTTPException(status_code=503, detail=str(e))
