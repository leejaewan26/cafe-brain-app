"""
Launch A6 + Phase 6 #12 — Rate Limit 검증.
"""
from app.middleware.rate_limit import RateLimiter


def test_rate_limiter_allows_under_limit():
    rl = RateLimiter(max_calls=5, window_seconds=60)
    for _ in range(5):
        allowed, _, _ = rl.check("client_1")
        assert allowed is True


def test_rate_limiter_blocks_over_limit():
    rl = RateLimiter(max_calls=3, window_seconds=60)
    for _ in range(3):
        rl.check("client_2")
    allowed, remaining, retry = rl.check("client_2")
    assert allowed is False
    assert remaining == 0
    assert retry > 0


def test_rate_limiter_per_client_isolated():
    rl = RateLimiter(max_calls=2, window_seconds=60)
    rl.check("a"); rl.check("a")  # a 소진
    allowed_a, _, _ = rl.check("a")
    allowed_b, _, _ = rl.check("b")
    assert allowed_a is False  # a는 차단
    assert allowed_b is True   # b는 통과 (격리됨)


def test_rate_limiter_custom_max_calls_override():
    """Phase 6 #12 — max_calls 인자로 매장별 한도 override."""
    rl = RateLimiter(max_calls=10, window_seconds=60)
    # custom 한도 2로 호출
    rl.check("vip", max_calls=2)
    rl.check("vip", max_calls=2)
    allowed, _, _ = rl.check("vip", max_calls=2)
    assert allowed is False  # 2회 초과
