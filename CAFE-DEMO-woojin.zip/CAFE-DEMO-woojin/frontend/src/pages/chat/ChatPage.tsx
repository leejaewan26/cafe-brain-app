// AI 어시스턴트 전용 페이지
// 플로팅 패널과 동일한 기능을 풀스크린으로 제공
// 대화 내역 사이드바 + 대형 채팅 영역
import { useState, useRef, useEffect, useCallback } from 'react'
import { Link } from 'react-router-dom'
import {
  ChevronLeft, Coffee, Send, Plus, Trash2, AlignLeft,
  Copy, Check, Loader2, Sparkles,
} from 'lucide-react'
import { useChatStore } from '@/store/chatStore'
import { useStoreContext } from '@/hooks/useStoreContext'
import { useMenuStore } from '@/store/menuStore'
import { useSettingsStore } from '@/store/settingsStore'
import { useAuthStore } from '@/store/authStore'
import AiFeedback from '@/components/AiFeedback'
import { cn } from '@/lib/utils'

// ─── 예시 질문 ───
const EXAMPLE_QUESTIONS = [
  { emoji: '📊', text: '이번 달 매출 어떤지 요약해줘', short: '매출 요약' },
  { emoji: '💰', text: '아메리카노 원가율이 35%면 가격을 올려야 할까?', short: '원가 분석' },
  { emoji: '🌧️', text: '비 오는 날 인스타 문구 감성적으로 써줘', short: '인스타 문구' },
  { emoji: '👥', text: '직원 3명 주 15시간 이상 근무면 주휴수당 얼마야?', short: '주휴수당 계산' },
  { emoji: '📋', text: '오늘 마감 체크리스트 보여줘', short: '마감 체크리스트' },
  { emoji: '🍰', text: '딸기 케이크 신메뉴 인스타 홍보문구 써줘', short: '신메뉴 홍보' },
]

// ─── 인라인 마크다운 렌더러 ───
function renderInline(text: string): React.ReactNode {
  const parts = text.split(/(\*\*[^*]+\*\*|`[^`]+`|\*[^*]+\*)/g)
  return parts.map((part, i) => {
    if (part.startsWith('**') && part.endsWith('**'))
      return <strong key={i} className="font-bold text-[#2C1810]">{part.slice(2, -2)}</strong>
    if (part.startsWith('`') && part.endsWith('`'))
      return <code key={i} className="bg-gray-100 px-1 rounded text-xs font-mono">{part.slice(1, -1)}</code>
    if (part.startsWith('*') && part.endsWith('*'))
      return <em key={i} className="italic text-gray-600">{part.slice(1, -1)}</em>
    return part
  })
}

function MarkdownBlock({ content }: { content: string }) {
  const lines = content.split('\n')
  const nodes: React.ReactNode[] = []
  let i = 0
  while (i < lines.length) {
    const line = lines[i]
    if (line.startsWith('```')) {
      const lang = line.slice(3).trim()
      const code: string[] = []
      i++
      while (i < lines.length && !lines[i].startsWith('```')) { code.push(lines[i]); i++ }
      nodes.push(
        <div key={i} className="my-2 rounded-xl bg-[#1A1A1A] p-3 overflow-x-auto">
          {lang && <p className="text-xs text-gray-400 mb-1">{lang}</p>}
          <pre className="text-xs text-green-300 font-mono whitespace-pre-wrap">{code.join('\n')}</pre>
        </div>
      )
      i++; continue
    }
    if (line.startsWith('## ')) { nodes.push(<h3 key={i} className="text-sm font-bold text-[#2C1810] mt-3 mb-1">{line.slice(3)}</h3>); i++; continue }
    if (line.startsWith('# ')) { nodes.push(<h2 key={i} className="text-base font-bold text-[#2C1810] mt-3 mb-1">{line.slice(2)}</h2>); i++; continue }
    if (/^---+$/.test(line.trim())) { nodes.push(<hr key={i} className="border-gray-200 my-2" />); i++; continue }
    if (line.startsWith('- ') || line.startsWith('• ')) {
      nodes.push(
        <div key={i} className="flex items-start gap-2 py-0.5">
          <span className="text-[#D4A574] mt-1 text-xs">▸</span>
          <span className="text-sm text-gray-700 flex-1">{renderInline(line.replace(/^[•-]\s*/, ''))}</span>
        </div>
      ); i++; continue
    }
    if (/^\d+\.\s/.test(line)) {
      const match = line.match(/^(\d+)\.\s(.*)/)
      if (match) nodes.push(
        <div key={i} className="flex items-start gap-2 py-0.5">
          <span className="text-xs font-bold text-[#D4A574] w-5 shrink-0 pt-0.5">{match[1]}.</span>
          <span className="text-sm text-gray-700 flex-1">{renderInline(match[2])}</span>
        </div>
      ); i++; continue
    }
    if (!line.trim()) { nodes.push(<div key={i} className="h-1.5" />); i++; continue }
    nodes.push(<p key={i} className="text-sm text-gray-700 leading-relaxed">{renderInline(line)}</p>)
    i++
  }
  return <div className="space-y-px">{nodes}</div>
}

// ─── 메시지 버블 ───
function MsgBubble({ msg }: { msg: { id: string; role: string; content: string; timestamp: string } }) {
  const [copied, setCopied] = useState(false)
  const isUser = msg.role === 'user'
  return (
    <div className={cn('flex gap-3 group', isUser ? 'flex-row-reverse' : 'flex-row')}>
      {!isUser && (
        <div className="w-8 h-8 rounded-full bg-gradient-to-br from-[#D4A574] to-[#2C1810] flex items-center justify-center shrink-0 mt-1">
          <Coffee size={14} className="text-white" />
        </div>
      )}
      <div className={cn('max-w-[75%] space-y-1', isUser ? 'items-end flex flex-col' : '')}>
        <div className={cn(
          'rounded-2xl px-4 py-3',
          isUser ? 'bg-[#2C1810] text-white rounded-tr-sm' : 'bg-white border border-gray-100 shadow-sm rounded-tl-sm'
        )}>
          {isUser
            ? <p className="text-sm text-white leading-relaxed">{msg.content}</p>
            : <MarkdownBlock content={msg.content} />
          }
        </div>
        {!isUser && (
          <>
            <div className="flex items-center gap-2 opacity-0 group-hover:opacity-100 transition-opacity duration-200">
              <span className="text-xs text-gray-400 italic">ⓘ AI 생성 콘텐츠</span>
              <button
                onClick={async () => { await navigator.clipboard.writeText(msg.content); setCopied(true); setTimeout(() => setCopied(false), 2000) }}
                className="flex items-center gap-1 text-xs text-gray-400 hover:text-[#2C1810] transition-colors"
              >
                {copied ? <><Check size={10} />복사됨</> : <><Copy size={10} />복사</>}
              </button>
            </div>
            <AiFeedback sourceType="chat_message" sourceRef={`chat-${msg.id}`} compact />
          </>
        )}
        <span className={cn('text-xs text-gray-300', isUser ? 'text-right' : '')}>
          {new Date(msg.timestamp).toLocaleTimeString('ko-KR', { hour: '2-digit', minute: '2-digit' })}
        </span>
      </div>
    </div>
  )
}

// ═══════════════════════════════════
// ─── 메인 ChatPage ───
// ═══════════════════════════════════
export default function ChatPage() {
  const {
    sessions, activeSessionId, newSession,
    setActiveSession, addMessage, deleteSession,
  } = useChatStore()
  const { storeInfo, buildPromptContext } = useStoreContext()
  const { menus } = useMenuStore()
  // AiChat과 일관성: 사장님 선호 어조 + 매장 ID (메모리 추출용)
  const defaultTone = useSettingsStore((s) => s.defaultTone)
  const storeId = useAuthStore((s) => s.user?.id)

  const [input, setInput] = useState('')
  const [isLoading, setIsLoading] = useState(false)
  const [showSidebar, setShowSidebar] = useState(true)

  const messagesEndRef = useRef<HTMLDivElement>(null)
  const inputRef = useRef<HTMLTextAreaElement>(null)

  const activeSession = sessions.find(s => s.id === activeSessionId)

  useEffect(() => {
    if (!activeSessionId) newSession()
  }, [activeSessionId, newSession])

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' })
  }, [activeSession?.messages.length, isLoading])

  const buildSystemContext = useCallback((): string => {
    const menuList = menus.slice(0, 10).map(m =>
      `${m.name}(${m.salePrice.toLocaleString()}원, 원가비중 ${m.salePrice > 0 ? Math.round((m.totalCost / m.salePrice) * 100) : 0}%)`
    ).join(', ')
    return `당신은 ${storeInfo?.store_name ?? '카페'} 전용 AI 경영 파트너입니다.\n\n${buildPromptContext()}\n\n현재 메뉴: ${menuList || '없음'}\n\n답변 규칙:\n- 한국어, 실용적이고 구체적으로\n- 숫자·금액은 구체적으로 제시\n- 마크다운 활용 (표, 리스트, 볼드)`
  }, [storeInfo, menus, buildPromptContext])

  const handleSend = useCallback(async (text?: string) => {
    const content = (text ?? input).trim()
    if (!content || isLoading) return
    let sid = activeSessionId
    if (!sid) sid = newSession()
    addMessage(sid, { role: 'user', content })
    setInput('')
    setIsLoading(true)
    try {
      const res = await fetch('/api/v1/chat/message', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...(storeId ? { 'X-Store-Id': storeId } : {}),
        },
        body: JSON.stringify({
          message: content,
          system_context: buildSystemContext(),
          history: activeSession?.messages.slice(-10).map(m => ({ role: m.role, content: m.content })) ?? [],
          store_id: storeId ?? undefined,  // 메모리 추출 백그라운드용
          tone: defaultTone,                // 사장님 선호 어조
        }),
      })
      if (!res.ok) throw new Error(`서버 오류: ${res.status}`)
      const data = await res.json()
      addMessage(sid, { role: 'assistant', content: data.reply })
    } catch (e) {
      const msg = e instanceof Error ? e.message : '오류'
      addMessage(sid, {
        role: 'assistant',
        content: msg.includes('Failed to fetch')
          ? '⚠️ 백엔드 서버가 실행 중이지 않습니다.\n\n> `cd backend && uvicorn app.main:app --reload`'
          : `⚠️ ${msg}`,
      })
    } finally {
      setIsLoading(false)
    }
  }, [input, isLoading, activeSessionId, activeSession, newSession, addMessage, buildSystemContext, defaultTone, storeId])

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); handleSend() }
  }

  const isFirstMessage = !activeSession?.messages.length

  return (
    <div className="flex h-[calc(100dvh-56px)] bg-[#FAFAF8] overflow-hidden">

      {/* ─── 사이드바 ─── */}
      <div className={cn(
        'flex-shrink-0 bg-[#2C1810] flex flex-col transition-all duration-300 overflow-hidden',
        showSidebar ? 'w-64' : 'w-0'
      )}>
        <div className="p-3 border-b border-white/10 flex items-center justify-between">
          <p className="text-xs font-bold text-white/60 uppercase tracking-wider">대화 목록</p>
          <button
            onClick={() => { newSession() }}
            className="flex items-center gap-1 text-xs text-white/60 hover:text-white transition-colors px-2 py-1 rounded-lg hover:bg-white/10"
          >
            <Plus size={12} /> 새 대화
          </button>
        </div>
        <div className="flex-1 overflow-y-auto p-2 space-y-1">
          {sessions.length === 0
            ? <p className="text-xs text-white/30 p-2 text-center">대화 없음</p>
            : sessions.map(sess => (
              <div key={sess.id} className="group relative">
                <button
                  onClick={() => setActiveSession(sess.id)}
                  className={cn(
                    'w-full text-left px-3 py-2.5 rounded-xl text-xs transition-colors duration-200 pr-8',
                    activeSessionId === sess.id
                      ? 'bg-[#D4A574] text-white font-semibold'
                      : 'text-white/70 hover:bg-white/10'
                  )}
                >
                  <p className="truncate">{sess.title}</p>
                  <p className="text-[10px] opacity-50 mt-0.5">
                    {new Date(sess.updatedAt).toLocaleDateString('ko-KR')} · {sess.messages.length}개
                  </p>
                </button>
                <button
                  onClick={() => deleteSession(sess.id)}
                  className="absolute right-1.5 top-2 opacity-0 group-hover:opacity-100 text-white/40 hover:text-red-300 transition-all p-1 rounded"
                >
                  <Trash2 size={11} />
                </button>
              </div>
            ))
          }
        </div>
      </div>

      {/* ─── 메인 채팅 영역 ─── */}
      <div className="flex-1 flex flex-col min-w-0">

        {/* 헤더 */}
        <div className="bg-white border-b border-gray-100 px-4 py-3 flex items-center gap-3 shrink-0">
          <Link to="/dashboard" className="text-gray-400 hover:text-[#2C1810] transition-colors duration-200 md:hidden">
            <ChevronLeft size={20} />
          </Link>
          <button
            onClick={() => setShowSidebar(!showSidebar)}
            className={cn(
              'p-1.5 rounded-lg transition-colors hidden md:flex',
              showSidebar ? 'bg-[#2C1810]/10 text-[#2C1810]' : 'text-gray-400 hover:bg-gray-100'
            )}
          >
            <AlignLeft size={16} />
          </button>
          <div className="w-8 h-8 rounded-full bg-gradient-to-br from-[#D4A574] to-[#2C1810] flex items-center justify-center shrink-0">
            <Coffee size={15} className="text-white" />
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-1.5">
              <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse" />
              <p className="font-bold text-[#2C1810] text-sm">AI 경영 파트너</p>
            </div>
            <p className="text-xs text-gray-400 truncate">
              {storeInfo?.store_name ?? '카페 브레인'} · {activeSession?.title ?? '새 대화'}
            </p>
          </div>
          <button
            onClick={newSession}
            className="flex items-center gap-1 px-3 py-1.5 bg-[#2C1810] text-white rounded-xl text-xs font-medium hover:bg-[#3d2418] transition-colors duration-200"
          >
            <Plus size={12} /> 새 대화
          </button>
        </div>

        {/* 메시지 영역 */}
        <div className="flex-1 overflow-y-auto p-4 md:p-6 space-y-5">
          {isFirstMessage && (
            <div className="max-w-2xl mx-auto space-y-4">
              {/* 환영 */}
              <div className="flex gap-3">
                <div className="w-8 h-8 rounded-full bg-gradient-to-br from-[#D4A574] to-[#2C1810] flex items-center justify-center shrink-0">
                  <Coffee size={14} className="text-white" />
                </div>
                <div className="bg-white rounded-2xl rounded-tl-sm px-4 py-3 border border-gray-100 shadow-sm">
                  <p className="text-sm text-gray-700 leading-relaxed">
                    안녕하세요! ☕<br />
                    <strong className="text-[#2C1810]">{storeInfo?.store_name ?? '카페'}</strong>의 AI 경영 파트너입니다.<br />
                    매출 분석, 메뉴 원가 계산, SNS 문구 작성, 노무 상담 등 어떤 질문이든 도와드릴게요.
                  </p>
                </div>
              </div>
              {/* 예시 질문 그리드 */}
              <div className="ml-11">
                <p className="text-xs text-gray-400 font-medium mb-2">💡 이런 것들을 물어보세요</p>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
                  {EXAMPLE_QUESTIONS.map(q => (
                    <button
                      key={q.text}
                      onClick={() => handleSend(q.text)}
                      disabled={isLoading}
                      className="flex items-start gap-2 px-3 py-2.5 bg-white border border-gray-100 text-xs text-[#2C1810] rounded-xl hover:border-[#D4A574]/50 hover:bg-[#D4A574]/5 transition-all duration-200 shadow-sm text-left disabled:opacity-50"
                    >
                      <span className="text-base leading-none shrink-0 mt-0.5">{q.emoji}</span>
                      <span className="font-medium leading-snug">{q.short}</span>
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}

          <div className="max-w-2xl mx-auto w-full space-y-5">
            {activeSession?.messages.map(msg => (
              <MsgBubble key={msg.id} msg={msg} />
            ))}
            {isLoading && (
              <div className="flex gap-3">
                <div className="w-8 h-8 rounded-full bg-gradient-to-br from-[#D4A574] to-[#2C1810] flex items-center justify-center shrink-0">
                  <Coffee size={14} className="text-white" />
                </div>
                <div className="bg-white rounded-2xl rounded-tl-sm px-4 py-3 border border-gray-100 shadow-sm">
                  <div className="flex gap-1.5 items-center">
                    {[0, 150, 300].map(delay => (
                      <div key={delay} className="w-2 h-2 bg-[#D4A574] rounded-full animate-bounce" style={{ animationDelay: `${delay}ms` }} />
                    ))}
                  </div>
                </div>
              </div>
            )}
            <div ref={messagesEndRef} />
          </div>
        </div>

        {/* 입력창 */}
        <div
          className="bg-white border-t border-gray-100 p-4 shrink-0"
          style={{ paddingBottom: 'calc(1rem + env(safe-area-inset-bottom, 0px))' }}
        >
          <div className="max-w-2xl mx-auto">
            <div className="flex items-end gap-3 bg-[#FAFAF8] rounded-2xl border border-gray-200 px-4 py-3 focus-within:border-[#D4A574] focus-within:ring-1 focus-within:ring-[#D4A574]/30 transition-all duration-200">
              <textarea
                ref={inputRef}
                value={input}
                onChange={e => setInput(e.target.value)}
                onKeyDown={handleKeyDown}
                placeholder="무엇이든 물어보세요... (Enter로 전송, Shift+Enter 줄바꿈)"
                rows={1}
                className="flex-1 bg-transparent text-sm outline-none resize-none text-[#2C1810] placeholder:text-gray-300 max-h-32 leading-relaxed"
              />
              <button
                onClick={() => handleSend()}
                disabled={!input.trim() || isLoading}
                className={cn(
                  'p-2.5 rounded-xl transition-all duration-200 shrink-0',
                  input.trim() && !isLoading ? 'bg-[#2C1810] text-white hover:bg-[#3d2418]' : 'bg-gray-100 text-gray-300'
                )}
              >
                {isLoading ? <Loader2 size={18} className="animate-spin" /> : <Send size={18} />}
              </button>
            </div>
            <p className="text-center text-xs text-gray-300 mt-2">
              <Sparkles size={10} className="inline mr-1" />
              Powered by Gemini · AI가 생성한 내용은 참고용입니다
            </p>
          </div>
        </div>
      </div>
    </div>
  )
}
