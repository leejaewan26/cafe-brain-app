---
name: claude-ai-recipes
description: This skill should be used when the user asks how to build with Claude API, implement RAG, use Claude for classification or summarization, build AI agents, use tool calling, process images with vision, cache prompts, connect to vector databases, build customer service bots, moderate content, or format JSON output from Claude. Activates on phrases like "Claude API", "AI 에이전트", "RAG", "tool use", "도구 호출", "prompt caching", "vision", "이미지 분석", "subagent", "anthropic SDK".
version: 1.0.0
---

# Claude AI Recipes Skill

Practical code patterns and guides for building with Claude. Copy-paste ready examples for common AI development tasks.

> Based on: https://github.com/anthropics/claude-cookbooks

## When This Skill Applies

Activate when the user needs to:
- Call Claude API for any task
- Build RAG (Retrieval-Augmented Generation) systems
- Use Claude for classification, summarization, or extraction
- Implement tool use / function calling
- Process images with Claude's vision capabilities
- Build multi-agent / subagent architectures
- Optimize with prompt caching
- Connect Claude to databases or external tools

---

## Basic API Usage

```python
import anthropic

client = anthropic.Anthropic()  # reads ANTHROPIC_API_KEY from env

message = client.messages.create(
    model="claude-sonnet-4-6",
    max_tokens=1024,
    messages=[
        {"role": "user", "content": "Hello, Claude!"}
    ]
)
print(message.content[0].text)
```

---

## Classification

```python
def classify_text(text: str, categories: list[str]) -> str:
    prompt = f"""Classify the following text into one of these categories: {', '.join(categories)}

Text: {text}

Respond with only the category name, nothing else."""

    response = client.messages.create(
        model="claude-haiku-4-5-20251001",  # use Haiku for fast/cheap classification
        max_tokens=50,
        messages=[{"role": "user", "content": prompt}]
    )
    return response.content[0].text.strip()

# Usage
category = classify_text("The product broke after 2 days", ["complaint", "praise", "question", "other"])
```

---

## Structured JSON Output

```python
import json

def extract_structured(text: str, schema_description: str) -> dict:
    response = client.messages.create(
        model="claude-sonnet-4-6",
        max_tokens=1024,
        messages=[{
            "role": "user",
            "content": f"""Extract information from the text below.
Return ONLY valid JSON matching this structure: {schema_description}

Text: {text}"""
        }]
    )
    return json.loads(response.content[0].text)

# Example: extract person info
result = extract_structured(
    "John Smith, 34, works at Google as a software engineer in NYC.",
    '{"name": "string", "age": "number", "company": "string", "role": "string", "city": "string"}'
)
```

---

## Tool Use / Function Calling

```python
tools = [
    {
        "name": "get_weather",
        "description": "Get current weather for a location",
        "input_schema": {
            "type": "object",
            "properties": {
                "location": {"type": "string", "description": "City name"},
                "unit": {"type": "string", "enum": ["celsius", "fahrenheit"]}
            },
            "required": ["location"]
        }
    }
]

response = client.messages.create(
    model="claude-sonnet-4-6",
    max_tokens=1024,
    tools=tools,
    messages=[{"role": "user", "content": "What's the weather in Seoul?"}]
)

# Handle tool calls
if response.stop_reason == "tool_use":
    for block in response.content:
        if block.type == "tool_use":
            tool_name = block.name
            tool_input = block.input
            # Execute the tool
            result = execute_tool(tool_name, tool_input)
```

---

## RAG (Retrieval-Augmented Generation)

```python
def rag_query(question: str, context_chunks: list[str]) -> str:
    context = "\n\n---\n\n".join(context_chunks)

    response = client.messages.create(
        model="claude-sonnet-4-6",
        max_tokens=2048,
        messages=[{
            "role": "user",
            "content": f"""Answer the question using ONLY the provided context.
If the answer is not in the context, say "I don't have information about that."

Context:
{context}

Question: {question}"""
        }]
    )
    return response.content[0].text

# Typical RAG pipeline:
# 1. Embed question → query_embedding
# 2. Search vector DB → relevant_chunks
# 3. Pass chunks to rag_query
```

### With Pinecone
```python
import pinecone
from anthropic import Anthropic

def semantic_search_and_answer(question: str) -> str:
    # 1. Embed question (use a small embedding model)
    query_embedding = embed(question)

    # 2. Search Pinecone
    index = pinecone.Index("my-index")
    results = index.query(vector=query_embedding, top_k=5, include_metadata=True)

    # 3. Extract text chunks
    chunks = [r.metadata["text"] for r in results.matches]

    # 4. Generate answer
    return rag_query(question, chunks)
```

---

## Vision / Image Analysis

```python
import base64

def analyze_image(image_path: str, question: str) -> str:
    with open(image_path, "rb") as f:
        image_data = base64.standard_b64encode(f.read()).decode("utf-8")

    # Detect media type
    ext = image_path.split(".")[-1].lower()
    media_type = {"jpg": "image/jpeg", "jpeg": "image/jpeg", "png": "image/png", "gif": "image/gif", "webp": "image/webp"}[ext]

    response = client.messages.create(
        model="claude-sonnet-4-6",
        max_tokens=1024,
        messages=[{
            "role": "user",
            "content": [
                {
                    "type": "image",
                    "source": {
                        "type": "base64",
                        "media_type": media_type,
                        "data": image_data
                    }
                },
                {"type": "text", "text": question}
            ]
        }]
    )
    return response.content[0].text
```

---

## Prompt Caching

Reduce costs and latency for repeated large context (system prompts, documents):

```python
response = client.messages.create(
    model="claude-sonnet-4-6",
    max_tokens=1024,
    system=[
        {
            "type": "text",
            "text": very_long_system_prompt,  # This gets cached after first call
            "cache_control": {"type": "ephemeral"}
        }
    ],
    messages=[{"role": "user", "content": user_question}]
)

# Check cache usage
print(response.usage.cache_read_input_tokens)  # Tokens read from cache (cheap)
print(response.usage.cache_creation_input_tokens)  # Tokens written to cache (first call)
```

Cache persists for ~5 minutes. Use when:
- Large system prompts (> 1024 tokens)
- Same document processed multiple times
- Long conversation history

---

## Subagent / Multi-Agent Architecture

```python
def orchestrator(task: str) -> str:
    """Main agent that coordinates subagents"""

    # Step 1: Plan
    plan = client.messages.create(
        model="claude-sonnet-4-6",
        max_tokens=1024,
        system="You are a task planner. Break the task into subtasks.",
        messages=[{"role": "user", "content": task}]
    ).content[0].text

    # Step 2: Execute subtasks (can be parallelized)
    subtask_results = []
    for subtask in parse_subtasks(plan):
        result = subagent_executor(subtask)
        subtask_results.append(result)

    # Step 3: Synthesize
    return client.messages.create(
        model="claude-sonnet-4-6",
        max_tokens=2048,
        system="Synthesize the results into a final answer.",
        messages=[{
            "role": "user",
            "content": f"Original task: {task}\n\nResults: {subtask_results}"
        }]
    ).content[0].text
```

---

## Content Moderation

```python
def moderate_content(text: str) -> dict:
    response = client.messages.create(
        model="claude-haiku-4-5-20251001",
        max_tokens=200,
        messages=[{
            "role": "user",
            "content": f"""Analyze this text for policy violations. Return JSON:
{{"safe": true/false, "categories": ["list", "of", "violations"], "severity": "none/low/medium/high"}}

Text: {text}"""
        }]
    )
    return json.loads(response.content[0].text)
```

---

## Summarization

```python
def summarize(text: str, style: str = "bullet", max_points: int = 5) -> str:
    style_instructions = {
        "bullet": f"Return {max_points} bullet points covering the key information.",
        "paragraph": "Return a 2-3 sentence paragraph summary.",
        "executive": "Return a one-sentence executive summary followed by 3 key takeaways.",
        "technical": "Summarize for a technical audience. Include specific details, numbers, and methods."
    }

    response = client.messages.create(
        model="claude-sonnet-4-6",
        max_tokens=512,
        messages=[{
            "role": "user",
            "content": f"Summarize the following text. {style_instructions[style]}\n\nText:\n{text}"
        }]
    )
    return response.content[0].text
```

---

## Model Selection Guide

| Use Case | Recommended Model | Reason |
|----------|------------------|--------|
| Complex reasoning, coding | `claude-opus-4-6` | Best capability |
| General tasks, balanced | `claude-sonnet-4-6` | Best price/performance |
| Fast classification, simple tasks | `claude-haiku-4-5-20251001` | Fastest, cheapest |
| High-volume batch processing | `claude-haiku-4-5-20251001` | Cost efficiency |
| Agentic/tool use tasks | `claude-sonnet-4-6` | Good tool calling |
