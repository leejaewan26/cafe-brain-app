"""
G6 — 운영자(Cafe Brain 팀) admin 대시보드.

엔드포인트는 X-Admin-Key 헤더로 보호. 매장 사장님은 접근 X.
조회용만 (변경 X).
"""
import asyncio
from datetime import datetime, timedelta, timezone
from typing import Any

from fastapi import APIRouter, Header, HTTPException

from app.config import settings
from app.services.gemini_service import _get_supabase, get_cache_stats, get_token_stats
from app.services.slo_service import compute_percentiles

router = APIRouter()


def _check_admin(admin_key: str | None) -> None:
    """X-Admin-Key 검증."""
    expected = settings.agent_admin_key or ""
    if not expected:
        raise HTTPException(status_code=503, detail="Admin 키 미설정")
    if not admin_key or admin_key != expected:
        raise HTTPException(status_code=403, detail="권한 없음")


@router.get("/overview")
async def admin_overview(admin_key: str | None = Header(default=None, alias="X-Admin-Key")):
    """
    전체 매장 요약 — 가입자 수, 활성 매장 수, 토큰 사용, 캐시 적중률.
    """
    _check_admin(admin_key)
    sb = _get_supabase()
    if sb is None:
        raise HTTPException(status_code=503, detail="Supabase 미설정")

    try:
        # 매장 수
        stores_res = await asyncio.to_thread(
            lambda: sb.table("stores").select("id", count="exact", head=True).execute()
        )
        total_stores = stores_res.count or 0

        # 최근 7일 신규 매장
        week_ago = (datetime.now(timezone.utc) - timedelta(days=7)).isoformat()
        new_res = await asyncio.to_thread(
            lambda: sb.table("stores").select("id", count="exact", head=True).gte("created_at", week_ago).execute()
        )
        new_7d = new_res.count or 0

        # 활성 매장 (최근 24h 활동)
        day_ago = (datetime.now(timezone.utc) - timedelta(hours=24)).isoformat()
        active_res = await asyncio.to_thread(
            lambda: sb.table("agent_briefing_log")
            .select("store_id", count="exact", head=True)
            .gte("created_at", day_ago)
            .execute()
        )
        active_24h = active_res.count or 0

        # 메모리 총량
        mem_res = await asyncio.to_thread(
            lambda: sb.table("agent_memory")
            .select("id", count="exact", head=True)
            .is_("archived_at", "null")
            .execute()
        )
        total_memories = mem_res.count or 0

        return {
            "stores": {
                "total": total_stores,
                "new_7d": new_7d,
                "active_24h": active_24h,
            },
            "memories": {"total": total_memories},
            "cache": get_cache_stats(),
            "tokens": get_token_stats(),
            "deployment_env": settings.deployment_env,
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e)[:200])


@router.get("/slo")
async def admin_slo(
    window_days: int = 7,
    admin_key: str | None = Header(default=None, alias="X-Admin-Key"),
):
    """전체 endpoint별 SLO (모든 매장 합산)."""
    _check_admin(admin_key)
    rows = await compute_percentiles(window_days=window_days)
    return {"endpoints": rows}


# ═══════════════════════════════════════════════════════
# M7 — 비즈니스 메트릭 (LTV / MRR / 이탈률)
# ═══════════════════════════════════════════════════════


@router.get("/metrics")
async def admin_business_metrics(
    admin_key: str | None = Header(default=None, alias="X-Admin-Key"),
):
    """LTV / MRR / 이탈률 / NRR (Net Revenue Retention)."""
    _check_admin(admin_key)
    sb = _get_supabase()
    if sb is None:
        raise HTTPException(503, "Supabase 미설정")
    now = datetime.now(timezone.utc)

    # 1) MRR — 활성 구독의 amount_krw 월환산 합
    active_res = await asyncio.to_thread(
        lambda: sb.table("subscriptions")
        .select("plan_id, amount_krw")
        .in_("status", ["active", "past_due"])
        .execute()
    )
    rows = active_res.data or []
    mrr = 0
    for r in rows:
        amt = int(r.get("amount_krw") or 0)
        # yearly는 12로 나눠 월환산
        if r.get("plan_id") == "yearly":
            mrr += amt // 12
        else:
            mrr += amt

    # 2) 이탈률 (지난 30일)
    month_ago = (now - timedelta(days=30)).isoformat()
    canceled_res = await asyncio.to_thread(
        lambda: sb.table("subscriptions")
        .select("id", count="exact", head=True)
        .eq("status", "canceled")
        .gte("canceled_at", month_ago)
        .execute()
    )
    canceled_30d = canceled_res.count or 0

    # 30일 시작 시점 활성 구독 수 추정
    active_30d_ago_res = await asyncio.to_thread(
        lambda: sb.table("subscriptions")
        .select("id", count="exact", head=True)
        .lte("created_at", month_ago)
        .execute()
    )
    active_at_start = active_30d_ago_res.count or 0
    churn_rate = (canceled_30d / active_at_start) if active_at_start > 0 else 0

    # 3) LTV ≈ 월 ARPU / churn (단순화)
    arpu = mrr / max(1, len(rows))
    ltv = arpu / max(0.01, churn_rate) if churn_rate > 0 else arpu * 24  # 이탈 0이면 24개월 가정

    # 4) Trial → Paid 전환률 (30일 윈도)
    trial_signup_res = await asyncio.to_thread(
        lambda: sb.table("stores")
        .select("id", count="exact", head=True)
        .gte("created_at", (now - timedelta(days=60)).isoformat())
        .lte("created_at", month_ago)
        .execute()
    )
    trial_signups = trial_signup_res.count or 0
    new_active_res = await asyncio.to_thread(
        lambda: sb.table("subscriptions")
        .select("id", count="exact", head=True)
        .gte("created_at", month_ago)
        .execute()
    )
    new_paid = new_active_res.count or 0
    conversion_rate = (new_paid / trial_signups) if trial_signups > 0 else 0

    return {
        "mrr_krw": mrr,
        "arr_krw": mrr * 12,
        "active_subscriptions": len(rows),
        "arpu_krw": int(arpu),
        "estimated_ltv_krw": int(ltv),
        "churn_rate_30d": round(churn_rate * 100, 2),
        "trial_to_paid_conversion": round(conversion_rate * 100, 2),
        "canceled_30d": canceled_30d,
        "new_paid_30d": new_paid,
    }


# ═══════════════════════════════════════════════════════
# M6 — 운영 액션 (강제정지 / 메모리 검열)
# ═══════════════════════════════════════════════════════


from pydantic import BaseModel as _BaseModel


class SuspendRequest(_BaseModel):
    store_id: str
    reason: str


@router.post("/suspend-store")
async def suspend_store(
    req: SuspendRequest,
    admin_key: str | None = Header(default=None, alias="X-Admin-Key"),
):
    """매장 강제 정지 — 모든 AI 호출·결제·로그인 차단 (서비스 약관 위반 등)."""
    _check_admin(admin_key)
    sb = _get_supabase()
    if sb is None:
        raise HTTPException(503, "Supabase 미설정")

    await asyncio.to_thread(
        lambda: sb.table("stores")
        .update({
            "subscription_status": "suspended",
            "suspended_reason": req.reason[:500],
            "suspended_at": datetime.now(timezone.utc).isoformat(),
        })
        .eq("id", req.store_id)
        .execute()
    )
    # 활성 구독도 일시 정지 (canceling)
    await asyncio.to_thread(
        lambda: sb.table("subscriptions")
        .update({"status": "canceled", "cancel_reason": f"운영자 정지: {req.reason}"})
        .eq("store_id", req.store_id)
        .eq("status", "active")
        .execute()
    )
    return {"suspended": True, "store_id": req.store_id}


class FlagMemoryRequest(_BaseModel):
    memory_id: str
    reason: str  # 예: 부적절한 내용, 개인정보 포함, ToS 위반


@router.post("/flag-memory")
async def flag_memory(
    req: FlagMemoryRequest,
    admin_key: str | None = Header(default=None, alias="X-Admin-Key"),
):
    """메모리 검열 — archived_at 설정 + flagged 표시."""
    _check_admin(admin_key)
    sb = _get_supabase()
    if sb is None:
        raise HTTPException(503, "Supabase 미설정")

    await asyncio.to_thread(
        lambda: sb.table("agent_memory")
        .update({
            "archived_at": datetime.now(timezone.utc).isoformat(),
            "archive_reason": f"운영자 플래그: {req.reason[:200]}",
        })
        .eq("id", req.memory_id)
        .execute()
    )
    return {"flagged": True}


@router.get("/recent-stores")
async def admin_recent_stores(
    limit: int = 50,
    admin_key: str | None = Header(default=None, alias="X-Admin-Key"),
):
    """최근 가입한 매장 목록 (이메일 마스킹)."""
    _check_admin(admin_key)
    sb = _get_supabase()
    if sb is None:
        raise HTTPException(status_code=503, detail="Supabase 미설정")

    try:
        res = await asyncio.to_thread(
            lambda: sb.table("stores")
            .select("id, name, created_at, subscription_status, agent_learning_enabled")
            .order("created_at", desc=True)
            .limit(limit)
            .execute()
        )
        rows = res.data or []
        # ID 일부만 노출
        for r in rows:
            sid = r.get("id") or ""
            r["id_short"] = sid[:8] if sid else ""
        return {"stores": rows}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e)[:200])
