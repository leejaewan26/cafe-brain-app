-- Phase 6 #7+#10: 권한별 메모리 분리 + 자동 압축 인프라

-- ══════════════════════════════════════════════════════════
-- #7. agent_memory에 profile_role 컬럼 — 권한별 격리
-- ══════════════════════════════════════════════════════════
-- 가능 값:
--   'owner'   — 사장만 볼 수 있는 (재무·전략·인사 결정 등)
--   'manager' — 점장도 볼 수 있는 (운영·고객·재고 등)
--   NULL      — 모두 (기본, 기존 메모리)
ALTER TABLE public.agent_memory
  ADD COLUMN IF NOT EXISTS profile_role text
    CHECK (profile_role IS NULL OR profile_role IN ('owner', 'manager'));

CREATE INDEX IF NOT EXISTS idx_memory_role
  ON public.agent_memory(store_id, profile_role)
  WHERE archived_at IS NULL;

COMMENT ON COLUMN public.agent_memory.profile_role IS
  'Phase 6 #7: 메모리 가시성. owner=사장만 / manager=둘다 / NULL=전체 공개';


-- ══════════════════════════════════════════════════════════
-- #7. 권한 필터 적용된 검색 함수
-- ══════════════════════════════════════════════════════════
-- p_active_role: 'owner' / 'manager'
--   owner면 모든 메모리 (자기 owner-only + manager + NULL)
--   manager면 manager + NULL 만 (owner-only 제외)
CREATE OR REPLACE FUNCTION public.search_relevant_memories_v2(
  p_store_id uuid,
  p_active_role text DEFAULT 'owner',
  p_categories text[] DEFAULT NULL,
  p_limit int DEFAULT 10
)
RETURNS TABLE (
  id uuid,
  category text,
  content text,
  importance int,
  confidence numeric,
  profile_role text,
  created_at timestamptz
) AS $func$
BEGIN
  RETURN QUERY
  SELECT m.id, m.category, m.content, m.importance, m.confidence,
         m.profile_role, m.created_at
  FROM public.agent_memory m
  WHERE m.store_id = p_store_id
    AND m.archived_at IS NULL
    AND (m.expires_at IS NULL OR m.expires_at > now())
    AND (p_categories IS NULL OR m.category = ANY(p_categories))
    AND (
      p_active_role = 'owner'                       -- 사장: 전체 가시
      OR m.profile_role IS NULL                     -- NULL: 모두
      OR m.profile_role = 'manager'                 -- manager: 점장도 OK
    )
  ORDER BY
    (m.importance * 0.7 +
     CASE
       WHEN m.last_reinforced_at > now() - interval '7 days' THEN 3.0
       WHEN m.last_reinforced_at > now() - interval '30 days' THEN 1.5
       ELSE 0.5
     END * 0.3
    ) * m.confidence DESC,
    m.last_used_at DESC NULLS LAST
  LIMIT p_limit;
END;
$func$ LANGUAGE plpgsql STABLE SECURITY DEFINER;

COMMENT ON FUNCTION public.search_relevant_memories_v2 IS
  'Phase 6 #7: 활성 프로필 역할 기반 메모리 가시성 적용된 검색';


-- ══════════════════════════════════════════════════════════
-- #10. 메모리 압축 후보 식별 함수
-- ══════════════════════════════════════════════════════════
-- 같은 매장·같은 카테고리에 5개 이상 메모리 있는 그룹 찾기.
-- 백엔드 worker가 이 결과를 받아서 LLM으로 압축 → 새 메모리 INSERT + 원본 archived.
CREATE OR REPLACE FUNCTION public.find_memory_compression_candidates(
  p_store_id uuid,
  p_min_group_size int DEFAULT 5,
  p_min_age_days int DEFAULT 30
)
RETURNS TABLE (
  category text,
  group_size bigint,
  oldest_at timestamptz,
  newest_at timestamptz
) AS $func$
BEGIN
  RETURN QUERY
  SELECT
    m.category,
    count(*)::bigint AS group_size,
    min(m.created_at) AS oldest_at,
    max(m.created_at) AS newest_at
  FROM public.agent_memory m
  WHERE m.store_id = p_store_id
    AND m.archived_at IS NULL
    AND m.created_at < now() - (p_min_age_days || ' days')::interval
    AND m.importance <= 7  -- 매우 중요한 메모리는 압축 대상 아님
  GROUP BY m.category
  HAVING count(*) >= p_min_group_size
  ORDER BY group_size DESC;
END;
$func$ LANGUAGE plpgsql STABLE SECURITY DEFINER;


-- ══════════════════════════════════════════════════════════
-- #10. 압축 대상 메모리 fetch (한 카테고리 그룹의 전체 내용)
-- ══════════════════════════════════════════════════════════
CREATE OR REPLACE FUNCTION public.fetch_memories_for_compression(
  p_store_id uuid,
  p_category text,
  p_limit int DEFAULT 20
)
RETURNS TABLE (
  id uuid,
  content text,
  importance int,
  created_at timestamptz
) AS $func$
BEGIN
  RETURN QUERY
  SELECT m.id, m.content, m.importance, m.created_at
  FROM public.agent_memory m
  WHERE m.store_id = p_store_id
    AND m.category = p_category
    AND m.archived_at IS NULL
    AND m.importance <= 7
  ORDER BY m.created_at ASC
  LIMIT p_limit;
END;
$func$ LANGUAGE plpgsql STABLE SECURITY DEFINER;


COMMENT ON FUNCTION public.find_memory_compression_candidates IS
  'Phase 6 #10: 카테고리별 5+ 메모리 그룹 (30일 이상 + importance≤7) — 압축 후보';
COMMENT ON FUNCTION public.fetch_memories_for_compression IS
  'Phase 6 #10: 압축 대상 메모리 본문 가져오기 (LLM에 전달)';
