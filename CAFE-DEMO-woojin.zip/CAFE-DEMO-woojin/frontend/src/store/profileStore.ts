// 멀티 프로필 스토어 (Issue #5)
// 계정 1개 → 프로필 최대 3개 (사장/점장 역할)
// 활성 프로필 영속화 (localStorage)
import { create } from 'zustand'
import { persist } from 'zustand/middleware'

export type ProfileRole = 'owner' | 'manager'

export interface Profile {
  id: string
  store_id: string
  name: string
  role: ProfileRole
  avatar_emoji: string
  avatar_color: string
  created_at: string
  last_active_at?: string | null
  pin_hash?: string | null
  active?: boolean
  permissions?: Record<string, boolean>  // 세부 권한 오버라이드
}

interface ProfileState {
  profiles: Profile[]           // 이 매장의 전체 프로필
  activeProfile: Profile | null // 현재 활성 프로필
  setProfiles: (profiles: Profile[]) => void
  setActiveProfile: (profile: Profile | null) => void
  addProfile: (profile: Profile) => void
  updateProfile: (id: string, patch: Partial<Profile>) => void
  removeProfile: (id: string) => void
  reset: () => void
}

export const useProfileStore = create<ProfileState>()(
  persist(
    (set) => ({
      profiles: [],
      activeProfile: null,
      setProfiles: (profiles) => set({ profiles }),
      setActiveProfile: (activeProfile) => set({ activeProfile }),
      addProfile: (p) =>
        set((s) => ({ profiles: [...s.profiles, p] })),
      updateProfile: (id, patch) =>
        set((s) => ({
          profiles: s.profiles.map((p) => (p.id === id ? { ...p, ...patch } : p)),
          activeProfile:
            s.activeProfile?.id === id
              ? { ...s.activeProfile, ...patch }
              : s.activeProfile,
        })),
      removeProfile: (id) =>
        set((s) => ({
          profiles: s.profiles.filter((p) => p.id !== id),
          activeProfile: s.activeProfile?.id === id ? null : s.activeProfile,
        })),
      reset: () => set({ profiles: [], activeProfile: null }),
    }),
    {
      name: 'cafe-brain-profile',
      partialize: (state) => ({ activeProfile: state.activeProfile }),
    }
  )
)

// ─── 권한 헬퍼 ───
// 사장만 접근 가능한 민감 기능들
export const OWNER_ONLY_FEATURES = [
  'labor_cost_settings',      // 인건비 설정
  'juhusu_mode',              // 주휴수당 모드 (Issue #6)
  'order_approval',           // 발주 승인 (Issue #8)
  'account_delete',           // 계정 삭제
  'profile_management',       // 프로필 관리 (추가/삭제)
  'financial_info',           // 재무 정보 편집 (고정비, 매출)
] as const

export type OwnerOnlyFeature = typeof OWNER_ONLY_FEATURES[number]

/**
 * 현재 프로필이 해당 기능에 접근 가능한지 확인.
 * 사장이 점장 프로필 permissions에 명시적 오버라이드 설정 가능.
 */
export function canAccess(
  profile: Profile | null,
  feature: OwnerOnlyFeature | string
): boolean {
  if (!profile) return false

  // owner는 전체 접근 (단, 비활성이면 거부)
  if (profile.active === false) return false
  if (profile.role === 'owner') return true

  // permissions에 명시적 오버라이드가 있으면 그것을 우선
  if (profile.permissions && feature in profile.permissions) {
    return profile.permissions[feature] === true
  }

  // manager 기본값: OWNER_ONLY 목록 외 접근 가능
  return !OWNER_ONLY_FEATURES.includes(feature as OwnerOnlyFeature)
}

export function isOwner(profile: Profile | null): boolean {
  return profile?.role === 'owner'
}
