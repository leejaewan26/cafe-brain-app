"""
Pytest 공용 fixtures.

원칙:
- 외부 API 호출 절대 금지 (Gemini·Supabase 모킹)
- 인메모리 fixture 위주
- TestClient는 async 지원 (httpx.AsyncClient or starlette.TestClient)
"""
import os
import sys
from pathlib import Path

# 루트 경로 sys.path에 추가 (`from app.main import app` 가능하게)
ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

# 테스트 환경에선 외부 키 비움 — graceful degradation 경로 검증
os.environ.setdefault("GEMINI_API_KEY", "")
os.environ.setdefault("SUPABASE_URL", "")
os.environ.setdefault("SUPABASE_SERVICE_KEY", "")
os.environ.setdefault("CORS_ALLOW_ORIGINS", "*")
os.environ.setdefault("DEPLOYMENT_ENV", "local")

import pytest
from fastapi.testclient import TestClient


@pytest.fixture(scope="session")
def client():
    """FastAPI TestClient — 모든 테스트 공용."""
    from app.main import app
    with TestClient(app) as c:
        yield c
