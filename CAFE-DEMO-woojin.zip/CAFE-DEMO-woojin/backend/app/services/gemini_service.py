"""
Gemini API 래퍼 서비스
- Supabase `ai_cache` 테이블 기반 24시간 응답 캐싱 (Rule 3)
- PII 필터 미들웨어가 이미 적용된 후 호출됨
- 모든 AI 텍스트에 워터마크 자동 삽입 (Rule 3)
- Day 2-1: 캐시 히트/미스 계측 (CACHE_STATS + 로깅)
"""
import asyncio
import hashlib
import logging
from datetime import datetime, timedelta, timezone
from typing import Any, Optional

import google.generativeai as genai
from supabase import Client, create_client

from app.config import settings

logger = logging.getLogger("gemini_cache")

# Day 2-1: 인메모리 캐시 통계 (프로세스 수명 동안 누적)
CACHE_STATS = {
    "hits": 0,
    "misses": 0,
    "errors": 0,
}

# Phase 6: 토큰·비용 추적 (인메모리, 프로세스 수명)
# 매장별 추적은 백엔드 재시작 시 리셋되니 장기 통계는 ai_cache·logs 활용 권장
TOKEN_STATS: dict[str, Any] = {
    "total_calls": 0,
    "total_input_tokens": 0,
    "total_output_tokens": 0,
    "by_module": {},  # module_name → {calls, input_tokens, output_tokens}
}

# Gemini 2.5 Flash 가격 (2025년 기준, USD)
# Input: $0.075 / 1M tokens, Output: $0.30 / 1M tokens
# 환율 1,400원 가정
PRICE_PER_INPUT_TOKEN_KRW = 0.075 / 1_000_000 * 1400
PRICE_PER_OUTPUT_TOKEN_KRW = 0.30 / 1_000_000 * 1400


def get_cache_stats() -> dict:
    """현재 캐시 히트율·절감액 추정 반환 (admin 대시보드용)."""
    total = CACHE_STATS["hits"] + CACHE_STATS["misses"]
    hit_rate = (CACHE_STATS["hits"] / total) if total > 0 else 0.0
    # Gemini 2.5 Flash 평균 1K 입력·0.3K 출력 가정, 평균 비용 ₩0.23/call
    saved_krw_estimate = CACHE_STATS["hits"] * 0.23
    return {
        **CACHE_STATS,
        "total": total,
        "hit_rate": round(hit_rate, 4),
        "saved_krw_estimate": round(saved_krw_estimate, 2),
    }


def get_token_stats() -> dict:
    """Phase 6: 토큰 사용량·비용 추정 (인메모리)."""
    total_in = TOKEN_STATS["total_input_tokens"]
    total_out = TOKEN_STATS["total_output_tokens"]
    cost_in = total_in * PRICE_PER_INPUT_TOKEN_KRW
    cost_out = total_out * PRICE_PER_OUTPUT_TOKEN_KRW
    return {
        "total_calls": TOKEN_STATS["total_calls"],
        "total_input_tokens": total_in,
        "total_output_tokens": total_out,
        "estimated_cost_krw": round(cost_in + cost_out, 2),
        "by_module": TOKEN_STATS["by_module"],
        "pricing_note": "Gemini 2.5 Flash 표준 가격 기준 추정 (실제 청구는 GCP 콘솔 확인)",
    }


def _track_tokens(module: str, response: Any) -> None:
    """Gemini 응답에서 토큰 사용량 추출 + 누적. 실패는 무시."""
    try:
        usage = getattr(response, "usage_metadata", None)
        if usage is None:
            return
        in_tokens = int(getattr(usage, "prompt_token_count", 0) or 0)
        out_tokens = int(getattr(usage, "candidates_token_count", 0) or 0)
        TOKEN_STATS["total_calls"] += 1
        TOKEN_STATS["total_input_tokens"] += in_tokens
        TOKEN_STATS["total_output_tokens"] += out_tokens
        bucket = TOKEN_STATS["by_module"].setdefault(
            module, {"calls": 0, "input_tokens": 0, "output_tokens": 0}
        )
        bucket["calls"] += 1
        bucket["input_tokens"] += in_tokens
        bucket["output_tokens"] += out_tokens
    except Exception:
        pass


# 싱글톤 Supabase 클라이언트 (서비스 키로 RLS 우회)
_supabase_client: Optional[Client] = None


def _get_supabase() -> Optional[Client]:
    """Supabase 클라이언트 지연 초기화. 환경변수 누락 시 None."""
    global _supabase_client
    if _supabase_client is not None:
        return _supabase_client

    if not settings.supabase_url or not settings.supabase_service_key:
        # 캐시 기능 비활성화 (로컬 개발 환경 등)
        return None

    _supabase_client = create_client(
        settings.supabase_url,
        settings.supabase_service_key,
    )
    return _supabase_client


def _get_model():
    """Gemini 2.5 Flash 모델 초기화 (한국어 향상 + 컨텍스트 1M)"""
    genai.configure(api_key=settings.gemini_api_key)
    return genai.GenerativeModel('gemini-2.5-flash')


# ═══════════════════════════════════════════════════════
# 핵심 API: 직접 호출 + 캐싱 래퍼
# ═══════════════════════════════════════════════════════


async def generate_insight_from_image(
    prompt: str,
    image_base64: str,
    mime_type: str = "image/jpeg",
    show_watermark: bool = False,
    max_retries: int = 1,
) -> str:
    """
    K7 — Gemini Vision 공통 함수.

    이전엔 ai_chat.py / differentiation.py / OCR이 각자 inline 구현.
    여기서 단일화 — base64 디코드 + 토큰 트래킹 + 재시도 + 일관된 에러 처리.

    Args:
        prompt: 텍스트 프롬프트
        image_base64: data URL 또는 raw base64
        mime_type: image/jpeg, image/png, image/webp
        show_watermark: AI 워터마크 부착
        max_retries: Vision은 비싸므로 기본 1회만

    Returns:
        모델 응답 텍스트
    """
    import base64 as _b64

    # data URL 정리
    raw_b64 = image_base64
    if "," in raw_b64:
        raw_b64 = raw_b64.split(",", 1)[1]
    img_bytes = _b64.b64decode(raw_b64)

    last_exc: Optional[Exception] = None
    for attempt in range(max_retries + 1):
        try:
            model = _get_model()
            def _call():
                resp = model.generate_content([prompt, {"mime_type": mime_type, "data": img_bytes}])
                _track_tokens("vision", resp)
                return resp.text or ""
            text = (await asyncio.to_thread(_call)).strip()
            if show_watermark:
                return f"{text}\n\nⓘ AI가 생성한 콘텐츠입니다."
            return text
        except Exception as e:
            last_exc = e
            if attempt < max_retries:
                await asyncio.sleep(2 ** attempt)
                continue
            break
    raise RuntimeError(f"Vision 호출 실패: {last_exc}")


async def generate_insight(
    prompt: str,
    show_watermark: bool = True,
    max_retries: int = 2,
) -> str:
    """
    Gemini 텍스트 인사이트 생성 (캐싱 X).

    Args:
        prompt: Gemini 프롬프트
        show_watermark: 워터마크 표시 여부 (Critical C1: 사용자 설정 연결)
        max_retries: 일시 오류 시 재시도 횟수 (exponential backoff, Suggestion S3)

    Returns:
        Gemini 응답 (워터마크 옵션 반영)
    """
    last_exc: Optional[Exception] = None
    for attempt in range(max_retries + 1):
        try:
            model = _get_model()
            response = await asyncio.to_thread(model.generate_content, prompt)
            _track_tokens("generate_insight", response)  # Phase 6: 토큰 추적
            text = response.text.strip()
            if show_watermark:
                return f"{text}\n\nⓘ AI가 생성한 콘텐츠입니다."
            return text
        except Exception as e:
            last_exc = e
            # 마지막 시도는 즉시 실패
            if attempt >= max_retries:
                break
            # Exponential backoff: 0.5s, 1.5s
            await asyncio.sleep(0.5 * (3 ** attempt))

    raise RuntimeError(f"Gemini API 호출 실패 (재시도 {max_retries}회): {str(last_exc)}")


# ═══════════════════════════════════════════════════════
# Bonus E1 — Self-correction (자기 답변 검증)
# ═══════════════════════════════════════════════════════
# 에이전트가 자기 답변을 비평한 뒤 문제 있으면 1회만 자체 수정.
# 비싼 모듈(전략 보고서·BEP 분석)에만 사용 — 일반 채팅엔 X.

CRITIQUE_PROMPT = """아래는 카페 사장님께 드릴 답변 초안입니다.
원래 질문과 답변을 보고, 다음 기준으로 점검하세요:

1. 사실 오류 — 매장 데이터·메모리에 없는 숫자를 만들어내지 않았는가
2. 일반론 — "보통은 ~" "일반적으로 ~" 같은 추상적 조언만 있지 않은가
3. 모순 — 자체 모순되는 권고
4. 안전 — 부적절·해로운 권고
5. 구체성 — 사장님이 바로 행동할 수 있는 단계가 있는가

[원래 질문]
{question}

[답변 초안]
{draft}

[출력]
JSON만 (코드블록 X):
{{
  "ok": true | false,
  "issues": ["..."],         // 발견된 문제 (최대 3개)
  "improved": "수정안 또는 null"
}}

ok=true면 그대로 사용, false면 improved로 교체.
구체성·정확성 중대한 결함이 있을 때만 false.
""".strip()


async def generate_with_review(
    prompt: str,
    question_for_review: Optional[str] = None,
    show_watermark: bool = True,
    max_retries: int = 2,
) -> tuple[str, dict]:
    """
    답변 생성 → 자기 비평 → 필요 시 자체 수정.

    Args:
        prompt: 본 답변 생성 프롬프트
        question_for_review: 비평기에 보여줄 "원래 질문" (없으면 prompt 앞 200자)
        show_watermark: 워터마크 (기본 답변 끝)
        max_retries: 본 호출 재시도 (비평은 재시도 X)

    Returns:
        (final_text, review_meta)
        review_meta: {ok, issues, revised}  — UI에서 "🔍 자체 검증 통과/수정됨" 표기
    """
    # 1) 초안
    draft = await generate_insight(prompt, show_watermark=False, max_retries=max_retries)
    if not draft.strip():
        return draft, {"ok": False, "issues": ["empty"], "revised": False}

    # 2) 비평 (1회만, 실패하면 초안 그대로)
    q = (question_for_review or prompt[:300]).strip()
    critique_prompt = CRITIQUE_PROMPT.format(
        question=q[:800],
        draft=draft[:1500],
    )
    review_meta: dict = {"ok": True, "issues": [], "revised": False}
    try:
        critique_raw = await generate_insight(
            critique_prompt, show_watermark=False, max_retries=0
        )
        import json as _json
        import re as _re
        cleaned = _re.sub(r"```(?:json)?\s*|\s*```", "", critique_raw).strip()
        m = _re.search(r"\{[\s\S]*\}", cleaned)
        if m:
            cleaned = m.group()
        crit = _json.loads(cleaned)
        ok = bool(crit.get("ok", True))
        issues = crit.get("issues") or []
        improved = crit.get("improved")

        if not ok and isinstance(improved, str) and len(improved.strip()) > 30:
            final = improved.strip()
            review_meta = {
                "ok": False,
                "issues": [str(x)[:120] for x in issues[:3]],
                "revised": True,
            }
        else:
            final = draft
            review_meta = {
                "ok": True,
                "issues": [str(x)[:120] for x in issues[:3]],
                "revised": False,
            }
    except Exception:
        # 비평 실패는 무시 — 초안 그대로
        final = draft

    if show_watermark:
        suffix = "\n\nⓘ AI가 생성한 콘텐츠입니다."
        if review_meta.get("revised"):
            suffix += " (자체 검증 후 수정됨)"
        elif review_meta.get("ok"):
            suffix += " (자체 검증 통과)"
        final += suffix
    return final, review_meta


# ═══════════════════════════════════════════════════════
# Bonus E2 — Citation (답변에 출처 자동 표기)
# ═══════════════════════════════════════════════════════


def attach_citations(text: str, citations: list[dict]) -> str:
    """
    답변 끝에 인용 출처 footnote 부착.

    Args:
        text: AI 답변
        citations: [{"label": "2024-12-15 매출 데이터", "kind": "sales"}, ...]

    Returns:
        본문 + "\n\n📎 출처: …"
    """
    if not citations:
        return text
    seen = set()
    bullets = []
    for c in citations[:5]:
        label = (c.get("label") or "").strip()
        if not label or label in seen:
            continue
        seen.add(label)
        kind = c.get("kind", "")
        prefix = {
            "sales": "📊", "memory": "🧠", "review": "💬",
            "trend": "📈", "menu": "🍽️", "profile": "🏪",
        }.get(kind, "•")
        bullets.append(f"{prefix} {label}")
    if not bullets:
        return text
    return text.rstrip() + "\n\n📎 *근거 데이터:* " + " · ".join(bullets)


def derive_citations_from_tool_calls(tool_calls: list[dict]) -> list[dict]:
    """
    Tool Use 호출 로그에서 citation 자동 도출.
    예: get_sales_summary(today=2024-12-15) → "2024-12-15 매출 데이터"
    """
    cites: list[dict] = []
    for tc in tool_calls or []:
        name = tc.get("name", "")
        args = tc.get("args") or {}
        if name == "get_sales_summary":
            day = args.get("today") or args.get("date") or "최근"
            cites.append({"label": f"{day} 매출 데이터", "kind": "sales"})
        elif name == "list_menus":
            cites.append({"label": "매장 메뉴 목록", "kind": "menu"})
        elif name == "get_today_reviews":
            cites.append({"label": "최근 리뷰", "kind": "review"})
        elif name == "search_memories":
            q = args.get("query", "")
            cites.append({"label": f"학습 메모리({q[:20]})" if q else "학습 메모리", "kind": "memory"})
        elif name == "get_trend_snapshot":
            cites.append({"label": "최신 시장 트렌드", "kind": "trend"})
        elif name == "get_store_profile":
            cites.append({"label": "매장 프로필", "kind": "profile"})
    return cites


# ═══════════════════════════════════════════════════════
# Phase 6: Tool Use — Gemini Function Calling
# ═══════════════════════════════════════════════════════


async def generate_with_tools(
    prompt: str,
    store_id: str,
    max_iterations: int = 4,
) -> tuple[str, list[dict]]:
    """
    Gemini Tool Use — 에이전트가 데이터 조회 도구를 직접 호출 + 결과 반영해 응답.

    Args:
        prompt: 사용자 프롬프트 (시스템 컨텍스트 포함)
        store_id: 매장 ID (도구 호출 시 RLS 격리)
        max_iterations: tool call 반복 한도 (무한 루프 방지)

    Returns:
        (final_text, tool_calls_log)
        tool_calls_log: [{"name": "...", "args": {...}, "result": {...}}]
    """
    from app.services.agent_tools import TOOL_DECLARATIONS, execute_tool

    tool_calls_log: list[dict] = []

    if not settings.gemini_api_key:
        return prompt, tool_calls_log

    def _sync_call() -> tuple[str, list[dict]]:
        try:
            genai.configure(api_key=settings.gemini_api_key)
            model = genai.GenerativeModel(
                "gemini-2.5-flash",
                tools=[{"function_declarations": TOOL_DECLARATIONS}],
            )
            chat = model.start_chat()
            response = chat.send_message(prompt)
            try:
                _track_tokens("chat_with_tools", response)
            except Exception:
                pass

            for _ in range(max_iterations):
                # function_call 파트 찾기
                fn_call = None
                try:
                    for part in response.candidates[0].content.parts:
                        fc = getattr(part, "function_call", None)
                        if fc and fc.name:
                            fn_call = fc
                            break
                except (AttributeError, IndexError):
                    break

                if fn_call is None:
                    break

                # 도구 실행 (asyncio loop 새로 만들어서 sync 컨텍스트에서 호출)
                args_dict = dict(fn_call.args) if fn_call.args else {}
                tool_result: dict = {}
                try:
                    import asyncio as _asyncio
                    loop = _asyncio.new_event_loop()
                    try:
                        tool_result = loop.run_until_complete(
                            execute_tool(fn_call.name, args_dict, store_id)
                        )
                    finally:
                        loop.close()
                except Exception as ex:
                    tool_result = {"error": str(ex)[:100]}

                tool_calls_log.append({
                    "name": fn_call.name,
                    "args": args_dict,
                    "result": tool_result,
                })

                # 결과를 Gemini에 다시 전달
                response = chat.send_message(
                    genai.protos.Content(
                        parts=[
                            genai.protos.Part(
                                function_response=genai.protos.FunctionResponse(
                                    name=fn_call.name,
                                    response={"content": tool_result},
                                )
                            )
                        ]
                    )
                )
                try:
                    _track_tokens("chat_with_tools", response)
                except Exception:
                    pass

            # 최종 텍스트 추출
            try:
                text = response.text.strip()
            except (AttributeError, ValueError):
                # text 속성 못 가져오면 candidates에서 직접
                parts = response.candidates[0].content.parts
                text = "".join(getattr(p, "text", "") for p in parts).strip()

            return text, tool_calls_log
        except Exception as e:
            return f"[Tool use 실패: {str(e)[:120]}]\n\n도구 없이 다시 시도하시려면 같은 질문을 한 번 더 해주세요.", tool_calls_log

    return await asyncio.to_thread(_sync_call)


async def generate_insight_cached(
    prompt: str,
    cache_key: Optional[str] = None,
    ttl_hours: int = 24,
    show_watermark: bool = True,
) -> str:
    """
    24시간 캐싱 적용된 Gemini 호출.

    Args:
        prompt: Gemini 프롬프트
        cache_key: 명시적 캐시 키. None이면 프롬프트의 SHA256 해시 사용.
        ttl_hours: 캐시 유효 기간 (기본 24시간)
        show_watermark: 워터마크 표시 여부

    Returns:
        Gemini 응답 (워터마크 옵션 반영)
    """
    # 캐시 키: 워터마크 옵션이 달라지면 다른 캐시로 저장
    effective_key = cache_key or _hash_prompt(prompt)
    if not show_watermark:
        effective_key = f"{effective_key}:nowm"

    # 1) 캐시 조회 (Day 2-1: 히트/미스 계측)
    cached = await _get_from_cache(effective_key)
    if cached is not None:
        CACHE_STATS["hits"] += 1
        logger.info("cache HIT | key=%s...", effective_key[:12])
        return cached

    # 2) Gemini 호출
    CACHE_STATS["misses"] += 1
    logger.info("cache MISS | key=%s... → Gemini 호출", effective_key[:12])
    result = await generate_insight(prompt, show_watermark=show_watermark)

    # 3) 캐시 저장 (실패해도 응답은 반환)
    await _save_to_cache(effective_key, result, ttl_hours)
    return result


async def invalidate_store_cache(store_id: str) -> int:
    """
    특정 매장의 AI 응답 캐시 일괄 무효화 (Suggestion S2).
    stores 테이블 UPDATE 후 호출하면 다음 요청에서 fresh 응답 생성.

    Returns:
        삭제된 캐시 레코드 수
    """
    sb = _get_supabase()
    if sb is None:
        return 0
    try:
        # cache_key는 "store_id:template:..." 접두사 구조
        result = await asyncio.to_thread(
            lambda: sb.table("ai_cache")
            .delete()
            .like("cache_key", f"%{store_id}%")
            .execute()
        )
        return len(result.data) if result.data else 0
    except Exception:
        return 0


# ═══════════════════════════════════════════════════════
# 캐시 키 빌더 (라우터가 호출)
# ═══════════════════════════════════════════════════════


def build_cache_key(store_id: str, template: str, params: dict) -> str:
    """
    결정적 캐시 키 생성 (SHA256).

    Args:
        store_id: 매장 ID (매장별 격리)
        template: 프롬프트 템플릿 식별자 (예: "sales_insight", "review_reply")
        params: 프롬프트 변수들 (dict. 값은 문자열 변환 가능해야 함)
    """
    # dict를 정렬된 key=value 문자열로 직렬화해 결정성 확보
    param_str = "|".join(f"{k}={v}" for k, v in sorted(params.items()))
    raw = f"{store_id}:{template}:{param_str}"
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


def _hash_prompt(prompt: str) -> str:
    """프롬프트 자체의 SHA256 (명시적 cache_key 미지정 시 폴백)"""
    return hashlib.sha256(prompt.encode("utf-8")).hexdigest()


# ═══════════════════════════════════════════════════════
# 내부: Supabase ai_cache 테이블 I/O
# ═══════════════════════════════════════════════════════


async def _get_from_cache(cache_key: str) -> Optional[str]:
    """캐시 조회. 만료된 레코드 또는 오류 시 None."""
    sb = _get_supabase()
    if sb is None:
        return None

    try:
        now_iso = datetime.now(timezone.utc).isoformat()
        result = await asyncio.to_thread(
            lambda: sb.table("ai_cache")
            .select("response, expires_at")
            .eq("cache_key", cache_key)
            .gte("expires_at", now_iso)
            .limit(1)
            .execute()
        )
        if result.data:
            return result.data[0]["response"]
    except Exception as e:
        # 캐시 실패로 AI 호출을 막으면 안 됨
        CACHE_STATS["errors"] += 1
        logger.warning("cache read error: %s", str(e)[:100])
    return None


async def _save_to_cache(cache_key: str, response: str, ttl_hours: int) -> None:
    """캐시 저장 (UPSERT). 실패는 무시."""
    sb = _get_supabase()
    if sb is None:
        return

    try:
        expires_at = (
            datetime.now(timezone.utc) + timedelta(hours=ttl_hours)
        ).isoformat()
        await asyncio.to_thread(
            lambda: sb.table("ai_cache")
            .upsert(
                {
                    "cache_key": cache_key,
                    "response": response,
                    "expires_at": expires_at,
                },
                on_conflict="cache_key",
            )
            .execute()
        )
    except Exception as e:
        # 저장 실패는 성능 저하만 유발, 기능엔 영향 없음
        CACHE_STATS["errors"] += 1
        logger.warning("cache write error: %s", str(e)[:100])
