-- ═══════════════════════════════════════════════════════════════
-- 020 — K4 세금계산서 요청 테이블
-- ═══════════════════════════════════════════════════════════════

CREATE TABLE IF NOT EXISTS tax_invoices (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  store_id        UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  payment_key     TEXT NOT NULL,
  business_no     TEXT NOT NULL,        -- 사업자등록번호 (정규화 — 숫자만 10자)
  business_name   TEXT NOT NULL,
  representative  TEXT NOT NULL,
  email           TEXT NOT NULL,
  supply_amount   INT NOT NULL,         -- 공급가
  vat             INT NOT NULL,         -- 부가세
  total_amount    INT NOT NULL,
  status          TEXT NOT NULL DEFAULT 'requested'
    CHECK (status IN ('requested','issued','rejected','canceled')),
  external_id     TEXT,                  -- popbill 등 외부 invoice ID
  pdf_url         TEXT,
  issued_at       TIMESTAMPTZ,
  created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_tax_invoices_store ON tax_invoices(store_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_tax_invoices_status ON tax_invoices(status);

ALTER TABLE tax_invoices ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "tax_invoices_owner" ON tax_invoices;
CREATE POLICY "tax_invoices_owner" ON tax_invoices
  FOR ALL USING (auth.uid() = store_id);

COMMENT ON TABLE tax_invoices IS 'K4 세금계산서 발행 요청. external_id는 popbill 등 외부 시스템 ID.';
