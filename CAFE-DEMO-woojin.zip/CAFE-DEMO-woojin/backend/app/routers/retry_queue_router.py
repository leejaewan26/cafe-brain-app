"""L7 — 재시도 큐 cron endpoint."""
from fastapi import APIRouter, Header, HTTPException

from app.config import settings
from app.services.retry_queue import process_queue

router = APIRouter()


@router.post("/process")
async def process_retry_queue(
    cron_key: str = Header(default="", alias="X-Cron-Key"),
):
    """매 분 cron으로 호출 — pending job 처리."""
    expected = settings.agent_admin_key or ""
    if cron_key != expected:
        raise HTTPException(403, "권한 없음")
    return await process_queue(limit=50)
