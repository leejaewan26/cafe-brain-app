"""
Phase 6 #13 — Response time SLO 추적.

미들웨어가 모든 AI 엔드포인트의 (start, end, status, cache_hit, cost_krw)을
agent_latency_log에 INSERT한다. /api/agent/slo로 p50/p95/p99 + 캐시 적중률 조회.

DB INSERT는 비동기 백그라운드로 — 응답 자체를 늦추지 않는다.
DB 미연결 시 인메모리 fallback (단순 sliding 1k records).
"""
import asyncio
from collections import deque
from typing import Any, Optional

from app.services.gemini_service import _get_supabase

# 인메모리 fallback (Supabase 미연결 시 또는 INSERT 실패 시 응급 통계)
_RECENT: deque[dict[str, Any]] = deque(maxlen=1000)


async def record_latency(
    endpoint: str,
    duration_ms: int,
    method: str = "POST",
    status_code: Optional[int] = None,
    store_id: Optional[str] = None,
    cache_hit: bool = False,
    cost_krw: Optional[float] = None,
) -> None:
    """
    엔드포인트 응답시간 기록. 백그라운드 fire-and-forget 호출 권장.
    """
    rec: dict[str, Any] = {
        "endpoint": endpoint,
        "method": method,
        "duration_ms": int(max(0, duration_ms)),
        "cache_hit": cache_hit,
    }
    if status_code is not None:
        rec["status_code"] = status_code
    if store_id:
        rec["store_id"] = store_id
    if cost_krw is not None:
        rec["cost_krw"] = round(float(cost_krw), 4)

    _RECENT.append({**rec, "ts": asyncio.get_event_loop().time()})

    sb = _get_supabase()
    if sb is None:
        return

    try:
        await asyncio.to_thread(
            lambda: sb.table("agent_latency_log").insert(rec).execute()
        )
    except Exception:
        # SLO 기록 실패는 무시
        pass


async def compute_percentiles(
    store_id: Optional[str] = None,
    endpoint: Optional[str] = None,
    window_days: int = 7,
) -> list[dict[str, Any]]:
    """
    p50/p95/p99 + 캐시 적중률 조회. DB RPC 우선, 실패 시 인메모리.
    """
    sb = _get_supabase()
    if sb is not None:
        try:
            result = await asyncio.to_thread(
                lambda: sb.rpc(
                    "compute_slo_percentiles",
                    {
                        "p_store_id": store_id,
                        "p_endpoint": endpoint,
                        "p_window_days": window_days,
                    },
                ).execute()
            )
            if result.data:
                return result.data
        except Exception:
            pass

    # Fallback: 인메모리 통계
    return _compute_inmemory(endpoint=endpoint)


def _compute_inmemory(endpoint: Optional[str] = None) -> list[dict[str, Any]]:
    """인메모리 통계 (DB 미연결 시 응급)."""
    by_ep: dict[str, list[dict[str, Any]]] = {}
    for r in _RECENT:
        ep = r.get("endpoint", "?")
        if endpoint and ep != endpoint:
            continue
        by_ep.setdefault(ep, []).append(r)

    out: list[dict[str, Any]] = []
    for ep, records in by_ep.items():
        durations = sorted(r["duration_ms"] for r in records)
        if not durations:
            continue
        n = len(durations)
        cache_hits = sum(1 for r in records if r.get("cache_hit"))
        total_cost = sum(r.get("cost_krw") or 0 for r in records)

        def _pct(p: float) -> float:
            idx = max(0, min(n - 1, int(round(p * (n - 1)))))
            return float(durations[idx])

        out.append({
            "endpoint": ep,
            "total_calls": n,
            "cache_hit_rate": cache_hits / n if n else 0.0,
            "p50_ms": _pct(0.50),
            "p95_ms": _pct(0.95),
            "p99_ms": _pct(0.99),
            "total_cost_krw": round(total_cost, 4),
        })
    out.sort(key=lambda r: -r["total_calls"])
    return out


def get_recent_summary(limit: int = 20) -> list[dict[str, Any]]:
    """최근 호출 N건 — 디버그·실시간 모니터링용."""
    return list(_RECENT)[-limit:]
