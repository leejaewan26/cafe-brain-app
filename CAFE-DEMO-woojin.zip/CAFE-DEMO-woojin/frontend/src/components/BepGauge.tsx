// BEP(손익분기점) 게이지 위젯 (Issue #1)
// 입력: 설정페이지의 monthly_fixed_cost + 이번달 매출 데이터
// 출력: 달성률 프로그레스바 + 남은 금액 + 하루 목표
import { useEffect, useMemo, useState } from 'react'
import { TrendingUp, Target, AlertTriangle, Sparkles } from 'lucide-react'
import { Link } from 'react-router-dom'
import { useSalesStore } from '@/store/salesStore'
import { useAuthStore } from '@/store/authStore'
import { supabase } from '@/lib/supabase'
import { formatCurrency, cn } from '@/lib/utils'

interface BepGaugeProps {
  variant?: 'full' | 'compact'    // full: 대시보드 / compact: 플로팅 팝업
  className?: string
}

export default function BepGauge({ variant = 'full', className }: BepGaugeProps) {
  const { records } = useSalesStore()
  const { user, storeInfo } = useAuthStore()

  // Wave 5F: accounting_fixed_costs 활성 합계를 우선 사용 (더 정확)
  // fallback: storeInfo.monthly_fixed_cost (단일값)
  const [accountingFixed, setAccountingFixed] = useState<number | null>(null)

  useEffect(() => {
    if (!user) return
    let cancelled = false
    ;(async () => {
      const { data } = await supabase
        .from('accounting_fixed_costs')
        .select('monthly_amount')
        .eq('store_id', user.id)
        .eq('active', true)
      if (cancelled) return
      if (data && data.length > 0) {
        const total = data.reduce((s, row) => s + (row.monthly_amount as number), 0)
        setAccountingFixed(total)
      }
    })()
    return () => { cancelled = true }
  }, [user])

  const monthlyFixedCost = accountingFixed ?? (storeInfo?.monthly_fixed_cost ?? 0)

  const calc = useMemo(() => {
    // 이번 달 매출 누적
    const now = new Date()
    const thisMonth = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}`
    const monthRecords = records.filter((r) => r.sale_date.startsWith(thisMonth))

    const totalRevenue = monthRecords.reduce((sum, r) => sum + r.revenue, 0)
    const totalCost = monthRecords.reduce((sum, r) => sum + r.cost, 0)

    // 공헌이익률 = (매출 - 변동비) / 매출
    // 변동비는 여기선 원재료비(cost)만. 인건비·임대료는 monthly_fixed_cost에 포함 전제
    const contributionRate = totalRevenue > 0 ? (totalRevenue - totalCost) / totalRevenue : 0.65

    // BEP = 고정비 / 공헌이익률
    const bepAmount = contributionRate > 0 ? monthlyFixedCost / contributionRate : 0

    // 달성률
    const progressRate = bepAmount > 0 ? Math.min(100, (totalRevenue / bepAmount) * 100) : 0

    // 남은 매출
    const remaining = Math.max(0, bepAmount - totalRevenue)

    // 남은 일수 + 하루 목표
    const daysInMonth = new Date(now.getFullYear(), now.getMonth() + 1, 0).getDate()
    const daysLeft = Math.max(1, daysInMonth - now.getDate() + 1)
    const dailyTarget = remaining / daysLeft

    return {
      totalRevenue,
      bepAmount,
      progressRate,
      remaining,
      contributionRate: Math.round(contributionRate * 100),
      daysLeft,
      dailyTarget,
      achieved: progressRate >= 100,
      isConfigured: monthlyFixedCost > 0,
    }
  }, [records, monthlyFixedCost])

  // ─── 설정 미완료 상태 ───
  if (!calc.isConfigured) {
    return (
      <Link
        to="/settings"
        className={cn(
          'block bg-gradient-to-br from-[#D4A574]/10 to-[#2C1810]/5 rounded-2xl p-4 border border-[#D4A574]/30 hover:shadow-md transition-all duration-200',
          className
        )}
      >
        <div className="flex items-center gap-2 mb-2">
          <Target size={16} className="text-[#D4A574]" />
          <span className="text-xs font-bold text-[#2C1810]">BEP 설정 필요</span>
        </div>
        <p className="text-xs text-gray-500 mb-2">
          월 고정비를 입력하면 손익분기점 달성률을 실시간으로 볼 수 있어요
        </p>
        <span className="text-xs text-[#D4A574] font-semibold">설정하러 가기 →</span>
      </Link>
    )
  }

  // ─── 데이터 부족 상태 ───
  if (records.length === 0) {
    return (
      <Link
        to="/sales"
        className={cn(
          'block bg-[#FAFAF8] rounded-2xl p-4 border border-gray-100 hover:shadow-md transition-all duration-200',
          className
        )}
      >
        <div className="flex items-center gap-2 mb-2">
          <TrendingUp size={16} className="text-gray-400" />
          <span className="text-xs font-bold text-[#2C1810]">BEP 게이지</span>
        </div>
        <p className="text-xs text-gray-500">매출 데이터를 업로드하면 달성률을 보여드려요</p>
      </Link>
    )
  }

  // ─── 정상 상태 ───
  const colorClass = calc.achieved
    ? 'from-green-400 to-emerald-500'
    : calc.progressRate >= 70
      ? 'from-[#D4A574] to-[#c4956a]'
      : calc.progressRate >= 40
        ? 'from-amber-400 to-[#D4A574]'
        : 'from-red-400 to-orange-400'

  if (variant === 'compact') {
    return (
      <div className={cn('bg-white rounded-2xl p-5 shadow-lg border border-gray-100', className)}>
        <div className="flex items-center gap-2 mb-3">
          <Target size={16} className="text-[#D4A574]" />
          <span className="text-sm font-bold text-[#2C1810]">이번 달 BEP 진행률</span>
          {calc.achieved && (
            <span className="ml-auto text-xs bg-green-100 text-green-700 px-2 py-0.5 rounded-full font-semibold">
              <Sparkles size={10} className="inline" /> 달성
            </span>
          )}
        </div>

        <div className="text-center mb-3">
          <p className="text-3xl font-bold text-[#2C1810]">
            {Math.round(calc.progressRate)}
            <span className="text-lg text-gray-400">%</span>
          </p>
          <p className="text-xs text-gray-400 mt-0.5">
            {formatCurrency(calc.totalRevenue)} / {formatCurrency(calc.bepAmount)}
          </p>
        </div>

        <div className="w-full bg-gray-100 rounded-full h-2.5 overflow-hidden mb-3">
          <div
            className={`h-2.5 rounded-full bg-gradient-to-r ${colorClass} transition-all duration-700`}
            style={{ width: `${Math.min(100, calc.progressRate)}%` }}
          />
        </div>

        {calc.achieved ? (
          <p className="text-sm text-green-600 font-semibold text-center">
            🎉 이번 달 BEP를 달성했어요!
          </p>
        ) : (
          <div className="grid grid-cols-2 gap-3 text-xs">
            <div className="bg-[#FAFAF8] rounded-xl p-2.5 text-center">
              <p className="text-gray-400">남은 금액</p>
              <p className="font-bold text-[#2C1810] mt-0.5">{formatCurrency(calc.remaining)}</p>
            </div>
            <div className="bg-[#FAFAF8] rounded-xl p-2.5 text-center">
              <p className="text-gray-400">일 목표 ({calc.daysLeft}일 남음)</p>
              <p className="font-bold text-[#D4A574] mt-0.5">{formatCurrency(calc.dailyTarget)}</p>
            </div>
          </div>
        )}

        <p className="text-[10px] text-gray-400 mt-3 text-center">
          공헌이익률 {calc.contributionRate}% 기준
        </p>
      </div>
    )
  }

  // ─── full variant (대시보드용) ───
  return (
    <Link
      to="/sales"
      className={cn(
        'block bg-white rounded-2xl p-4 border border-gray-100 shadow-sm hover:shadow-md hover:border-[#D4A574]/40 transition-all duration-200',
        className
      )}
    >
      <div className="flex items-center gap-2 mb-3">
        <div className="w-9 h-9 rounded-xl bg-[#D4A574]/15 flex items-center justify-center">
          <Target size={16} className="text-[#D4A574]" />
        </div>
        <div className="flex-1 min-w-0">
          <p className="text-xs text-gray-500">이번 달 BEP</p>
          <p className="text-lg font-bold text-[#2C1810] leading-none mt-0.5">
            {Math.round(calc.progressRate)}%
          </p>
        </div>
        {calc.achieved ? (
          <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-green-100 text-green-700">
            달성 🎉
          </span>
        ) : calc.progressRate < 40 ? (
          <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-red-100 text-red-600">
            <AlertTriangle size={9} className="inline" /> 주의
          </span>
        ) : null}
      </div>

      <div className="w-full bg-gray-100 rounded-full h-1.5 overflow-hidden">
        <div
          className={`h-1.5 rounded-full bg-gradient-to-r ${colorClass} transition-all duration-700`}
          style={{ width: `${Math.min(100, calc.progressRate)}%` }}
        />
      </div>

      <div className="flex items-center justify-between text-[11px] text-gray-400 mt-2">
        <span>{formatCurrency(calc.totalRevenue)}</span>
        <span>
          {calc.achieved
            ? '목표 달성'
            : `하루 ${formatCurrency(calc.dailyTarget)} 필요`}
        </span>
      </div>
    </Link>
  )
}

// ─── 플로팅 팝업 (매출페이지용) ───
export function BepFloatingPopup() {
  const [open, setOpen] = useState(false)

  return (
    <>
      {/* 플로팅 아이콘 */}
      <button
        onClick={() => setOpen(!open)}
        className={cn(
          'fixed bottom-24 md:bottom-6 right-6 z-40 w-12 h-12 rounded-full shadow-xl flex items-center justify-center transition-all duration-300',
          open
            ? 'bg-[#2C1810] rotate-90'
            : 'bg-gradient-to-br from-[#D4A574] to-[#c4956a] hover:scale-110'
        )}
        title="BEP 달성률 보기"
        aria-label="BEP 달성률 팝업"
      >
        <Target size={20} className="text-white" />
      </button>

      {/* 팝업 */}
      {open && (
        <>
          <div
            className="fixed inset-0 z-30 bg-transparent"
            onClick={() => setOpen(false)}
          />
          <div className="fixed bottom-40 md:bottom-24 right-6 z-40 w-80 max-w-[calc(100vw-3rem)] animate-in slide-in-from-bottom-4 duration-200">
            <BepGauge variant="compact" />
          </div>
        </>
      )}
    </>
  )
}
