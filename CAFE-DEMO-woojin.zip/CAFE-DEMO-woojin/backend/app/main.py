"""
Cafe Brain FastAPI 백엔드 메인 앱
- 모든 Gemini API 호출은 이 서버를 경유 (Rule 3 준수)
- 미들웨어 체인 (실행 순서): CORS → RateLimit → PromptGuard → PII → 핸들러
  (add_middleware는 LIFO: 마지막에 추가한 것이 가장 바깥)
- Rule 3: 분당 10회 호출 제한 + 24시간 응답 캐싱
"""
import asyncio

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app.routers import (
    sales, schedule, review, marketing, menu, ai_chat,
    agent, agent_briefing, supplier, learning_hooks, push, ocr,
    billing, trends, data_export, admin,
    naver_reviews, pos_integrations, social_publish, retention,
    differentiation, notification_cron,
)
from app.routers import retry_queue_router
from app.middleware.pii_filter import PIIFilterMiddleware
from app.middleware.prompt_guard import PromptInjectionGuardMiddleware
from app.middleware.rate_limit import RateLimitMiddleware
from app.middleware.agent_gate import AgentGateMiddleware
from app.middleware.slo_tracker import SLOTrackerMiddleware
from app.observability import init_sentry, run_deep_healthcheck
from app.services.distill_worker import distill_worker_loop
from app.config import settings

# Sentry는 FastAPI 인스턴스 생성 전 초기화 (모든 예외 캡처)
_SENTRY_ACTIVE = init_sentry()

app = FastAPI(
    title="Cafe Brain API",
    description="""
소형 카페 AI 경영 솔루션 백엔드 (FastAPI + Gemini + Supabase).

## 주요 기능
- **AI 어시스턴트**: 자연어 매장 분석 (`/api/ai-chat`)
- **에이전트**: 능동 브리핑 + 메모리 학습 + 이상치 감지 (`/api/agent/*`)
- **OCR**: 영수증·송장 자동 인식 (`/api/ocr/*`, `/api/sales/ocr-invoice`)
- **결제**: Toss 빌링키 정기결제 (`/api/billing/*`)
- **연동**: 네이버 / POS / Instagram / n8n (`/api/{naver-reviews,pos,social}/*`)

## 버전
- **v1**: 안정 버전 (`/api/v1/*`) — production 권장
- **legacy**: 하위 호환 (`/api/*`) — deprecated, 차후 제거 예정

## 인증
- Supabase Auth Bearer 토큰 또는 X-Store-Id 헤더
- Admin 엔드포인트는 X-Admin-Key 헤더 필수
- Cron 엔드포인트는 X-Cron-Key 헤더 필수
""",
    version="1.3.0",
    contact={
        "name": "Cafe Brain Support",
        "email": "support@cafe-brain.app",
    },
    license_info={
        "name": "Proprietary",
    },
    openapi_tags=[
        {"name": "AI 어시스턴트", "description": "자연어 매장 분석"},
        {"name": "에이전트 (Phase 3)", "description": "능동 학습 + 이상치 감지"},
        {"name": "결제·구독", "description": "Toss 빌링키 + cron"},
        {"name": "데이터 export (GDPR)", "description": "본인 데이터 ZIP 다운로드 + erase"},
    ],
)

# ─── 미들웨어 체인 (마지막 add가 가장 바깥 레이어) ───
# 1. PII 필터링 (innermost, 핸들러 직전에 민감정보 마스킹)
app.add_middleware(PIIFilterMiddleware)

# 2. Prompt Injection Guard (PII 이전에 악성 페이로드 차단)
app.add_middleware(PromptInjectionGuardMiddleware)

# 3. Rate Limit (AI 엔드포인트만, 분당 10회)
app.add_middleware(RateLimitMiddleware)

# 4. Agent Gate (Phase 3) — 운영 시간 + 활성 세션만 능동 에이전트 허용
app.add_middleware(AgentGateMiddleware)

# 5. SLO Tracker (Phase 6 #13) — AI 엔드포인트 응답시간 측정 (백그라운드 INSERT)
app.add_middleware(SLOTrackerMiddleware)

# 6. CORS (outermost, 모든 응답에 CORS 헤더 + preflight 처리)
# Launch A1: 프로덕션은 specific origin (CORS_ALLOW_ORIGINS env). credentials=true와 *는 호환 X.
_cors_origins = settings.cors_origins_list
_allow_credentials = _cors_origins != ["*"]  # specific origin일 때만 credentials 허용
app.add_middleware(
    CORSMiddleware,
    allow_origins=_cors_origins,
    allow_credentials=_allow_credentials,
    allow_methods=["GET", "POST", "PUT", "DELETE", "OPTIONS", "PATCH"],
    allow_headers=[
        "Authorization", "Content-Type", "X-Store-Id", "X-Admin-Key",
        "X-Active-Profile", "X-Requested-With",
    ],
    expose_headers=[
        "X-RateLimit-Limit", "X-RateLimit-Remaining", "Retry-After",
        "X-Prompt-Risk", "X-Cache", "X-Agent-Skipped", "X-Response-Time-MS",
    ],
    max_age=600,
)

# 라우터 등록
# ─── I1: 라우터 등록 (v1 prefix + legacy alias) ─────────────────
# 모든 라우터를 /api/v1/* 와 /api/* 두 경로 모두에 등록.
# 레거시 /api/*는 향후 제거 예정 — 새 클라이언트는 /api/v1 사용 권장.
ROUTER_TABLE = [
    (sales.router, "sales", "매출 분석"),
    (schedule.router, "schedule", "스케줄링"),
    (review.router, "reviews", "리뷰 관리"),
    (marketing.router, "marketing", "마케팅 콘텐츠"),
    (menu.router, "menu", "메뉴·레시피"),
    (ai_chat.router, "chat", "AI 어시스턴트"),
    (agent.router, "agent", "에이전트 메모리"),
    (agent_briefing.router, "agent", "능동 에이전트"),
    (supplier.router, "supplier", "공급처 절감"),
    (learning_hooks.router, "learning", "학습 훅"),
    (push.router, "push", "Web Push 알림"),
    (ocr.router, "sales", "영수증 OCR"),
    (billing.router, "billing", "결제·구독"),
    (trends.router, "trends", "트렌드 분석 (Phase 4)"),
    (data_export.router, "data", "데이터 export (GDPR)"),
    (admin.router, "admin", "운영자 대시보드"),
    (naver_reviews.router, "naver-reviews", "네이버 리뷰 (H2)"),
    (pos_integrations.router, "pos", "POS 연동 (H3)"),
    (social_publish.router, "social", "소셜 게시 (H5)"),
    (retention.router, "retention", "데이터 보관 정책 (I4)"),
    (differentiation.router, "differentiation", "차별화 기능 (J3~J6)"),
    (notification_cron.router, "notification-cron", "이메일 트리거 cron (G4)"),
    (retry_queue_router.router, "retry-queue", "재시도 큐 (L7)"),
]

for r, path, tag in ROUTER_TABLE:
    # v1 (안정 버전)
    app.include_router(r, prefix=f"/api/v1/{path}", tags=[tag])
    # legacy alias (하위 호환 — 차후 제거)
    app.include_router(r, prefix=f"/api/{path}", tags=[f"{tag} (legacy)"], include_in_schema=False)


# Phase 6 #3: distill worker — 백엔드 시작 시 백그라운드 task 등록
@app.on_event("startup")
async def _start_background_workers():
    """1시간마다 _distill_pending=true 매장 스캔 + 자동 distill 실행."""
    asyncio.create_task(distill_worker_loop())


@app.get("/health")
async def health_check():
    """기본 헬스체크 — 로드밸런서·k8s liveness용 (빠른 응답)"""
    return {"status": "ok", "service": "cafe-brain-api", "sentry": _SENTRY_ACTIVE}


# Launch A7: Cloud Run / k8s 표준 프로브 분리
# - /liveness: 프로세스가 살아있는지만 확인 (초당 호출 가능, 의존성 X)
# - /readiness: 트래픽 받을 준비됐는지 (의존성 일부 점검, 5~30초 주기)
# - /health/deep: 풀 진단 (외부 의존성 전부, 모니터링 대시보드용)


@app.get("/liveness")
async def liveness_probe():
    """
    Liveness — 프로세스만 살아있는지. 외부 의존성 절대 호출 X.
    Cloud Run / k8s가 컨테이너 재시작 결정에 사용.
    """
    return {"status": "alive"}


@app.get("/readiness")
async def readiness_probe():
    """
    Readiness — 트래픽 받을 준비가 됐는지.
    필수 환경변수만 검증 (DB·Gemini는 graceful degradation이라 미체크).
    503이면 Cloud Run이 트래픽 빼줌.
    """
    from fastapi.responses import JSONResponse
    missing: list[str] = []
    if not settings.gemini_api_key:
        missing.append("GEMINI_API_KEY")
    # Supabase는 옵션이지만 프로덕션에선 필수
    if settings.deployment_env == "production":
        if not settings.supabase_url:
            missing.append("SUPABASE_URL")
        if not settings.supabase_service_key:
            missing.append("SUPABASE_SERVICE_KEY")

    if missing:
        return JSONResponse(
            status_code=503,
            content={
                "status": "not_ready",
                "missing_config": missing,
                "env": settings.deployment_env,
            },
        )
    return {
        "status": "ready",
        "env": settings.deployment_env,
        "version": settings.app_version,
    }


@app.get("/health/deep")
async def deep_health_check():
    """
    심화 헬스체크 (Day 2-2) — DB·Gemini·Supabase·메모리·캐시 점검.
    모니터링 대시보드·Synthetic 체크에서 주기 호출 권장.
    """
    return await run_deep_healthcheck()
