-- 011_store_operating_hours.sql
-- Phase 3: 매장별 영업시간 (AI 에이전트 게이트와 연동)
-- 이 시간 안에서만 능동 에이전트(브리핑·메모리 추출 등)가 Gemini 호출
-- 글로벌 기본값(env AGENT_HOUR_OPEN/CLOSE)을 매장별로 override

ALTER TABLE public.stores
  ADD COLUMN IF NOT EXISTS open_hour INTEGER NOT NULL DEFAULT 6
    CHECK (open_hour >= 0 AND open_hour <= 23),
  ADD COLUMN IF NOT EXISTS close_hour INTEGER NOT NULL DEFAULT 22
    CHECK (close_hour >= 1 AND close_hour <= 24);

-- 종료 > 시작 무결성 (자정 넘는 영업은 별도 처리, 현재는 단순 day-bound)
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint WHERE conname = 'stores_operating_hours_order'
  ) THEN
    ALTER TABLE public.stores
      ADD CONSTRAINT stores_operating_hours_order
      CHECK (close_hour > open_hour);
  END IF;
END$$;

COMMENT ON COLUMN public.stores.open_hour IS 'Phase 3: 영업 시작 시간 (KST 0-23). AI 에이전트 게이트가 사용';
COMMENT ON COLUMN public.stores.close_hour IS 'Phase 3: 영업 종료 시간 (KST 1-24). AI 에이전트 게이트가 사용';
