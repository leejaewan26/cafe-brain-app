"""
NewsAPI.org — 글로벌 영문 뉴스.

API: https://newsapi.org/docs
무료 (개발용): 무제한, 단 24h 지연
유료(소액): 실시간

해외 카페 트렌드·신메뉴 미디어 노출 시그널.
"""
import os
from datetime import datetime, timedelta, timezone
from typing import Optional

import httpx

NEWSAPI_URL = "https://newsapi.org/v2/everything"


async def search_global_news(
    query: str,
    page_size: int = 15,
    days_back: int = 7,
    language: str = "en",
) -> Optional[list[dict]]:
    """
    NewsAPI.org 검색.

    Args:
        query: 검색어 (영어, 예: 'cafe trends OR specialty coffee')
        page_size: 1-100
        days_back: 최근 며칠
        language: 'en' (개발 무료는 영어 위주)

    Returns:
        [{"title", "description", "url", "source", "published_at"}] 또는 None
    """
    api_key = os.getenv("NEWSAPI_KEY", "")
    if not api_key or not query:
        return None

    from_date = (datetime.now(timezone.utc) - timedelta(days=days_back)).strftime("%Y-%m-%d")

    params = {
        "q": query,
        "from": from_date,
        "language": language,
        "sortBy": "publishedAt",
        "pageSize": min(100, page_size),
        "apiKey": api_key,
    }

    try:
        async with httpx.AsyncClient(timeout=15) as client:
            r = await client.get(NEWSAPI_URL, params=params)
            r.raise_for_status()
            articles = r.json().get("articles", [])
            return [
                {
                    "title": a.get("title", ""),
                    "description": a.get("description", ""),
                    "url": a.get("url", ""),
                    "source": (a.get("source") or {}).get("name", ""),
                    "published_at": a.get("publishedAt", ""),
                }
                for a in articles
                if a.get("title") and a.get("title") != "[Removed]"
            ]
    except Exception:
        return None
