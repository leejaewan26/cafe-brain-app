// H6 — 언어 스위처 (ko ↔ en)
import { useTranslation } from 'react-i18next'
import { Globe } from 'lucide-react'

export default function LanguageSwitcher({ className = '' }: { className?: string }) {
  const { i18n } = useTranslation()

  const toggle = () => {
    const next = i18n.language?.startsWith('en') ? 'ko' : 'en'
    void i18n.changeLanguage(next)
  }

  const isEn = i18n.language?.startsWith('en')

  return (
    <button
      onClick={toggle}
      className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-medium text-gray-500 hover:text-[#2C1810] hover:bg-gray-50 transition-colors ${className}`}
      title={isEn ? '한국어로 전환' : 'Switch to English'}
      aria-label={isEn ? 'Switch to Korean' : 'Switch to English'}
    >
      <Globe size={13} />
      {isEn ? 'EN' : '한'}
    </button>
  )
}
