// Canva 딥링크 드롭다운 (Day 6-1, Issue #13)
// 마케팅 생성 결과물 하단에 부착 — 3 템플릿 선택 + 복사 fallback
import { useState, useRef, useEffect } from 'react'
import { Palette, ChevronDown, Copy, ExternalLink, Check } from 'lucide-react'
import toast from 'react-hot-toast'
import { CANVA_TEMPLATES, openInCanva, copyToClipboard, type CanvaTemplate } from '@/lib/canva'
import { cn } from '@/lib/utils'
import { track } from '@/lib/analytics'

interface CanvaExportProps {
  /** Canva에 프리필할 텍스트 (생성된 마케팅 카피) */
  text: string
  /** 매장명 (Canva 타이틀·검색 힌트) */
  brandName?: string
  /** 버튼 크기 */
  size?: 'sm' | 'md'
}

export default function CanvaExport({ text, brandName, size = 'md' }: CanvaExportProps) {
  const [open, setOpen] = useState(false)
  const [copied, setCopied] = useState(false)
  const ref = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const h = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false)
    }
    if (open) document.addEventListener('mousedown', h)
    return () => document.removeEventListener('mousedown', h)
  }, [open])

  useEffect(() => {
    const h = (e: KeyboardEvent) => { if (e.key === 'Escape') setOpen(false) }
    if (open) document.addEventListener('keydown', h)
    return () => document.removeEventListener('keydown', h)
  }, [open])

  const handleOpen = (template: CanvaTemplate) => {
    if (!text.trim()) {
      toast.error('내보낼 텍스트가 비어있어요')
      return
    }
    openInCanva(template, text, brandName)
    toast.success(`Canva에서 ${template.label} 편집 창을 열었어요`)
    track('marketing_canva_export', { template: template.id, aspect: template.aspectRatio })
    setOpen(false)
  }

  const handleCopy = async () => {
    const ok = await copyToClipboard(text)
    if (ok) {
      toast.success('카피를 클립보드에 복사했어요')
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    } else {
      toast.error('복사 실패 — 브라우저가 지원 안 할 수 있어요')
    }
  }

  const btnSize = size === 'sm' ? 'px-3 py-1.5 text-xs' : 'px-4 py-2 text-sm'

  return (
    <div ref={ref} className="relative inline-block no-print">
      <button
        onClick={() => setOpen((v) => !v)}
        className={cn(
          btnSize,
          'inline-flex items-center gap-1.5 rounded-xl',
          'bg-gradient-to-r from-[#00C4CC] to-[#7D2AE8] text-white font-semibold shadow-sm',
          'hover:opacity-90 transition-opacity',
          'focus:outline-none focus-visible:ring-2 focus-visible:ring-[#7D2AE8] focus-visible:ring-offset-1',
        )}
        aria-haspopup="menu"
        aria-expanded={open}
      >
        <Palette size={size === 'sm' ? 12 : 14} />
        Canva에서 편집
        <ChevronDown size={size === 'sm' ? 12 : 14} className={cn('transition-transform', open && 'rotate-180')} />
      </button>

      {open && (
        <div
          role="menu"
          className={cn(
            'absolute right-0 mt-2 w-64 rounded-xl border border-gray-200 dark:border-gray-700',
            'bg-white dark:bg-gray-800 shadow-xl z-50 overflow-hidden',
            'animate-in fade-in slide-in-from-top-2 duration-150',
          )}
        >
          <div className="px-4 py-2.5 text-[10px] font-bold text-gray-400 uppercase bg-gray-50 dark:bg-gray-900 border-b border-gray-100 dark:border-gray-700">
            템플릿 선택
          </div>
          {CANVA_TEMPLATES.map((t) => (
            <button
              key={t.id}
              role="menuitem"
              onClick={() => handleOpen(t)}
              className="w-full flex items-center gap-3 px-4 py-2.5 text-left hover:bg-[#FAFAF8] dark:hover:bg-gray-700 transition-colors focus:outline-none focus-visible:bg-[#FAFAF8] dark:focus-visible:bg-gray-700"
            >
              <span className="text-xl">{t.emoji}</span>
              <div className="flex-1">
                <div className="text-sm font-semibold text-[#2C1810] dark:text-gray-100">
                  {t.label}
                </div>
                <div className="text-[10px] text-gray-500 dark:text-gray-400">
                  {t.aspectRatio} · {t.dimensions}
                </div>
              </div>
              <ExternalLink size={12} className="text-gray-400" />
            </button>
          ))}

          {/* Fallback: 복사 */}
          <div className="border-t border-gray-100 dark:border-gray-700">
            <button
              role="menuitem"
              onClick={handleCopy}
              className="w-full flex items-center gap-3 px-4 py-2.5 text-left hover:bg-[#FAFAF8] dark:hover:bg-gray-700 transition-colors"
            >
              <span className="text-[#D4A574]">
                {copied ? <Check size={14} /> : <Copy size={14} />}
              </span>
              <div className="flex-1">
                <div className="text-sm font-semibold text-[#2C1810] dark:text-gray-100">
                  {copied ? '복사 완료!' : '텍스트만 복사'}
                </div>
                <div className="text-[10px] text-gray-500 dark:text-gray-400">
                  다른 도구에 붙여넣기
                </div>
              </div>
            </button>
          </div>
        </div>
      )}
    </div>
  )
}
