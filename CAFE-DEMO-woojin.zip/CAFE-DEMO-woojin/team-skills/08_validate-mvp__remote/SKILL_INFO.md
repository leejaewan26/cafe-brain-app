# validate-mvp (원격 스킬 — 파일 없음)

이 스킬은 **Anthropic 원격 스킬**로, 로컬 파일이 아닌 클라우드에서 로드됩니다.  
직접 복사가 불가능하므로 아래 방법으로 설치하세요.

---

## 설치 방법

Claude Code 터미널에서:

```
/install-skill anthropic-skills:validate-mvp
```

또는 Claude Code 대화 중:
```
validate-mvp 스킬 설치해줘
```

---

## 무엇을 하는 스킬인가

**MVP / 사업 아이디어를 가상 페르소나 수백 명으로 시장 검증**하는 스킬.

### 핵심 기능
- 전문가 그룹 (UX, 백엔드, 데이터, 보안 등) 각자의 관점에서 코드 리뷰
- 실제 타깃 사용자 페르소나 3인 시뮬레이션 (별점 + 구체적 피드백)
- 라운드별 검증 → 피드백 반영 → 재검증 반복 사이클
- 최종 런칭 판정: 🔴 중단 / 🔧 수정 후 런칭 / ⚡ 조건부 런칭 / ✅ 즉시 런칭

### 발동 조건
- "이거 될까?", "MVP 검수해줘", "페르소나 반응 봐줘"
- "시장성 있어?", "어느정도 완성됐는지 확인해줘"
- 서비스 개발 후 런칭 전 최종 검수

### Cafe Brain 프로젝트에서 활용 예시
> validate-mvp 3라운드 진행 결과:
> - R1: ⭐⭐⭐ (iOS 버그, 다운로드 없음, 피드백 없음 등 다수 이슈)
> - R2: ⭐⭐⭐⭐ (주요 기능 수정 후)
> - R3: ⭐⭐⭐⭐½ → **⚡ 조건부 런칭 가능** 판정

---

## 관련 원격 스킬 (같이 설치 권장)

| 스킬 | 설치 명령 | 용도 |
|------|---------|------|
| `anthropic-skills:startup-pitch` | `/install-skill anthropic-skills:startup-pitch` | 사업계획서 · IR 자료 |
| `anthropic-skills:skill-creator` | `/install-skill anthropic-skills:skill-creator` | 새 스킬 직접 만들기 |
| `anthropic-skills:pdf` | `/install-skill anthropic-skills:pdf` | PDF 생성/편집 |
| `anthropic-skills:xlsx` | `/install-skill anthropic-skills:xlsx` | 엑셀 처리 |
| `anthropic-skills:pptx` | `/install-skill anthropic-skills:pptx` | PPT 생성 |
