// 트렌드 분석 페이지 (Phase 4)
// - 7개 데이터 소스 동시 수집 + Gemini 전략 보고서
// - 활성 소스 표시 + 보고서 마크다운 렌더 + raw 데이터 카드
import { useEffect, useState, useCallback, useMemo } from 'react'
import { Link } from 'react-router-dom'
import {
  ChevronLeft, TrendingUp, Sparkles, Loader2, AlertCircle,
  CheckCircle2, XCircle, ExternalLink, RefreshCw, Globe2, Newspaper,
  Youtube, Search, Brain, BarChart3,
} from 'lucide-react'
import { useAuthStore } from '@/store/authStore'
import { useStoreContext } from '@/hooks/useStoreContext'
import { useMenuStore } from '@/store/menuStore'
import { cn } from '@/lib/utils'

// ─── 타입 ───
interface SourceStatus {
  name: string
  active: boolean
  note: string
}

interface ReportResponse {
  report: string
  active_sources: string[]
  raw: {
    collected_at: string
    naver_datalab?: { momentum?: Array<{ keyword: string; current_avg: number; prev_avg: number; change_pct: number; trend: string }> } | null
    naver_news?: Array<{ title: string; description: string; link: string; pub_date: string }> | null
    google_trends?: { comparison?: Array<{ keyword: string; global_score: number; korea_score: number; gap: number; label: string }> } | null
    youtube?: Array<{ title: string; channel: string; view_count: number; url: string }> | null
    newsapi?: Array<{ title: string; source: string; url: string; published_at: string }> | null
    google_news?: Array<{ title: string; link: string; source: string; pub_date: string }> | null
    gemini_grounding?: { text: string; sources: Array<{ uri: string; title: string }> } | null
  }
  collected_at: string
}

const SOURCE_META: Record<string, { label: string; icon: React.ElementType; color: string }> = {
  naver_datalab:    { label: 'Naver DataLab',    icon: Search,    color: '#03C75A' },
  naver_news:       { label: 'Naver 뉴스',        icon: Newspaper, color: '#03C75A' },
  google_trends:    { label: 'Google Trends',    icon: Globe2,    color: '#4285F4' },
  youtube:          { label: 'YouTube',          icon: Youtube,   color: '#FF0000' },
  newsapi:          { label: 'NewsAPI.org',      icon: Newspaper, color: '#7C3AED' },
  google_news_rss:  { label: 'Google News',      icon: Newspaper, color: '#4285F4' },
  gemini_grounding: { label: 'Gemini + Search',  icon: Brain,     color: '#D4A574' },
}

// ─── 마크다운 (가벼운 렌더러 — 의존성 X) ───
function MarkdownLite({ text }: { text: string }) {
  const lines = text.split('\n')
  const elements: React.ReactNode[] = []
  let listBuffer: string[] = []

  const flushList = () => {
    if (listBuffer.length === 0) return
    elements.push(
      <ul key={`ul-${elements.length}`} className="list-disc pl-5 space-y-1 my-2 text-sm text-[#3D3D3A]">
        {listBuffer.map((it, i) => <li key={i}>{renderInline(it)}</li>)}
      </ul>
    )
    listBuffer = []
  }

  const renderInline = (s: string): React.ReactNode => {
    // **bold** 와 *italic* 처리 (간단 정규식)
    const parts: React.ReactNode[] = []
    const re = /(\*\*[^*]+\*\*|\*[^*]+\*|_[^_]+_)/g
    let lastIdx = 0
    let m: RegExpExecArray | null
    let key = 0
    while ((m = re.exec(s)) !== null) {
      if (m.index > lastIdx) parts.push(s.slice(lastIdx, m.index))
      const tok = m[0]
      if (tok.startsWith('**')) parts.push(<strong key={key++} className="font-semibold text-[#2C1810]">{tok.slice(2, -2)}</strong>)
      else if (tok.startsWith('*') || tok.startsWith('_')) parts.push(<em key={key++} className="italic">{tok.slice(1, -1)}</em>)
      lastIdx = m.index + tok.length
    }
    if (lastIdx < s.length) parts.push(s.slice(lastIdx))
    return parts
  }

  for (const line of lines) {
    const trimmed = line.trim()
    if (trimmed.startsWith('## ')) {
      flushList()
      elements.push(
        <h2 key={`h2-${elements.length}`} className="text-base font-bold text-[#2C1810] mt-5 mb-2 flex items-center gap-2">
          <span className="w-1 h-4 bg-[#D4A574] rounded-full" />
          {trimmed.slice(3)}
        </h2>
      )
    } else if (trimmed.startsWith('# ')) {
      flushList()
      elements.push(
        <h1 key={`h1-${elements.length}`} className="text-lg font-bold text-[#2C1810] mt-6 mb-3">
          {trimmed.slice(2)}
        </h1>
      )
    } else if (trimmed.startsWith('- ') || trimmed.startsWith('* ')) {
      listBuffer.push(trimmed.slice(2))
    } else if (trimmed.startsWith('|')) {
      // 표 (간단 처리: 그대로 pre)
      flushList()
      elements.push(
        <pre key={`tbl-${elements.length}`} className="bg-[#FAFAF8] rounded-lg p-2 text-[11px] font-mono text-[#3D3D3A] overflow-x-auto my-2 whitespace-pre">
          {trimmed}
        </pre>
      )
    } else if (trimmed === '') {
      flushList()
    } else {
      flushList()
      elements.push(
        <p key={`p-${elements.length}`} className="text-sm text-[#3D3D3A] leading-relaxed my-1">
          {renderInline(trimmed)}
        </p>
      )
    }
  }
  flushList()
  return <div>{elements}</div>
}

// ─── 메인 페이지 ───
export default function TrendsPage() {
  const user = useAuthStore((s) => s.user)
  const { storeInfo } = useStoreContext()
  const { menus } = useMenuStore()

  const [sources, setSources] = useState<SourceStatus[]>([])
  const [report, setReport] = useState<ReportResponse | null>(null)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  // 소스 상태 조회
  const fetchSources = useCallback(async () => {
    try {
      const r = await fetch('/api/v1/trends/sources')
      if (!r.ok) return
      const d = await r.json()
      setSources(d.sources || [])
    } catch {/* 조용히 */}
  }, [])

  useEffect(() => { void fetchSources() }, [fetchSources])

  // 매장 컨텍스트 → 키워드 시드
  const seedKeywords = useMemo(() => {
    const fromMenus = menus.slice(0, 3).map((m) => m.name).filter(Boolean)
    const baseKr = ['카페 신메뉴', '디저트 트렌드', '스페셜티 커피']
    return [...fromMenus, ...baseKr].slice(0, 5)
  }, [menus])

  const handleGenerate = useCallback(async () => {
    if (!user) {
      setError('로그인이 필요합니다.')
      return
    }
    setLoading(true)
    setError(null)
    setReport(null)

    try {
      const r = await fetch('/api/v1/trends/report', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-Store-Id': user.id,
        },
        body: JSON.stringify({
          store_id: user.id,
          store_name: storeInfo?.store_name ?? '내 카페',
          district_type: storeInfo?.district_type ?? '복합',
          ambiance_keywords: storeInfo?.ambiance_keywords ?? [],
          top_menus: menus.slice(0, 5).map((m) => m.name),
          custom_keywords_kr: seedKeywords,
        }),
      })
      if (!r.ok) {
        const data = await r.json().catch(() => null)
        throw new Error(data?.detail ?? `요청 실패 (${r.status})`)
      }
      const data: ReportResponse = await r.json()
      setReport(data)

      // Phase 5/F: 트렌드 → 메모리 자동 저장 (매장 매치 키워드)
      // 사용자 학습 신호로 활용 — 다음 브리핑에서 "지난주 호지차 봤었죠" 가능
      try {
        const matchKeywords: string[] = []
        // Naver DataLab 모멘텀 상승 키워드
        const momentum = data.raw.naver_datalab?.momentum ?? []
        momentum.filter((m) => m.change_pct >= 20).slice(0, 3).forEach((m) => {
          matchKeywords.push(`${m.keyword} (검색량 +${m.change_pct.toFixed(0)}%)`)
        })
        // Google Trends 선점기회
        const comparison = data.raw.google_trends?.comparison ?? []
        comparison.filter((c) => c.label === '선점기회').slice(0, 2).forEach((c) => {
          matchKeywords.push(`${c.keyword} (해외 ${c.global_score} / 한국 ${c.korea_score} — 선점기회)`)
        })

        if (matchKeywords.length > 0 && user) {
          await fetch('/api/v1/agent/memory', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', 'X-Store-Id': user.id },
            body: JSON.stringify({
              store_id: user.id,
              category: 'event',
              content: `${data.collected_at} 트렌드 분석: ${matchKeywords.join(' / ')}`,
              importance: 6,
              confidence: 0.75,
              source_type: 'trend_report',
            }),
          }).catch(() => {/* 메모리 저장 실패는 조용히 */})
        }
      } catch {/* 트렌드 → 메모리 실패 무시 */}
    } catch (e) {
      setError(e instanceof Error ? e.message : String(e))
    } finally {
      setLoading(false)
    }
  }, [user, storeInfo, menus, seedKeywords])

  return (
    <div className="min-h-screen bg-[#FAFAF8]">
      {/* 헤더 */}
      <header className="bg-[#2C1810] text-white px-4 py-3 flex items-center gap-3 sticky top-0 z-20">
        <Link to="/dashboard" className="hover:text-[#D4A574] transition-colors duration-200">
          <ChevronLeft size={20} />
        </Link>
        <TrendingUp size={18} className="text-[#D4A574]" />
        <h1 className="font-bold text-base flex-1">시장 트렌드 분석</h1>
        <span className="text-[10px] text-[#D4A574]">7-Source AI</span>
      </header>

      <main className="max-w-3xl mx-auto px-4 py-5 space-y-5">

        {/* ─── 데이터 소스 상태 ─── */}
        <section className="bg-white rounded-2xl p-4 border border-gray-100 shadow-sm">
          <div className="flex items-center justify-between mb-3">
            <div>
              <h2 className="font-bold text-[#2C1810] text-sm flex items-center gap-2">
                <BarChart3 size={14} className="text-[#D4A574]" />
                데이터 소스 ({sources.filter((s) => s.active).length}/{sources.length} 활성)
              </h2>
              <p className="text-xs text-gray-400 mt-0.5">키 미설정 소스는 자동 비활성</p>
            </div>
            <button
              onClick={fetchSources}
              className="p-1.5 text-gray-400 hover:text-[#2C1810] transition-colors"
              title="소스 상태 새로고침"
            >
              <RefreshCw size={13} />
            </button>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
            {sources.map((s) => {
              const meta = SOURCE_META[s.name] || { label: s.name, icon: Globe2, color: '#999' }
              const Icon = meta.icon
              return (
                <div
                  key={s.name}
                  title={s.note}
                  className={cn(
                    'flex items-center gap-1.5 px-2 py-1.5 rounded-lg text-[11px] font-medium border',
                    s.active
                      ? 'bg-green-50 border-green-100 text-green-700'
                      : 'bg-gray-50 border-gray-100 text-gray-400',
                  )}
                >
                  <Icon size={12} style={{ color: s.active ? meta.color : '#aaa' }} />
                  <span className="flex-1 truncate">{meta.label}</span>
                  {s.active
                    ? <CheckCircle2 size={11} className="text-green-500 shrink-0" />
                    : <XCircle size={11} className="text-gray-300 shrink-0" />
                  }
                </div>
              )
            })}
          </div>
        </section>

        {/* ─── 분석 트리거 ─── */}
        <section className="bg-gradient-to-br from-[#2C1810] to-[#3d2418] text-white rounded-2xl p-5 shadow-sm">
          <h2 className="font-bold text-base flex items-center gap-2 mb-1.5">
            <Sparkles size={15} className="text-[#D4A574]" />
            AI 전략 분석 보고서
          </h2>
          <p className="text-xs text-white/70 leading-relaxed mb-4">
            7개 데이터 소스를 동시 수집해 Gemini가 매장 컨텍스트와 매치하여 전략 보고서를 작성합니다.
            동일 매장·동일 일자 조합은 24시간 캐싱.
          </p>
          <button
            onClick={handleGenerate}
            disabled={loading}
            className="w-full py-3 bg-[#D4A574] text-[#2C1810] rounded-xl font-bold text-sm hover:opacity-90 transition-opacity disabled:opacity-50 flex items-center justify-center gap-2"
          >
            {loading
              ? <><Loader2 size={15} className="animate-spin" /> 7개 소스 수집 + Gemini 종합 중...</>
              : <><Sparkles size={15} /> {report ? '다시 생성' : '지금 분석 받기'}</>
            }
          </button>
        </section>

        {/* ─── 에러 ─── */}
        {error && (
          <div className="bg-red-50 border border-red-100 rounded-2xl p-4 text-sm text-red-700 flex items-start gap-2">
            <AlertCircle size={15} className="mt-0.5 shrink-0" />
            <div className="flex-1">
              <p className="font-semibold mb-1">분석 실패</p>
              <p className="text-xs leading-relaxed">{error}</p>
            </div>
            <button onClick={handleGenerate} className="text-xs text-red-600 underline shrink-0">재시도</button>
          </div>
        )}

        {/* ─── 보고서 ─── */}
        {report && (
          <>
            <section className="bg-white rounded-2xl p-5 border border-gray-100 shadow-sm">
              <div className="flex items-center justify-between mb-3 pb-3 border-b border-gray-100">
                <h2 className="font-bold text-[#2C1810] text-sm flex items-center gap-2">
                  <Sparkles size={14} className="text-[#D4A574]" />
                  전략 분석 보고서
                </h2>
                <span className="text-[10px] text-gray-400">수집일: {report.collected_at}</span>
              </div>
              <MarkdownLite text={report.report} />
            </section>

            {/* ─── Raw 데이터 — Naver DataLab 모멘텀 차트 ─── */}
            {report.raw.naver_datalab?.momentum && report.raw.naver_datalab.momentum.length > 0 && (
              <section className="bg-white rounded-2xl p-4 border border-gray-100 shadow-sm">
                <h3 className="font-bold text-[#2C1810] text-sm mb-3 flex items-center gap-2">
                  <Search size={13} className="text-[#03C75A]" />
                  Naver DataLab — 한국 검색량 모멘텀
                </h3>
                <div className="space-y-2">
                  {report.raw.naver_datalab.momentum.map((m, i) => (
                    <div key={i} className="flex items-center gap-3 text-xs">
                      <span className="font-medium text-[#2C1810] w-32 truncate">{m.keyword}</span>
                      <div className="flex-1 bg-gray-100 rounded-full h-1.5 overflow-hidden">
                        <div
                          className={cn(
                            'h-full rounded-full transition-all',
                            m.change_pct > 0 ? 'bg-green-400' : 'bg-red-400',
                          )}
                          style={{ width: `${Math.min(100, Math.abs(m.change_pct))}%` }}
                        />
                      </div>
                      <span className={cn(
                        'text-xs font-bold w-16 text-right',
                        m.change_pct > 0 ? 'text-green-600' : 'text-red-600',
                      )}>
                        {m.change_pct > 0 ? '+' : ''}{m.change_pct.toFixed(1)}%
                      </span>
                    </div>
                  ))}
                </div>
              </section>
            )}

            {/* ─── Google Trends 한국 vs 글로벌 ─── */}
            {report.raw.google_trends?.comparison && report.raw.google_trends.comparison.length > 0 && (
              <section className="bg-white rounded-2xl p-4 border border-gray-100 shadow-sm">
                <h3 className="font-bold text-[#2C1810] text-sm mb-3 flex items-center gap-2">
                  <Globe2 size={13} className="text-[#4285F4]" />
                  Google Trends — 한국 vs 글로벌 비교
                </h3>
                <div className="space-y-2">
                  {report.raw.google_trends.comparison.map((c, i) => (
                    <div key={i} className="border border-gray-100 rounded-lg p-2.5 text-xs">
                      <div className="flex items-center justify-between mb-1.5">
                        <span className="font-semibold text-[#2C1810]">{c.keyword}</span>
                        <span className={cn(
                          'text-[10px] px-2 py-0.5 rounded-full font-medium',
                          c.label === '선점기회' ? 'bg-amber-100 text-amber-700' :
                          c.label === '성장중' ? 'bg-green-100 text-green-700' :
                          c.label === '한국선도' ? 'bg-blue-100 text-blue-700' :
                          c.label === '끝물' ? 'bg-gray-100 text-gray-500' :
                          'bg-gray-50 text-gray-600'
                        )}>
                          {c.label}
                        </span>
                      </div>
                      <div className="grid grid-cols-2 gap-2 text-[11px]">
                        <div>
                          <span className="text-gray-400">글로벌 </span>
                          <span className="font-semibold text-[#2C1810]">{c.global_score}</span>
                        </div>
                        <div>
                          <span className="text-gray-400">한국 </span>
                          <span className="font-semibold text-[#2C1810]">{c.korea_score}</span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </section>
            )}

            {/* ─── YouTube Top 5 ─── */}
            {report.raw.youtube && report.raw.youtube.length > 0 && (
              <section className="bg-white rounded-2xl p-4 border border-gray-100 shadow-sm">
                <h3 className="font-bold text-[#2C1810] text-sm mb-3 flex items-center gap-2">
                  <Youtube size={13} className="text-[#FF0000]" />
                  YouTube — 카페·디저트 인기 영상
                </h3>
                <div className="space-y-2">
                  {report.raw.youtube.slice(0, 5).map((v, i) => (
                    <a
                      key={i}
                      href={v.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="block border border-gray-100 rounded-lg p-2.5 hover:bg-gray-50 transition-colors"
                    >
                      <p className="text-xs font-medium text-[#2C1810] line-clamp-2">{v.title}</p>
                      <div className="flex items-center justify-between mt-1 text-[10px] text-gray-500">
                        <span>{v.channel}</span>
                        <span>조회 {v.view_count.toLocaleString()}</span>
                      </div>
                    </a>
                  ))}
                </div>
              </section>
            )}

            {/* ─── 뉴스 모음 (Naver 뉴스 + NewsAPI) ─── */}
            {((report.raw.naver_news && report.raw.naver_news.length > 0) ||
              (report.raw.newsapi && report.raw.newsapi.length > 0)) && (
              <section className="bg-white rounded-2xl p-4 border border-gray-100 shadow-sm">
                <h3 className="font-bold text-[#2C1810] text-sm mb-3 flex items-center gap-2">
                  <Newspaper size={13} className="text-[#7C3AED]" />
                  미디어 헤드라인
                </h3>
                <div className="space-y-2 text-xs">
                  {(report.raw.naver_news ?? []).slice(0, 5).map((n, i) => (
                    <a key={`kn-${i}`} href={n.link} target="_blank" rel="noopener noreferrer"
                      className="flex items-start gap-2 hover:bg-gray-50 p-2 rounded-lg transition-colors">
                      <span className="text-[10px] bg-[#03C75A]/10 text-[#03C75A] px-1.5 py-0.5 rounded font-medium shrink-0">KR</span>
                      <span className="flex-1 text-[#2C1810] line-clamp-2">{n.title}</span>
                    </a>
                  ))}
                  {(report.raw.newsapi ?? []).slice(0, 5).map((n, i) => (
                    <a key={`en-${i}`} href={n.url} target="_blank" rel="noopener noreferrer"
                      className="flex items-start gap-2 hover:bg-gray-50 p-2 rounded-lg transition-colors">
                      <span className="text-[10px] bg-[#7C3AED]/10 text-[#7C3AED] px-1.5 py-0.5 rounded font-medium shrink-0">EN</span>
                      <span className="flex-1 text-[#2C1810] line-clamp-2">{n.title}</span>
                    </a>
                  ))}
                </div>
              </section>
            )}

            {/* ─── Gemini Grounding 출처 ─── */}
            {report.raw.gemini_grounding?.sources && report.raw.gemini_grounding.sources.length > 0 && (
              <section className="bg-white rounded-2xl p-4 border border-gray-100 shadow-sm">
                <h3 className="font-bold text-[#2C1810] text-sm mb-3 flex items-center gap-2">
                  <Brain size={13} className="text-[#D4A574]" />
                  Gemini 검색 출처
                </h3>
                <div className="space-y-1.5">
                  {report.raw.gemini_grounding.sources.map((s, i) => (
                    <a key={i} href={s.uri} target="_blank" rel="noopener noreferrer"
                      className="flex items-center gap-1.5 text-xs text-[#2C1810] hover:text-[#D4A574] transition-colors">
                      <ExternalLink size={11} className="shrink-0" />
                      <span className="truncate">{s.title || s.uri}</span>
                    </a>
                  ))}
                </div>
              </section>
            )}
          </>
        )}

        {/* ─── 키 미설정 안내 ─── */}
        {sources.length > 0 && sources.filter((s) => s.active).length < sources.length && (
          <div className="bg-amber-50 border border-amber-100 rounded-2xl p-4 text-xs text-amber-800">
            <p className="font-semibold mb-1.5">💡 더 많은 데이터로 정확한 분석을 받으려면</p>
            <p className="leading-relaxed">
              비활성 소스의 API 키를 백엔드 <code className="bg-amber-100 px-1 rounded">.env</code>에 추가하세요.
              키 발급 가이드는 README 또는 사장님 매뉴얼 참조.
            </p>
            <ul className="mt-2 space-y-0.5 list-disc pl-4">
              {sources.filter((s) => !s.active).map((s) => {
                const meta = SOURCE_META[s.name] || { label: s.name }
                return <li key={s.name}><strong>{meta.label}</strong>: {s.note}</li>
              })}
            </ul>
          </div>
        )}

        <div className="pb-6" />
      </main>
    </div>
  )
}
