import csv
import random
from datetime import datetime, timedelta

# 카페 메뉴 및 기본 정보 (메뉴명, 단가, 원가율)
MENUS = {
    '아메리카노': {'price': 4500, 'cost_rate': 0.25},
    '카페라테': {'price': 5000, 'cost_rate': 0.30},
    '바닐라라테': {'price': 5500, 'cost_rate': 0.32},
    '카라멜마키아토': {'price': 5500, 'cost_rate': 0.32},
    '콜드브루': {'price': 5000, 'cost_rate': 0.28},
    '아이스티': {'price': 4000, 'cost_rate': 0.20},
    '유자차': {'price': 4500, 'cost_rate': 0.25},
    '카푸치노': {'price': 5000, 'cost_rate': 0.30},
    '크루아상': {'price': 3500, 'cost_rate': 0.40},
    '케이크': {'price': 6500, 'cost_rate': 0.45},
}

start_date = datetime(2025, 12, 1)
end_date = datetime(2026, 3, 31)

rows = []
rows.append(['날짜', '메뉴명', '수량', '매출', '원가', '할인', '시간대'])

current_date = start_date
while current_date <= end_date:
    is_weekend = current_date.weekday() >= 5
    
    # 주말엔 손님이 1.5배 방문
    daily_customers = random.randint(80, 150) if is_weekend else random.randint(50, 100)
    
    # 시간대 가중치 부여 (점심시간 12~14시, 오후 15~17시 피크)
    hours = list(range(8, 22))
    
    for _ in range(daily_customers):
        # 시간대 결정
        hour = random.choices(hours, weights=[1, 2, 3, 4, 8, 8, 5, 4, 3, 3, 2, 2, 1, 1], k=1)[0]
        
        # 메뉴 결정 (아메리카노 비중이 젤 높음)
        menu = random.choices(
            list(MENUS.keys()),
            weights=[35, 15, 10, 5, 10, 5, 5, 5, 5, 5],
            k=1
        )[0]
        
        # 수량 1~3개
        qty = random.choices([1, 2, 3], weights=[70, 20, 10], k=1)[0]
        
        price = MENUS[menu]['price']
        cost = int(price * MENUS[menu]['cost_rate'])
        
        sales = price * qty
        total_cost = cost * qty
        
        # 10% 확률로 1000원 할인 이벤트
        discount = 1000 if random.random() < 0.1 else 0
        
        rows.append([
            current_date.strftime('%Y-%m-%d'),
            menu,
            qty,
            sales,
            total_cost,
            discount,
            hour
        ])
        
    current_date += timedelta(days=1)

with open('sample_data/large_sales_sample.csv', 'w', encoding='utf-8', newline='') as f:
    writer = csv.writer(f)
    writer.writerows(rows)

print(f"Total rows generated: {len(rows)}")
