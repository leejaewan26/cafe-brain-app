---
name: frontend-design
description: Create distinctive, production-grade frontend interfaces with high design quality. Use this skill when the user asks to build web components, pages, or applications, design a UI, create a dashboard, build a landing page, style a component, or improve the visual design of any frontend. Activates on phrases like "UI 만들어", "컴포넌트 디자인", "페이지 레이아웃", "프론트엔드", "디자인", "build a page", "design component", "UI design", "landing page", "dashboard layout".
version: 1.0.0
---

# Frontend Design Skill

Create distinctive, production-grade frontend interfaces that avoid generic "AI slop" aesthetics. Real working code with exceptional attention to aesthetic detail.

> Source: `claude.com/plugins/frontend-design` (also installed as a plugin)

## When This Skill Applies

Activate when building:
- UI components (buttons, cards, modals, forms, tables)
- Full pages (landing, dashboard, settings, profile)
- Layouts (navigation, sidebar, grid systems)
- Data visualizations and charts
- Any interface requiring visual design decisions

---

## Design Thinking: Do This Before Coding

1. **Purpose**: What problem does this interface solve? Who uses it?
2. **Tone**: Commit to a BOLD aesthetic direction:
   - Brutally minimal
   - Maximalist / information-dense
   - Retro-futuristic / cyberpunk
   - Organic / natural / soft
   - Luxury / refined
   - Playful / toy-like
   - Editorial / magazine-style
   - Brutalist / raw / typographic
   - Industrial / utilitarian
3. **Differentiation**: What makes this UNFORGETTABLE?

**The key is intentionality.** Bold maximalism and refined minimalism both work. Pick one and execute with precision.

---

## Typography

- Choose fonts that are beautiful, unique, and interesting
- **Avoid**: Arial, Inter, Roboto, system-ui (overused/generic)
- **Prefer**: Distinctive display font paired with refined body font
- Examples: Playfair Display + Source Serif, Bebas Neue + DM Sans, Fraunces + Instrument Sans
- Load via Google Fonts or Fontsource

---

## Color & Theme

- Commit to a cohesive palette using CSS variables
- Dominant colors with sharp accents > timid evenly-distributed palettes
- Dark themes: use true blacks (#0a0a0a) or near-black with color tints
- Light themes: off-white backgrounds (not pure white) with warm or cool cast
- Accent colors: one dominant, used sparingly for maximum impact

```css
:root {
  --bg: #0c0c0f;
  --surface: #161619;
  --border: #2a2a30;
  --text: #f0f0f5;
  --text-muted: #888896;
  --accent: #6c63ff;
  --accent-dim: #6c63ff22;
}
```

---

## Motion & Animation

- CSS-only animations for HTML (prefer over JS when possible)
- React: use Motion library (`motion/react`) for complex animations
- High-impact moments: staggered page load reveals, not scattered micro-interactions
- Hover states that surprise: scale, color shift, border reveal, underline draw
- One well-orchestrated entrance > many small effects

```css
@keyframes slideUp {
  from { opacity: 0; transform: translateY(20px); }
  to   { opacity: 1; transform: translateY(0); }
}

.card {
  animation: slideUp 0.4s ease forwards;
}
.card:nth-child(2) { animation-delay: 0.1s; }
.card:nth-child(3) { animation-delay: 0.2s; }
```

---

## Spatial Composition

- Unexpected layouts over predictable ones
- Asymmetry where appropriate
- Generous negative space OR controlled density (not mediocre middle)
- Grid-breaking elements for visual interest
- Diagonal flows, overlapping elements, offset grids

---

## Backgrounds & Visual Atmosphere

Instead of solid colors, add depth:

```css
/* Gradient mesh */
background: radial-gradient(at 20% 80%, #1a0533 0%, transparent 50%),
            radial-gradient(at 80% 20%, #001a3d 0%, transparent 50%),
            #0a0a0f;

/* Noise texture overlay */
.noise::after {
  content: '';
  position: fixed;
  inset: 0;
  background-image: url("data:image/svg+xml,...");  /* SVG noise */
  opacity: 0.03;
  pointer-events: none;
}

/* Subtle grid */
background-image: linear-gradient(rgba(255,255,255,.03) 1px, transparent 1px),
                  linear-gradient(90deg, rgba(255,255,255,.03) 1px, transparent 1px);
background-size: 40px 40px;
```

---

## Component Patterns

### Card
```tsx
<div className="group relative overflow-hidden rounded-2xl border border-white/5 bg-white/[0.02] p-6
  transition-all duration-300 hover:border-white/10 hover:bg-white/[0.04]">
  {/* Gradient accent top */}
  <div className="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-violet-500/50 to-transparent" />
  {children}
</div>
```

### Button Variants
```tsx
// Primary
<button className="rounded-lg bg-violet-600 px-4 py-2 text-sm font-medium text-white
  transition hover:bg-violet-500 active:scale-[0.98]">
  Action
</button>

// Ghost
<button className="rounded-lg border border-white/10 px-4 py-2 text-sm font-medium text-white/70
  transition hover:border-white/20 hover:text-white">
  Cancel
</button>
```

### Input
```tsx
<input className="w-full rounded-lg border border-white/10 bg-white/5 px-4 py-2.5 text-sm
  text-white placeholder:text-white/30
  focus:border-violet-500/50 focus:outline-none focus:ring-1 focus:ring-violet-500/30
  transition" />
```

---

## What to NEVER Do

- Purple gradients on white backgrounds (most overused AI aesthetic)
- Rounded everything with identical border-radius
- Generic card grid layouts with equal spacing
- Shadow-heavy "neumorphic" style
- Pastel colors with no contrast
- Cookie-cutter navbar: logo left, links center, CTA right (add variation)
- Every component looking like a Tailwind UI clone

---

## Framework Quick Reference

```tsx
// React + Tailwind (most common)
// Use cn() / clsx for conditional classes
import { cn } from '@/lib/utils'

// React + CSS Modules
import styles from './Component.module.css'

// Vanilla CSS with custom properties
// Best for one-off pages, demos, and unique aesthetics
```
