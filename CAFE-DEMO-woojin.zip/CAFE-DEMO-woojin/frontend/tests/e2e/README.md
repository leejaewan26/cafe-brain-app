# Playwright E2E 테스트 — Cafe Brain QA

## 🎯 커버리지

5개 핵심 사용자 시나리오 자동화:

| # | 시나리오 | 파일 | 검증 |
|---|---------|------|------|
| 1 | 온보딩 + 대시보드 | `1-onboarding.spec.ts` | 신규 가입 → 매장 정보 → 프로필 → 홈 위젯 |
| 2 | 멀티프로필 권한 | `2-profile-permissions.spec.ts` | 사장 vs 점장 기능 접근 제한 |
| 3 | 매출 분석 플로우 | `3-sales-insight.spec.ts` | CSV 업로드 → 차트 → AI 인사이트 → 피드백 |
| 4 | 리뷰 관리 | `4-review-management.spec.ts` | 리뷰 등록 → AI 답글 → 인사이트 키워드 |
| 5 | 능동 에이전트 학습 | `5-agent-learning.spec.ts` | 브리핑 자동 호출 + 메모리 추출 루프 |

## 🚀 실행 방법

### 최초 1회 Playwright 설치
```bash
cd frontend
npm install
npx playwright install --with-deps chromium
# 또는
npm run test:e2e:install
```

### 테스트 실행
```bash
# 기본 (headless, 병렬)
npm run test:e2e

# 인터랙티브 UI 모드 (디버깅)
npm run test:e2e:ui

# 특정 시나리오만
npx playwright test tests/e2e/3-sales-insight.spec.ts

# 모바일 뷰포트만
npx playwright test --project=mobile-safari
```

### HTML 리포트 보기
```bash
npx playwright show-report
```

## 🎭 목킹 전략

**프로덕션 DB·외부 API 의존성 완전 제거**:
- Supabase REST API → `page.route('**/rest/v1/**')` 가로채기
- Supabase Auth → 토큰만 localStorage 주입
- 백엔드 FastAPI → 모든 `/api/*` 엔드포인트 모킹
- Gemini API → 결정적 더미 응답

**장점**:
- CI에서 API 키·DB 없이 실행 가능
- 실행 속도 < 1분
- 플래키(flaky) 없음

**한계**:
- 실제 RLS·네트워크 오류 시뮬레이션 제한
- Supabase Realtime은 미검증
- → Phase 2에서 Playwright + Supabase CLI 통합으로 확장

## 📁 구조

```
tests/e2e/
├── fixtures/
│   ├── mockData.ts      # 공통 목 데이터 (사용자·매장·리뷰 등)
│   └── apiMock.ts       # Supabase·API 라우팅 헬퍼
├── 1-onboarding.spec.ts
├── 2-profile-permissions.spec.ts
├── 3-sales-insight.spec.ts
├── 4-review-management.spec.ts
├── 5-agent-learning.spec.ts
└── README.md (이 파일)
```

## ✨ CI 통합 (선택)

`.github/workflows/playwright.yml` 추가 예시:

```yaml
name: E2E Tests
on: [push, pull_request]
jobs:
  test:
    runs-on: ubuntu-latest
    defaults:
      run:
        working-directory: ./frontend
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-node@v4
        with:
          node-version: 20
      - run: npm ci
      - run: npx playwright install --with-deps chromium
      - run: npm run test:e2e
      - uses: actions/upload-artifact@v4
        if: failure()
        with:
          name: playwright-report
          path: frontend/playwright-report/
```

## 📊 확장 계획

- [ ] 시나리오 6: 발주 관리 (사장·점장 워크플로우)
- [ ] 시나리오 7: 다크모드 전환 시 모든 페이지 가시성
- [ ] 시나리오 8: 오프라인 (Service Worker 캐시)
- [ ] 접근성 자동화 (axe-playwright)
