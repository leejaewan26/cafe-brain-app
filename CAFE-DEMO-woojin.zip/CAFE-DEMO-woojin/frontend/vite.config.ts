import { defineConfig, type Plugin } from 'vite'
import react from '@vitejs/plugin-react'
import tailwindcss from '@tailwindcss/vite'
import path from 'path'

// N3 — Sentry sourcemap 업로드 (배포 빌드에서만)
// SENTRY_AUTH_TOKEN + SENTRY_ORG + SENTRY_PROJECT 환경변수 있을 때만 활성화
async function maybeSentryPlugin(): Promise<Plugin | null> {
  if (!process.env.SENTRY_AUTH_TOKEN || !process.env.SENTRY_ORG || !process.env.SENTRY_PROJECT) {
    return null
  }
  try {
    const { sentryVitePlugin } = await import('@sentry/vite-plugin')
    return sentryVitePlugin({
      authToken: process.env.SENTRY_AUTH_TOKEN,
      org: process.env.SENTRY_ORG,
      project: process.env.SENTRY_PROJECT,
      sourcemaps: {
        assets: ['./dist/**/*.js', './dist/**/*.js.map'],
        filesToDeleteAfterUpload: ['./dist/**/*.js.map'],  // 업로드 후 public dist에서 삭제
      },
      release: {
        name: process.env.SENTRY_RELEASE,
      },
      telemetry: false,
    })
  } catch {
    console.warn('@sentry/vite-plugin 미설치 — sourcemap 업로드 스킵')
    return null
  }
}

const sentryPlugin = await maybeSentryPlugin()

// Cafe Brain 프론트엔드 Vite 설정
// 4단계: 매뉴얼 청크 분리로 초기 로딩 개선
export default defineConfig({
  plugins: [
    react(),
    tailwindcss(),
    ...(sentryPlugin ? [sentryPlugin] : []),
  ],
  resolve: {
    alias: {
      '@': path.resolve(__dirname, './src'),
    },
  },
  server: {
    port: 5173,
    host: true,  // 0.0.0.0 bind — 같은 Wi-Fi 핸드폰에서 접근 가능
    proxy: {
      '/api': {
        target: 'http://localhost:8000',
        changeOrigin: true,
      },
    },
  },
  build: {
    // I6 — Performance budget
    // 청크당 600KB 경고 (gzip 후 ~200KB), 메인 번들은 300KB 이하 목표
    chunkSizeWarningLimit: 600,
    // 소스맵은 production에서도 활성 (Sentry 디버깅용 — sentry-cli로 업로드)
    sourcemap: true,
    // Terser 최적화
    minify: 'esbuild',
    rollupOptions: {
      output: {
        // ─── 매뉴얼 청크 분리 ───
        manualChunks: (id) => {
          // React + 라우터 코어
          if (id.includes('node_modules/react') || id.includes('node_modules/react-dom')) {
            return 'react-vendor'
          }
          // 차트 라이브러리
          if (id.includes('recharts') || id.includes('d3-')) {
            return 'charts'
          }
          // Zustand 상태 관리
          if (id.includes('zustand')) {
            return 'state'
          }
          // Lucide 아이콘
          if (id.includes('lucide-react')) {
            return 'icons'
          }
          // i18next (H6)
          if (id.includes('i18next') || id.includes('react-i18next')) {
            return 'i18n'
          }
          // Sentry
          if (id.includes('@sentry')) {
            return 'sentry'
          }
          // 기타 node_modules
          if (id.includes('node_modules')) {
            return 'vendor'
          }
        },
      },
    },
  },
})
