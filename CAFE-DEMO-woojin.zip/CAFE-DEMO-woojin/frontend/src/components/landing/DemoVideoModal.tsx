// 랜딩 페이지 "2분 영상 보기" — 풀스크린 모달 시네마틱 데모
// MP4 호스팅 없이 React + CSS 애니메이션으로 재생.
// 6 scene × 120초:
//   00:00-00:08  Hook         "혼자 카페 운영하시나요?"
//   00:08-00:25  Problem      5개 앱 왔다갔다 + 시간 낭비
//   00:25-00:35  Intro        Cafe Brain 로고 reveal
//   00:35-01:35  Features     6개 기능 10초씩 데모
//   01:35-01:50  Trust        보안·프라이버시 배지
//   01:50-02:00  CTA          무료 시작 버튼
//
// 컨트롤: ESC/X 닫기, Space pause, ←/→ 5초 점프, 진행바 클릭 시점 이동
// ESC 또는 다른 키로 멈추면 onClose 호출됨
import { useEffect, useRef, useState } from 'react'
import {
  X, Play, Pause, Coffee, Sparkles, Brain, BarChart2,
  Bell, Database, TrendingUp, Target, Shield, ArrowRight, Check,
  AlertCircle,
} from 'lucide-react'

const TOTAL_SEC = 120

interface SceneConfig {
  start: number  // seconds
  end: number
  render: (progress: number, t: number) => React.ReactNode  // progress 0~1, t = 절대 초
}

interface DemoVideoModalProps {
  open: boolean
  onClose: () => void
}

export default function DemoVideoModal({ open, onClose }: DemoVideoModalProps) {
  const [t, setT] = useState(0)         // 현재 재생 시점 (초)
  const [playing, setPlaying] = useState(true)
  const rafRef = useRef<number | null>(null)
  const startedAtRef = useRef<number>(0)
  const baseTimeRef = useRef<number>(0)  // pause/seek 시 누적된 시점

  // 모달 열림 시 초기화
  useEffect(() => {
    if (!open) return
    setT(0)
    setPlaying(true)
    baseTimeRef.current = 0
    startedAtRef.current = performance.now()
  }, [open])

  // requestAnimationFrame 기반 타이머
  useEffect(() => {
    if (!open || !playing) {
      if (rafRef.current) cancelAnimationFrame(rafRef.current)
      return
    }
    startedAtRef.current = performance.now()
    const tick = () => {
      const elapsed = (performance.now() - startedAtRef.current) / 1000
      const next = baseTimeRef.current + elapsed
      if (next >= TOTAL_SEC) {
        setT(TOTAL_SEC)
        setPlaying(false)
        return
      }
      setT(next)
      rafRef.current = requestAnimationFrame(tick)
    }
    rafRef.current = requestAnimationFrame(tick)
    return () => {
      if (rafRef.current) cancelAnimationFrame(rafRef.current)
    }
  }, [open, playing])

  // 키보드 컨트롤
  useEffect(() => {
    if (!open) return
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose()
      else if (e.key === ' ') {
        e.preventDefault()
        togglePlay()
      } else if (e.key === 'ArrowRight') seek(t + 5)
      else if (e.key === 'ArrowLeft') seek(t - 5)
    }
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open, t])

  const togglePlay = () => {
    if (t >= TOTAL_SEC) {
      // 끝났으면 처음부터
      baseTimeRef.current = 0
      setT(0)
      setPlaying(true)
      return
    }
    if (playing) {
      // pause: 현재까지 시점 저장
      baseTimeRef.current = t
    } else {
      startedAtRef.current = performance.now()
    }
    setPlaying(!playing)
  }

  const seek = (target: number) => {
    const next = Math.max(0, Math.min(TOTAL_SEC, target))
    baseTimeRef.current = next
    startedAtRef.current = performance.now()
    setT(next)
  }

  if (!open) return null

  // 현재 재생 중인 씬
  const scene = SCENES.find((s) => t >= s.start && t < s.end) ?? SCENES[SCENES.length - 1]
  const sceneProgress = scene ? (t - scene.start) / (scene.end - scene.start) : 1

  return (
    <div className="fixed inset-0 z-[60] bg-black flex items-center justify-center">
      {/* 시네마 16:9 박스 */}
      <div className="relative w-full max-w-6xl aspect-video bg-[#0E0B08] rounded-2xl overflow-hidden shadow-2xl">
        {/* 씬 렌더 */}
        <div className="absolute inset-0">
          {scene.render(sceneProgress, t)}
        </div>

        {/* 상단 진행 바 (씬 마커 포함) */}
        <div className="absolute top-0 left-0 right-0 h-1 bg-white/10 group">
          <div
            className="h-full bg-gradient-to-r from-[#D4A574] to-[#E0B584] transition-[width] duration-100 ease-linear"
            style={{ width: `${(t / TOTAL_SEC) * 100}%` }}
          />
          {/* 클릭으로 시점 이동 */}
          <button
            className="absolute inset-0 cursor-pointer"
            aria-label="시점 이동"
            onClick={(e) => {
              const rect = e.currentTarget.getBoundingClientRect()
              const ratio = (e.clientX - rect.left) / rect.width
              seek(ratio * TOTAL_SEC)
            }}
          />
          {/* 씬 마커 */}
          {SCENES.map((s) => (
            <div
              key={s.start}
              className="absolute top-0 w-px h-full bg-white/30"
              style={{ left: `${(s.start / TOTAL_SEC) * 100}%` }}
            />
          ))}
        </div>

        {/* 닫기 버튼 */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 w-10 h-10 rounded-full bg-black/40 hover:bg-black/70 backdrop-blur text-white flex items-center justify-center transition-colors z-10"
          aria-label="닫기"
        >
          <X size={18} />
        </button>

        {/* 하단 컨트롤 바 */}
        <div className="absolute bottom-0 left-0 right-0 p-4 bg-gradient-to-t from-black/80 to-transparent flex items-center gap-3 z-10">
          <button
            onClick={togglePlay}
            className="w-10 h-10 rounded-full bg-white/15 hover:bg-white/25 backdrop-blur text-white flex items-center justify-center transition-colors"
            aria-label={playing ? '일시 정지' : '재생'}
          >
            {playing ? <Pause size={16} /> : <Play size={16} className="ml-0.5" />}
          </button>
          <span className="text-white text-xs font-mono tabular-nums">
            {formatTime(t)} / {formatTime(TOTAL_SEC)}
          </span>
          <span className="text-white/60 text-xs ml-2 hidden sm:block">
            {scene && `· ${SCENE_LABELS[SCENES.indexOf(scene)] ?? ''}`}
          </span>
          <div className="ml-auto text-white/40 text-[11px] hidden md:block">
            Space 재생/정지 · ← → 5초 이동 · ESC 닫기
          </div>
        </div>
      </div>
    </div>
  )
}

function formatTime(s: number): string {
  const mm = Math.floor(s / 60).toString().padStart(2, '0')
  const ss = Math.floor(s % 60).toString().padStart(2, '0')
  return `${mm}:${ss}`
}

// ════════════════════════════════════════════════════════════════════
// 씬 정의 (각 씬 당 ~10-60초)
// ════════════════════════════════════════════════════════════════════

const SCENE_LABELS = [
  '도입',
  '문제 인식',
  '솔루션 등장',
  '핵심 기능',
  '신뢰',
  '시작하기',
]

// 진행에 따라 fade in/out하는 헬퍼 (progress 0~1 기준)
function fadeIn(progress: number, durationRatio = 0.15): number {
  return Math.min(1, progress / durationRatio)
}
function fadeOut(progress: number, durationRatio = 0.15): number {
  if (progress < 1 - durationRatio) return 1
  return Math.max(0, (1 - progress) / durationRatio)
}
function fadeInOut(progress: number, inDur = 0.15, outDur = 0.15): number {
  return Math.min(fadeIn(progress, inDur), fadeOut(progress, outDur))
}

// ─── Scene 1: Hook (0~8초) ───
function Scene1Hook({ progress }: { progress: number }) {
  const opacity = fadeInOut(progress, 0.1, 0.1)
  const subOpacity = fadeInOut(Math.max(0, progress - 0.3) / 0.7, 0.2, 0.15)

  return (
    <div className="absolute inset-0 bg-gradient-to-br from-[#2C1810] via-[#1A0E08] to-black flex flex-col items-center justify-center text-center px-8">
      {/* 김 모락모락 (CSS 애니메이션) */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 pointer-events-none opacity-30">
        <Coffee size={120} className="text-[#D4A574] animate-pulse" />
      </div>

      <h2
        className="relative text-4xl md:text-6xl font-bold text-white leading-tight mb-6"
        style={{ opacity, fontFamily: "'Copernicus', 'Charter', serif" }}
      >
        혼자 카페를<br />
        <span className="text-[#D4A574]">운영하고 계신가요?</span>
      </h2>
      <p
        className="text-lg md:text-2xl text-white/60 max-w-2xl"
        style={{ opacity: subOpacity }}
      >
        매출, 리뷰, 스케줄, 메뉴, 발주…<br />
        하루 종일 다섯 개의 앱을 왔다갔다.
      </p>
    </div>
  )
}

// ─── Scene 2: Problem (8~25초) ───
function Scene2Problem({ progress }: { progress: number }) {
  // 5개 앱 아이콘이 흩어져서 떠다니는 모습
  const apps = [
    { name: 'POS 매출', icon: BarChart2, color: '#5A9E6F', delay: 0 },
    { name: '리뷰 답글', icon: Sparkles, color: '#E07A5F', delay: 0.1 },
    { name: '직원 스케줄', icon: Coffee, color: '#4A90A4', delay: 0.2 },
    { name: '메뉴 관리', icon: Database, color: '#7B6CB0', delay: 0.3 },
    { name: '발주 시트', icon: AlertCircle, color: '#D4A574', delay: 0.4 },
  ]
  const counterValue = Math.min(4, progress * 6) // 0~4시간 카운트업
  const subOpacity = fadeIn(Math.max(0, progress - 0.6) / 0.4, 0.2)

  return (
    <div className="absolute inset-0 bg-[#FAFAF8] flex flex-col items-center justify-center text-center px-8 overflow-hidden">
      {/* 5개 앱 (둥글게 배치, 살짝 떠 있음) */}
      <div className="relative w-full max-w-3xl h-72 mb-8">
        {apps.map((a, i) => {
          const angle = (i / apps.length) * Math.PI * 2 - Math.PI / 2
          const radius = 180
          const x = Math.cos(angle) * radius
          const y = Math.sin(angle) * radius * 0.5
          const itemOpacity = fadeIn(Math.max(0, progress - a.delay) / (1 - a.delay), 0.15)
          const float = Math.sin(progress * Math.PI * 4 + i) * 8
          const Icon = a.icon
          return (
            <div
              key={a.name}
              className="absolute top-1/2 left-1/2 transform"
              style={{
                transform: `translate(calc(-50% + ${x}px), calc(-50% + ${y + float}px))`,
                opacity: itemOpacity,
              }}
            >
              <div
                className="w-20 h-20 rounded-2xl flex items-center justify-center shadow-lg mb-2"
                style={{ backgroundColor: a.color + '22', border: `2px solid ${a.color}55` }}
              >
                <Icon size={28} style={{ color: a.color }} />
              </div>
              <p className="text-xs font-semibold text-[#2C1810] text-center">{a.name}</p>
            </div>
          )
        })}
        {/* 가운데 사장님 */}
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2">
          <div className="text-5xl">😵‍💫</div>
        </div>
      </div>

      <p className="text-lg text-[#87867F] mb-3" style={{ opacity: fadeIn(progress, 0.1) }}>
        하루 평균 낭비되는 시간
      </p>
      <p className="text-6xl md:text-7xl font-bold text-[#2C1810] tabular-nums">
        {counterValue.toFixed(1)}
        <span className="text-3xl ml-2 text-[#87867F] font-normal">시간</span>
      </p>
      <p
        className="text-base text-[#87867F] mt-4 max-w-md"
        style={{ opacity: subOpacity }}
      >
        분명 데이터는 쌓이는데, 뭘 봐야 할지 알 수 없어요.
      </p>
    </div>
  )
}

// ─── Scene 3: Intro (25~35초) ───
function Scene3Intro({ progress }: { progress: number }) {
  const ringOpacity = fadeInOut(progress, 0.1, 0.1)
  const logoScale = 0.8 + 0.2 * Math.min(1, progress * 2.5)
  const titleOpacity = fadeIn(Math.max(0, progress - 0.4) / 0.6, 0.2)

  return (
    <div className="absolute inset-0 bg-gradient-to-br from-[#2C1810] to-black flex flex-col items-center justify-center text-center px-8 overflow-hidden">
      {/* 회전하는 후광 */}
      <div
        className="absolute inset-0 flex items-center justify-center"
        style={{ opacity: ringOpacity * 0.3 }}
      >
        <div
          className="w-[600px] h-[600px] rounded-full border-2 border-[#D4A574] animate-spin"
          style={{ animationDuration: '8s' }}
        />
        <div
          className="absolute w-[400px] h-[400px] rounded-full border border-[#D4A574]/50 animate-spin"
          style={{ animationDuration: '12s', animationDirection: 'reverse' }}
        />
      </div>

      <div
        className="relative w-32 h-32 rounded-3xl bg-gradient-to-br from-[#D4A574] to-[#2C1810] flex items-center justify-center shadow-2xl mb-6"
        style={{ transform: `scale(${logoScale})` }}
      >
        <Coffee size={56} className="text-white" />
      </div>

      <div style={{ opacity: titleOpacity }}>
        <h2
          className="text-5xl md:text-7xl font-bold text-white mb-3"
          style={{ fontFamily: "'Copernicus', 'Charter', serif" }}
        >
          카페 <span className="text-[#D4A574]">브레인</span>
        </h2>
        <p className="text-lg md:text-xl text-white/70 max-w-xl">
          그 모든 걸 하나로. 사장님만을 위한 AI 비서.
        </p>
      </div>
    </div>
  )
}

// ─── Scene 4: Features (35~95초) — 6 sub-scenes × 10초 ───
const FEATURE_SUBSCENES: Array<{
  start: number  // scene 내 절대 초 (35~95)
  duration: number
  title: string
  subtitle: string
  render: (progress: number) => React.ReactNode
}> = [
  // 4a — 매출 분석 (35~45)
  {
    start: 35, duration: 10,
    title: '매출 분석',
    subtitle: 'AI가 4사분면으로 자동 정리',
    render: (p) => <FeatureSales progress={p} />,
  },
  // 4b — AI 채팅 (45~55)
  {
    start: 45, duration: 10,
    title: 'AI 채팅',
    subtitle: '"비 오는 금요일은 어떻게 했지?" 전부 기억해요',
    render: (p) => <FeatureChat progress={p} />,
  },
  // 4c — 능동 브리핑 (55~65)
  {
    start: 55, duration: 10,
    title: '능동 브리핑',
    subtitle: '아침에 알아서 먼저 말 거는 AI',
    render: (p) => <FeatureBriefing progress={p} />,
  },
  // 4d — 학습 메모리 (65~75)
  {
    start: 65, duration: 10,
    title: '60일 학습',
    subtitle: '쓸수록 매장에 맞춰지는 개인 비서',
    render: (p) => <FeatureMemory progress={p} />,
  },
  // 4e — 트렌드 (75~85)
  {
    start: 75, duration: 10,
    title: '시장 트렌드',
    subtitle: '7개 소스 실시간 분석 → 한 줄 요약',
    render: (p) => <FeatureTrends progress={p} />,
  },
  // 4f — 이상치 룰 (85~95)
  {
    start: 85, duration: 10,
    title: '이상치 감지',
    subtitle: '사장님이 정의한 룰을 매일 자동 평가',
    render: (p) => <FeatureRules progress={p} />,
  },
]

function Scene4Features({ t }: { t: number }) {
  // t는 절대 시점, FEATURE_SUBSCENES.start로 매칭
  const sub = FEATURE_SUBSCENES.find((s) => t >= s.start && t < s.start + s.duration) ?? FEATURE_SUBSCENES[0]
  const subProgress = (t - sub.start) / sub.duration
  const opacity = fadeInOut(subProgress, 0.1, 0.1)

  return (
    <div className="absolute inset-0 bg-[#FAFAF8] flex flex-col">
      {/* 상단 라벨 */}
      <div className="px-8 pt-12 pb-4 flex flex-col items-center text-center">
        <p className="text-[10px] font-bold uppercase tracking-widest text-[#D4A574] mb-2">
          핵심 기능 {FEATURE_SUBSCENES.indexOf(sub) + 1} / {FEATURE_SUBSCENES.length}
        </p>
        <h3 className="text-3xl md:text-4xl font-bold text-[#2C1810] mb-2">
          {sub.title}
        </h3>
        <p className="text-base text-[#87867F]">{sub.subtitle}</p>
      </div>

      {/* 컨텐츠 영역 */}
      <div className="flex-1 px-8 pb-16 flex items-center justify-center" style={{ opacity }}>
        {sub.render(subProgress)}
      </div>
    </div>
  )
}

function FeatureSales({ progress }: { progress: number }) {
  const quadrants = [
    { label: '⭐️ 스타', count: 12, color: '#22C55E' },
    { label: '🥚 고민', count: 4, color: '#F59E0B' },
    { label: '🐎 일꾼', count: 8, color: '#3B82F6' },
    { label: '🐶 퇴출', count: 3, color: '#EF4444' },
  ]
  return (
    <div className="grid grid-cols-2 gap-4 max-w-2xl w-full">
      {quadrants.map((q, i) => {
        const o = fadeIn(Math.max(0, progress - i * 0.1) / (1 - i * 0.1), 0.2)
        return (
          <div
            key={q.label}
            className="bg-white rounded-2xl p-6 shadow-sm border border-gray-100"
            style={{ opacity: o, borderLeft: `4px solid ${q.color}` }}
          >
            <p className="text-sm text-[#87867F] mb-1">{q.label}</p>
            <p className="text-4xl font-bold text-[#2C1810] tabular-nums">
              {Math.round(q.count * Math.min(1, progress * 1.5))}
              <span className="text-base ml-1 text-[#87867F] font-normal">개 메뉴</span>
            </p>
          </div>
        )
      })}
    </div>
  )
}

function FeatureChat({ progress }: { progress: number }) {
  const userBubble = fadeIn(progress, 0.1)
  const aiBubble = fadeIn(Math.max(0, progress - 0.35) / 0.65, 0.15)
  const aiText = '지난 비 오는 금요일들 평균 매출은 ₩680K로 평일 평균보다 22% 낮았어요. 따뜻한 음료 비중이 +18%p 올랐고, 손님 대기 시간이 길어지는 패턴이 있었습니다.'
  const charsToShow = Math.floor(aiText.length * Math.max(0, (progress - 0.45) / 0.5))
  return (
    <div className="max-w-2xl w-full space-y-3">
      {/* 사용자 메시지 */}
      <div className="flex justify-end" style={{ opacity: userBubble }}>
        <div className="bg-[#2C1810] text-white rounded-2xl rounded-tr-sm px-4 py-3 max-w-md text-sm">
          비 오는 금요일은 평소보다 매출 어땠어?
        </div>
      </div>
      {/* AI 답변 */}
      <div className="flex gap-2" style={{ opacity: aiBubble }}>
        <div className="w-8 h-8 rounded-full bg-gradient-to-br from-[#D4A574] to-[#2C1810] flex items-center justify-center shrink-0 mt-1">
          <Coffee size={14} className="text-white" />
        </div>
        <div className="bg-white border border-gray-100 shadow-sm rounded-2xl rounded-tl-sm px-4 py-3 max-w-md text-sm text-[#2C1810] leading-relaxed">
          {aiText.slice(0, charsToShow)}
          {charsToShow < aiText.length && <span className="inline-block w-1 h-4 bg-[#D4A574] ml-0.5 animate-pulse" />}
          {charsToShow >= aiText.length && (
            <p className="mt-2 text-[10px] text-[#D4A574] font-semibold">
              📎 근거: 📊 최근 3개월 매출 데이터 · 🧠 학습 메모리(비 패턴)
            </p>
          )}
        </div>
      </div>
    </div>
  )
}

function FeatureBriefing({ progress }: { progress: number }) {
  const slideIn = fadeIn(progress, 0.15)
  const titleY = (1 - Math.min(1, progress * 4)) * 20
  return (
    <div
      className="max-w-md w-full bg-white rounded-2xl shadow-2xl border border-gray-100 p-5"
      style={{ opacity: slideIn, transform: `translateY(${titleY}px)` }}
    >
      <div className="flex items-center gap-2 mb-3">
        <div className="w-8 h-8 rounded-full bg-gradient-to-br from-[#D4A574] to-[#2C1810] flex items-center justify-center">
          <Bell size={13} className="text-white" />
        </div>
        <div>
          <p className="font-bold text-[#2C1810] text-sm">아침 브리핑</p>
          <p className="text-xs text-[#87867F]">방금 도착</p>
        </div>
      </div>
      <p className="text-sm text-[#2C1810] leading-relaxed">
        오늘은 <strong className="text-[#D4A574]">월요일</strong>이라 점심 손님이 평소보다 +12% 예상돼요.
        지난주 시그니처 <strong>"라벤더 라떼"</strong>가 주목받았으니 인스타 스토리 한 컷 어떠세요?
      </p>
      <p className="mt-3 text-[10px] text-[#87867F]">
        ⓘ AI가 생성한 콘텐츠 (자체 검증 통과)
      </p>
    </div>
  )
}

function FeatureMemory({ progress }: { progress: number }) {
  const memories = [
    { cat: '운영 패턴', text: '주말 점심 피크 12-14시', color: '#4A90A4' },
    { cat: '고객 인사이트', text: '디카페인 수요 매주 +8%', color: '#D4A574' },
    { cat: '결정 이력', text: '주휴 포함 스케줄 선호', color: '#7B6CB0' },
    { cat: '목표·KPI', text: '월 매출 1,200만원 BEP', color: '#22C55E' },
  ]
  return (
    <div className="max-w-2xl w-full grid grid-cols-2 gap-3">
      {memories.map((m, i) => {
        const o = fadeIn(Math.max(0, progress - i * 0.18) / Math.max(0.01, 1 - i * 0.18), 0.15)
        return (
          <div
            key={i}
            className="bg-white rounded-xl p-4 border border-gray-100 shadow-sm flex items-start gap-3"
            style={{ opacity: o, transform: `translateX(${(1 - o) * -10}px)` }}
          >
            <div
              className="w-8 h-8 rounded-lg flex items-center justify-center shrink-0"
              style={{ backgroundColor: m.color + '22' }}
            >
              <Brain size={13} style={{ color: m.color }} />
            </div>
            <div>
              <p className="text-[10px] font-semibold uppercase tracking-wide" style={{ color: m.color }}>
                {m.cat}
              </p>
              <p className="text-sm text-[#2C1810] mt-0.5">{m.text}</p>
            </div>
          </div>
        )
      })}
    </div>
  )
}

function FeatureTrends({ progress }: { progress: number }) {
  const sources = ['Naver DataLab', 'Naver News', 'Google Trends', 'YouTube', 'NewsAPI', 'Google News', 'Gemini Search']
  return (
    <div className="max-w-3xl w-full">
      <div className="flex flex-wrap gap-2 justify-center mb-6">
        {sources.map((s, i) => {
          const o = fadeIn(Math.max(0, progress - i * 0.05) / Math.max(0.01, 1 - i * 0.05), 0.15)
          return (
            <span
              key={s}
              className="px-3 py-1.5 bg-white rounded-full text-xs font-medium text-[#2C1810] border border-[#D4A574]/40 shadow-sm"
              style={{ opacity: o }}
            >
              {s}
            </span>
          )
        })}
      </div>
      <div
        className="bg-white rounded-2xl p-5 shadow-sm border border-gray-100"
        style={{ opacity: fadeIn(Math.max(0, progress - 0.5) / 0.5, 0.2) }}
      >
        <div className="flex items-center gap-2 mb-2">
          <TrendingUp size={16} className="text-[#22C55E]" />
          <p className="font-bold text-sm text-[#2C1810]">이번 주 카페 트렌드 요약</p>
        </div>
        <p className="text-sm text-[#2C1810] leading-relaxed">
          "라벤더·말차" 관련 검색량 +42% 급증. 인스타 카페 게시물에서
          <strong className="text-[#D4A574]"> 보라색 음료</strong> 빈도 상승.
          지금 시즌 메뉴 후보로 검토해볼 만해요.
        </p>
      </div>
    </div>
  )
}

function FeatureRules({ progress }: { progress: number }) {
  return (
    <div className="max-w-md w-full space-y-3">
      <div
        className="bg-white rounded-xl p-4 border border-gray-100 shadow-sm"
        style={{ opacity: fadeIn(progress, 0.15) }}
      >
        <div className="flex items-center gap-2 mb-1">
          <div className="w-2 h-2 rounded-full bg-green-500" />
          <p className="text-sm font-semibold text-[#2C1810]">주말 매출 급감 알림</p>
        </div>
        <p className="text-[10px] text-[#87867F]">매출액 · 오늘 vs 지난 7일 평균 · 변동률 -30</p>
      </div>
      <div
        className="bg-amber-50 rounded-xl p-4 border-2 border-amber-300 shadow-md flex items-start gap-3"
        style={{
          opacity: fadeIn(Math.max(0, progress - 0.4) / 0.6, 0.15),
          transform: `scale(${0.95 + 0.05 * fadeIn(Math.max(0, progress - 0.4) / 0.6)})`,
        }}
      >
        <AlertCircle size={18} className="text-amber-600 shrink-0 mt-0.5" />
        <div>
          <p className="text-sm font-bold text-amber-900">🚨 룰 트리거</p>
          <p className="text-xs text-amber-800 leading-relaxed mt-1">
            오늘 매출이 평일 평균 대비 <strong>-32%</strong>입니다.
            가능 원인: 비 예보, 인근 행사 종료. 푸시 알림 발송됨.
          </p>
        </div>
      </div>
    </div>
  )
}

// ─── Scene 5: Trust (95~105초) ───
function Scene5Trust({ progress }: { progress: number }) {
  const stats = [
    { num: '14', label: '일 무료 체험', icon: Sparkles, color: '#D4A574' },
    { num: '60', label: '일 학습 컨텍스트', icon: Brain, color: '#7B6CB0' },
    { num: '99.9', label: '% 가용성 목표', icon: Target, color: '#22C55E' },
  ]
  const badges = [
    { label: '신용카드 불필요', icon: Check },
    { label: 'PII 자동 마스킹', icon: Shield },
    { label: 'GDPR·PIPA 준수', icon: Shield },
    { label: '한국 카페 맥락', icon: Coffee },
  ]
  return (
    <div className="absolute inset-0 bg-gradient-to-br from-[#FAFAF8] via-white to-[#F5F4EE] flex flex-col items-center justify-center px-8">
      <h3
        className="text-3xl md:text-4xl font-bold text-[#2C1810] mb-2 text-center"
        style={{ opacity: fadeIn(progress, 0.1) }}
      >
        믿고 맡기실 수 있어요
      </h3>
      <p
        className="text-[#87867F] mb-10"
        style={{ opacity: fadeIn(Math.max(0, progress - 0.1) / 0.9, 0.15) }}
      >
        보안·프라이버시·법무를 모두 신경 썼습니다.
      </p>

      {/* 통계 */}
      <div className="grid grid-cols-3 gap-6 max-w-2xl w-full mb-8">
        {stats.map((s, i) => {
          const o = fadeIn(Math.max(0, progress - 0.2 - i * 0.1) / Math.max(0.01, 0.8 - i * 0.1), 0.2)
          const Icon = s.icon
          return (
            <div key={s.label} className="text-center" style={{ opacity: o }}>
              <Icon size={24} style={{ color: s.color }} className="mx-auto mb-2" />
              <p className="text-4xl md:text-5xl font-bold text-[#2C1810] tabular-nums">{s.num}</p>
              <p className="text-xs text-[#87867F] mt-1">{s.label}</p>
            </div>
          )
        })}
      </div>

      {/* 배지 */}
      <div className="flex flex-wrap justify-center gap-2 max-w-2xl">
        {badges.map((b, i) => {
          const o = fadeIn(Math.max(0, progress - 0.5 - i * 0.07) / Math.max(0.01, 0.5 - i * 0.07), 0.2)
          const Icon = b.icon
          return (
            <span
              key={b.label}
              className="px-3 py-1.5 bg-white rounded-full text-xs font-medium text-[#2C1810] border border-gray-200 shadow-sm flex items-center gap-1.5"
              style={{ opacity: o }}
            >
              <Icon size={11} className="text-[#5A9E6F]" />
              {b.label}
            </span>
          )
        })}
      </div>
    </div>
  )
}

// ─── Scene 6: CTA (105~120초) ───
function Scene6CTA({ progress }: { progress: number }) {
  const titleOp = fadeIn(progress, 0.15)
  const ctaOp = fadeIn(Math.max(0, progress - 0.3) / 0.7, 0.2)
  const pulse = 1 + 0.04 * Math.sin(progress * Math.PI * 6)
  return (
    <div className="absolute inset-0 bg-gradient-to-br from-[#2C1810] to-[#0E0B08] flex flex-col items-center justify-center text-center px-8 overflow-hidden">
      {/* 배경 글로우 */}
      <div
        className="absolute inset-0"
        style={{
          backgroundImage: 'radial-gradient(circle at 50% 50%, rgba(212,165,116,0.18), transparent 60%)',
          opacity: fadeIn(progress, 0.1),
        }}
      />

      <Coffee size={56} className="text-[#D4A574] mb-6" style={{ opacity: titleOp }} />

      <h2
        className="text-4xl md:text-6xl font-bold text-white leading-tight mb-4"
        style={{ opacity: titleOp, fontFamily: "'Copernicus', 'Charter', serif" }}
      >
        오늘부터<br />
        <span className="text-[#D4A574]">사장님 옆에 AI 비서</span>
      </h2>
      <p
        className="text-lg md:text-xl text-white/70 mb-10 max-w-xl"
        style={{ opacity: titleOp }}
      >
        14일 동안 모든 기능을 무료로. 신용카드 필요 없어요.
      </p>

      <div
        className="inline-flex items-center gap-2 px-8 py-4 bg-[#D4A574] text-[#2C1810] rounded-2xl text-lg font-bold shadow-2xl"
        style={{ opacity: ctaOp, transform: `scale(${pulse})` }}
      >
        지금 무료로 시작하기 <ArrowRight size={20} />
      </div>

      <p
        className="text-xs text-white/40 mt-6"
        style={{ opacity: ctaOp }}
      >
        cafe-brain.app · 가입 2분 · 한국 카페 맥락 맞춤
      </p>
    </div>
  )
}

// ════════════════════════════════════════════════════════════════════
// 씬 타임라인
// ════════════════════════════════════════════════════════════════════

const SCENES: SceneConfig[] = [
  { start: 0, end: 8,    render: (p) => <Scene1Hook progress={p} /> },
  { start: 8, end: 25,   render: (p) => <Scene2Problem progress={p} /> },
  { start: 25, end: 35,  render: (p) => <Scene3Intro progress={p} /> },
  { start: 35, end: 95,  render: (_, t) => <Scene4Features t={t} /> },
  { start: 95, end: 105, render: (p) => <Scene5Trust progress={p} /> },
  { start: 105, end: 120, render: (p) => <Scene6CTA progress={p} /> },
]
