// 설정 > 프로필 관리 탭 (사장 전용) — Issue #5 권한 완성
// 사장이 타 프로필의 이름/역할/PIN/권한/활성화를 전권 관리
import { useCallback, useEffect, useState } from 'react'
import {
  Users, Lock, Unlock, Edit3, Trash2, UserPlus,
  ShieldCheck, Shield, Loader2, Check, X, AlertCircle,
} from 'lucide-react'
import toast from 'react-hot-toast'
import { supabase } from '@/lib/supabase'
import { useAuthStore } from '@/store/authStore'
import { useProfileStore, type Profile, type ProfileRole, OWNER_ONLY_FEATURES } from '@/store/profileStore'
import { cn } from '@/lib/utils'

// 세분 권한 라벨 (사장이 점장별로 커스텀)
const PERMISSION_LABELS: Record<string, string> = {
  labor_cost_settings: '인건비 설정 변경',
  juhusu_mode: '주휴수당 모드 선택',
  order_approval: '발주 승인',
  financial_info: '재무 정보 편집',
  profile_management: '프로필 추가·삭제',
  account_delete: '계정 삭제',
}

export default function ProfilesTab() {
  const user = useAuthStore((s) => s.user)
  const activeProfile = useProfileStore((s) => s.activeProfile)
  const [profiles, setProfiles] = useState<Profile[]>([])
  const [loading, setLoading] = useState(true)
  const [editingId, setEditingId] = useState<string | null>(null)

  const isOwner = activeProfile?.role === 'owner'

  const loadProfiles = useCallback(async () => {
    if (!user) return
    setLoading(true)
    const { data, error } = await supabase
      .from('profiles')
      .select('*')
      .eq('store_id', user.id)
      .order('role', { ascending: true })
      .order('created_at')
    if (error) toast.error(error.message)
    else setProfiles((data ?? []) as Profile[])
    setLoading(false)
  }, [user])

  useEffect(() => {
    // eslint-disable-next-line react-hooks/set-state-in-effect
    if (user && isOwner) void loadProfiles()
  }, [user, isOwner, loadProfiles])

  if (!isOwner) {
    return (
      <div className="bg-white rounded-2xl p-8 border border-gray-100 text-center">
        <Shield size={32} className="mx-auto mb-3 text-gray-300" />
        <h3 className="font-bold text-[#2C1810] mb-1">사장 전용 기능</h3>
        <p className="text-sm text-gray-500">프로필 관리는 사장 프로필만 가능합니다</p>
      </div>
    )
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center py-10">
        <Loader2 className="w-6 h-6 animate-spin text-[#D4A574]" />
      </div>
    )
  }

  return (
    <div className="space-y-4">
      <section className="bg-white rounded-2xl p-5 border border-gray-100 shadow-sm">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h3 className="font-bold text-[#2C1810] flex items-center gap-2">
              <Users size={16} className="text-[#D4A574]" />
              프로필 관리 ({profiles.length}/3)
            </h3>
            <p className="text-xs text-gray-400 mt-0.5">
              사장 프로필은 모든 프로필의 이름·PIN·권한·활성화를 관리할 수 있어요
            </p>
          </div>
          {profiles.length < 3 && (
            <button
              onClick={() => {
                // /profile-select 경유로 새 프로필 생성 (기존 UX 재사용)
                window.location.href = '/profile-select?add=1'
              }}
              className="flex items-center gap-1 px-3 py-1.5 bg-[#2C1810] text-white rounded-lg text-xs font-semibold hover:bg-[#3d2418]"
            >
              <UserPlus size={12} /> 추가
            </button>
          )}
        </div>

        <div className="space-y-3">
          {profiles.map((p) => (
            <ProfileRow
              key={p.id}
              profile={p}
              isCurrent={p.id === activeProfile?.id}
              editing={editingId === p.id}
              onEdit={() => setEditingId(p.id)}
              onCancel={() => setEditingId(null)}
              onSaved={async () => {
                setEditingId(null)
                await loadProfiles()
              }}
            />
          ))}
        </div>
      </section>

      <div className="flex items-start gap-2 p-3 bg-blue-50/50 border border-blue-100 rounded-xl text-xs text-blue-700">
        <AlertCircle size={13} className="mt-0.5 shrink-0" />
        <div>
          <p className="font-semibold mb-1">권한 커스터마이징</p>
          <p>점장 기본은 "인건비·재무 X, 발주 요청 O". 필요한 권한은 개별 켜고 끌 수 있어요.</p>
        </div>
      </div>
    </div>
  )
}

// ─── 개별 프로필 행 ───
function ProfileRow({
  profile,
  isCurrent,
  editing,
  onEdit,
  onCancel,
  onSaved,
}: {
  profile: Profile
  isCurrent: boolean
  editing: boolean
  onEdit: () => void
  onCancel: () => void
  onSaved: () => void
}) {
  const [name, setName] = useState(profile.name)
  // role/permissions는 편집 모드 진입 시 고정 (서버 동기화 후 useRef로 관리하면 더 정교하지만 MVP는 일회성)
  const role: ProfileRole = profile.role
  const [active, setActive] = useState(profile.active !== false)
  const [newPin, setNewPin] = useState('')
  const [permissions, setPermissions] = useState<Record<string, boolean>>(
    profile.permissions ?? {}
  )
  const [saving, setSaving] = useState(false)

  const togglePermission = (key: string) => {
    setPermissions((p) => ({ ...p, [key]: !p[key] }))
  }

  const handleSave = async () => {
    if (!name.trim()) { toast.error('이름을 입력하세요'); return }
    setSaving(true)
    try {
      const updates: Record<string, unknown> = {
        name: name.trim(),
        role,
        active,
        permissions,
      }

      // PIN 변경 요청이 있으면 해싱해서 추가
      if (newPin.length >= 4) {
        const pin_hash = await hashPin(newPin, profile.id)
        updates.pin_hash = pin_hash
      } else if (newPin === 'REMOVE') {
        updates.pin_hash = null
      }

      const { error } = await supabase
        .from('profiles')
        .update(updates)
        .eq('id', profile.id)
      if (error) throw error

      toast.success('프로필이 업데이트됐어요')
      onSaved()
    } catch (e) {
      toast.error(e instanceof Error ? e.message : '저장 실패')
    } finally {
      setSaving(false)
    }
  }

  const handleDelete = async () => {
    if (profile.role === 'owner') {
      toast.error('사장 프로필은 삭제할 수 없어요')
      return
    }
    if (!confirm(`"${profile.name}" 프로필을 삭제하시겠어요?`)) return
    const { error } = await supabase.from('profiles').delete().eq('id', profile.id)
    if (error) toast.error(error.message)
    else {
      toast.success('프로필이 삭제됐어요')
      onSaved()
    }
  }

  if (!editing) {
    return (
      <div
        className={cn(
          'flex items-center gap-3 p-3 rounded-xl border transition-colors',
          isCurrent ? 'border-[#D4A574] bg-[#D4A574]/5' : 'border-gray-100 hover:bg-gray-50',
          !active && 'opacity-50'
        )}
      >
        <div
          className="w-10 h-10 rounded-xl flex items-center justify-center text-lg shrink-0"
          style={{ backgroundColor: profile.avatar_color }}
        >
          {profile.avatar_emoji}
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 flex-wrap">
            <p className="font-semibold text-[#2C1810] text-sm">{profile.name}</p>
            <span
              className={cn(
                'text-[10px] font-bold px-2 py-0.5 rounded-full',
                profile.role === 'owner' ? 'bg-amber-100 text-amber-700' : 'bg-blue-100 text-blue-700'
              )}
            >
              {profile.role === 'owner' ? '사장' : '점장·매니저'}
            </span>
            {profile.pin_hash && <Lock size={11} className="text-gray-400" />}
            {!active && <span className="text-[10px] bg-gray-200 text-gray-500 px-1.5 py-0.5 rounded-full">비활성</span>}
            {isCurrent && <span className="text-[10px] bg-green-100 text-green-700 px-1.5 py-0.5 rounded-full font-medium">현재</span>}
          </div>
        </div>
        <button onClick={onEdit} className="p-1.5 text-gray-400 hover:text-[#2C1810] rounded-lg hover:bg-gray-100">
          <Edit3 size={14} />
        </button>
        {profile.role !== 'owner' && !isCurrent && (
          <button onClick={handleDelete} className="p-1.5 text-red-400 hover:bg-red-50 rounded-lg">
            <Trash2 size={14} />
          </button>
        )}
      </div>
    )
  }

  // 편집 모드
  return (
    <div className="p-4 border-2 border-[#D4A574] rounded-xl bg-[#D4A574]/5 space-y-3">
      <div className="flex items-center gap-3">
        <div
          className="w-10 h-10 rounded-xl flex items-center justify-center text-lg shrink-0"
          style={{ backgroundColor: profile.avatar_color }}
        >
          {profile.avatar_emoji}
        </div>
        <input
          value={name}
          onChange={(e) => setName(e.target.value)}
          className="flex-1 px-3 py-1.5 rounded-lg border border-gray-200 text-sm focus:outline-none focus:ring-2 focus:ring-[#D4A574]"
          maxLength={20}
        />
      </div>

      {/* 역할 표시 (변경은 DB trigger 제약상 별도 프로세스) */}
      <div>
        <label className="text-xs font-semibold text-gray-600 block mb-1">역할</label>
        <p className="text-sm text-[#2C1810] dark:text-gray-200">
          {role === 'owner' ? '👨‍💼 사장' : '🧑‍💼 점장·매니저'}
          <span className="text-[10px] text-gray-400 ml-2">역할 변경은 별도 절차 필요</span>
        </p>
      </div>

      {/* 활성화 */}
      <div className="flex items-center justify-between">
        <div>
          <p className="text-xs font-semibold text-gray-700">활성화</p>
          <p className="text-[10px] text-gray-400">비활성 프로필은 로그인 불가</p>
        </div>
        <label className="relative inline-flex items-center cursor-pointer">
          <input type="checkbox" checked={active} onChange={(e) => setActive(e.target.checked)} className="sr-only peer" />
          <div className="w-10 h-5 bg-gray-200 rounded-full peer peer-checked:after:translate-x-5 after:content-[''] after:absolute after:top-0.5 after:left-0.5 after:bg-white after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-[#2C1810]" />
        </label>
      </div>

      {/* PIN 변경 */}
      {profile.role !== 'owner' && (
        <div>
          <label className="text-xs font-semibold text-gray-600 block mb-1">
            PIN {profile.pin_hash ? '변경' : '설정'}
          </label>
          <div className="flex gap-2">
            <input
              type="password"
              inputMode="numeric"
              maxLength={6}
              value={newPin === 'REMOVE' ? '' : newPin}
              onChange={(e) => setNewPin(e.target.value.replace(/\D/g, ''))}
              placeholder={profile.pin_hash ? '새 PIN (비우면 유지)' : 'PIN 4-6자리'}
              className="flex-1 px-3 py-1.5 rounded-lg border border-gray-200 text-sm focus:outline-none focus:ring-2 focus:ring-[#D4A574]"
            />
            {profile.pin_hash && (
              <button
                onClick={() => setNewPin('REMOVE')}
                className="px-2 py-1.5 text-xs text-red-500 border border-red-200 rounded-lg hover:bg-red-50"
                title="PIN 제거"
              >
                <Unlock size={12} />
              </button>
            )}
          </div>
          {newPin === 'REMOVE' && <p className="text-[10px] text-red-500 mt-1">PIN이 제거됩니다</p>}
        </div>
      )}

      {/* 세분 권한 (점장만 의미 있음) */}
      {profile.role === 'manager' && (
        <div>
          <label className="text-xs font-semibold text-gray-600 block mb-1.5 flex items-center gap-1">
            <ShieldCheck size={11} />
            세부 권한 오버라이드
          </label>
          <p className="text-[10px] text-gray-400 mb-2">기본: 사장 전용 기능은 막힘. 여기서 개별 허용 가능</p>
          <div className="space-y-1">
            {OWNER_ONLY_FEATURES.map((key) => (
              <label
                key={key}
                className="flex items-center gap-2 p-2 rounded-lg hover:bg-white cursor-pointer"
              >
                <input
                  type="checkbox"
                  checked={permissions[key] === true}
                  onChange={() => togglePermission(key)}
                  className="accent-[#D4A574]"
                />
                <span className="text-xs text-gray-700">{PERMISSION_LABELS[key] ?? key}</span>
              </label>
            ))}
          </div>
        </div>
      )}

      {/* 버튼 */}
      <div className="flex gap-2 pt-2">
        <button
          onClick={onCancel}
          className="flex-1 py-2 border border-gray-200 rounded-lg text-sm text-gray-600 hover:bg-gray-50"
        >
          <X size={12} className="inline mr-1" /> 취소
        </button>
        <button
          onClick={handleSave}
          disabled={saving}
          className="flex-1 py-2 bg-[#2C1810] text-white rounded-lg text-sm font-semibold hover:bg-[#3d2418] disabled:opacity-50"
        >
          {saving ? <Loader2 size={12} className="inline animate-spin" /> : <><Check size={12} className="inline mr-1" /> 저장</>}
        </button>
      </div>
    </div>
  )
}

// PIN 해시 (per-profile salt + 1000 iterations, ProfileSelectPage와 동일)
async function hashPin(pin: string, profileSalt: string): Promise<string> {
  const encoder = new TextEncoder()
  let current: ArrayBuffer = encoder.encode(`${pin}:${profileSalt}:cafe-brain-v2`).buffer as ArrayBuffer
  for (let i = 0; i < 1000; i++) {
    current = await crypto.subtle.digest('SHA-256', current)
  }
  return Array.from(new Uint8Array(current))
    .map((b) => b.toString(16).padStart(2, '0'))
    .join('')
}
