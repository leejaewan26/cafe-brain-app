// 스마트 스케줄링 Zustand 스토어
import { create } from 'zustand'
import { persist } from 'zustand/middleware'
import type { Employee, Shift } from '@/types/schedule'

// 기본 직원 색상 팔레트
const COLORS = ['#2C1810', '#D4A574', '#6b3d2a', '#22c55e', '#3b82f6', '#f59e0b', '#8b5cf6']

interface ScheduleState {
  employees: Employee[]
  shifts: Shift[]
  laborCostCapRatio: number  // 인건비 상한 비율 (default 0.25)

  // 직원 CRUD
  addEmployee: (emp: Omit<Employee, 'id' | 'color'>) => void
  updateEmployee: (id: string, updates: Partial<Employee>) => void
  deleteEmployee: (id: string) => void

  // 시프트 관리
  setShift: (shift: Shift) => void
  removeShift: (shiftId: string) => void
  setWeekShifts: (shifts: Shift[]) => void
  clearWeekShifts: (weekStart: string) => void

  // 설정
  setLaborCostCapRatio: (ratio: number) => void
}

// 샘플 직원 3명 (풀타임 1, 파트타임 2)
const SAMPLE_EMPLOYEES: Employee[] = [
  {
    id: 'emp-01',
    name: '김매니저',
    employment_type: 'full_time',
    hourly_rate: 12000,
    preferred_start: 9,
    preferred_end: 18,
    max_weekly_hours: 40,
    unavailable_days: [0],   // 일요일 불가
    color: COLORS[0],
  },
  {
    id: 'emp-02',
    name: '박아르바이트',
    employment_type: 'part_time',
    hourly_rate: 10030,       // 2024년 최저시급
    preferred_start: 11,
    preferred_end: 16,
    max_weekly_hours: 25,
    unavailable_days: [3, 4], // 수·목요일 불가
    color: COLORS[1],
  },
  {
    id: 'emp-03',
    name: '이알바',
    employment_type: 'part_time',
    hourly_rate: 10030,
    preferred_start: 9,
    preferred_end: 14,
    max_weekly_hours: 20,
    unavailable_days: [6],    // 토요일 불가
    color: COLORS[2],
  },
]

export const useScheduleStore = create<ScheduleState>()(
  persist(
    (set) => ({
      employees: SAMPLE_EMPLOYEES,
      shifts: [],
      laborCostCapRatio: 0.25,

      addEmployee: (emp) =>
        set((state) => ({
          employees: [
            ...state.employees,
            {
              ...emp,
              id: `emp-${Date.now()}`,
              color: COLORS[state.employees.length % COLORS.length],
            },
          ],
        })),

      updateEmployee: (id, updates) =>
        set((state) => ({
          employees: state.employees.map((e) => (e.id === id ? { ...e, ...updates } : e)),
        })),

      deleteEmployee: (id) =>
        set((state) => ({
          employees: state.employees.filter((e) => e.id !== id),
          shifts: state.shifts.filter((s) => s.employee_id !== id),
        })),

      setShift: (shift) =>
        set((state) => {
          const existing = state.shifts.findIndex(
            (s) => s.employee_id === shift.employee_id &&
                   s.week_start === shift.week_start &&
                   s.day_index === shift.day_index
          )
          if (existing >= 0) {
            const newShifts = [...state.shifts]
            newShifts[existing] = shift
            return { shifts: newShifts }
          }
          return { shifts: [...state.shifts, shift] }
        }),

      removeShift: (shiftId) =>
        set((state) => ({ shifts: state.shifts.filter((s) => s.id !== shiftId) })),

      setWeekShifts: (shifts) =>
        set((state) => {
          if (!shifts.length) return state
          const weekStart = shifts[0].week_start
          const others = state.shifts.filter((s) => s.week_start !== weekStart)
          return { shifts: [...others, ...shifts] }
        }),

      clearWeekShifts: (weekStart) =>
        set((state) => ({ shifts: state.shifts.filter((s) => s.week_start !== weekStart) })),

      setLaborCostCapRatio: (ratio) => set({ laborCostCapRatio: ratio }),
    }),
    { name: 'cafe-brain-schedule' }
  )
)
