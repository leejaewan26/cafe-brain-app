"""
7개 트렌드 데이터 소스 동시 수집기.

asyncio.gather로 병렬 호출 → 가장 느린 소스에 맞춰 응답.
실패한 소스는 None으로 반환 (보고서 생성 시 graceful 표시).
"""
import asyncio
from datetime import date, timedelta
from typing import Any

from app.services.trends import (
    naver_datalab,
    naver_news,
    google_trends,
    youtube,
    newsapi,
    google_news_rss,
    gemini_grounding,
)

# 카페 업계 기본 시드 키워드 (한국어)
DEFAULT_SEED_KEYWORDS_KR = [
    "카페 신메뉴",
    "디저트 트렌드",
    "스페셜티 커피",
    "논커피 음료",
    "비건 디저트",
]

# 영문 시드 (NewsAPI 등 영어권)
DEFAULT_SEED_KEYWORDS_EN = [
    "cafe trends",
    "specialty coffee",
    "viral dessert",
    "korean cafe",
]


async def collect_all_sources(
    custom_keywords_kr: list[str] | None = None,
    custom_keywords_en: list[str] | None = None,
) -> dict[str, Any]:
    """
    7개 데이터 소스 병렬 수집.

    Args:
        custom_keywords_kr: 매장별 한국어 키워드 (없으면 시드 사용)
        custom_keywords_en: 영문 키워드

    Returns:
        {
          "collected_at": ISO,
          "naver_datalab":   {raw, momentum} | None,
          "naver_news":      [items] | None,
          "google_trends":   {korea, global, comparison} | None,
          "youtube":         [videos] | None,
          "newsapi":         [articles] | None,
          "google_news":     [items] | None,
          "gemini_grounding": {text, sources} | None,
          "active_sources": ["naver_datalab", ...],
        }
    """
    kws_kr = (custom_keywords_kr or [])[:5] or DEFAULT_SEED_KEYWORDS_KR
    kws_en = (custom_keywords_en or [])[:5] or DEFAULT_SEED_KEYWORDS_EN

    today = date.today()
    one_month_ago = today - timedelta(days=30)

    grounding_query = (
        "지난 일주일간 한국과 해외 카페·디저트 업계에서 화제된 신메뉴, "
        "신상 음료, 떠오르는 키워드를 5가지씩 정리해줘. "
        f"오늘 날짜 기준 ({today.isoformat()}). 출처도 함께."
    )

    naver_query = " OR ".join(kws_kr[:3])
    youtube_query = "카페 신메뉴 OR 디저트 트렌드"
    newsapi_query = " OR ".join(kws_en[:3])
    google_news_query = " OR ".join(kws_kr[:3])

    results = await asyncio.gather(
        naver_datalab.fetch_search_trends(
            keywords=kws_kr,
            start_date=one_month_ago.isoformat(),
            end_date=today.isoformat(),
            time_unit="date",
        ),
        naver_news.search_news(query=naver_query, display=15),
        google_trends.fetch_compare_korea_vs_global(keywords=kws_kr, timeframe="now 7-d"),
        youtube.search_trending_videos(query=youtube_query, max_results=10, days_back=14),
        newsapi.search_global_news(query=newsapi_query, page_size=10, days_back=7),
        google_news_rss.fetch_google_news(query=google_news_query, max_items=10, lang="ko"),
        gemini_grounding.grounded_research(grounding_query),
        return_exceptions=True,
    )

    # 예외는 None으로 변환
    cleaned = [r if not isinstance(r, BaseException) else None for r in results]

    naver_dl_raw = cleaned[0]
    payload = {
        "collected_at": today.isoformat(),
        "naver_datalab": {
            "raw": naver_dl_raw,
            "momentum": naver_datalab.compute_keyword_momentum(naver_dl_raw or {}),
        } if naver_dl_raw else None,
        "naver_news": cleaned[1],
        "google_trends": cleaned[2],
        "youtube": cleaned[3],
        "newsapi": cleaned[4],
        "google_news": cleaned[5],
        "gemini_grounding": cleaned[6],
    }

    payload["active_sources"] = [
        name for name, value in {
            "naver_datalab": payload["naver_datalab"],
            "naver_news": payload["naver_news"],
            "google_trends": payload["google_trends"],
            "youtube": payload["youtube"],
            "newsapi": payload["newsapi"],
            "google_news": payload["google_news"],
            "gemini_grounding": payload["gemini_grounding"],
        }.items() if value
    ]

    return payload
