// 리뷰 관리 모듈 타입 정의
export type ReviewRating = 1 | 2 | 3 | 4 | 5
export type ReplyStatus = 'pending' | 'generated' | 'edited' | 'copied'

// Feature B: 답글 어조 타입
export type ReplyTone = 'formal' | 'casual' | 'witty'

// Feature A: 키워드 분석 결과
export interface KeywordInsight {
  positive: Array<{ word: string; count: number }>
  negative: Array<{ word: string; count: number }>
  analyzed_at: string
}

// Feature A: 플랫폼 집계 결과
export interface PlatformSummary {
  platform: string
  count: number
  avg_rating: number
  positive_ratio: number
}

// Feature A: 기간별 별점 추이
export interface RatingTrend {
  period: string
  avg_rating: number
  count: number
}

// 개별 리뷰 레코드
export interface Review {
  id: string
  nickname: string        // 고객 닉네임
  content: string         // 원본 리뷰 내용
  rating: ReviewRating    // 별점 (1~5)
  date: string            // 리뷰 작성일 'YYYY-MM-DD'
  platform?: string       // 플랫폼 (네이버, 카카오, 구글 등)
  ai_reply: string        // AI 생성 답글
  reply_status: ReplyStatus  // 답글 상태
  is_selected: boolean    // 일괄 처리 선택 여부
}

// AI 답글 생성 요청
export interface ReplyGenerateRequest {
  review_id: string
  nickname: string
  content: string
  rating: number
  store_name: string
  menu_list: string[]   // 매장 메뉴 목록 컨텍스트
  tone: ReplyTone       // Feature B: 답글 어조
}

// 엑셀 업로드 컬럼 매핑
export interface ReviewColumnMapping {
  nickname: string
  content: string
  rating: string
  date: string
  platform?: string
}
