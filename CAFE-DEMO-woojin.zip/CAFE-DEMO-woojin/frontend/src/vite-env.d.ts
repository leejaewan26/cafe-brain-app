/// <reference types="vite/client" />

// Vite 환경변수 타입 선언 (VITE_ 접두사 필수)
interface ImportMetaEnv {
  readonly VITE_SUPABASE_URL: string
  readonly VITE_SUPABASE_ANON_KEY: string
}

interface ImportMeta {
  readonly env: ImportMetaEnv
}
