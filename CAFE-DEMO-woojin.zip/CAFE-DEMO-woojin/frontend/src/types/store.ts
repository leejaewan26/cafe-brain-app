// 전역 타입 정의 - Supabase stores 테이블 매핑
export interface Store {
  id: string
  store_name: string
  owner_name: string
  district_type: '주택가' | '오피스' | '대학가' | '관광지' | '복합'
  menu_count: number
  employee_count: number
  avg_monthly_sales: number
  ambiance_keywords: string[]
  target_labor_ratio: number
  created_at: string
  // ─── Wave 1 신규 필드 ───
  logo_url?: string | null              // Issue #15: 매장 로고 (Supabase Storage URL)
  monthly_fixed_cost?: number | null    // Issue #1: BEP 계산용 월 고정비
  // ─── Phase 3: 매장 영업시간 (에이전트 게이트와 연동) ───
  open_hour?: number                    // 영업 시작 (0-23, KST). 미설정 시 글로벌 기본값 6
  close_hour?: number                   // 영업 종료 (1-24, KST). 미설정 시 글로벌 기본값 22
}

// 온보딩 단계별 데이터 타입
export interface OnboardingStep1 {
  store_name: string
  owner_name: string
}

export interface OnboardingStep2 {
  district_type: Store['district_type']
}

export interface OnboardingStep3 {
  menu_count: number
  employee_count: number
  avg_monthly_sales: number
}

export interface OnboardingStep4 {
  ambiance_keywords: string[]
}

export type OnboardingData = OnboardingStep1 &
  OnboardingStep2 &
  OnboardingStep3 &
  OnboardingStep4
