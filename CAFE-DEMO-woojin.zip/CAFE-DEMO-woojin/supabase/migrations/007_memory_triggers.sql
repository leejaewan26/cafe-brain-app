-- Issue #10 Foundation 2단계: 이벤트 캡처 DB 트리거
-- 주요 이벤트(리뷰·발주·매출)를 agent_memory로 자동 수집
-- Batch 4 능동 에이전트가 풍부한 학습 데이터를 갖도록

-- ══════════════════════════════════════════════════════════
-- 1. 리뷰 INSERT 트리거 (reviews 테이블은 Frontend 기반이지만
--    서버 저장으로 전환 시 대비해 INSERT 훅 준비)
-- ══════════════════════════════════════════════════════════

-- 나쁜 리뷰(1-2점) 신규 등록 → event 메모리 생성
-- (현재 reviews 테이블은 없지만 향후 확장 대비 함수만 준비)
CREATE OR REPLACE FUNCTION public.capture_review_event()
RETURNS TRIGGER AS $$
BEGIN
  IF NEW.rating <= 2 THEN
    INSERT INTO public.agent_memory (
      store_id, category, content, importance, confidence,
      source_type, source_ref
    ) VALUES (
      NEW.store_id,
      'customer_insight',
      format('부정 리뷰 (%s점): %s', NEW.rating,
        substring(COALESCE(NEW.content, '') FROM 1 FOR 150)),
      7,  -- 부정 리뷰는 중요도 높게
      0.9,
      'review_new',
      NEW.id::text
    );
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;


-- ══════════════════════════════════════════════════════════
-- 2. 발주 승인 트리거 — decision_history 메모리 자동 생성
-- ══════════════════════════════════════════════════════════

CREATE OR REPLACE FUNCTION public.capture_order_decision()
RETURNS TRIGGER AS $$
DECLARE
  item_summary text;
BEGIN
  -- status가 pending → approved 로 전환된 경우만
  IF OLD.status = 'pending' AND NEW.status = 'approved' THEN
    -- 발주 품목 요약
    SELECT string_agg(ingredient_name || '(' || quantity || unit || ')', ', ')
      INTO item_summary
      FROM public.order_items
      WHERE order_id = NEW.id
      LIMIT 10;

    INSERT INTO public.agent_memory (
      store_id, category, content, importance, confidence,
      source_type, source_ref
    ) VALUES (
      NEW.store_id,
      'decision_history',
      format('%s 발주 승인 — %s',
        NEW.supplier_name,
        COALESCE(substring(item_summary FROM 1 FOR 200), '품목 정보 없음')),
      6,
      1.0,
      'order_approved',
      NEW.id::text
    );
  END IF;

  -- 반려도 학습 신호로 기록
  IF OLD.status = 'pending' AND NEW.status = 'rejected' THEN
    INSERT INTO public.agent_memory (
      store_id, category, content, importance, confidence,
      source_type, source_ref
    ) VALUES (
      NEW.store_id,
      'rejected_suggestion',
      format('발주 반려: %s (사유: %s)',
        NEW.supplier_name,
        COALESCE(NEW.rejected_reason, '미지정')),
      5,
      0.9,
      'order_rejected',
      NEW.id::text
    );
  END IF;

  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

DROP TRIGGER IF EXISTS trg_capture_order_decision ON public.orders;
CREATE TRIGGER trg_capture_order_decision
  AFTER UPDATE ON public.orders
  FOR EACH ROW
  EXECUTE FUNCTION public.capture_order_decision();


-- ══════════════════════════════════════════════════════════
-- 3. 매출 이상 감지 함수 — pg_cron 또는 Edge Function에서 주기 호출
-- ══════════════════════════════════════════════════════════

-- 특정 매장의 오늘 매출과 최근 7일 평균 비교, -20% 이하면 event 메모리 생성
-- 리턴: 감지된 이벤트 수
CREATE OR REPLACE FUNCTION public.detect_sales_anomaly(p_store_id uuid)
RETURNS int AS $$
DECLARE
  today_revenue numeric;
  week_avg numeric;
  drop_pct numeric;
  memory_count int := 0;
BEGIN
  -- 오늘 매출 합계
  SELECT COALESCE(SUM(revenue), 0) INTO today_revenue
    FROM public.sales_records
    WHERE store_id = p_store_id
      AND sale_date = CURRENT_DATE;

  -- 최근 7일 평균 (오늘 제외)
  SELECT COALESCE(AVG(daily_sum), 0) INTO week_avg
    FROM (
      SELECT sale_date, SUM(revenue) AS daily_sum
        FROM public.sales_records
        WHERE store_id = p_store_id
          AND sale_date BETWEEN CURRENT_DATE - 7 AND CURRENT_DATE - 1
        GROUP BY sale_date
    ) daily;

  -- 최소 3일 이상 데이터 + 오늘 매출 존재 시만 판단
  IF week_avg > 0 AND today_revenue > 0 THEN
    drop_pct := ((today_revenue - week_avg) / week_avg) * 100;

    IF drop_pct <= -20 THEN
      INSERT INTO public.agent_memory (
        store_id, category, content, importance, confidence,
        source_type, source_ref
      ) VALUES (
        p_store_id,
        'event',
        format('매출 급락 감지 — 오늘 %s원 (최근 7일 평균 %s원 대비 %s%%)',
          round(today_revenue)::text,
          round(week_avg)::text,
          round(drop_pct, 1)::text),
        8,  -- 급락은 중요도 높게
        0.85,
        'sales_anomaly',
        CURRENT_DATE::text
      );
      memory_count := memory_count + 1;
    END IF;
  END IF;

  RETURN memory_count;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;


-- ══════════════════════════════════════════════════════════
-- 4. BEP 달성 감지 함수 — 월 BEP 도달 시 goal 메모리
-- ══════════════════════════════════════════════════════════

CREATE OR REPLACE FUNCTION public.detect_bep_milestone(p_store_id uuid)
RETURNS int AS $$
DECLARE
  monthly_fixed numeric;
  month_revenue numeric;
  month_cost numeric;
  bep_amount numeric;
  contribution_rate numeric;
  existing_count int;
BEGIN
  -- 이번 달 BEP 이미 감지된 이벤트 있는지 확인 (중복 방지)
  SELECT count(*) INTO existing_count
    FROM public.agent_memory
    WHERE store_id = p_store_id
      AND category = 'goal'
      AND source_type = 'bep_reached'
      AND source_ref = to_char(CURRENT_DATE, 'YYYY-MM')
      AND archived_at IS NULL;

  IF existing_count > 0 THEN RETURN 0; END IF;

  -- 매장 월 고정비
  SELECT monthly_fixed_cost INTO monthly_fixed
    FROM public.stores
    WHERE id = p_store_id;

  IF monthly_fixed IS NULL OR monthly_fixed <= 0 THEN RETURN 0; END IF;

  -- 이번 달 매출·원가
  SELECT
    COALESCE(SUM(revenue), 0),
    COALESCE(SUM(cost), 0)
    INTO month_revenue, month_cost
    FROM public.sales_records
    WHERE store_id = p_store_id
      AND date_trunc('month', sale_date) = date_trunc('month', CURRENT_DATE);

  -- 공헌이익률
  IF month_revenue > 0 THEN
    contribution_rate := (month_revenue - month_cost) / month_revenue;
    IF contribution_rate > 0 THEN
      bep_amount := monthly_fixed / contribution_rate;

      IF month_revenue >= bep_amount THEN
        INSERT INTO public.agent_memory (
          store_id, category, content, importance, confidence,
          source_type, source_ref
        ) VALUES (
          p_store_id,
          'goal',
          format('%s월 BEP 달성! 매출 %s원 / 목표 %s원',
            EXTRACT(MONTH FROM CURRENT_DATE)::text,
            round(month_revenue)::text,
            round(bep_amount)::text),
          9,
          1.0,
          'bep_reached',
          to_char(CURRENT_DATE, 'YYYY-MM')
        );
        RETURN 1;
      END IF;
    END IF;
  END IF;

  RETURN 0;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;


-- ══════════════════════════════════════════════════════════
-- 5. 통합 체크 함수 — Batch 4 pg_cron 5분마다 호출 예정
-- ══════════════════════════════════════════════════════════

CREATE OR REPLACE FUNCTION public.run_daily_memory_capture(p_store_id uuid)
RETURNS TABLE(event_type text, count int) AS $$
BEGIN
  RETURN QUERY
    SELECT 'sales_anomaly'::text, public.detect_sales_anomaly(p_store_id)
    UNION ALL
    SELECT 'bep_milestone'::text, public.detect_bep_milestone(p_store_id);
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

COMMENT ON FUNCTION public.run_daily_memory_capture IS
  'Batch 4 pg_cron에서 매장별 주기 호출. 이상 감지·마일스톤을 memory로 자동 수집.';
