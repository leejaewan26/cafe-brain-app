// Zustand 인증 상태 스토어
import { create } from 'zustand'
import { persist } from 'zustand/middleware'
import type { User, Session } from '@supabase/supabase-js'
import type { Store } from '@/types/store'

interface AuthState {
  user: User | null
  session: Session | null
  storeInfo: Store | null
  isOnboarded: boolean
  // 상태 설정 함수
  setUser: (user: User | null) => void
  setSession: (session: Session | null) => void
  setStoreInfo: (storeInfo: Store | null) => void
  setIsOnboarded: (isOnboarded: boolean) => void
  // 로그아웃 초기화
  reset: () => void
}

export const useAuthStore = create<AuthState>()(
  persist(
    (set) => ({
      user: null,
      session: null,
      storeInfo: null,
      isOnboarded: false,
      setUser: (user) => set({ user }),
      setSession: (session) => set({ session }),
      setStoreInfo: (storeInfo) => set({ storeInfo }),
      setIsOnboarded: (isOnboarded) => set({ isOnboarded }),
      reset: () =>
        set({
          user: null,
          session: null,
          storeInfo: null,
          isOnboarded: false,
        }),
    }),
    {
      name: 'cafe-brain-auth', // localStorage 키
      partialize: (state) => ({
        // 민감 정보(session 토큰)는 Supabase가 별도 관리
        storeInfo: state.storeInfo,
        isOnboarded: state.isOnboarded,
      }),
    }
  )
)
