// 설정 > AI 학습 탭 (Phase 5)
// - 매장에 축적된 AI 메모리 투명하게 공개
// - 메모리별 잊어줘 버튼 (망각권)
// - 학습 on/off 토글 (프라이버시 권리)
import { useEffect, useState, useCallback } from 'react'
import {
  Brain, Trash2, AlertCircle, Loader2, RefreshCw,
  TrendingUp, Star, Receipt, ThumbsUp, ThumbsDown,
  Calendar, Sparkles, Target, Megaphone, DollarSign, Database,
  Activity, ShieldCheck, Plus, X, Edit3, Volume2,
} from 'lucide-react'
import toast from 'react-hot-toast'
import { useAuthStore } from '@/store/authStore'
import { supabase } from '@/lib/supabase'
import { cn } from '@/lib/utils'
import { useTTS } from '@/hooks/useTTS'

interface MemoryItem {
  id: string
  category: string
  content: string
  importance: number
  confidence: number
  created_at: string
}

interface UsageStats {
  cache: {
    hits: number
    misses: number
    total: number
    hit_rate: number
    saved_krw_estimate: number
    errors: number
  }
  tokens: {
    total_calls: number
    total_input_tokens: number
    total_output_tokens: number
    estimated_cost_krw: number
    by_module: Record<string, { calls: number; input_tokens: number; output_tokens: number }>
    pricing_note: string
  }
}

// Phase 6 #13 SLO
interface SLOStat {
  endpoint: string
  total_calls: number
  cache_hit_rate: number
  p50_ms: number
  p95_ms: number
  p99_ms: number
  total_cost_krw: number
}

// Phase 6 #11 Audit
interface AuditItem {
  id: string
  action: string
  actor_role: string | null
  target_type: string | null
  target_id: string | null
  before: Record<string, unknown> | null
  after: Record<string, unknown> | null
  created_at: string
}

// Phase 6 #14 Anomaly Rules
type RuleMetric = 'sales' | 'orders' | 'review_score' | 'menu_sales'
type RuleComparator = 'pct_change' | 'abs_lt' | 'abs_gt'
type RuleWindow = 'today_vs_week_avg' | 'week_vs_prev_week' | 'today_abs'
type RuleChannel = 'briefing' | 'push' | 'both'

interface AnomalyRule {
  id: string
  name: string
  metric: RuleMetric
  metric_param?: string | null
  comparator: RuleComparator
  threshold: number
  window_type: RuleWindow
  enabled: boolean
  channel: RuleChannel
  cooldown_h: number
  last_fired_at?: string | null
  created_at: string
}

const METRIC_LABEL: Record<RuleMetric, string> = {
  sales: '매출액',
  orders: '주문 건수',
  review_score: '리뷰 평점',
  menu_sales: '메뉴 판매량',
}
const COMP_LABEL: Record<RuleComparator, string> = {
  pct_change: '변동률(%)',
  abs_lt: '미만',
  abs_gt: '초과',
}
const WINDOW_LABEL: Record<RuleWindow, string> = {
  today_vs_week_avg: '오늘 vs 지난 7일 평균',
  week_vs_prev_week: '이번주 vs 지난주',
  today_abs: '오늘 절대값',
}
const CHANNEL_LABEL: Record<RuleChannel, string> = {
  briefing: '브리핑',
  push: '푸시',
  both: '둘 다',
}

const ACTION_LABEL: Record<string, string> = {
  memory_delete: '메모리 삭제',
  memory_create: '메모리 추가',
  feedback: 'AI 피드백',
  learning_toggle: '학습 토글',
  profile_switch: '프로필 전환',
  anomaly_rule_create: '룰 추가',
  anomaly_rule_update: '룰 수정',
  anomaly_rule_delete: '룰 삭제',
}

const CATEGORY_META: Record<string, { label: string; icon: React.ElementType; color: string }> = {
  business_pattern:    { label: '운영 패턴',    icon: TrendingUp, color: '#4A90A4' },
  customer_insight:    { label: '고객 인사이트', icon: Star,       color: '#D4A574' },
  decision_history:    { label: '결정 이력',    icon: Receipt,    color: '#7B6CB0' },
  preference:          { label: '사장님 선호',  icon: Sparkles,   color: '#E07A5F' },
  event:               { label: '주목 이벤트',  icon: Calendar,   color: '#F59E0B' },
  goal:                { label: '목표·KPI',     icon: Target,     color: '#22C55E' },
  accepted_suggestion: { label: '수용한 제안',  icon: ThumbsUp,   color: '#5A9E6F' },
  rejected_suggestion: { label: '거부한 제안',  icon: ThumbsDown, color: '#9B9B9B' },
}

export default function AgentTab() {
  const user = useAuthStore((s) => s.user)
  const [memories, setMemories] = useState<MemoryItem[]>([])
  const [loading, setLoading] = useState(false)
  const [filter, setFilter] = useState<string | null>(null)
  const [learningEnabled, setLearningEnabled] = useState(true)
  const [confirmForget, setConfirmForget] = useState<string | null>(null)
  // Phase 6: 사용량·비용 대시보드
  const [usage, setUsage] = useState<UsageStats | null>(null)
  // Bonus E3: TTS 자동 재생 토글
  const tts = useTTS()
  // Phase 6 #13 SLO
  const [slo, setSlo] = useState<SLOStat[]>([])
  // Phase 6 #11 Audit
  const [audit, setAudit] = useState<AuditItem[]>([])
  // Phase 6 #14 Anomaly Rules
  const [rules, setRules] = useState<AnomalyRule[]>([])
  const [showRuleForm, setShowRuleForm] = useState(false)
  const [editingRule, setEditingRule] = useState<AnomalyRule | null>(null)

  const fetchUsage = useCallback(async () => {
    try {
      const r = await fetch('/api/v1/agent/usage')
      if (r.ok) setUsage(await r.json())
    } catch {/* 조용히 */}
  }, [])
  useEffect(() => { void fetchUsage() }, [fetchUsage])

  const fetchSlo = useCallback(async () => {
    if (!user) return
    try {
      const params = new URLSearchParams({ store_id: user.id, window_days: '7' })
      const r = await fetch(`/api/v1/agent/slo?${params}`)
      if (r.ok) setSlo(await r.json())
    } catch {/* 조용히 */}
  }, [user])
  useEffect(() => { void fetchSlo() }, [fetchSlo])

  const fetchAudit = useCallback(async () => {
    if (!user) return
    try {
      const params = new URLSearchParams({ store_id: user.id, limit: '20' })
      const r = await fetch(`/api/v1/agent/audit?${params}`)
      if (r.ok) setAudit(await r.json())
    } catch {/* 조용히 */}
  }, [user])
  useEffect(() => { void fetchAudit() }, [fetchAudit])

  const fetchRules = useCallback(async () => {
    if (!user) return
    try {
      const params = new URLSearchParams({ store_id: user.id })
      const r = await fetch(`/api/v1/agent/rules?${params}`)
      if (r.ok) setRules(await r.json())
    } catch {/* 조용히 */}
  }, [user])
  useEffect(() => { void fetchRules() }, [fetchRules])

  const saveRule = async (form: Omit<AnomalyRule, 'id' | 'created_at' | 'last_fired_at'>) => {
    if (!user) return
    const isEdit = editingRule !== null
    try {
      const url = isEdit
        ? `/api/v1/agent/rules/${editingRule.id}`
        : '/api/v1/agent/rules'
      const r = await fetch(url, {
        method: isEdit ? 'PUT' : 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-Store-Id': user.id,
        },
        body: JSON.stringify(form),
      })
      if (!r.ok) throw new Error('저장 실패')
      toast.success(isEdit ? '룰이 수정되었어요' : '룰이 추가되었어요')
      setShowRuleForm(false)
      setEditingRule(null)
      void fetchRules()
    } catch {
      toast.error('룰 저장에 실패했어요')
    }
  }

  const deleteRule = async (ruleId: string) => {
    if (!user) return
    try {
      const r = await fetch(`/api/v1/agent/rules/${ruleId}`, {
        method: 'DELETE',
        headers: { 'X-Store-Id': user.id },
      })
      if (!r.ok) throw new Error()
      setRules((prev) => prev.filter((x) => x.id !== ruleId))
      toast.success('룰을 삭제했어요')
    } catch {
      toast.error('룰 삭제 실패')
    }
  }

  const evaluateRules = async () => {
    if (!user) return
    try {
      const r = await fetch('/api/v1/agent/rules/evaluate', {
        method: 'POST',
        headers: { 'X-Store-Id': user.id },
      })
      if (!r.ok) throw new Error()
      const data = await r.json() as { triggered: Array<{ name: string }>, count: number }
      if (data.count === 0) {
        toast.success('모든 룰이 정상 범위입니다 ✨')
      } else {
        toast(`${data.count}개 룰 트리거: ${data.triggered.map((x) => x.name).join(', ')}`, { duration: 6000 })
      }
      void fetchRules()
    } catch {
      toast.error('평가 실패')
    }
  }

  const fetchMemories = useCallback(async () => {
    if (!user) return
    setLoading(true)
    try {
      const params = new URLSearchParams({ store_id: user.id, limit: '100' })
      if (filter) params.set('category', filter)
      const r = await fetch(`/api/v1/agent/memory?${params}`)
      if (r.ok) {
        const d = await r.json()
        setMemories(d.memories ?? [])
      }
    } catch {/* 조용히 */} finally {
      setLoading(false)
    }
  }, [user, filter])

  // 학습 활성 상태 조회
  const fetchLearningState = useCallback(async () => {
    if (!user) return
    const { data } = await supabase
      .from('stores')
      .select('agent_learning_enabled')
      .eq('id', user.id)
      .limit(1)
      .single()
    if (data) setLearningEnabled(data.agent_learning_enabled ?? true)
  }, [user])

  useEffect(() => { void fetchMemories() }, [fetchMemories])
  useEffect(() => { void fetchLearningState() }, [fetchLearningState])

  const handleToggleLearning = async () => {
    if (!user) return
    const next = !learningEnabled
    setLearningEnabled(next)
    try {
      const { error } = await supabase
        .from('stores')
        .update({ agent_learning_enabled: next })
        .eq('id', user.id)
      if (error) throw error
      toast.success(next ? 'AI 학습이 다시 켜졌어요 ✨' : 'AI 학습을 껐어요. 더 이상 데이터를 축적하지 않습니다.')
    } catch {
      setLearningEnabled(!next)
      toast.error('설정 저장 실패')
    }
  }

  const handleForget = async (memoryId: string) => {
    if (!user) return
    try {
      const r = await fetch(`/api/v1/agent/memory/${memoryId}`, {
        method: 'DELETE',
        headers: { 'X-Store-Id': user.id },
      })
      if (!r.ok) throw new Error('실패')
      setMemories((prev) => prev.filter((m) => m.id !== memoryId))
      setConfirmForget(null)
      toast.success('잊어드렸어요 🌙')
    } catch {
      toast.error('삭제 실패. 다시 시도해주세요.')
    }
  }

  // 카테고리별 그룹핑
  const grouped = memories.reduce<Record<string, MemoryItem[]>>((acc, m) => {
    if (!acc[m.category]) acc[m.category] = []
    acc[m.category].push(m)
    return acc
  }, {})

  const totalCount = memories.length
  const categoryCounts = Object.entries(grouped).map(([cat, items]) => ({
    cat,
    count: items.length,
    meta: CATEGORY_META[cat] ?? { label: cat, icon: Brain, color: '#999' },
  }))

  return (
    <div className="space-y-5">

      {/* ─── 학습 상태 ─── */}
      <section className="bg-white rounded-2xl p-5 border border-gray-100 shadow-sm">
        <div className="flex items-start justify-between mb-3">
          <div>
            <h3 className="font-bold text-[#2C1810] flex items-center gap-2">
              <Brain size={16} className="text-[#D4A574]" />
              AI 학습
            </h3>
            <p className="text-xs text-gray-400 mt-0.5">
              {learningEnabled
                ? `현재 ${totalCount}개 메모리 축적됨`
                : '학습 OFF — 새 데이터 안 쌓임 (기존 메모리는 유지)'}
            </p>
          </div>
          <button
            onClick={handleToggleLearning}
            className={cn(
              'relative w-12 h-6 rounded-full transition-colors duration-200 shrink-0',
              learningEnabled ? 'bg-green-500' : 'bg-gray-300',
            )}
            aria-label="AI 학습 토글"
          >
            <div className={cn(
              'absolute top-0.5 w-5 h-5 bg-white rounded-full shadow transition-all duration-200',
              learningEnabled ? 'left-6' : 'left-0.5',
            )} />
          </button>
        </div>
        <p className="text-[11px] text-gray-500 leading-relaxed bg-[#FAFAF8] rounded-lg p-2.5">
          AI가 매장 데이터·결정·고객 인사이트를 학습해 갈수록 개인화됩니다.
          <strong className="text-[#2C1810]"> 끄면 새 메모리 저장 X</strong>, 기존 메모리는 그대로 둡니다.
          개별 메모리는 아래에서 "잊어줘"로 삭제 가능합니다.
        </p>

        {/* Bonus E3: TTS 자동 재생 토글 — 출근길 듣기 모드 */}
        {tts.supported && (
          <div className="mt-3 flex items-center justify-between gap-3 bg-[#FAFAF8] rounded-lg p-2.5">
            <div className="flex items-center gap-2">
              <Volume2 size={13} className="text-[#7B6CB0]" />
              <div>
                <p className="text-xs font-semibold text-[#2C1810]">아침 브리핑 자동 재생</p>
                <p className="text-[10px] text-gray-500 mt-0.5">앱 진입 시 일일 브리핑을 음성으로 들려드려요</p>
              </div>
            </div>
            <button
              onClick={() => tts.setAutoplay(!tts.autoplay)}
              className={cn(
                'relative w-10 h-5 rounded-full transition-colors duration-200 shrink-0',
                tts.autoplay ? 'bg-[#7B6CB0]' : 'bg-gray-300',
              )}
              aria-label="브리핑 자동 재생 토글"
            >
              <div className={cn(
                'absolute top-0.5 w-4 h-4 bg-white rounded-full shadow transition-all duration-200',
                tts.autoplay ? 'left-5' : 'left-0.5',
              )} />
            </button>
          </div>
        )}
      </section>

      {/* ─── Phase 6: AI 사용량·비용 (캐시 + 토큰) ─── */}
      {usage && (
        <section className="bg-white rounded-2xl p-5 border border-gray-100 shadow-sm">
          <div className="flex items-center justify-between mb-3">
            <h3 className="font-bold text-[#2C1810] flex items-center gap-2">
              <DollarSign size={15} className="text-[#22C55E]" />
              AI 사용량·비용
            </h3>
            <button
              onClick={fetchUsage}
              className="p-1.5 text-gray-400 hover:text-[#2C1810] transition-colors"
              title="새로고침"
            >
              <RefreshCw size={13} />
            </button>
          </div>

          {/* 4-카드 요약 */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-2 mb-3">
            <div className="bg-[#FAFAF8] rounded-xl p-3 text-center">
              <p className="text-[10px] text-gray-400 mb-1">총 호출</p>
              <p className="text-sm font-bold text-[#2C1810]">{usage.tokens.total_calls.toLocaleString()}</p>
            </div>
            <div className="bg-[#FAFAF8] rounded-xl p-3 text-center">
              <p className="text-[10px] text-gray-400 mb-1">캐시 히트율</p>
              <p className="text-sm font-bold text-green-600">
                {(usage.cache.hit_rate * 100).toFixed(1)}%
              </p>
            </div>
            <div className="bg-[#FAFAF8] rounded-xl p-3 text-center">
              <p className="text-[10px] text-gray-400 mb-1">절감 (캐시)</p>
              <p className="text-sm font-bold text-green-600">
                ₩{usage.cache.saved_krw_estimate.toLocaleString()}
              </p>
            </div>
            <div className="bg-[#FAFAF8] rounded-xl p-3 text-center">
              <p className="text-[10px] text-gray-400 mb-1">추정 비용</p>
              <p className="text-sm font-bold text-[#2C1810]">
                ₩{usage.tokens.estimated_cost_krw.toLocaleString()}
              </p>
            </div>
          </div>

          {/* 토큰 상세 */}
          <div className="grid grid-cols-2 gap-2 mb-3 text-xs">
            <div className="flex items-center justify-between bg-[#FAFAF8] rounded-lg px-3 py-2">
              <span className="text-gray-500">입력 토큰</span>
              <span className="font-semibold text-[#2C1810]">
                {usage.tokens.total_input_tokens.toLocaleString()}
              </span>
            </div>
            <div className="flex items-center justify-between bg-[#FAFAF8] rounded-lg px-3 py-2">
              <span className="text-gray-500">출력 토큰</span>
              <span className="font-semibold text-[#2C1810]">
                {usage.tokens.total_output_tokens.toLocaleString()}
              </span>
            </div>
          </div>

          {/* 모듈별 분포 */}
          {Object.keys(usage.tokens.by_module).length > 0 && (
            <div className="space-y-1.5">
              <p className="text-[11px] font-semibold text-gray-500 flex items-center gap-1">
                <Database size={11} />
                모듈별 호출
              </p>
              {Object.entries(usage.tokens.by_module).map(([mod, stats]) => {
                const totalCalls = usage.tokens.total_calls || 1
                const pct = (stats.calls / totalCalls) * 100
                return (
                  <div key={mod} className="flex items-center gap-2 text-[11px]">
                    <span className="font-medium text-[#2C1810] w-32 truncate">{mod}</span>
                    <div className="flex-1 bg-gray-100 rounded-full h-1.5 overflow-hidden">
                      <div
                        className="h-full bg-gradient-to-r from-[#D4A574] to-[#2C1810] rounded-full"
                        style={{ width: `${Math.min(100, pct)}%` }}
                      />
                    </div>
                    <span className="text-gray-400 w-16 text-right">
                      {stats.calls}회
                    </span>
                  </div>
                )
              })}
            </div>
          )}

          <p className="text-[10px] text-gray-400 mt-3 leading-relaxed">
            ⓘ {usage.tokens.pricing_note}<br />
            인메모리 통계 — 백엔드 재시작 시 초기화됩니다. 정확한 청구는 GCP 콘솔 확인.
          </p>
        </section>
      )}

      {/* ─── Phase 6 #13: 응답시간 SLO (지난 7일) ─── */}
      {slo.length > 0 && (
        <section className="bg-white rounded-2xl p-5 border border-gray-100 shadow-sm">
          <div className="flex items-center justify-between mb-3">
            <h3 className="font-bold text-[#2C1810] flex items-center gap-2">
              <Activity size={15} className="text-[#7B6CB0]" />
              응답시간 SLO (최근 7일)
            </h3>
            <button
              onClick={fetchSlo}
              className="p-1.5 text-gray-400 hover:text-[#2C1810] transition-colors"
              title="새로고침"
            >
              <RefreshCw size={13} />
            </button>
          </div>
          <div className="space-y-1.5">
            <div className="grid grid-cols-12 gap-2 px-3 py-1.5 text-[10px] text-gray-400 font-semibold border-b border-gray-100">
              <span className="col-span-5">엔드포인트</span>
              <span className="col-span-2 text-right">호출</span>
              <span className="col-span-2 text-right">p50</span>
              <span className="col-span-2 text-right">p95</span>
              <span className="col-span-1 text-right">캐시</span>
            </div>
            {slo.slice(0, 8).map((s) => (
              <div
                key={s.endpoint}
                className="grid grid-cols-12 gap-2 px-3 py-2 text-[11px] hover:bg-[#FAFAF8] rounded-lg transition-colors"
              >
                <span className="col-span-5 font-medium text-[#2C1810] truncate" title={s.endpoint}>
                  {s.endpoint.replace('/api/', '')}
                </span>
                <span className="col-span-2 text-right text-gray-500">{s.total_calls.toLocaleString()}</span>
                <span className="col-span-2 text-right font-semibold text-[#2C1810]">{Math.round(s.p50_ms)}ms</span>
                <span className={cn(
                  'col-span-2 text-right font-semibold',
                  s.p95_ms > 5000 ? 'text-red-500' : s.p95_ms > 2000 ? 'text-amber-500' : 'text-[#2C1810]'
                )}>
                  {Math.round(s.p95_ms)}ms
                </span>
                <span className="col-span-1 text-right text-green-600">
                  {Math.round(s.cache_hit_rate * 100)}%
                </span>
              </div>
            ))}
          </div>
          <p className="text-[10px] text-gray-400 mt-3">
            ⓘ p95가 2초 넘으면 주황, 5초 넘으면 빨강. 캐시 적중률이 높을수록 비용·지연 모두 감소합니다.
          </p>
        </section>
      )}

      {/* ─── Phase 6 #14: 사용자 정의 이상치 룰 ─── */}
      <section className="bg-white rounded-2xl p-5 border border-gray-100 shadow-sm">
        <div className="flex items-center justify-between mb-3">
          <h3 className="font-bold text-[#2C1810] flex items-center gap-2">
            <Target size={15} className="text-[#22C55E]" />
            이상치 감지 룰
            <span className="text-[10px] text-gray-400 font-normal">{rules.length}개</span>
          </h3>
          <div className="flex gap-1">
            <button
              onClick={evaluateRules}
              className="text-[11px] px-2 py-1 rounded-lg border border-gray-200 text-gray-600 hover:bg-gray-50 transition-colors"
            >
              지금 평가
            </button>
            <button
              onClick={() => { setEditingRule(null); setShowRuleForm(true) }}
              className="text-[11px] px-2 py-1 rounded-lg bg-[#2C1810] text-white hover:bg-[#3A2519] transition-colors flex items-center gap-1"
            >
              <Plus size={11} /> 추가
            </button>
          </div>
        </div>

        {rules.length === 0 ? (
          <p className="text-xs text-gray-400 text-center py-6 leading-relaxed">
            아직 등록된 룰이 없어요.<br />
            "주말 매출이 평일 평균 대비 -30%면 알림" 같은 룰을 직접 정의할 수 있어요.
          </p>
        ) : (
          <div className="space-y-1.5">
            {rules.map((r) => (
              <div
                key={r.id}
                className={cn(
                  'flex items-center gap-2 px-3 py-2 rounded-lg border transition-colors',
                  r.enabled ? 'border-gray-100 bg-white' : 'border-gray-50 bg-gray-50 opacity-60',
                )}
              >
                <div
                  className={cn(
                    'w-2 h-2 rounded-full shrink-0',
                    r.enabled ? 'bg-green-500' : 'bg-gray-300',
                  )}
                />
                <div className="flex-1 min-w-0">
                  <p className="text-xs font-semibold text-[#2C1810] truncate">{r.name}</p>
                  <p className="text-[10px] text-gray-500">
                    {METRIC_LABEL[r.metric]} · {WINDOW_LABEL[r.window_type]} · {COMP_LABEL[r.comparator]} {r.threshold}
                    {' · '}{CHANNEL_LABEL[r.channel]}
                    {r.last_fired_at && ' · 마지막 발화: ' + new Date(r.last_fired_at).toLocaleDateString('ko-KR')}
                  </p>
                </div>
                <button
                  onClick={() => { setEditingRule(r); setShowRuleForm(true) }}
                  className="p-1 text-gray-400 hover:text-[#2C1810] transition-colors"
                  title="수정"
                >
                  <Edit3 size={12} />
                </button>
                <button
                  onClick={() => deleteRule(r.id)}
                  className="p-1 text-gray-400 hover:text-red-500 transition-colors"
                  title="삭제"
                >
                  <Trash2 size={12} />
                </button>
              </div>
            ))}
          </div>
        )}

        {showRuleForm && (
          <RuleFormModal
            initial={editingRule}
            onSave={saveRule}
            onCancel={() => { setShowRuleForm(false); setEditingRule(null) }}
          />
        )}
      </section>

      {/* ─── Phase 6 #11: 감사 로그 (최근 20건) ─── */}
      {audit.length > 0 && (
        <section className="bg-white rounded-2xl p-5 border border-gray-100 shadow-sm">
          <div className="flex items-center justify-between mb-3">
            <h3 className="font-bold text-[#2C1810] flex items-center gap-2">
              <ShieldCheck size={15} className="text-[#4A90A4]" />
              감사 로그 (최근 20건)
            </h3>
            <button
              onClick={fetchAudit}
              className="p-1.5 text-gray-400 hover:text-[#2C1810] transition-colors"
              title="새로고침"
            >
              <RefreshCw size={13} />
            </button>
          </div>
          <div className="space-y-1">
            {audit.map((a) => (
              <div
                key={a.id}
                className="flex items-center gap-2 px-3 py-1.5 text-[11px] hover:bg-[#FAFAF8] rounded transition-colors"
              >
                <span className="text-gray-300 font-mono">
                  {new Date(a.created_at).toLocaleString('ko-KR', {
                    month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit',
                  })}
                </span>
                <span className="font-semibold text-[#2C1810] w-20">
                  {ACTION_LABEL[a.action] ?? a.action}
                </span>
                {a.target_type && (
                  <span className="text-gray-400 truncate flex-1">
                    {a.target_type}: {a.target_id?.slice(0, 8)}
                  </span>
                )}
                {a.actor_role && (
                  <span className="text-[10px] px-1.5 py-0.5 bg-gray-100 text-gray-500 rounded">
                    {a.actor_role}
                  </span>
                )}
              </div>
            ))}
          </div>
          <p className="text-[10px] text-gray-400 mt-3">
            ⓘ 누가 언제 무엇을 했는지 자동 기록됩니다 (GDPR·내부 감사 대응).
          </p>
        </section>
      )}

      {/* ─── 메모리 통계 + 카테고리 필터 ─── */}
      {categoryCounts.length > 0 && (
        <section className="bg-white rounded-2xl p-4 border border-gray-100 shadow-sm">
          <div className="flex items-center justify-between mb-3">
            <h3 className="font-bold text-[#2C1810] text-sm">카테고리별</h3>
            <button
              onClick={fetchMemories}
              disabled={loading}
              className="p-1.5 text-gray-400 hover:text-[#2C1810] transition-colors"
              title="새로고침"
            >
              <RefreshCw size={13} className={loading ? 'animate-spin' : ''} />
            </button>
          </div>
          <div className="flex flex-wrap gap-1.5">
            <button
              onClick={() => setFilter(null)}
              className={cn(
                'px-2.5 py-1 rounded-full text-[11px] font-medium transition-colors',
                filter === null ? 'bg-[#2C1810] text-white' : 'bg-gray-50 text-gray-500 hover:bg-gray-100',
              )}
            >
              전체 {totalCount}
            </button>
            {categoryCounts.map(({ cat, count, meta }) => {
              const Icon = meta.icon
              return (
                <button
                  key={cat}
                  onClick={() => setFilter(filter === cat ? null : cat)}
                  className={cn(
                    'flex items-center gap-1 px-2.5 py-1 rounded-full text-[11px] font-medium transition-colors border',
                    filter === cat
                      ? 'bg-[#2C1810] text-white border-[#2C1810]'
                      : 'bg-white text-gray-600 border-gray-200 hover:border-gray-300',
                  )}
                >
                  <Icon size={10} style={{ color: filter === cat ? 'white' : meta.color }} />
                  {meta.label} {count}
                </button>
              )
            })}
          </div>
        </section>
      )}

      {/* ─── 메모리 목록 ─── */}
      <section className="space-y-2">
        {loading && memories.length === 0 && (
          <div className="flex items-center justify-center py-12 text-gray-400">
            <Loader2 size={18} className="animate-spin mr-2" />
            <span className="text-sm">메모리 불러오는 중...</span>
          </div>
        )}

        {!loading && memories.length === 0 && (
          <div className="bg-white rounded-2xl p-8 border border-gray-100 text-center">
            <Brain size={32} className="text-gray-300 mx-auto mb-2" />
            <p className="text-sm text-[#2C1810] font-semibold">아직 학습된 메모리가 없어요</p>
            <p className="text-xs text-gray-400 mt-1 leading-relaxed">
              매출 업로드, 리뷰 답글, AI 채팅 등을 사용하시면<br />
              점점 매장에 맞는 응답이 가능해집니다.
            </p>
          </div>
        )}

        {memories.map((m) => {
          const meta = CATEGORY_META[m.category] ?? { label: m.category, icon: Brain, color: '#999' }
          const Icon = meta.icon
          const isConfirming = confirmForget === m.id
          return (
            <div
              key={m.id}
              className="bg-white rounded-2xl p-4 border border-gray-100 shadow-sm hover:border-gray-200 transition-colors"
            >
              <div className="flex items-start gap-3">
                <div
                  className="w-7 h-7 rounded-lg flex items-center justify-center shrink-0"
                  style={{ backgroundColor: `${meta.color}18` }}
                >
                  <Icon size={13} style={{ color: meta.color }} />
                </div>

                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-1.5">
                    <span
                      className="text-[10px] font-medium px-1.5 py-0.5 rounded"
                      style={{ backgroundColor: `${meta.color}18`, color: meta.color }}
                    >
                      {meta.label}
                    </span>
                    <span className="text-[10px] text-gray-400">중요도 {m.importance}/10</span>
                    <span className="text-[10px] text-gray-400">신뢰도 {Math.round(m.confidence * 100)}%</span>
                    <span className="text-[10px] text-gray-300 ml-auto">
                      {new Date(m.created_at).toLocaleDateString('ko-KR')}
                    </span>
                  </div>
                  <p className="text-sm text-[#2C1810] leading-relaxed">{m.content}</p>
                </div>
              </div>

              {isConfirming ? (
                <div className="flex items-center gap-2 mt-3 p-2.5 bg-red-50 border border-red-100 rounded-xl">
                  <AlertCircle size={13} className="text-red-500 shrink-0" />
                  <p className="text-[11px] text-red-700 flex-1">정말 잊어드릴까요? 복구 불가합니다.</p>
                  <button
                    onClick={() => handleForget(m.id)}
                    className="text-[11px] bg-red-500 text-white px-2 py-1 rounded-lg hover:bg-red-600 transition-colors"
                  >
                    잊어줘
                  </button>
                  <button
                    onClick={() => setConfirmForget(null)}
                    className="text-[11px] text-gray-500 hover:text-gray-700"
                  >
                    취소
                  </button>
                </div>
              ) : (
                <button
                  onClick={() => setConfirmForget(m.id)}
                  className="mt-2 ml-10 flex items-center gap-1 text-[11px] text-gray-400 hover:text-red-500 transition-colors"
                >
                  <Trash2 size={10} />
                  잊어줘
                </button>
              )}
            </div>
          )
        })}
      </section>

      {/* 도움말 */}
      <section className="bg-amber-50 border border-amber-100 rounded-2xl p-4 text-xs text-amber-800 leading-relaxed">
        <p className="font-semibold flex items-center gap-1.5 mb-1.5">
          <Megaphone size={13} />
          학습 데이터에 대한 권리
        </p>
        <ul className="list-disc pl-5 space-y-1">
          <li><strong>볼 권리</strong>: 위에 모든 메모리가 투명하게 공개됩니다</li>
          <li><strong>삭제할 권리</strong>: "잊어줘" 버튼으로 즉시 삭제 (복구 불가)</li>
          <li><strong>학습 거부</strong>: 상단 토글로 새 메모리 축적 중지</li>
          <li>저장된 데이터는 본인 매장만 접근 가능 (Supabase RLS)</li>
        </ul>
      </section>

    </div>
  )
}

// ─── Phase 6 #14: 룰 추가/수정 모달 ─────────────────────────
interface RuleFormProps {
  initial: AnomalyRule | null
  onSave: (form: Omit<AnomalyRule, 'id' | 'created_at' | 'last_fired_at'>) => void
  onCancel: () => void
}

function RuleFormModal({ initial, onSave, onCancel }: RuleFormProps) {
  const [name, setName] = useState(initial?.name ?? '')
  const [metric, setMetric] = useState<RuleMetric>(initial?.metric ?? 'sales')
  const [comparator, setComparator] = useState<RuleComparator>(initial?.comparator ?? 'pct_change')
  const [threshold, setThreshold] = useState<number>(initial?.threshold ?? -20)
  const [windowType, setWindowType] = useState<RuleWindow>(initial?.window_type ?? 'today_vs_week_avg')
  const [enabled, setEnabled] = useState(initial?.enabled ?? true)
  const [channel, setChannel] = useState<RuleChannel>(initial?.channel ?? 'briefing')
  const [cooldownH, setCooldownH] = useState(initial?.cooldown_h ?? 24)
  const [metricParam, setMetricParam] = useState(initial?.metric_param ?? '')

  const submit = () => {
    if (!name.trim()) {
      toast.error('룰 이름을 입력해주세요')
      return
    }
    onSave({
      name: name.trim(),
      metric,
      metric_param: metric === 'menu_sales' ? (metricParam || null) : null,
      comparator,
      threshold: Number(threshold),
      window_type: windowType,
      enabled,
      channel,
      cooldown_h: Math.max(1, Math.min(168, Number(cooldownH) || 24)),
    })
  }

  return (
    <div className="fixed inset-0 bg-black/40 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-2xl p-5 w-full max-w-md max-h-[90vh] overflow-y-auto shadow-2xl">
        <div className="flex items-center justify-between mb-4">
          <h4 className="font-bold text-[#2C1810]">
            {initial ? '룰 수정' : '새 이상치 감지 룰'}
          </h4>
          <button
            onClick={onCancel}
            className="p-1 text-gray-400 hover:text-[#2C1810] transition-colors"
          >
            <X size={16} />
          </button>
        </div>

        <div className="space-y-3 text-sm">
          <div>
            <label className="block text-[11px] font-semibold text-gray-500 mb-1">이름</label>
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="예: 주말 매출 급감"
              className="w-full px-3 py-2 border border-gray-200 rounded-lg text-sm focus:outline-none focus:border-[#2C1810]"
            />
          </div>

          <div className="grid grid-cols-2 gap-2">
            <div>
              <label className="block text-[11px] font-semibold text-gray-500 mb-1">측정 항목</label>
              <select
                value={metric}
                onChange={(e) => setMetric(e.target.value as RuleMetric)}
                className="w-full px-2 py-2 border border-gray-200 rounded-lg text-sm focus:outline-none focus:border-[#2C1810]"
              >
                {(Object.keys(METRIC_LABEL) as RuleMetric[]).map((m) => (
                  <option key={m} value={m}>{METRIC_LABEL[m]}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-[11px] font-semibold text-gray-500 mb-1">비교 기간</label>
              <select
                value={windowType}
                onChange={(e) => setWindowType(e.target.value as RuleWindow)}
                className="w-full px-2 py-2 border border-gray-200 rounded-lg text-sm focus:outline-none focus:border-[#2C1810]"
              >
                {(Object.keys(WINDOW_LABEL) as RuleWindow[]).map((w) => (
                  <option key={w} value={w}>{WINDOW_LABEL[w]}</option>
                ))}
              </select>
            </div>
          </div>

          {metric === 'menu_sales' && (
            <div>
              <label className="block text-[11px] font-semibold text-gray-500 mb-1">메뉴 ID</label>
              <input
                type="text"
                value={metricParam}
                onChange={(e) => setMetricParam(e.target.value)}
                placeholder="모니터링할 메뉴 UUID"
                className="w-full px-3 py-2 border border-gray-200 rounded-lg text-sm font-mono"
              />
            </div>
          )}

          <div className="grid grid-cols-2 gap-2">
            <div>
              <label className="block text-[11px] font-semibold text-gray-500 mb-1">비교 방식</label>
              <select
                value={comparator}
                onChange={(e) => setComparator(e.target.value as RuleComparator)}
                className="w-full px-2 py-2 border border-gray-200 rounded-lg text-sm focus:outline-none focus:border-[#2C1810]"
              >
                {(Object.keys(COMP_LABEL) as RuleComparator[]).map((c) => (
                  <option key={c} value={c}>{COMP_LABEL[c]}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-[11px] font-semibold text-gray-500 mb-1">임계값</label>
              <input
                type="number"
                value={threshold}
                onChange={(e) => setThreshold(Number(e.target.value))}
                step="0.1"
                className="w-full px-3 py-2 border border-gray-200 rounded-lg text-sm focus:outline-none focus:border-[#2C1810]"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-2">
            <div>
              <label className="block text-[11px] font-semibold text-gray-500 mb-1">알림 채널</label>
              <select
                value={channel}
                onChange={(e) => setChannel(e.target.value as RuleChannel)}
                className="w-full px-2 py-2 border border-gray-200 rounded-lg text-sm focus:outline-none focus:border-[#2C1810]"
              >
                {(Object.keys(CHANNEL_LABEL) as RuleChannel[]).map((c) => (
                  <option key={c} value={c}>{CHANNEL_LABEL[c]}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-[11px] font-semibold text-gray-500 mb-1">쿨다운 (시간)</label>
              <input
                type="number"
                value={cooldownH}
                min={1}
                max={168}
                onChange={(e) => setCooldownH(Number(e.target.value))}
                className="w-full px-3 py-2 border border-gray-200 rounded-lg text-sm focus:outline-none focus:border-[#2C1810]"
              />
            </div>
          </div>

          <label className="flex items-center gap-2 cursor-pointer">
            <input
              type="checkbox"
              checked={enabled}
              onChange={(e) => setEnabled(e.target.checked)}
              className="w-4 h-4 accent-[#2C1810]"
            />
            <span className="text-xs text-gray-600">활성화</span>
          </label>

          <p className="text-[10px] text-gray-400 leading-relaxed bg-[#FAFAF8] rounded-lg p-2">
            ⓘ 예: 매출액 + 오늘 vs 지난 7일 평균 + 변동률 + -30 → 평균 대비 30% 이상 떨어지면 알림.<br />
            매일 daily_briefing 시 자동 평가됩니다.
          </p>
        </div>

        <div className="flex gap-2 mt-4">
          <button
            onClick={onCancel}
            className="flex-1 py-2 rounded-lg border border-gray-200 text-gray-600 hover:bg-gray-50 transition-colors text-sm"
          >
            취소
          </button>
          <button
            onClick={submit}
            className="flex-1 py-2 rounded-lg bg-[#2C1810] text-white hover:bg-[#3A2519] transition-colors text-sm font-semibold"
          >
            {initial ? '저장' : '추가'}
          </button>
        </div>
      </div>
    </div>
  )
}
