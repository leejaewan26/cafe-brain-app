// 다크모드 차트 팔레트 (Wave 5E)
// Recharts 컴포넌트에 일관된 다크 테마 적용
// CSS 변수와 동기화되어 런타임 테마 전환 지원

export const CHART_COLORS_LIGHT = {
  primary: '#2C1810',
  accent: '#D4A574',
  success: '#5A9E6F',
  warning: '#D4A574',
  danger: '#E07A5F',
  info: '#4A90A4',
  muted: '#9B9B9B',
  grid: '#f0f0f0',
  text: '#3D3D3A',
  tick: '#87867F',
  background: '#FFFFFF',
  tooltipBg: '#FFFFFF',
  tooltipBorder: '#E5E4DF',
  palette: ['#D4A574', '#2C1810', '#4A90A4', '#5A9E6F', '#E07A5F', '#7B6CB0', '#C89B3C'],
}

export const CHART_COLORS_DARK = {
  primary: '#D4A574',       // 다크 모드에선 액센트가 주 색
  accent: '#E5C19E',        // 밝게
  success: '#7BB890',
  warning: '#D4A574',
  danger: '#F09B82',
  info: '#7BB5C9',
  muted: '#888888',
  grid: '#3A3A3A',
  text: '#C4C4C4',
  tick: '#888888',
  background: '#2D2D2D',
  tooltipBg: '#2D2D2D',
  tooltipBorder: '#3A3A3A',
  palette: ['#D4A574', '#F09B82', '#7BB5C9', '#7BB890', '#E5C19E', '#B5A1D6', '#E3B54E'],
}

/**
 * 현재 테마 기반 차트 색상 팔레트 반환.
 * 컴포넌트에서 `const chart = useChartColors()` 식으로 사용.
 */
export function getChartColors() {
  if (typeof document === 'undefined') return CHART_COLORS_LIGHT
  return document.documentElement.classList.contains('dark')
    ? CHART_COLORS_DARK
    : CHART_COLORS_LIGHT
}

/**
 * 다크모드 토글 시 자동 업데이트되는 팔레트.
 * MutationObserver로 .dark 클래스 변경 감지.
 */
import { useEffect, useState } from 'react'

export function useChartColors() {
  const [colors, setColors] = useState(getChartColors)

  useEffect(() => {
    if (typeof document === 'undefined') return
    const html = document.documentElement

    const update = () => setColors(getChartColors())
    const observer = new MutationObserver(update)
    observer.observe(html, { attributes: true, attributeFilter: ['class'] })
    return () => observer.disconnect()
  }, [])

  return colors
}

// Recharts Tooltip 공통 스타일 객체
export function tooltipStyle(colors: ReturnType<typeof getChartColors>) {
  return {
    backgroundColor: colors.tooltipBg,
    border: `1px solid ${colors.tooltipBorder}`,
    borderRadius: '12px',
    fontSize: '12px',
    color: colors.text,
    padding: '8px 12px',
  }
}
