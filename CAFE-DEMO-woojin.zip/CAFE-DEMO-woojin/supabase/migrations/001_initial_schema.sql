-- Cafe Brain - Supabase 데이터베이스 마이그레이션
-- stores 테이블 (온보딩 데이터 저장)
CREATE TABLE IF NOT EXISTS public.stores (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  store_name text NOT NULL,
  owner_name text NOT NULL,
  district_type text NOT NULL CHECK (district_type IN ('주택가','오피스','대학가','관광지','복합')),
  menu_count integer NOT NULL DEFAULT 10,
  employee_count integer NOT NULL DEFAULT 2,
  avg_monthly_sales numeric NOT NULL DEFAULT 7500000,
  ambiance_keywords text[] NOT NULL DEFAULT '{}',
  target_labor_ratio numeric NOT NULL DEFAULT 0.25,
  created_at timestamptz NOT NULL DEFAULT now()
);

-- RLS 활성화: 본인 데이터만 접근 가능
ALTER TABLE public.stores ENABLE ROW LEVEL SECURITY;

CREATE POLICY "stores: 본인 데이터만 조회" ON public.stores
  FOR SELECT USING (auth.uid() = id);

CREATE POLICY "stores: 본인 데이터만 삽입" ON public.stores
  FOR INSERT WITH CHECK (auth.uid() = id);

CREATE POLICY "stores: 본인 데이터만 수정" ON public.stores
  FOR UPDATE USING (auth.uid() = id);

CREATE POLICY "stores: 본인 데이터만 삭제" ON public.stores
  FOR DELETE USING (auth.uid() = id);

-- ai_cache 테이블 (Gemini 응답 24시간 캐싱)
CREATE TABLE IF NOT EXISTS public.ai_cache (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  cache_key text UNIQUE NOT NULL,
  response text NOT NULL,
  expires_at timestamptz NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);

-- 만료된 캐시 자동 정리 인덱스
CREATE INDEX IF NOT EXISTS idx_ai_cache_expires_at ON public.ai_cache(expires_at);

-- chat_history 테이블 (AI 채팅 이력)
CREATE TABLE IF NOT EXISTS public.chat_history (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  store_id uuid NOT NULL REFERENCES public.stores(id) ON DELETE CASCADE,
  role text NOT NULL CHECK (role IN ('user', 'assistant')),
  message text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.chat_history ENABLE ROW LEVEL SECURITY;

CREATE POLICY "chat_history: 본인 데이터만 접근" ON public.chat_history
  FOR ALL USING (store_id = auth.uid());
