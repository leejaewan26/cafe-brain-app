// 재료 단가 DB 관리 페이지 (Issue #18)
// 사장·점장 모두 조회 가능, 단가 편집은 사장 전용
import { useCallback, useEffect, useMemo, useState } from 'react'
import { Link } from 'react-router-dom'
import {
  Package, ChevronLeft, Plus, Edit3, Trash2, Save, X, Loader2,
  Search, Lock, TrendingUp, TrendingDown,
} from 'lucide-react'
import toast from 'react-hot-toast'
import { supabase } from '@/lib/supabase'
import { useAuthStore } from '@/store/authStore'
import { useProfileStore, canAccess } from '@/store/profileStore'
import { formatCurrency, cn } from '@/lib/utils'
import InvoiceOcrUploader from '@/components/InvoiceOcrUploader'

interface Ingredient {
  id: string
  store_id: string
  name: string
  unit: string
  unit_price: number
  supplier?: string | null
  notes?: string | null
  updated_at: string
  created_at: string
}

const UNIT_OPTIONS = ['g', 'kg', 'ml', 'L', '개', '팩', '봉', '박스']

export default function IngredientsPage() {
  const user = useAuthStore((s) => s.user)
  const activeProfile = useProfileStore((s) => s.activeProfile)
  const canEdit = canAccess(activeProfile, 'financial_info')

  const [items, setItems] = useState<Ingredient[]>([])
  const [loading, setLoading] = useState(true)
  const [search, setSearch] = useState('')
  const [editingId, setEditingId] = useState<string | null>(null)
  const [showAdd, setShowAdd] = useState(false)

  const loadIngredients = useCallback(async () => {
    if (!user) return
    setLoading(true)
    const { data, error } = await supabase
      .from('ingredients')
      .select('*')
      .eq('store_id', user.id)
      .order('name')
    if (error) toast.error(error.message)
    else setItems((data ?? []) as Ingredient[])
    setLoading(false)
  }, [user])

  useEffect(() => {
    // eslint-disable-next-line react-hooks/set-state-in-effect
    if (user) void loadIngredients()
  }, [user, loadIngredients])

  const filtered = useMemo(
    () => items.filter((i) => i.name.toLowerCase().includes(search.toLowerCase())),
    [items, search]
  )

  return (
    <div className="min-h-screen bg-[#FAFAF8] dark:bg-[#1A1A1A]">
      <header className="bg-[#2C1810] text-white px-4 py-3 flex items-center gap-3">
        <Link to="/dashboard" className="hover:text-[#D4A574]">
          <ChevronLeft size={20} />
        </Link>
        <Package size={18} className="text-[#D4A574]" />
        <h1 className="font-bold text-base flex-1">재료 원가 관리</h1>
        {canEdit && (
          <button
            onClick={() => setShowAdd(true)}
            className="flex items-center gap-1 px-3 py-1.5 bg-[#D4A574] text-[#2C1810] rounded-lg text-xs font-semibold hover:bg-[#c4956a]"
          >
            <Plus size={13} /> 재료 추가
          </button>
        )}
      </header>

      <main className="max-w-3xl mx-auto px-4 py-4 space-y-4 pb-24">
        {/* 검색 + 통계 */}
        <div className="grid grid-cols-3 gap-3">
          <div className="col-span-2 relative">
            <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
            <input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="재료명 검색"
              className="w-full pl-9 pr-3 py-2.5 rounded-xl border border-gray-200 dark:border-gray-700 dark:bg-gray-800 dark:text-gray-200 text-sm focus:outline-none focus:ring-2 focus:ring-[#D4A574]"
            />
          </div>
          <div className="bg-white dark:bg-gray-800 rounded-xl p-2.5 border border-gray-100 dark:border-gray-700 text-center">
            <p className="text-[10px] text-gray-400">등록 재료</p>
            <p className="text-base font-bold text-[#2C1810] dark:text-gray-100">{items.length}개</p>
          </div>
        </div>

        {!canEdit && (
          <div className="flex items-center gap-2 p-3 bg-amber-50 border border-amber-100 rounded-xl text-xs text-amber-700">
            <Lock size={12} /> 조회만 가능합니다. 편집은 사장 프로필로 전환 필요.
          </div>
        )}

        {/* F1: 송장 OCR 업로드 — canEdit일 때만 */}
        {canEdit && user && (
          <InvoiceOcrUploader
            onConfirm={async (resp) => {
              const rows = resp.line_items.map((li) => ({
                store_id: user.id,
                name: li.item_name,
                unit: li.unit ?? 'EA',
                unit_price: li.unit_price,
                supplier: resp.supplier_name ?? null,
                notes: `OCR 자동 입력 (${resp.invoice_date ?? '-'})`,
              }))
              const { error } = await supabase.from('ingredients').insert(rows)
              if (error) throw error
              await loadIngredients()
            }}
          />
        )}

        {loading && (
          <div className="flex items-center justify-center py-10">
            <Loader2 className="w-6 h-6 animate-spin text-[#D4A574]" />
          </div>
        )}

        {!loading && filtered.length === 0 && (
          <div className="bg-white dark:bg-gray-800 rounded-2xl p-10 text-center text-gray-400 border border-gray-100 dark:border-gray-700">
            <Package size={28} className="mx-auto mb-2 opacity-30" />
            <p className="text-sm">{search ? '검색 결과 없음' : '아직 재료가 없어요'}</p>
            {canEdit && !search && (
              <button
                onClick={() => setShowAdd(true)}
                className="mt-3 text-xs text-[#D4A574] font-semibold hover:text-[#c4956a]"
              >
                첫 재료 추가 →
              </button>
            )}
          </div>
        )}

        <div className="space-y-2">
          {filtered.map((ing) =>
            editingId === ing.id ? (
              <IngredientEditRow
                key={ing.id}
                ingredient={ing}
                onCancel={() => setEditingId(null)}
                onSaved={() => { setEditingId(null); void loadIngredients() }}
              />
            ) : (
              <IngredientRow
                key={ing.id}
                ingredient={ing}
                canEdit={canEdit}
                onEdit={() => setEditingId(ing.id)}
              />
            )
          )}
        </div>
      </main>

      {showAdd && user && (
        <AddIngredientModal
          storeId={user.id}
          onClose={() => setShowAdd(false)}
          onAdded={() => { setShowAdd(false); void loadIngredients() }}
        />
      )}
    </div>
  )
}

// ─── 재료 카드 (조회) ───
function IngredientRow({ ingredient, canEdit, onEdit }: {
  ingredient: Ingredient
  canEdit: boolean
  onEdit: () => void
}) {
  return (
    <div className="bg-white dark:bg-gray-800 rounded-xl p-3 border border-gray-100 dark:border-gray-700 flex items-center gap-3">
      <div className="w-9 h-9 rounded-lg bg-[#D4A574]/15 flex items-center justify-center shrink-0">
        <Package size={15} className="text-[#D4A574]" />
      </div>
      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-2 flex-wrap">
          <p className="font-semibold text-[#2C1810] dark:text-gray-100 text-sm">{ingredient.name}</p>
          <span className="text-[10px] bg-gray-100 dark:bg-gray-700 text-gray-500 dark:text-gray-400 px-1.5 py-0.5 rounded-full">
            /{ingredient.unit}
          </span>
          {ingredient.supplier && (
            <span className="text-[10px] text-gray-400">{ingredient.supplier}</span>
          )}
        </div>
        <p className="text-xs text-gray-500 dark:text-gray-400 mt-0.5">
          {formatCurrency(ingredient.unit_price)} / {ingredient.unit}
          {ingredient.notes && <span className="ml-2 text-gray-400">· {ingredient.notes}</span>}
        </p>
      </div>
      {canEdit && (
        <button
          onClick={onEdit}
          className="p-1.5 text-gray-400 hover:text-[#2C1810] dark:hover:text-gray-200 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700"
        >
          <Edit3 size={14} />
        </button>
      )}
    </div>
  )
}

// ─── 재료 편집 행 ───
function IngredientEditRow({
  ingredient,
  onCancel,
  onSaved,
}: {
  ingredient: Ingredient
  onCancel: () => void
  onSaved: () => void
}) {
  const [name, setName] = useState(ingredient.name)
  const [unit, setUnit] = useState(ingredient.unit)
  const [unitPrice, setUnitPrice] = useState(ingredient.unit_price)
  const [supplier, setSupplier] = useState(ingredient.supplier ?? '')
  const [saving, setSaving] = useState(false)
  const priceChange = unitPrice - ingredient.unit_price

  const handleSave = async () => {
    if (!name.trim()) { toast.error('재료명 필수'); return }
    setSaving(true)
    const { error } = await supabase
      .from('ingredients')
      .update({
        name: name.trim(),
        unit,
        unit_price: unitPrice,
        supplier: supplier.trim() || null,
        updated_at: new Date().toISOString(),
      })
      .eq('id', ingredient.id)
    if (error) toast.error(error.message)
    else {
      toast.success(priceChange !== 0
        ? `단가 업데이트 (${priceChange > 0 ? '+' : ''}${formatCurrency(priceChange)})`
        : '저장됐어요'
      )
      onSaved()
    }
    setSaving(false)
  }

  const handleDelete = async () => {
    if (!confirm(`"${ingredient.name}" 삭제?`)) return
    const { error } = await supabase.from('ingredients').delete().eq('id', ingredient.id)
    if (error) toast.error(error.message)
    else { toast.success('삭제됨'); onSaved() }
  }

  return (
    <div className="bg-[#D4A574]/5 rounded-xl p-3 border-2 border-[#D4A574] space-y-2">
      <div className="grid grid-cols-12 gap-2">
        <input value={name} onChange={(e) => setName(e.target.value)}
          className="col-span-4 px-2 py-1.5 rounded-lg border border-gray-200 text-sm" placeholder="재료명" />
        <select value={unit} onChange={(e) => setUnit(e.target.value)}
          className="col-span-2 px-2 py-1.5 rounded-lg border border-gray-200 text-sm">
          {UNIT_OPTIONS.map((u) => <option key={u} value={u}>{u}</option>)}
        </select>
        <input type="number" value={unitPrice}
          onChange={(e) => setUnitPrice(Number(e.target.value) || 0)}
          className="col-span-3 px-2 py-1.5 rounded-lg border border-gray-200 text-sm text-right" />
        <input value={supplier} onChange={(e) => setSupplier(e.target.value)}
          className="col-span-3 px-2 py-1.5 rounded-lg border border-gray-200 text-sm" placeholder="공급처" />
      </div>
      {priceChange !== 0 && (
        <p className={cn('text-xs flex items-center gap-1',
          priceChange > 0 ? 'text-red-500' : 'text-green-600')}>
          {priceChange > 0 ? <TrendingUp size={12} /> : <TrendingDown size={12} />}
          단가 {priceChange > 0 ? '+' : ''}{formatCurrency(priceChange)}
          ({((priceChange / ingredient.unit_price) * 100).toFixed(1)}%)
        </p>
      )}
      <div className="flex gap-2">
        <button onClick={handleDelete}
          className="px-3 py-1.5 text-xs text-red-500 border border-red-200 rounded-lg hover:bg-red-50">
          <Trash2 size={11} className="inline mr-1" /> 삭제
        </button>
        <div className="flex-1" />
        <button onClick={onCancel} className="px-3 py-1.5 text-xs border border-gray-200 rounded-lg text-gray-600">
          <X size={11} className="inline" /> 취소
        </button>
        <button onClick={handleSave} disabled={saving}
          className="px-3 py-1.5 text-xs bg-[#2C1810] text-white rounded-lg disabled:opacity-50">
          {saving ? <Loader2 size={11} className="inline animate-spin" /> : <><Save size={11} className="inline mr-1" /> 저장</>}
        </button>
      </div>
    </div>
  )
}

// ─── 재료 추가 모달 ───
function AddIngredientModal({ storeId, onClose, onAdded }: {
  storeId: string; onClose: () => void; onAdded: () => void
}) {
  const [name, setName] = useState('')
  const [unit, setUnit] = useState(UNIT_OPTIONS[0])
  const [unitPrice, setUnitPrice] = useState(0)
  const [supplier, setSupplier] = useState('')
  const [notes, setNotes] = useState('')
  const [saving, setSaving] = useState(false)

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => { if (e.key === 'Escape') onClose() }
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [onClose])

  const handleAdd = async () => {
    if (!name.trim()) { toast.error('재료명 필수'); return }
    setSaving(true)
    const { error } = await supabase.from('ingredients').insert({
      store_id: storeId,
      name: name.trim(),
      unit,
      unit_price: unitPrice,
      supplier: supplier.trim() || null,
      notes: notes.trim() || null,
    })
    if (error) toast.error(error.message)
    else { toast.success('추가됐어요'); onAdded() }
    setSaving(false)
  }

  return (
    <div role="dialog" aria-modal="true"
      className="fixed inset-0 bg-black/50 flex items-end md:items-center justify-center z-50 md:p-4"
      onClick={(e) => { if (e.target === e.currentTarget) onClose() }}
    >
      <div className="bg-white dark:bg-gray-800 w-full md:max-w-md md:rounded-2xl rounded-t-3xl p-5 space-y-3">
        <div className="flex items-center justify-between">
          <h3 className="font-bold text-[#2C1810] dark:text-gray-100">새 재료 추가</h3>
          <button onClick={onClose} aria-label="닫기"><X size={18} /></button>
        </div>
        <input value={name} onChange={(e) => setName(e.target.value)} placeholder="재료명 (예: 원두)"
          className="w-full px-3 py-2 rounded-xl border border-gray-200 dark:border-gray-700 dark:bg-gray-700 dark:text-gray-100 text-sm focus:outline-none focus:ring-2 focus:ring-[#D4A574]" />
        <div className="grid grid-cols-2 gap-2">
          <select value={unit} onChange={(e) => setUnit(e.target.value)}
            className="px-3 py-2 rounded-xl border border-gray-200 dark:border-gray-700 dark:bg-gray-700 dark:text-gray-100 text-sm">
            {UNIT_OPTIONS.map((u) => <option key={u} value={u}>{u}</option>)}
          </select>
          <input type="number" value={unitPrice || ''}
            onChange={(e) => setUnitPrice(Number(e.target.value) || 0)}
            placeholder="단가 (원)"
            className="px-3 py-2 rounded-xl border border-gray-200 dark:border-gray-700 dark:bg-gray-700 dark:text-gray-100 text-sm" />
        </div>
        <input value={supplier} onChange={(e) => setSupplier(e.target.value)} placeholder="공급처 (선택)"
          className="w-full px-3 py-2 rounded-xl border border-gray-200 dark:border-gray-700 dark:bg-gray-700 dark:text-gray-100 text-sm" />
        <textarea value={notes} onChange={(e) => setNotes(e.target.value)} placeholder="메모 (선택)" rows={2}
          className="w-full px-3 py-2 rounded-xl border border-gray-200 dark:border-gray-700 dark:bg-gray-700 dark:text-gray-100 text-sm resize-none" />
        <div className="flex gap-2 pt-2">
          <button onClick={onClose} className="flex-1 py-2 border border-gray-200 rounded-xl text-sm text-gray-600">취소</button>
          <button onClick={handleAdd} disabled={saving}
            className="flex-1 py-2 bg-[#2C1810] text-white rounded-xl text-sm font-semibold disabled:opacity-50">
            {saving ? '추가 중...' : '추가'}
          </button>
        </div>
      </div>
    </div>
  )
}
