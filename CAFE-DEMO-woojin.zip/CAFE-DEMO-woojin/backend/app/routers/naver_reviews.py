"""
H2 — 네이버 리뷰 자동 수집

전략 (3중 레이어):
  L1. 네이버 검색 API: 매장명 → place_id 매칭 (NAVER_CLIENT_ID/SECRET 필요)
  L2. 네이버 Reservation API: 예약 + 후기 (사업자 인증 필요)
  L3. 수동 URL 입력 fallback: 사장님이 네이버 지도 URL 붙여넣기 → 메타 정보 추출

스크래핑은 ToS 위반이므로 절대 X. API 권한 없는 사장님은 L3로 안내.

DB 스키마: reviews 테이블의 source 컬럼 (manual / naver_api / naver_url / kakao 등)
"""
import asyncio
import logging
import re
from datetime import datetime, timezone
from typing import Optional
from urllib.parse import quote

import httpx
from fastapi import APIRouter, Header, HTTPException
from pydantic import BaseModel, Field, HttpUrl

from app.config import settings
from app.services.gemini_service import _get_supabase

logger = logging.getLogger("naver_reviews")
router = APIRouter()


class NaverPlaceSearchResponse(BaseModel):
    candidates: list[dict]
    note: Optional[str] = None


@router.get("/search-place", response_model=NaverPlaceSearchResponse)
async def search_naver_place(query: str):
    """
    매장명으로 네이버 검색 → 후보 매장 목록 반환.
    사장님이 본인 매장을 선택하면 place_id를 stores.naver_place_id에 저장.

    네이버 검색 API: https://openapi.naver.com/v1/search/local.json
    """
    client_id = getattr(settings, "naver_client_id", "") or ""
    client_secret = getattr(settings, "naver_client_secret", "") or ""

    if not client_id or not client_secret:
        return NaverPlaceSearchResponse(
            candidates=[],
            note="네이버 검색 API 미설정. 환경변수 NAVER_CLIENT_ID/SECRET 필요.",
        )

    try:
        async with httpx.AsyncClient(timeout=10.0) as client:
            r = await client.get(
                "https://openapi.naver.com/v1/search/local.json",
                params={"query": query, "display": 10, "sort": "comment"},
                headers={
                    "X-Naver-Client-Id": client_id,
                    "X-Naver-Client-Secret": client_secret,
                },
            )
            if r.status_code != 200:
                raise HTTPException(r.status_code, detail=r.text[:200])
            data = r.json()
            items = data.get("items", [])
            # 정제
            candidates = []
            for it in items:
                # title은 <b>HTML</b> 포함 → strip
                title = re.sub(r"<[^>]+>", "", it.get("title", ""))
                candidates.append({
                    "title": title,
                    "category": it.get("category", ""),
                    "address": it.get("address", ""),
                    "road_address": it.get("roadAddress", ""),
                    "telephone": it.get("telephone", ""),
                    "link": it.get("link", ""),
                    # network ID는 link URL 끝에 있는 경우가 많음
                    "place_id_hint": _extract_place_id(it.get("link", "")),
                })
            return NaverPlaceSearchResponse(candidates=candidates)
    except HTTPException:
        raise
    except Exception as e:
        logger.warning("네이버 검색 실패: %s", e)
        return NaverPlaceSearchResponse(
            candidates=[],
            note=f"검색 실패: {str(e)[:80]}",
        )


def _extract_place_id(link: str) -> Optional[str]:
    """링크 URL에서 place_id 추출 (예: place.map.naver.com/12345678)."""
    m = re.search(r"/place/(\d+)", link) or re.search(r"placeId=(\d+)", link) or re.search(r"map\.naver\.com/.*?(\d{6,})", link)
    return m.group(1) if m else None


class LinkPlaceRequest(BaseModel):
    store_id: str = Field(..., min_length=1)
    naver_place_id: str
    naver_place_name: str


@router.post("/link-place")
async def link_naver_place(req: LinkPlaceRequest):
    """매장에 네이버 place_id 매핑."""
    sb = _get_supabase()
    if sb is None:
        raise HTTPException(503, "Supabase 미설정")

    await asyncio.to_thread(
        lambda: sb.table("stores")
        .update({
            "naver_place_id": req.naver_place_id,
            "naver_place_name": req.naver_place_name,
        })
        .eq("id", req.store_id)
        .execute()
    )
    return {"linked": True, "place_id": req.naver_place_id}


# ─── L2: Reservation API (사업자 인증 후 사용 가능) ─────────────


@router.post("/sync-reservation/{store_id}")
async def sync_naver_reservation_reviews(
    store_id: str,
    admin_key: str = Header(default="", alias="X-Admin-Key"),
):
    """
    네이버 예약 API로 후기 동기화.

    실제 호출: GET /restaurant/v3.2/businesses/{businessId}/reviews
    필요: NAVER_RESERVATION_TOKEN (사업자 단위 발급)

    구현 단계:
      1) settings에서 토큰 + businessId 매핑 확인
      2) 토스 호출 → 새 review만 INSERT (멱등 — review.naver_review_id UNIQUE)
      3) 결과 반환
    """
    expected = settings.agent_admin_key or ""
    if not expected or admin_key != expected:
        raise HTTPException(403, "권한 없음")

    sb = _get_supabase()
    if sb is None:
        raise HTTPException(503, "Supabase 미설정")

    # stores에서 business_id 조회
    res = await asyncio.to_thread(
        lambda: sb.table("stores")
        .select("naver_business_id, naver_place_id, name")
        .eq("id", store_id)
        .single()
        .execute()
    )
    row = res.data or {}
    business_id = row.get("naver_business_id")
    if not business_id:
        raise HTTPException(400, "naver_business_id 미연결")

    token = getattr(settings, "naver_reservation_token", "") or ""
    if not token:
        return {
            "synced": 0,
            "note": "네이버 예약 API 토큰 미설정 — 임시로 stub 응답",
            "store_name": row.get("name"),
            "business_id": business_id,
        }

    # 실 호출
    try:
        async with httpx.AsyncClient(timeout=15.0) as client:
            r = await client.get(
                f"https://partner.booking.naver.com/restaurant/v3.2/businesses/{business_id}/reviews",
                headers={"Authorization": f"Bearer {token}"},
                params={"size": 50},
            )
            if r.status_code != 200:
                raise HTTPException(r.status_code, detail=r.text[:200])
            data = r.json()
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(500, f"네이버 호출 실패: {str(e)[:100]}")

    # INSERT (중복은 review_naver_id UNIQUE 제약으로 차단)
    new_count = 0
    for rev in data.get("reviews", []):
        try:
            await asyncio.to_thread(
                lambda r=rev: sb.table("reviews").insert({
                    "store_id": store_id,
                    "rating": r.get("rating", 5),
                    "content": r.get("body", ""),
                    "author": r.get("author", "익명"),
                    "source": "naver_api",
                    "naver_review_id": str(r.get("id")),
                    "created_at": r.get("createdAt", datetime.now(timezone.utc).isoformat()),
                    "replied": bool(r.get("reply")),
                }).execute()
            )
            new_count += 1
        except Exception:
            pass  # 중복 등 — skip

    return {"synced": new_count, "total_fetched": len(data.get("reviews", []))}


# ─── L3: 수동 URL 붙여넣기 (모든 사장님 사용 가능) ──────────────


class ManualReviewImportRequest(BaseModel):
    store_id: str
    naver_url: HttpUrl
    rating: int = Field(..., ge=1, le=5)
    content: str = Field(..., min_length=2, max_length=2000)
    author: Optional[str] = "네이버 후기"
    review_date: Optional[str] = None


# ─── L4: 답글 발송 (Reply API) ────────────────────────────────


class ReplyRequest(BaseModel):
    store_id: str
    review_id: str  # internal reviews.id
    content: str = Field(..., min_length=2, max_length=1000)
    auto_generated: bool = False


@router.post("/reply")
async def reply_to_review(req: ReplyRequest):
    """
    리뷰에 답글 발송.

    - source = naver_api 인 리뷰만 실 발송 (Naver Reservation API)
    - 그 외는 internal에만 저장 (네이버 답글은 사장님이 수동으로 복붙)

    실제 호출:
      POST partner.booking.naver.com/restaurant/v3.2/businesses/{biz}/reviews/{nrid}/reply
    """
    sb = _get_supabase()
    if sb is None:
        raise HTTPException(503, "Supabase 미설정")

    # 권한 + 리뷰 조회
    rev_res = await asyncio.to_thread(
        lambda: sb.table("reviews")
        .select("source, naver_review_id, store_id")
        .eq("id", req.review_id)
        .eq("store_id", req.store_id)
        .single()
        .execute()
    )
    rev = rev_res.data
    if not rev:
        raise HTTPException(404, "리뷰를 찾을 수 없습니다")

    posted_externally = False

    if rev.get("source") == "naver_api" and rev.get("naver_review_id"):
        # 네이버 비즈니스 ID 조회
        store_res = await asyncio.to_thread(
            lambda: sb.table("stores")
            .select("naver_business_id")
            .eq("id", req.store_id)
            .single()
            .execute()
        )
        biz_id = (store_res.data or {}).get("naver_business_id")
        token = getattr(settings, "naver_reservation_token", "") or ""

        if biz_id and token:
            try:
                async with httpx.AsyncClient(timeout=15.0) as client:
                    r = await client.post(
                        f"https://partner.booking.naver.com/restaurant/v3.2/businesses/{biz_id}/reviews/{rev['naver_review_id']}/reply",
                        headers={
                            "Authorization": f"Bearer {token}",
                            "Content-Type": "application/json",
                        },
                        json={"body": req.content},
                    )
                    if r.status_code in (200, 201):
                        posted_externally = True
                    else:
                        logger.warning("네이버 답글 실패 %s: %s", r.status_code, r.text[:200])
            except Exception as e:
                logger.warning("네이버 답글 호출 예외: %s", e)

    # internal에 저장 (replied=true)
    await asyncio.to_thread(
        lambda: sb.table("reviews")
        .update({
            "replied": True,
            "reply_content": req.content,
            "reply_posted_externally": posted_externally,
            "reply_at": datetime.now(timezone.utc).isoformat(),
            "reply_auto_generated": req.auto_generated,
        })
        .eq("id", req.review_id)
        .execute()
    )

    return {
        "replied": True,
        "posted_externally": posted_externally,
        "note": "네이버 외부 발송 완료" if posted_externally else "내부 저장만 — 네이버 답글은 직접 복사 필요",
    }


@router.post("/import-manual")
async def import_manual_review(req: ManualReviewImportRequest):
    """
    사장님이 직접 네이버 리뷰 URL + 본문을 붙여넣어 가져오는 fallback.
    스크래핑 없이 사장님이 직접 입력 → 검열·진위 확보.
    """
    sb = _get_supabase()
    if sb is None:
        raise HTTPException(503, "Supabase 미설정")

    res = await asyncio.to_thread(
        lambda: sb.table("reviews").insert({
            "store_id": req.store_id,
            "rating": req.rating,
            "content": req.content,
            "author": req.author,
            "source": "naver_url",
            "source_url": str(req.naver_url),
            "created_at": req.review_date or datetime.now(timezone.utc).isoformat(),
            "replied": False,
        }).execute()
    )
    return {"imported": True, "review_id": (res.data or [{}])[0].get("id")}
