// I7 — H/I 배치 신규 기능 스모크 테스트
// 페이지 로드, 핵심 UI 노출 여부만 빠르게 확인 (실제 결제·연결은 모킹 필요)
import { test, expect } from '@playwright/test'

test.describe('H/I 신규 기능 스모크', () => {
  test('1. /agent-tools 페이지 로드 + 4탭 노출', async ({ page }) => {
    await page.goto('/agent-tools')
    await expect(page.getByRole('heading', { name: '에이전트 도구' })).toBeVisible({ timeout: 10000 })
    await expect(page.getByText('전략 분해', { exact: false })).toBeVisible()
    await expect(page.getByText('A/B 비교', { exact: false })).toBeVisible()
    await expect(page.getByText('메모리 검색', { exact: false })).toBeVisible()
    await expect(page.getByText('감사 로그', { exact: false })).toBeVisible()
  })

  test('2. /integrations 페이지 — 4탭 (네이버/POS/IG/n8n)', async ({ page }) => {
    await page.goto('/integrations')
    await expect(page.getByRole('heading', { name: '외부 연동' })).toBeVisible({ timeout: 10000 })
    await expect(page.getByText('네이버')).toBeVisible()
    await expect(page.getByText('POS')).toBeVisible()
    await expect(page.getByText('Instagram')).toBeVisible()
  })

  test('3. /admin 페이지 — 키 게이트 노출', async ({ page }) => {
    await page.goto('/admin')
    await expect(page.getByText('운영자 인증')).toBeVisible({ timeout: 10000 })
    await expect(page.getByPlaceholder('Admin 키')).toBeVisible()
  })

  test('4. /billing 페이지 — 플랜 카드 + 결제 버튼', async ({ page }) => {
    await page.goto('/billing')
    await expect(page.getByText(/요금제/i)).toBeVisible({ timeout: 10000 })
    await expect(page.getByText(/토스로 안전 결제/)).toBeVisible()
  })

  test('5. 언어 토글 — 한 ↔ EN', async ({ page }) => {
    await page.goto('/dashboard')
    // 사이드바 하단 언어 스위처
    const switcher = page.locator('button[title*="Switch"], button[title*="전환"]').first()
    await expect(switcher).toBeVisible({ timeout: 10000 })
  })
})
