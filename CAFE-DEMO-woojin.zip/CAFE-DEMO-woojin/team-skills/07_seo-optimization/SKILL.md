---
name: seo-optimization
description: This skill should be used when the user asks to audit a website for SEO, improve search rankings, fix technical SEO issues, analyze schema markup, optimize for Google AI Overviews, improve page speed, set up Google Search Console or GA4, create an SEO strategy, do keyword research, optimize meta tags, or improve local SEO. Activates on phrases like "SEO", "검색 최적화", "구글 순위", "메타 태그", "schema", "sitemap", "페이지 속도", "PageSpeed", "Search Console", "키워드", "백링크".
version: 1.0.0
---

# SEO Optimization Skill

Comprehensive SEO analysis and optimization covering technical SEO, content quality, schema markup, AI search optimization, local SEO, and Google API integrations.

> Based on: https://github.com/AgriciDaniel/claude-seo

## When This Skill Applies

Activate when the user needs:
- Full site SEO audits
- Technical SEO fixes (crawlability, Core Web Vitals, sitemaps)
- On-page optimization (meta tags, headings, content)
- Schema markup generation and validation
- AI search optimization (Google AI Overviews, LLM citation optimization)
- Local SEO and Google Business Profile
- Google API integration (Search Console, PageSpeed, GA4)
- Competitive SEO analysis

---

## Full Site Audit Framework

Run these 9 categories in parallel for comprehensive coverage:

### 1. Technical SEO
- **Crawlability**: robots.txt, noindex tags, canonical URLs
- **Indexability**: XML sitemap present and submitted, pages in Google index
- **URL structure**: clean, descriptive, no dynamic parameters
- **HTTPS**: SSL cert valid, HTTP redirects to HTTPS, no mixed content
- **Core Web Vitals**: LCP < 2.5s, INP < 200ms, CLS < 0.1
- **Mobile-first**: responsive design, viewport meta tag, tap targets ≥ 48px

### 2. On-Page SEO
- Title tags: 50-60 chars, primary keyword near front, unique per page
- Meta descriptions: 150-160 chars, compelling, includes keyword
- H1: one per page, matches search intent
- H2/H3: logical hierarchy, include semantic keywords
- Image alt text: descriptive, keyword-relevant where natural
- Internal linking: 3-5 relevant internal links per page

### 3. Content Quality (E-E-A-T)
- **Experience**: Real examples, case studies, first-hand knowledge
- **Expertise**: Author credentials, depth of coverage, citations
- **Authoritativeness**: Domain authority, backlink profile, brand mentions
- **Trustworthiness**: Privacy policy, contact info, security badges, reviews
- Content length: match to search intent (informational = longer, transactional = concise)
- Thin content: flag pages < 300 words without clear purpose

### 4. Schema Markup
Generate and validate JSON-LD for:
- `Organization` / `WebSite` (homepage)
- `Article` / `BlogPosting` (content pages)
- `Product` / `Offer` (e-commerce)
- `FAQPage` (FAQ sections)
- `HowTo` (tutorial content)
- `LocalBusiness` (local SEO)
- `VideoObject` (video content)
- `BreadcrumbList` (site navigation)

Validation: test with Google Rich Results Test, Schema.org validator

### 5. Image Optimization
- Format: WebP/AVIF preferred, JPEG for photos, PNG for transparency
- Compression: aim < 100KB for most images
- Lazy loading: `loading="lazy"` for below-fold images
- Dimensions: specify width/height to prevent CLS
- CDN: serve images from CDN when possible

### 6. Sitemap Architecture
- XML sitemap: include all canonical URLs, exclude noindex pages
- Priority: 1.0 for homepage, 0.8 for main sections, 0.6 for regular pages
- Changefreq: align with actual update frequency
- Image sitemap: include for image-heavy sites
- Video sitemap: include for video content
- Submit to Google Search Console and Bing Webmaster Tools

### 7. AI Search Optimization (GEO)
Optimize for Google AI Overviews and LLM citations:
- **Structured answers**: Use clear H2/H3 questions + direct answer paragraphs
- **Definition boxes**: Define key terms at top of page
- **Numbered/bulleted lists**: AI prefers scannable structured content
- **Factual claims**: Include statistics with sources
- **Entity optimization**: Mention related entities (people, places, organizations)
- **FAQ sections**: Target conversational queries
- **Speakable schema**: Mark content suitable for voice/AI reading

### 8. Local SEO
- Google Business Profile: complete all fields, add photos, respond to reviews
- NAP consistency: Name, Address, Phone identical across all citations
- Local citations: Yelp, Yellow Pages, industry directories
- Local schema: `LocalBusiness` with `geo` coordinates, opening hours
- Location pages: unique content per location, embed Google Map
- Reviews: respond to all reviews within 24h

### 9. Core Web Vitals
```
LCP (Largest Contentful Paint) target: < 2.5s
  Fixes: preload hero image, optimize server response, use CDN

INP (Interaction to Next Paint) target: < 200ms
  Fixes: reduce JavaScript execution, defer non-critical scripts

CLS (Cumulative Layout Shift) target: < 0.1
  Fixes: explicit image dimensions, avoid inserting content above existing
```

---

## Google API Integrations

### Search Console
- Check: coverage errors, manual actions, security issues
- Top queries: identify pages ranking 4-10 (quick win opportunities)
- CTR optimization: improve titles/descriptions for low-CTR pages ranking well

### PageSpeed Insights / CrUX
- Field data: real user metrics by page, device type, connection speed
- Lab data: Lighthouse scores for actionable recommendations
- Compare: desktop vs. mobile performance gaps

### GA4
- Key events: identify highest-converting pages
- Bounce rate by landing page: flag underperforming entry points
- Search queries: cross-reference with Search Console

---

## Competitive Analysis

1. Identify top 5 competitors for target keywords
2. Analyze: domain authority, backlink profiles, content gaps
3. SERP feature analysis: who owns featured snippets, PAA boxes
4. Content gap: topics competitors rank for that you don't cover
5. Backlink opportunities: sites linking to competitors but not you

---

## Programmatic SEO

For scaling to hundreds/thousands of pages:
- Template: one strong template with variable data injection
- Data source: CSV, database, or API-driven
- Unique value: each page must have unique, useful content (not just data swap)
- Internal linking: faceted navigation, breadcrumbs, category pages
- Canonicalization: prevent duplicate content across parameter variations
- Quality threshold: minimum content length and uniqueness check before publishing

---

## Quick Win Checklist

- [ ] Title tags unique and keyword-optimized
- [ ] Meta descriptions written for all key pages
- [ ] Core Web Vitals pass on mobile
- [ ] Schema markup on homepage and key pages
- [ ] XML sitemap submitted to Search Console
- [ ] robots.txt not blocking important pages
- [ ] Internal links from high-authority pages to target pages
- [ ] Images compressed and have alt text
- [ ] HTTPS with no mixed content warnings
- [ ] Google Business Profile complete (if local business)
