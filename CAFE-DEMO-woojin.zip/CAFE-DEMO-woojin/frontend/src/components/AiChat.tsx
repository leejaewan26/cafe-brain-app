// AI 어시스턴트 플로팅 채팅 컴포넌트
// - 우측 하단 커피잔 아이콘 버튼
// - 슬라이드업 채팅 패널 (마크다운 렌더링)
// - 예시 질문 버블, 세션 사이드바
// - Rule 3: Gemini 백엔드 경유, AI 배지 표시
import { useState, useRef, useEffect, useCallback } from 'react'
import {
  Coffee, X, Send, Plus, Trash2, Copy, Check,
  Loader2, Sparkles,
  AlignLeft, Image as ImageIcon,
  Volume2, VolumeX, Mic, MicOff, Search,
} from 'lucide-react'
import ChatHistorySearch from '@/components/ChatHistorySearch'
import { useChatStore } from '@/store/chatStore'
import { useStoreContext } from '@/hooks/useStoreContext'
import { useMenuStore } from '@/store/menuStore'
import { useSettingsStore } from '@/store/settingsStore'
import { useAuthStore } from '@/store/authStore'
import AiFeedback from '@/components/AiFeedback'
import { useTTS } from '@/hooks/useTTS'
import { useSTT } from '@/hooks/useSTT'
import { cn } from '@/lib/utils'

// ─── 예시 질문 ───
const EXAMPLE_QUESTIONS = [
  { emoji: '🌧️', text: '비 오는 날 인스타 문구 써줘', short: '인스타 문구' },
  { emoji: '💰', text: '원두값 15% 오르면 아메리카노 가격 얼마로 올려야 해?', short: '원가 계산' },
  { emoji: '🌍', text: '외국인 손님용 원두 영어 소개 대본 만들어줘 (한글 발음 포함)', short: '영어 대본' },
  { emoji: '📋', text: '오늘 마감 체크리스트 보여줘', short: '마감 체크리스트' },
  { emoji: '📊', text: '이번 달 매출 요약해 줘', short: '매출 요약' },
]

// ─── 간이 마크다운 렌더러 ───
// React-markdown 없이 기본 패턴만 처리 (표, 코드블록, 리스트, 볼드)
function MarkdownContent({ content }: { content: string }) {
  const renderLine = (line: string, idx: number): React.ReactNode => {
    // 코드블록은 위에서 처리되므로 일반 라인
    // ## 헤딩
    if (line.startsWith('## ')) {
      return <h3 key={idx} className="text-sm font-bold text-[#2C1810] mt-3 mb-1">{line.slice(3)}</h3>
    }
    if (line.startsWith('# ')) {
      return <h2 key={idx} className="text-base font-bold text-[#2C1810] mt-3 mb-1">{line.slice(2)}</h2>
    }
    // 구분선
    if (/^---+$/.test(line.trim())) {
      return <hr key={idx} className="border-gray-200 my-2" />
    }
    // 리스트 항목 (체크박스)
    if (/^- \[[ x]\]/.test(line)) {
      const checked = line.startsWith('- [x]')
      const text = line.replace(/^- \[[ x]\]\s*/, '')
      return (
        <div key={idx} className="flex items-start gap-2 py-0.5">
          <span className="text-sm mt-0.5">{checked ? '✅' : '☐'}</span>
          <span className="text-sm text-gray-700">{renderInline(text)}</span>
        </div>
      )
    }
    // 리스트 항목
    if (line.startsWith('- ') || line.startsWith('• ')) {
      const text = line.replace(/^[•-]\s*/, '')
      return (
        <div key={idx} className="flex items-start gap-2 py-0.5">
          <span className="text-[#D4A574] mt-1 text-xs">▸</span>
          <span className="text-sm text-gray-700 flex-1">{renderInline(text)}</span>
        </div>
      )
    }
    // 번호 리스트
    if (/^\d+\.\s/.test(line)) {
      const match = line.match(/^(\d+)\.\s(.*)/)
      if (match) {
        return (
          <div key={idx} className="flex items-start gap-2 py-0.5">
            <span className="text-xs font-bold text-[#D4A574] w-5 shrink-0 pt-0.5">{match[1]}.</span>
            <span className="text-sm text-gray-700 flex-1">{renderInline(match[2])}</span>
          </div>
        )
      }
    }
    // 표 헤더/행
    if (line.startsWith('|')) {
      return null // 표는 별도로 처리
    }
    // 빈 줄
    if (!line.trim()) {
      return <div key={idx} className="h-1.5" />
    }
    // 일반 텍스트
    return <p key={idx} className="text-sm text-gray-700 leading-relaxed">{renderInline(line)}</p>
  }

  // 인라인 마크다운 (볼드, 이탤릭, 백틱)
  const renderInline = (text: string): React.ReactNode => {
    const parts = text.split(/(\*\*[^*]+\*\*|`[^`]+`|\*[^*]+\*)/g)
    return parts.map((part, i) => {
      if (part.startsWith('**') && part.endsWith('**')) {
        return <strong key={i} className="font-bold text-[#2C1810]">{part.slice(2, -2)}</strong>
      }
      if (part.startsWith('`') && part.endsWith('`')) {
        return <code key={i} className="bg-gray-100 px-1 rounded text-xs font-mono text-[#2C1810]">{part.slice(1, -1)}</code>
      }
      if (part.startsWith('*') && part.endsWith('*')) {
        return <em key={i} className="italic text-gray-600">{part.slice(1, -1)}</em>
      }
      return part
    })
  }

  // 표 처리
  const renderTable = (tableLines: string[], startIdx: number): React.ReactNode => {
    const rows = tableLines.filter((l) => l.includes('|') && !l.match(/^[\s|:-]+$/))
    if (rows.length < 1) return null
    const parseRow = (row: string) =>
      row.split('|').map((cell) => cell.trim()).filter((_, i, arr) => i > 0 && i < arr.length - 1)
    const [header, ...body] = rows
    return (
      <div key={startIdx} className="overflow-x-auto my-2 rounded-lg border border-gray-200">
        <table className="text-xs w-full">
          <thead className="bg-[#2C1810] text-white">
            <tr>{parseRow(header).map((cell, i) => <th key={i} className="px-3 py-1.5 text-left font-semibold">{cell}</th>)}</tr>
          </thead>
          <tbody>
            {body.map((row, ri) => (
              <tr key={ri} className={ri % 2 === 0 ? 'bg-white' : 'bg-gray-50'}>
                {parseRow(row).map((cell, ci) => <td key={ci} className="px-3 py-1.5 text-gray-700">{cell}</td>)}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    )
  }

  // 전처리: 코드블록, 표 분리
  const lines = content.split('\n')
  const nodes: React.ReactNode[] = []
  let i = 0

  while (i < lines.length) {
    // 코드블록
    if (lines[i].startsWith('```')) {
      const lang = lines[i].slice(3).trim()
      const codeLines: string[] = []
      i++
      while (i < lines.length && !lines[i].startsWith('```')) {
        codeLines.push(lines[i])
        i++
      }
      nodes.push(
        <div key={i} className="my-2 rounded-xl bg-[#1A1A1A] p-3 overflow-x-auto">
          {lang && <p className="text-xs text-gray-400 mb-1">{lang}</p>}
          <pre className="text-xs text-green-300 font-mono whitespace-pre-wrap">{codeLines.join('\n')}</pre>
        </div>
      )
      i++ // closing ```
      continue
    }
    // 표 블록
    if (lines[i].startsWith('|')) {
      const tableLines: string[] = []
      const startIdx = i
      while (i < lines.length && (lines[i].startsWith('|') || lines[i].match(/^[\s|:-]+$/))) {
        tableLines.push(lines[i])
        i++
      }
      nodes.push(renderTable(tableLines, startIdx))
      continue
    }
    nodes.push(renderLine(lines[i], i))
    i++
  }

  return <div className="space-y-px">{nodes}</div>
}

// ─── 메시지 버블 ───
function MessageBubble({ msg }: { msg: { id: string; role: string; content: string; timestamp: string } }) {
  const [copied, setCopied] = useState(false)
  const isUser = msg.role === 'user'
  // Bonus E3: TTS — 어시스턴트 메시지에만 노출
  const { supported: ttsSupported, speaking, speak, stop } = useTTS()
  const isThisSpeaking = speaking // 글로벌 1개만 재생 — 다른 메시지가 재생 중이면 false 표시되지만 stop이면 모두 멈춤

  const handleCopy = async () => {
    await navigator.clipboard.writeText(msg.content)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  const handleSpeak = () => {
    if (isThisSpeaking) stop()
    else speak(msg.content)
  }

  return (
    <div className={cn('flex gap-2 group', isUser ? 'flex-row-reverse' : 'flex-row')}>
      {/* 아바타 */}
      {!isUser && (
        <div className="w-7 h-7 rounded-full bg-gradient-to-br from-[#D4A574] to-[#2C1810] flex items-center justify-center shrink-0 mt-1">
          <Coffee size={13} className="text-white" />
        </div>
      )}

      <div className={cn('max-w-[82%] space-y-1', isUser ? 'items-end flex flex-col' : '')}>
        <div className={cn(
          'rounded-2xl px-3.5 py-2.5',
          isUser
            ? 'bg-[#2C1810] text-white rounded-tr-sm'
            : 'bg-white border border-gray-100 shadow-sm rounded-tl-sm'
        )}>
          {isUser ? (
            <p className="text-sm text-white leading-relaxed">{msg.content}</p>
          ) : (
            <MarkdownContent content={msg.content} />
          )}
        </div>

        {/* AI 배지 + 복사 + TTS + 피드백 (학습 신호) */}
        {!isUser && (
          <>
            <div className="flex items-center gap-2 opacity-0 group-hover:opacity-100 transition-opacity duration-200">
              <span className="text-xs text-gray-400 italic">ⓘ AI가 생성한 콘텐츠</span>
              <button
                onClick={handleCopy}
                className="flex items-center gap-1 text-xs text-gray-400 hover:text-[#2C1810] transition-colors"
              >
                {copied ? <><Check size={10} /> 복사됨</> : <><Copy size={10} /> 복사</>}
              </button>
              {ttsSupported && (
                <button
                  onClick={handleSpeak}
                  className={cn(
                    'flex items-center gap-1 text-xs transition-colors',
                    isThisSpeaking ? 'text-[#D4A574]' : 'text-gray-400 hover:text-[#2C1810]',
                  )}
                  title={isThisSpeaking ? '음성 정지' : '음성으로 듣기'}
                >
                  {isThisSpeaking ? <><VolumeX size={10} /> 정지</> : <><Volume2 size={10} /> 듣기</>}
                </button>
              )}
            </div>
            <AiFeedback sourceType="chat_message" sourceRef={`chat-${msg.id}`} compact />
          </>
        )}
        <span className={cn('text-xs text-gray-400', isUser ? 'text-right' : '')}>
          {new Date(msg.timestamp).toLocaleTimeString('ko-KR', { hour: '2-digit', minute: '2-digit' })}
        </span>
      </div>
    </div>
  )
}

// ═══════════════════════════════════════════════════════
// ─── 메인 AiChat 컴포넌트 ───
// ═══════════════════════════════════════════════════════
export default function AiChat() {
  const {
    sessions, activeSessionId, isPanelOpen,
    togglePanel, closePanel, newSession,
    setActiveSession, addMessage, deleteSession,
  } = useChatStore()

  const { storeInfo, buildPromptContext } = useStoreContext()
  const { menus } = useMenuStore()
  // Day 6-2: 사장님 선호 어조 + 매장 ID (메모리 추출용)
  const defaultTone = useSettingsStore((s) => s.defaultTone)
  const storeId = useAuthStore((s) => s.user?.id)

  const [input, setInput] = useState('')
  const [isLoading, setIsLoading] = useState(false)
  const [showSidebar, setShowSidebar] = useState(false)
  const [hasUnread, setHasUnread] = useState(false)
  // I3: 모든 세션 횡단 검색 모달
  const [showHistorySearch, setShowHistorySearch] = useState(false)
  // Phase 6 #8: Vision 첨부
  const [attachedImage, setAttachedImage] = useState<{ base64: string; mime: string; preview: string } | null>(null)
  // G5: 음성 입력 (STT) — 인식된 텍스트는 input에 누적
  const stt = useSTT({
    onFinal: (finalText) => {
      // 음성 인식 종료 시 input에 합침
      setInput((prev) => (prev + ' ' + finalText).trim())
    },
  })

  const messagesEndRef = useRef<HTMLDivElement>(null)
  const inputRef = useRef<HTMLTextAreaElement>(null)
  const fileRef = useRef<HTMLInputElement>(null)

  // 현재 세션
  const activeSession = sessions.find((s) => s.id === activeSessionId)

  // 자동 스크롤
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' })
  }, [activeSession?.messages.length, isLoading])

  // 패널 열릴 때 세션 없으면 자동 생성
  useEffect(() => {
    if (isPanelOpen && !activeSessionId) {
      newSession()
    }
  }, [isPanelOpen, activeSessionId, newSession])

  // 매장 컨텍스트 시스템 프롬프트 생성
  const buildSystemContext = useCallback((): string => {
    const menuList = menus.slice(0, 10).map((m) =>
      `${m.name}(${m.salePrice.toLocaleString()}원, 원가비중 ${m.salePrice > 0 ? Math.round((m.totalCost / m.salePrice) * 100) : 0}%)`
    ).join(', ')

    const storeCtx = buildPromptContext()

    return `당신은 ${storeInfo?.store_name ?? '카페'} 전용 AI 경영 파트너입니다.
카페 점주의 질문에 실용적이고 구체적으로 답변해주세요.

${storeCtx}

현재 등록된 메뉴: ${menuList || '정보 없음'}

답변 규칙:
- 한국어로 답변
- 숫자·금액은 구체적으로 제시
- 마크다운 형식 활용 (필요 시 표, 리스트, 코드블록)
- 실용적이고 바로 쓸 수 있는 답변 우선
- SNS 문구 요청 시 이모지 활용
- 원가/가격 계산 요청 시 계산 과정 보여주기`
  }, [storeInfo, menus, buildPromptContext])

  // Phase 6 #8: 사진 첨부 핸들러 (Vision)
  const handleImagePick = useCallback(async (e: React.ChangeEvent<HTMLInputElement>) => {
    const f = e.target.files?.[0]
    if (!f) return
    if (f.size > 10 * 1024 * 1024) {
      alert('이미지가 너무 커요 (10MB 이하)')
      return
    }
    const reader = new FileReader()
    reader.onload = () => {
      const result = String(reader.result ?? '')
      setAttachedImage({
        base64: result.split(',', 2)[1] ?? '',
        mime: f.type || 'image/jpeg',
        preview: result,
      })
    }
    reader.readAsDataURL(f)
    if (fileRef.current) fileRef.current.value = ''
  }, [])

  // 메시지 전송
  const handleSend = useCallback(async (text?: string) => {
    const content = (text ?? input).trim()
    if ((!content && !attachedImage) || isLoading) return

    let sessionId = activeSessionId
    if (!sessionId) {
      sessionId = newSession()
    }

    // 이미지 있으면 메시지에 미리보기 마커 첨부
    const imageMarker = attachedImage ? '\n\n_[📷 이미지 첨부됨]_' : ''
    addMessage(sessionId, { role: 'user', content: (content || '(이미지만 전송)') + imageMarker })
    setInput('')
    const sentImage = attachedImage
    setAttachedImage(null)
    setIsLoading(true)

    try {
      const res = await fetch('/api/v1/chat/message', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...(storeId ? { 'X-Store-Id': storeId } : {}),
        },
        body: JSON.stringify({
          message: content || '이 이미지에 대해 분석해주세요.',
          system_context: buildSystemContext(),
          history: activeSession?.messages.slice(-10).map((m) => ({
            role: m.role,
            content: m.content,
          })) ?? [],
          store_id: storeId ?? undefined,
          tone: defaultTone,  // Day 6-2: 사장님 선호 어조 주입
          ...(sentImage ? {
            image_base64: sentImage.base64,
            image_mime: sentImage.mime,
          } : {}),
        }),
      })
      if (!res.ok) throw new Error(`서버 오류: ${res.status}`)
      const data = await res.json()
      addMessage(sessionId, { role: 'assistant', content: data.reply })
    } catch (e) {
      const msg = e instanceof Error ? e.message : '오류'
      const errMsg = msg.includes('Failed to fetch')
        ? '백엔드 서버를 시작해주세요.\n\n> `cd backend && uvicorn app.main:app --reload`'
        : msg
      addMessage(sessionId, { role: 'assistant', content: `⚠️ ${errMsg}` })
    } finally {
      setIsLoading(false)
    }
  }, [input, isLoading, activeSessionId, activeSession, newSession, addMessage, buildSystemContext, defaultTone, storeId, attachedImage])

  // Enter 키 핸들러 (Shift+Enter = 줄바꿈)
  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault()
      handleSend()
    }
  }

  // 새 대화 만들기
  const handleNewChat = () => {
    newSession()
    setShowSidebar(false)
  }

  const isFirstMessage = !activeSession?.messages.length

  return (
    <>
      {/* ─── 플로팅 버튼 ─── */}
      <button
        onClick={() => { togglePanel(); setHasUnread(false) }}
        className={cn(
          'fixed bottom-6 right-6 z-50 w-14 h-14 rounded-full shadow-2xl',
          'flex items-center justify-center transition-all duration-300',
          'bg-gradient-to-br from-[#2C1810] to-[#D4A574]',
          // Day 1-3 WCAG AA: 키보드 포커스 링 (4px, 브랜드 컬러, 오프셋 2px)
          'focus:outline-none focus-visible:ring-4 focus-visible:ring-[#D4A574]',
          'focus-visible:ring-offset-2 focus-visible:ring-offset-transparent',
          isPanelOpen ? 'scale-90 rotate-12' : 'hover:scale-110 hover:-translate-y-1'
        )}
        aria-label={isPanelOpen ? 'AI 어시스턴트 닫기' : 'AI 어시스턴트 열기'}
        aria-expanded={isPanelOpen}
        aria-haspopup="dialog"
      >
        {isPanelOpen
          ? <X size={22} className="text-white" />
          : <Coffee size={22} className="text-white" />}
        {/* 미읽 뱃지 */}
        {hasUnread && !isPanelOpen && (
          <span className="absolute -top-1 -right-1 w-4 h-4 bg-red-500 rounded-full text-[9px] text-white flex items-center justify-center font-bold">
            !
          </span>
        )}
      </button>

      {/* ─── 배경 오버레이 ─── */}
      {isPanelOpen && (
        <div
          className="fixed inset-0 z-40 bg-black/20 backdrop-blur-sm md:hidden"
          onClick={closePanel}
        />
      )}

      {/* ─── 채팅 패널 ─── */}
      <div className={cn(
        'fixed bottom-24 right-6 z-50 w-[380px] max-w-[calc(100vw-3rem)]',
        'bg-white rounded-3xl shadow-2xl border border-gray-100',
        'flex overflow-hidden transition-all duration-300 ease-out origin-bottom-right',
        isPanelOpen
          ? 'opacity-100 scale-100 translate-y-0 pointer-events-auto'
          : 'opacity-0 scale-95 translate-y-4 pointer-events-none'
      )}
        style={{ height: '560px' }}
      >
        {/* ─── 세션 사이드바 ─── */}
        <div className={cn(
          'bg-[#2C1810] flex flex-col transition-all duration-300 overflow-hidden shrink-0',
          showSidebar ? 'w-48' : 'w-0'
        )}>
          <div className="p-3 border-b border-white/10">
            <p className="text-xs font-bold text-white/70 uppercase tracking-wider">대화 목록</p>
          </div>
          <div className="flex-1 overflow-y-auto p-2 space-y-1">
            {sessions.length === 0 ? (
              <p className="text-xs text-white/40 p-2">대화가 없습니다</p>
            ) : (
              sessions.map((sess) => (
                <div key={sess.id} className="group relative">
                  <button
                    onClick={() => { setActiveSession(sess.id); setShowSidebar(false) }}
                    className={cn(
                      'w-full text-left px-2.5 py-2 rounded-xl text-xs transition-colors duration-200 pr-7',
                      activeSessionId === sess.id
                        ? 'bg-[#D4A574] text-white font-semibold'
                        : 'text-white/70 hover:bg-white/10'
                    )}
                  >
                    <p className="truncate">{sess.title}</p>
                    <p className="text-[10px] opacity-60 mt-0.5">
                      {new Date(sess.updatedAt).toLocaleDateString('ko-KR')}
                    </p>
                  </button>
                  <button
                    onClick={() => deleteSession(sess.id)}
                    className="absolute right-1.5 top-2 opacity-0 group-hover:opacity-100 text-white/50 hover:text-red-300 transition-all p-0.5 rounded"
                  >
                    <Trash2 size={11} />
                  </button>
                </div>
              ))
            )}
          </div>
          <div className="p-2 border-t border-white/10">
            <button
              onClick={handleNewChat}
              className="w-full flex items-center gap-1.5 px-2.5 py-2 text-xs text-white/70 hover:text-white hover:bg-white/10 rounded-xl transition-colors"
            >
              <Plus size={12} /> 새 대화
            </button>
          </div>
        </div>

        {/* ─── 메인 채팅 영역 ─── */}
        <div className="flex-1 flex flex-col min-w-0">
          {/* 채팅 헤더 */}
          <div className="bg-[#2C1810] px-3 py-2.5 flex items-center gap-2 shrink-0">
            <button
              onClick={() => setShowSidebar(!showSidebar)}
              className={cn(
                'p-1.5 rounded-lg text-white/70 hover:text-white hover:bg-white/10 transition-colors',
                showSidebar && 'bg-white/10 text-white'
              )}
              title="대화 목록"
            >
              <AlignLeft size={15} />
            </button>
            {/* I3: 모든 세션 검색 */}
            <button
              onClick={() => setShowHistorySearch(true)}
              className="p-1.5 rounded-lg text-white/70 hover:text-white hover:bg-white/10 transition-colors"
              title="모든 대화에서 검색 (Ctrl+K)"
            >
              <Search size={14} />
            </button>
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-1.5">
                <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse" />
                <p className="text-white text-sm font-semibold">AI 경영 파트너</p>
              </div>
              <p className="text-white/50 text-xs truncate">
                {storeInfo?.store_name ?? '카페 브레인'} · {activeSession?.title ?? '새 대화'}
              </p>
            </div>
            <button
              onClick={handleNewChat}
              title="새 대화"
              className="p-1.5 rounded-lg text-white/70 hover:text-white hover:bg-white/10 transition-colors"
            >
              <Plus size={15} />
            </button>
            <button
              onClick={closePanel}
              className="p-1.5 rounded-lg text-white/70 hover:text-white hover:bg-white/10 transition-colors"
            >
              <X size={15} />
            </button>
          </div>

          {/* 메시지 영역 */}
          <div className="flex-1 overflow-y-auto p-3 space-y-4 bg-[#FAFAF8]">
            {/* 첫 인사 메시지 */}
            {isFirstMessage && (
              <div className="space-y-3">
                <div className="flex gap-2">
                  <div className="w-7 h-7 rounded-full bg-gradient-to-br from-[#D4A574] to-[#2C1810] flex items-center justify-center shrink-0">
                    <Coffee size={13} className="text-white" />
                  </div>
                  <div className="bg-white rounded-2xl rounded-tl-sm px-3.5 py-2.5 border border-gray-100 shadow-sm max-w-[82%]">
                    <p className="text-sm text-gray-700 leading-relaxed">
                      안녕하세요! ☕<br />
                      <strong className="text-[#2C1810]">{storeInfo?.store_name ?? '카페'}</strong> 전용 AI 경영 파트너입니다.<br />
                      경영에 관한 어떤 질문이든 도와드릴게요!
                    </p>
                  </div>
                </div>

                {/* 예시 질문 버블 */}
                <div className="ml-9 space-y-1.5">
                  <p className="text-xs text-gray-400 font-medium">💡 자주 쓰는 질문</p>
                  <div className="flex flex-wrap gap-1.5">
                    {EXAMPLE_QUESTIONS.map((q) => (
                      <button
                        key={q.text}
                        onClick={() => handleSend(q.text)}
                        disabled={isLoading}
                        className="flex items-center gap-1.5 px-3 py-1.5 bg-white border border-[#D4A574]/40 text-xs text-[#2C1810] rounded-full hover:bg-[#D4A574]/10 hover:border-[#D4A574] transition-all duration-200 shadow-sm disabled:opacity-50"
                      >
                        <span>{q.emoji}</span>
                        <span className="font-medium">{q.short}</span>
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {/* 대화 메시지들 */}
            {activeSession?.messages.map((msg) => (
              <MessageBubble key={msg.id} msg={msg} />
            ))}

            {/* 로딩 표시 */}
            {isLoading && (
              <div className="flex gap-2">
                <div className="w-7 h-7 rounded-full bg-gradient-to-br from-[#D4A574] to-[#2C1810] flex items-center justify-center shrink-0">
                  <Coffee size={13} className="text-white" />
                </div>
                <div className="bg-white rounded-2xl rounded-tl-sm px-3.5 py-2.5 border border-gray-100 shadow-sm">
                  <div className="flex gap-1.5 items-center">
                    <div className="w-1.5 h-1.5 bg-[#D4A574] rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
                    <div className="w-1.5 h-1.5 bg-[#D4A574] rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
                    <div className="w-1.5 h-1.5 bg-[#D4A574] rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
                  </div>
                </div>
              </div>
            )}

            <div ref={messagesEndRef} />
          </div>

          {/* 입력창 */}
          <div className="p-3 bg-white border-t border-gray-100 shrink-0">
            {/* Phase 6 #8: 첨부 이미지 미리보기 */}
            {attachedImage && (
              <div className="flex items-center gap-2 mb-2 bg-[#FAFAF8] rounded-xl p-2">
                <img src={attachedImage.preview} alt="첨부" className="w-12 h-12 rounded-lg object-cover" />
                <span className="text-xs text-gray-500 flex-1">사진 첨부됨</span>
                <button
                  onClick={() => setAttachedImage(null)}
                  className="text-gray-400 hover:text-red-500 p-1"
                  aria-label="첨부 제거"
                >
                  <X size={13} />
                </button>
              </div>
            )}

            <div className="flex items-end gap-2 bg-[#FAFAF8] rounded-2xl border border-gray-200 px-3 py-2 focus-within:border-[#D4A574] focus-within:ring-1 focus-within:ring-[#D4A574]/30 transition-all duration-200">
              {/* 사진 첨부 버튼 */}
              <button
                onClick={() => fileRef.current?.click()}
                disabled={isLoading || !!attachedImage}
                className="p-1.5 text-gray-400 hover:text-[#D4A574] disabled:opacity-30 transition-colors shrink-0"
                title="사진 첨부 (Vision 분석)"
                aria-label="사진 첨부"
              >
                <ImageIcon size={16} />
              </button>
              {/* G5: 음성 입력 (STT) */}
              {stt.supported && (
                <button
                  onClick={() => stt.listening ? stt.stop() : stt.start()}
                  disabled={isLoading}
                  className={cn(
                    'p-1.5 transition-colors shrink-0 relative',
                    stt.listening
                      ? 'text-red-500'
                      : 'text-gray-400 hover:text-[#D4A574]'
                  )}
                  title={stt.listening ? '음성 인식 중지' : '음성 입력 시작'}
                  aria-label={stt.listening ? '음성 인식 중지' : '음성 입력 시작'}
                >
                  {stt.listening ? (
                    <>
                      <MicOff size={16} />
                      {/* 빨간 펄스 점 */}
                      <span className="absolute -top-0.5 -right-0.5 w-2 h-2 bg-red-500 rounded-full animate-pulse" />
                    </>
                  ) : (
                    <Mic size={16} />
                  )}
                </button>
              )}
              <input
                ref={fileRef}
                type="file"
                accept="image/*"
                className="hidden"
                onChange={handleImagePick}
              />
              <div className="flex-1 relative">
                <textarea
                  ref={inputRef}
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  onKeyDown={handleKeyDown}
                  placeholder={stt.listening ? '🎤 듣는 중…' : '무엇이든 물어보세요... (Enter로 전송)'}
                  rows={1}
                  className="w-full bg-transparent text-sm outline-none resize-none text-[#2C1810] placeholder:text-gray-300 max-h-24 leading-relaxed"
                  style={{ scrollbar: 'thin' } as React.CSSProperties}
                />
                {/* STT 진행 중 텍스트 (확정 X) */}
                {stt.listening && stt.interim && (
                  <p className="text-xs text-gray-400 italic truncate">
                    …{stt.interim}
                  </p>
                )}
              </div>
              <button
                onClick={() => handleSend()}
                disabled={(!input.trim() && !attachedImage) || isLoading}
                className={cn(
                  'p-2 rounded-xl transition-all duration-200 shrink-0',
                  (input.trim() || attachedImage) && !isLoading
                    ? 'bg-[#2C1810] text-white hover:bg-[#3d2418]'
                    : 'bg-gray-100 text-gray-300'
                )}
              >
                {isLoading ? <Loader2 size={16} className="animate-spin" /> : <Send size={16} />}
              </button>
            </div>
            <p className="text-center text-xs text-gray-300 mt-1.5">
              <Sparkles size={10} className="inline mr-0.5" />
              Powered by Gemini · Shift+Enter 줄바꿈
            </p>
          </div>
        </div>
      </div>
      {/* I3: 대화 이력 전체 검색 모달 */}
      {showHistorySearch && (
        <ChatHistorySearch
          onSelect={(sessionId) => setActiveSession(sessionId)}
          onClose={() => setShowHistorySearch(false)}
        />
      )}
    </>
  )
}
