"""
마케팅 콘텐츠 생성 라우터
- 플랫폼별 프롬프트 템플릿 분리
- 시안 3개 동시 생성
- SEO 블로그 모드: 키워드 삽입 + 에세이 스타일 리라이트
"""
from fastapi import APIRouter
from pydantic import BaseModel
from typing import List, Optional
import asyncio
from app.services.gemini_service import (
    generate_insight,
    generate_insight_cached,
    build_cache_key,
    generate_with_review,
)
from app.services.feature_flags import is_enabled as flag_enabled

router = APIRouter()


# ─── 스키마 ───

class MarketingRequest(BaseModel):
    """마케팅 콘텐츠 생성 요청"""
    platform: str
    promotion_target: str
    description: str
    tone: str
    target_audience: str
    store_name: str
    menu_list: List[str]


class DraftItem(BaseModel):
    content: str
    hashtags: List[str] = []
    char_count: int


class MarketingResponse(BaseModel):
    drafts: List[DraftItem]


class SeoRequest(BaseModel):
    """SEO 블로그 초안 생성 요청"""
    keywords: List[str]
    description: str
    store_name: str
    rewrite_style: Optional[str] = None   # None=기본, 'essay'=에세이 스타일


class SeoResponse(BaseModel):
    content: str
    char_count: int
    keyword_hits: dict


# ─── 플랫폼별 프롬프트 빌더 ───

TONE_MAP = {
    'emotional': '감성적이고 따뜻한',
    'humor': '유머러스하고 위트 있는',
    'informative': '정보 전달 위주의 명확한',
    'casual': '담백하고 일상적인',
}

TARGET_MAP = {
    'mz_women': '2030 여성 (MZ세대)',
    'office': '직장인',
    'student': '학생',
    'family': '가족',
    'general': '전 연령대',
}

PROMOTION_MAP = {
    'new_menu': '신메뉴 홍보',
    'event': '이벤트 안내',
    'season': '시즌 프로모션',
    'daily': '일상 기록',
    'intro': '매장 소개',
}


def build_prompt(req: MarketingRequest, draft_num: int) -> str:
    """플랫폼별 마케팅 콘텐츠 프롬프트 생성"""
    tone = TONE_MAP.get(req.tone, '자연스러운')
    target = TARGET_MAP.get(req.target_audience, '고객')
    promo = PROMOTION_MAP.get(req.promotion_target, '홍보')
    menus = ', '.join(req.menu_list[:6]) if req.menu_list else '다양한 메뉴'

    variation = ['신선하고 창의적인 시각으로', '고객의 감정에 직접 호소하는 방식으로', '스토리텔링 방식으로'][draft_num % 3]

    base = f"""
매장명: {req.store_name}
홍보 목적: {promo}
상세 내용: {req.description}
톤: {tone}
타깃: {target}
주요 메뉴: {menus}
시안 번호: {draft_num + 1}번 ({variation} 작성)

위 정보를 바탕으로"""

    if req.platform == 'instagram_feed':
        return base + f"""
인스타그램 피드용 캡션을 작성해주세요.
- MZ 감성의 {tone} 문체
- 이모지 적절히 활용 (5~8개)
- 본문 3~5줄
- 마지막에 해시태그 10개 (한국어+영어 혼합)
- #카페 #커피 등 기본 태그 포함
- "광고"나 "홍보" 단어 사용 금지

캡션만 바로 작성 (설명 없이):"""

    elif req.platform == 'instagram_story':
        return base + f"""
인스타그램 스토리용 짧은 텍스트를 작성해주세요.
- 1~2문장 이내 (매우 짧게)
- 강렬한 임팩트, 큰 글씨로 읽히는 느낌
- 이모지 2~3개
- CTA(행동 유도) 한 줄: 예) "지금 바로 →"
- 해시태그 없이

텍스트만 바로 작성:"""

    elif req.platform == 'threads':
        return base + f"""
스레드(Threads)용 게시글을 작성해주세요.
- 3줄 이내 (절대 넘지 말 것)
- 솔직하고 위트 있게, 홍보냄새 최소화
- 일상 공유하듯 자연스럽게
- 이모지 1~2개
- 해시태그 없음

텍스트만 바로 작성:"""

    elif req.platform == 'naver_blog':
        return base + f"""
네이버 블로그 포스팅을 작성해주세요.
- 제목: SEO 최적화된 제목 1개
- 본문: 1,800~2,000자 분량
- 구조: 서론 → 본론(2~3 소제목) → 결론
- SEO 키워드를 자연스럽게 3~5회 반복
- 소제목은 ## 사용
- 마지막에 관련 검색 키워드 5개 나열

전체 블로그 포스팅 작성:"""

    elif req.platform == 'kakao':
        return base + f"""
카카오톡 채널 공지 메시지를 작성해주세요.
- 간결하고 명확하게 (5~7줄)
- 핵심 정보: 무엇/언제/어디서/얼마
- 이모지로 구분선 역할 (📌 🕐 📍 💰)
- 말미에 CTA: "지금 바로 방문해보세요! 👋"

공지 메시지만 바로 작성:"""

    return base + " 마케팅 콘텐츠를 작성해주세요:"


# ─── 엔드포인트 ───

@router.post("/generate", response_model=MarketingResponse)
async def generate_marketing(req: MarketingRequest):
    """
    플랫폼별 마케팅 시안 3개 동시 생성
    - 인스타그램/스토리/스레드/블로그/카카오 템플릿 분리
    """
    # 마케팅 시안 3개는 의도적으로 variation이 달라야 하므로 캐싱 X
    # (같은 입력에 3번 호출 시 시안 A/B/C의 "신선함"이 사라짐 방지)
    # 단, 각 시안은 draft_num을 키로 포함시켜 동일 draft_num만 캐시 공유
    async def _gen_with_cache(i: int) -> str:
        p = build_prompt(req, i)
        key = build_cache_key(
            store_id=req.store_name,
            template=f"marketing_{req.platform}_draft{i}",
            params={
                "promo": req.promotion_target,
                "desc": req.description[:200],
                "tone": req.tone,
                "target": req.target_audience,
            },
        )
        return await generate_insight_cached(p, cache_key=key)

    tasks = [_gen_with_cache(i) for i in range(3)]
    results = await asyncio.gather(*tasks, return_exceptions=True)

    drafts = []
    for r in results:
        if isinstance(r, Exception):
            content = "콘텐츠 생성에 실패했습니다. 다시 시도해주세요."
        else:
            content = str(r)

        # 해시태그 분리 (인스타그램)
        hashtags = []
        if req.platform in ('instagram_feed',):
            lines = content.split('\n')
            for i, line in enumerate(lines):
                if line.strip().startswith('#'):
                    hashtags = [t for t in line.split() if t.startswith('#')]
                    content = '\n'.join(lines[:i]).strip()
                    break

        drafts.append(DraftItem(
            content=content,
            hashtags=hashtags,
            char_count=len(content)
        ))

    return MarketingResponse(drafts=drafts)


@router.post("/seo", response_model=SeoResponse)
async def generate_seo_blog(req: SeoRequest):
    """
    SEO 블로그 초안 생성
    - 키워드 5개 → 2,000자 초안
    - rewrite_style='essay' → 에세이풍 리라이트
    """
    kw_str = ', '.join(req.keywords)

    if req.rewrite_style == 'essay':
        prompt = f"""
다음 블로그 글을 에세이 작가 스타일로 감성적으로 리라이트해주세요.
- 원글 내용 유지하되 문체를 에세이풍으로
- 1인칭 서술, 개인적 감상 추가
- 키워드: {kw_str}
- 2,000자 내외 유지

원글:
{req.description}

리라이트 결과만 작성:"""
    else:
        prompt = f"""
'{req.store_name}' 카페에 대한 네이버 블로그 포스팅을 작성해주세요.

[SEO 키워드] {kw_str}
[주제] {req.description}

작성 규칙:
- 제목: 키워드 포함한 SEO 최적화 제목
- 분량: 1,800~2,200자
- 구조: 서론(200자) → 본론①(500자) → 본론②(500자) → 본론③(400자) → 결론(300자)
- 키워드를 각 섹션에 1~2회씩 자연스럽게 삽입
- ## 소제목 사용
- 마지막 줄: [검색 키워드] {kw_str}

전체 포스팅 작성:"""

    # SEO 블로그는 캐싱 적용 (동일 키워드 조합 재사용 가능)
    seo_cache_key = build_cache_key(
        store_id=req.store_name,
        template=f"seo_blog_{req.rewrite_style or 'default'}",
        params={
            "kw": ",".join(sorted(req.keywords)),
            "desc": req.description[:300],
        },
    )
    # I10 — Self-correction (flag 활성 시): SEO 블로그는 정확성·신뢰도 중요
    if await flag_enabled("agent_self_correction"):
        content, _meta = await generate_with_review(
            prompt,
            question_for_review=f"SEO 블로그: {','.join(req.keywords)} - {req.description[:80]}",
        )
    else:
        content = await generate_insight_cached(prompt, cache_key=seo_cache_key)

    # 키워드 밀도 계산
    keyword_hits = {}
    for kw in req.keywords:
        keyword_hits[kw] = content.count(kw)

    return SeoResponse(
        content=content,
        char_count=len(content),
        keyword_hits=keyword_hits
    )
