// 공개 랜딩 페이지 (Claude 디자인 미감 + 프로젝트 브랜드)
// 비로그인 사용자가 접근, 가입 전환 유도
import { useState } from 'react'
import { Link } from 'react-router-dom'
import {
  Coffee, Sparkles, Brain, Target, Users, ShoppingCart, Wallet,
  Bell, Moon, ArrowRight, Check, Star, Zap,
} from 'lucide-react'
import DemoVideoModal from '@/components/landing/DemoVideoModal'

const FEATURES = [
  {
    icon: Brain,
    title: '능동형 AI 비서',
    desc: '매장 데이터로 60일 학습. 먼저 말 거는 개인 AI.',
    hook: '"지난 금요일 비 오는 날처럼 오늘도..."',
    color: '#D4A574',
  },
  {
    icon: Target,
    title: '실시간 BEP 게이지',
    desc: '이번 달 손익분기점까지 얼마 남았는지 한눈에.',
    hook: '하루 ₩42,500 × 17일 = 달성',
    color: '#5A9E6F',
  },
  {
    icon: Star,
    title: '리뷰 AI 답글',
    desc: '정중·친근·유머 3가지 어조. 사장님 톤으로.',
    hook: '리뷰 10개 → 2분 컷',
    color: '#E07A5F',
  },
  {
    icon: Users,
    title: '스마트 스케줄링',
    desc: '주휴수당 포함/최소화 토글. 월 수십만원 차이.',
    hook: '인건비 -19% 최적화',
    color: '#4A90A4',
  },
  {
    icon: ShoppingCart,
    title: '발주 관리',
    desc: '점장 요청 → 사장 승인. 모든 이력 자동.',
    hook: '구두 전달 0건',
    color: '#7B6CB0',
  },
  {
    icon: Wallet,
    title: '월별 손익',
    desc: '매출 - 원재료 - 고정비 = 순이익 자동.',
    hook: '영업이익률 실시간',
    color: '#22C55E',
  },
  {
    icon: Bell,
    title: 'Push 알림',
    desc: '매출 급락·BEP 달성·발주 요청 즉시.',
    hook: '앱 닫아도 수신',
    color: '#F59E0B',
  },
  {
    icon: Moon,
    title: '다크모드',
    desc: '야간 마감 작업도 눈 편하게.',
    hook: 'OS 자동 감지',
    color: '#6B7280',
  },
]

const TESTIMONIALS = [
  {
    name: '김사장',
    detail: '연남동 카페 4년차',
    quote: 'AI가 "지난주 이맘때 매출이 왜 빠졌는지" 분석해서 보여줘요. 처음엔 신기했는데 이젠 없으면 불안함.',
    rating: 5,
  },
  {
    name: '이사장',
    detail: '성수동 감성카페',
    quote: '인스타 문구 매일 짜는 게 제일 힘들었는데, 시안 3개 뽑아주니까 고민 끝. Canva 연동까지 되니 완전 편해요.',
    rating: 5,
  },
  {
    name: '박점장',
    detail: '강남 프랜차이즈 점장',
    quote: '사장님이랑 발주 실수로 싸운 게 이번 달엔 0건. 앱에 다 기록되니까 오해가 없어요.',
    rating: 5,
  },
]

export default function LandingPage() {
  const [showVideo, setShowVideo] = useState(false)

  return (
    <div className="min-h-screen bg-[#FAFAF7]">
      {/* ─── 네비 ─── */}
      <header className="sticky top-0 z-40 bg-[#FAFAF7]/90 backdrop-blur-md border-b border-[#E5E4DF]">
        <div className="max-w-6xl mx-auto px-6 py-4 flex items-center justify-between">
          <Link to="/" className="flex items-center gap-2">
            <div className="w-9 h-9 rounded-xl bg-[#2C1810] flex items-center justify-center">
              <Coffee size={18} className="text-[#D4A574]" />
            </div>
            <span
              className="font-semibold text-[#141413] text-lg"
              style={{ fontFamily: "'Copernicus', 'Charter', serif" }}
            >
              Cafe Brain
            </span>
          </Link>
          <div className="flex items-center gap-3">
            <Link to="/login" className="text-sm text-[#3D3D3A] hover:text-[#141413] font-medium">
              로그인
            </Link>
            <Link
              to="/login"
              className="px-4 py-2 bg-[#2C1810] text-white rounded-lg text-sm font-semibold hover:bg-[#3d2418] transition-colors"
            >
              무료 시작하기
            </Link>
          </div>
        </div>
      </header>

      {/* ─── Hero ─── */}
      <section className="max-w-4xl mx-auto px-6 pt-20 pb-16 md:pt-32 md:pb-24 text-center">
        {/* 배지 */}
        <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-[#D4A574]/10 text-[#B3513E] rounded-full text-xs font-semibold mb-8">
          <Sparkles size={12} />
          14일 무료 · 신용카드 없음
        </div>

        <h1
          className="text-5xl md:text-7xl font-normal text-[#141413] leading-[1.1] tracking-tight mb-6"
          style={{ fontFamily: "'Copernicus', 'Charter', serif" }}
        >
          매출 분석,<br />
          <span className="text-[#D4A574]">AI가 대신 읽어드려요</span>
        </h1>

        <p className="text-lg md:text-xl text-[#3D3D3A] leading-relaxed max-w-2xl mx-auto mb-10">
          POS에 쌓이는 숫자는 많은데 뭘 봐야 할지 모르셨죠?<br className="hidden md:block" />
          카페 브레인은 <strong>매출·리뷰·스케줄을 하나로 묶어</strong>
          사장님만을 위한 맞춤 인사이트로 바꿔드립니다.
        </p>

        <div className="flex flex-col sm:flex-row items-center justify-center gap-3 mb-16">
          <Link
            to="/login"
            className="inline-flex items-center gap-2 px-6 py-3 bg-[#2C1810] text-white rounded-xl text-base font-semibold hover:bg-[#3d2418] transition-colors shadow-lg"
          >
            지금 무료 시작 <ArrowRight size={16} />
          </Link>
          <button
            onClick={() => setShowVideo(true)}
            className="inline-flex items-center gap-2 px-6 py-3 border border-[#E5E4DF] text-[#141413] rounded-xl text-base font-semibold hover:bg-[#F5F4EE] transition-colors"
          >
            2분 영상 보기 ▶
          </button>
        </div>

        {/* 신뢰 라인 */}
        <div className="flex flex-wrap items-center justify-center gap-x-8 gap-y-2 text-sm text-[#87867F]">
          <span className="flex items-center gap-1"><Check size={14} className="text-[#5A9E6F]" /> 가입 2분</span>
          <span className="flex items-center gap-1"><Check size={14} className="text-[#5A9E6F]" /> 언제든 해지</span>
          <span className="flex items-center gap-1"><Check size={14} className="text-[#5A9E6F]" /> 한국 카페 맥락 맞춤</span>
        </div>
      </section>

      {/* ─── AI 브리핑 Demo ─── */}
      <section className="max-w-4xl mx-auto px-6 pb-20">
        <div className="bg-gradient-to-br from-[#2C1810] via-[#3d2418] to-[#2C1810] rounded-3xl p-8 md:p-12 relative overflow-hidden">
          <div
            className="absolute inset-0 opacity-20"
            style={{ backgroundImage: 'radial-gradient(circle at 80% 20%, #D4A574 0%, transparent 40%)' }}
          />
          <div className="relative">
            <p className="text-[#D4A574] text-xs font-bold uppercase tracking-wider mb-2">
              🌅 오늘 아침 브리핑
            </p>
            <p
              className="text-white text-xl md:text-2xl leading-relaxed mb-4"
              style={{ fontFamily: "'Copernicus', 'Charter', serif" }}
            >
              "김사장님, 지난 금요일 비 오는 날 매출이 20% 빠졌었죠.
              오늘도 비 예보가 있습니다. 저번처럼 콜드브루 할인
              이벤트를 고민해보시는 게 어떨까요?"
            </p>
            <div className="flex items-center gap-2 mt-6">
              <span className="w-2 h-2 rounded-full bg-[#5A9E6F] animate-pulse" />
              <p className="text-[#D4A574] text-xs">
                사장님 매장 데이터 42건 학습 완료
              </p>
            </div>
          </div>
        </div>
        <p className="text-center text-[#87867F] text-sm mt-4">
          일반 AI는 묻는 말에 답합니다. 카페 브레인은 먼저 말합니다.
        </p>
      </section>

      {/* ─── Features Grid ─── */}
      <section className="bg-[#F5F4EE] py-20 md:py-28">
        <div className="max-w-6xl mx-auto px-6">
          <div className="text-center mb-14">
            <h2
              className="text-4xl md:text-5xl font-normal text-[#141413] mb-4 tracking-tight"
              style={{ fontFamily: "'Copernicus', 'Charter', serif" }}
            >
              매장 운영의 모든 것을<br />하나의 AI로
            </h2>
            <p className="text-[#3D3D3A] text-lg max-w-2xl mx-auto">
              8가지 핵심 기능이 서로 연결되어 사장님의 의사결정을 돕습니다.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-5">
            {FEATURES.map(({ icon: Icon, title, desc, hook, color }) => (
              <div
                key={title}
                className="bg-white rounded-2xl p-6 border border-[#E5E4DF] hover:shadow-lg transition-shadow"
              >
                <div
                  className="w-12 h-12 rounded-2xl flex items-center justify-center mb-4"
                  style={{ backgroundColor: `${color}15` }}
                >
                  <Icon size={22} style={{ color }} />
                </div>
                <h3 className="font-bold text-[#141413] text-lg mb-2">{title}</h3>
                <p className="text-sm text-[#3D3D3A] leading-relaxed mb-3">{desc}</p>
                <p
                  className="text-xs italic pl-3 border-l-2"
                  style={{ color: color, borderColor: color }}
                >
                  {hook}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ─── Testimonials ─── */}
      <section className="max-w-5xl mx-auto px-6 py-20 md:py-28">
        <h2
          className="text-3xl md:text-4xl font-normal text-center text-[#141413] mb-12 tracking-tight"
          style={{ fontFamily: "'Copernicus', 'Charter', serif" }}
        >
          먼저 써본 사장님들의 이야기
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
          {TESTIMONIALS.map((t) => (
            <div
              key={t.name}
              className="bg-white rounded-2xl p-6 border border-[#E5E4DF]"
            >
              <div className="flex gap-0.5 mb-3">
                {Array.from({ length: t.rating }).map((_, i) => (
                  <Star key={i} size={14} className="fill-[#D4A574] text-[#D4A574]" />
                ))}
              </div>
              <p className="text-sm text-[#3D3D3A] leading-relaxed mb-4 min-h-[80px]">"{t.quote}"</p>
              <div className="pt-4 border-t border-[#E5E4DF]">
                <p className="font-semibold text-[#141413] text-sm">{t.name}</p>
                <p className="text-xs text-[#87867F] mt-0.5">{t.detail}</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* ─── Pricing (Day 4-3: 백엔드 billing.py와 일치, 가격 정보 명확화) ─── */}
      <section id="pricing" className="bg-[#F5F4EE] py-20 md:py-28">
        <div className="max-w-5xl mx-auto px-6">
          <div className="text-center mb-4">
            <span className="inline-block px-3 py-1 rounded-full bg-[#D4A574]/20 text-[#D4A574] text-xs font-bold">
              7일 무료 · 언제든 해지
            </span>
          </div>
          <h2
            className="text-4xl md:text-5xl font-normal text-center text-[#141413] mb-4 tracking-tight"
            style={{ fontFamily: "'Copernicus', 'Charter', serif" }}
          >
            소형 카페 한 잔 값
          </h2>
          <p className="text-center text-[#3D3D3A] mb-12 max-w-xl mx-auto">
            신용카드 없이 7일 먼저 써보세요. 하루 1,000원으로 영수증 OCR, AI 브리핑, 리뷰 답글까지.
          </p>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
            <PricingCard
              name="체험"
              price="0"
              period="7일"
              features={[
                '모든 기능 제한 없이',
                '신용카드 등록 불필요',
                'AI 호출 · OCR · 리뷰 답글',
                '7일 후 자동 만료',
              ]}
            />
            <PricingCard
              name="월 구독"
              price="30,000"
              period="월"
              features={[
                'AI 매출 분석 월 1,000회',
                '리뷰 자동 답글 무제한',
                '영수증 OCR 자동 입력',
                '멀티 프로필 최대 3명',
                '다크모드 · PDF · Excel 내보내기',
                'Push 알림 (Daily Briefing)',
              ]}
              highlighted
            />
            <PricingCard
              name="연 구독"
              price="300,000"
              period="년"
              badge="17% 할인"
              features={[
                '월 구독 전체 혜택 +',
                '월 평균 25,000원',
                '우선 고객 지원 (24h)',
                '베타 기능 선출시 체험',
                '연 2회 1:1 운영 컨설팅',
              ]}
            />
          </div>

          {/* 비교 안내 */}
          <p className="text-center text-xs text-[#87867F] mt-8">
            * 카드 정보는 <strong>토스페이먼츠</strong> 보안 시스템으로만 처리되며 당사 서버에 저장되지 않습니다.
          </p>
        </div>
      </section>

      {/* ─── Final CTA ─── */}
      <section className="max-w-3xl mx-auto px-6 py-20 md:py-28 text-center">
        <h2
          className="text-4xl md:text-5xl font-normal text-[#141413] mb-6 tracking-tight"
          style={{ fontFamily: "'Copernicus', 'Charter', serif" }}
        >
          우리 가게도<br />AI에게 배우게 해보세요
        </h2>
        <p className="text-[#3D3D3A] text-lg mb-8">
          가입 2분. 설정 3분. 그리고 매일 아침 브리핑이 옵니다.
        </p>
        <Link
          to="/login"
          className="inline-flex items-center gap-2 px-8 py-4 bg-[#2C1810] text-white rounded-xl text-base font-semibold hover:bg-[#3d2418] transition-colors shadow-xl"
        >
          <Zap size={18} /> 지금 무료로 시작하기
        </Link>
      </section>

      {/* ─── Footer ─── */}
      <footer className="bg-[#141413] text-white/60 py-12">
        <div className="max-w-6xl mx-auto px-6">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4">
            <div className="flex items-center gap-2">
              <Coffee size={16} className="text-[#D4A574]" />
              <span className="text-sm">© 2026 Cafe Brain</span>
            </div>
            <div className="flex items-center gap-6 text-xs">
              <Link to="/terms" className="hover:text-white">이용약관</Link>
              <Link to="/privacy" className="hover:text-white">개인정보처리방침</Link>
              <Link to="/faq" className="hover:text-white">자주 묻는 질문</Link>
              <a href="https://pf.kakao.com/cafebrain" target="_blank" rel="noopener noreferrer" className="hover:text-white">카카오 문의</a>
            </div>
          </div>
        </div>
      </footer>

      {/* 2분 데모 영상 모달 */}
      <DemoVideoModal open={showVideo} onClose={() => setShowVideo(false)} />
    </div>
  )
}

// ─── 가격 카드 ───
function PricingCard({
  name,
  price,
  period,
  features,
  highlighted,
  badge,
}: {
  name: string
  price: string
  period: string
  features: string[]
  highlighted?: boolean
  badge?: string
}) {
  return (
    <div
      className={`rounded-2xl p-6 border-2 relative ${
        highlighted
          ? 'bg-[#2C1810] border-[#D4A574] text-white shadow-xl md:scale-105'
          : 'bg-white border-[#E5E4DF] text-[#141413]'
      }`}
    >
      {highlighted && (
        <div className="inline-block px-2.5 py-1 bg-[#D4A574] text-[#2C1810] rounded-full text-[10px] font-bold mb-3">
          ⭐ 가장 인기
        </div>
      )}
      {badge && !highlighted && (
        <div className="absolute -top-3 right-5 px-3 py-1 bg-red-500 text-white rounded-full text-[10px] font-bold shadow">
          {badge}
        </div>
      )}
      <h3 className={`font-bold text-xl mb-2 ${highlighted ? 'text-white' : ''}`}>{name}</h3>
      <div className="flex items-baseline gap-1 mb-5">
        <span className={`text-3xl font-black ${highlighted ? 'text-[#D4A574]' : ''}`}>
          {price === '0' ? '무료' : `₩${price}`}
        </span>
        <span className={`text-sm ${highlighted ? 'text-white/60' : 'text-[#87867F]'}`}>
          /{period}
        </span>
      </div>
      <ul className="space-y-2.5 mb-6">
        {features.map((f) => (
          <li key={f} className="flex items-start gap-2 text-sm">
            <Check
              size={14}
              className={`mt-0.5 shrink-0 ${highlighted ? 'text-[#D4A574]' : 'text-[#5A9E6F]'}`}
            />
            <span className={highlighted ? 'text-white/90' : 'text-[#3D3D3A]'}>{f}</span>
          </li>
        ))}
      </ul>
      <Link
        to="/login"
        className={`block w-full py-2.5 rounded-xl text-center text-sm font-semibold transition-colors ${
          highlighted
            ? 'bg-[#D4A574] text-[#2C1810] hover:bg-[#c4956a]'
            : 'border border-[#E5E4DF] text-[#141413] hover:bg-[#F5F4EE]'
        }`}
      >
        {price === '0' ? '7일 무료로 시작' : '7일 체험 후 결제'}
      </Link>
    </div>
  )
}
