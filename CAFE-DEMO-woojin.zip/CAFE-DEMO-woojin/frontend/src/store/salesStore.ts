// 매출 데이터 전역 Zustand 스토어 — Phase 2: Supabase 영속화
// - 진실 소스: Supabase `sales_records` (RLS: store_id = auth.uid())
// - 로그인/사용자 변경 시 자동 동기화, 로그아웃 시 인메모리 클리어
// - addRecords / deleteRecord / clearRecords: optimistic UI + 서버 반영 + 실패 롤백
// - localStorage persist 제거 — 기기·직원 프로필이 달라도 동일한 진실 데이터 보장
import { create } from 'zustand'
import { supabase } from '@/lib/supabase'
import { useAuthStore } from './authStore'
import type { SalesRecord } from '@/types/sales'

interface SalesState {
  records: SalesRecord[]
  loading: boolean
  syncedAt: number | null
  // 액션
  syncFromServer: () => Promise<void>
  addRecords: (recs: SalesRecord[]) => Promise<void>
  deleteRecord: (id: string) => Promise<void>
  clearRecords: () => Promise<void>
}

// 인증된 사용자 ID (= store_id, RLS 기반)
function getStoreId(): string | null {
  return useAuthStore.getState().user?.id ?? null
}

// 임시 ID 식별자 — 서버 insert 전 optimistic UI에서만 사용
const TMP_PREFIX = 'tmp-'
const isTmpId = (id: string | undefined): boolean =>
  typeof id === 'string' && id.startsWith(TMP_PREFIX)
const newTmpId = (): string =>
  `${TMP_PREFIX}${Date.now()}-${Math.random().toString(36).slice(2, 8)}`

export const useSalesStore = create<SalesState>((set, get) => ({
  records: [],
  loading: false,
  syncedAt: null,

  // ─── 서버 → 클라이언트 동기화 ───
  syncFromServer: async () => {
    const storeId = getStoreId()
    if (!storeId) return // 비로그인 noop

    set({ loading: true })
    try {
      const { data, error } = await supabase
        .from('sales_records')
        .select('*')
        .eq('store_id', storeId)
        .order('sale_date', { ascending: false })
      if (error) throw error
      set({
        records: (data ?? []) as SalesRecord[],
        syncedAt: Date.now(),
      })
    } catch (e) {
      console.error('[salesStore] syncFromServer 실패:', e)
    } finally {
      set({ loading: false })
    }
  },

  // ─── 추가 (CSV 업로드 / OCR / 수동 입력) ───
  addRecords: async (recs) => {
    const storeId = getStoreId()

    // 비로그인 fallback: 인메모리만 유지
    if (!storeId) {
      set((s) => ({ records: [...s.records, ...recs] }))
      return
    }

    // optimistic UI: 임시 id 부여 후 즉시 화면 반영
    const optimistic: SalesRecord[] = recs.map((r) => ({
      ...r,
      id: r.id && !isTmpId(r.id) ? r.id : newTmpId(),
      store_id: storeId,
    }))
    set((s) => ({ records: [...s.records, ...optimistic] }))

    // 서버 insert payload — id/created_at은 DB가 채움
    const payloads = recs.map((r) => ({
      store_id: storeId,
      sale_date: r.sale_date,
      hour_slot: r.hour_slot,
      day_of_week: r.day_of_week,
      menu_name: r.menu_name,
      quantity: r.quantity,
      revenue: r.revenue,
      cost: r.cost ?? 0,
      discount: r.discount ?? 0,
    }))

    try {
      const { data, error } = await supabase
        .from('sales_records')
        .insert(payloads)
        .select()
      if (error) throw error
      const inserted = (data ?? []) as SalesRecord[]
      // 임시 행 제거 + DB 결과로 교체
      set((s) => ({
        records: s.records
          .filter((r) => !isTmpId(r.id))
          .concat(inserted),
      }))
    } catch (e) {
      console.error('[salesStore] insert 실패:', e)
      // 롤백: 임시 추가분 제거
      set((s) => ({
        records: s.records.filter((r) => !isTmpId(r.id)),
      }))
      throw e // 호출자(SalesPage)가 toast 표시할 수 있도록 재던짐
    }
  },

  // ─── 단일 삭제 ───
  deleteRecord: async (id) => {
    const prev = get().records
    // optimistic
    set({ records: prev.filter((r) => r.id !== id) })

    // 임시 ID는 서버에 없으니 종료
    if (isTmpId(id)) return

    try {
      const { error } = await supabase
        .from('sales_records')
        .delete()
        .eq('id', id)
      if (error) throw error
    } catch (e) {
      console.error('[salesStore] delete 실패:', e)
      set({ records: prev }) // 롤백
      throw e
    }
  },

  // ─── 전체 삭제 (현재 매장만) ───
  clearRecords: async () => {
    const storeId = getStoreId()
    const prev = get().records
    // optimistic
    set({ records: [] })

    if (!storeId) return // 비로그인이면 인메모리만 비우면 끝

    try {
      const { error } = await supabase
        .from('sales_records')
        .delete()
        .eq('store_id', storeId)
      if (error) throw error
    } catch (e) {
      console.error('[salesStore] clear 실패:', e)
      set({ records: prev }) // 롤백
      throw e
    }
  },
}))

// ─── 인증 상태 변화 자동 반응 (브라우저 컨텍스트) ───
// authStore.user가 set/clear될 때마다 sales 데이터를 자동으로 동기화·정리.
// 컴포넌트가 명시적으로 호출하지 않아도 된다.
if (typeof window !== 'undefined') {
  let lastUserId: string | null = useAuthStore.getState().user?.id ?? null

  // 부팅 시 이미 로그인된 상태(세션 복원)라면 초기 동기화
  if (lastUserId) {
    void useSalesStore.getState().syncFromServer()
  }

  useAuthStore.subscribe((state) => {
    const newId = state.user?.id ?? null
    if (newId === lastUserId) return

    if (newId) {
      // 로그인 또는 다른 사용자 전환 — 서버에서 그 사용자 데이터 동기화
      void useSalesStore.getState().syncFromServer()
    } else {
      // 로그아웃 — 인메모리 sales 클리어
      useSalesStore.setState({ records: [], syncedAt: null, loading: false })
    }
    lastUserId = newId
  })
}
