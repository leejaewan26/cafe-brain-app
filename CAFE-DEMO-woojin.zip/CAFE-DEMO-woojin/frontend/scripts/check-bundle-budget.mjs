#!/usr/bin/env node
// I6 — Performance budget 검증 스크립트
// 사용: npm run build && node scripts/check-bundle-budget.mjs
//
// 예산 (gzip 전 raw):
//   - main entry chunk: < 300KB
//   - per-route chunk:  < 150KB
//   - 전체 합산:        < 1.5MB
import { readdir, stat } from 'node:fs/promises'
import path from 'node:path'

const DIST = path.resolve(process.cwd(), 'dist/assets')
const BUDGETS = {
  mainEntry: 300 * 1024,
  perRoute: 150 * 1024,
  totalAll: 1500 * 1024,
}

async function main() {
  let files
  try {
    files = await readdir(DIST)
  } catch {
    console.error('❌ dist/assets 미존재 — npm run build 먼저')
    process.exit(1)
  }

  const jsFiles = files.filter((f) => f.endsWith('.js'))
  let totalSize = 0
  const violations = []

  for (const f of jsFiles) {
    const full = path.join(DIST, f)
    const s = await stat(full)
    totalSize += s.size

    // 메인 엔트리 (이름에 index 또는 main)
    const isMain = /^(index|main)-/.test(f)
    const budget = isMain ? BUDGETS.mainEntry : BUDGETS.perRoute
    const ok = s.size <= budget
    const status = ok ? '✅' : '⚠️'
    console.log(`${status} ${f.padEnd(40)} ${(s.size / 1024).toFixed(1).padStart(7)} KB / ${(budget / 1024).toFixed(0)} KB`)
    if (!ok) {
      violations.push({ file: f, size: s.size, budget })
    }
  }

  console.log('─'.repeat(70))
  const totalOk = totalSize <= BUDGETS.totalAll
  console.log(`${totalOk ? '✅' : '⚠️'} TOTAL                                  ${(totalSize / 1024).toFixed(1).padStart(7)} KB / ${(BUDGETS.totalAll / 1024).toFixed(0)} KB`)

  if (violations.length || !totalOk) {
    console.log('\n번들 예산 초과:')
    if (!totalOk) console.log(`  - 전체 ${(totalSize / 1024).toFixed(0)} KB > ${(BUDGETS.totalAll / 1024).toFixed(0)} KB`)
    violations.forEach((v) => {
      console.log(`  - ${v.file}: ${(v.size / 1024).toFixed(0)} KB > ${(v.budget / 1024).toFixed(0)} KB`)
    })
    // CI에선 exit 1 권장 — 일단 경고만 (점진 도입)
    if (process.env.CI) process.exit(1)
  }
}

void main()
