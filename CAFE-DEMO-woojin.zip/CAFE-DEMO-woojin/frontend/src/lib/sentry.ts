// Launch A5 — Sentry 프론트엔드 통합
// VITE_SENTRY_DSN 환경변수 있을 때만 활성. 프로덕션 빌드에서만 권장.
//
// 프라이버시:
//  - sendDefaultPii=false: IP·이메일 등 자동 수집 X
//  - beforeSend: Authorization·매장 ID·이미지 base64 등 마스킹
//  - replaysSessionSampleRate=0.0: 세션 리플레이 기본 OFF (필요 시 키)
//
// 사용법: main.tsx에서 initSentry() 호출.

import * as Sentry from '@sentry/react'

const DSN = import.meta.env.VITE_SENTRY_DSN as string | undefined
const ENV = (import.meta.env.VITE_SENTRY_ENV as string | undefined) || (import.meta.env.MODE || 'development')
const RELEASE = (import.meta.env.VITE_APP_VERSION as string | undefined) || '1.2.0'

const SENSITIVE_HEADERS = new Set(['authorization', 'cookie', 'x-store-id', 'x-admin-key'])
const SENSITIVE_BODY_KEYS = new Set([
  'image_base64', 'image', 'gemini_api_key', 'supabase_service_key',
  'password', 'card_number', 'cvc', 'rrn', '주민번호',
])

function scrubEvent(event: Sentry.ErrorEvent): Sentry.ErrorEvent | null {
  // 헤더 마스킹
  const req = event.request
  if (req?.headers && typeof req.headers === 'object') {
    for (const k of Object.keys(req.headers)) {
      if (SENSITIVE_HEADERS.has(k.toLowerCase())) {
        (req.headers as Record<string, string>)[k] = '[REDACTED]'
      }
    }
  }
  // body 마스킹
  if (req?.data && typeof req.data === 'object') {
    const data = req.data as Record<string, unknown>
    for (const k of Object.keys(data)) {
      if (SENSITIVE_BODY_KEYS.has(k.toLowerCase())) {
        data[k] = '[REDACTED]'
      }
    }
  }
  return event
}

let _initialized = false

export function initSentry(): boolean {
  if (_initialized) return true
  if (!DSN) {
    if (import.meta.env.DEV) {
      console.info('[Sentry] disabled (VITE_SENTRY_DSN not set)')
    }
    return false
  }

  try {
    Sentry.init({
      dsn: DSN,
      environment: ENV,
      release: `cafe-brain@${RELEASE}`,
      // 프로덕션에서 활성, 그 외는 OFF
      enabled: ENV === 'production' || ENV === 'staging',

      // 프라이버시 우선
      sendDefaultPii: false,

      // 트레이스 샘플링: prod 10%, staging 50%, dev 0%
      tracesSampleRate: ENV === 'production' ? 0.1 : (ENV === 'staging' ? 0.5 : 0.0),

      // 세션 리플레이: 기본 OFF (PII 위험·비용)
      replaysSessionSampleRate: 0.0,
      replaysOnErrorSampleRate: ENV === 'production' ? 0.1 : 0.0,

      // 통합: BrowserTracing은 자동 (default)
      integrations: [
        Sentry.browserTracingIntegration(),
        Sentry.replayIntegration({
          maskAllText: true,
          blockAllMedia: true,
        }),
      ],

      beforeSend: scrubEvent,
    })
    _initialized = true
    return true
  } catch (e) {
    console.error('[Sentry] init failed', e)
    return false
  }
}

/**
 * 사용자 ID 설정 (로그인 후 호출).
 * email 등 PII는 절대 보내지 않고 user.id (uuid)만.
 */
export function setSentryUser(userId: string | null) {
  if (!_initialized) return
  if (userId) {
    Sentry.setUser({ id: userId })
  } else {
    Sentry.setUser(null)
  }
}

/**
 * 에러 바운더리 — App 최상단에 감싸서 사용.
 */
export const SentryErrorBoundary = Sentry.ErrorBoundary
