"""
학습 루프 훅 (Wave 5C)

프론트엔드가 주요 사용자 행동(매출 업로드, 리뷰 등록 등) 후 호출하는 훅 엔드포인트.
각 훅은 관련 DB 함수를 실행하고 새 메모리를 생성.

엔드포인트:
- POST /learning/after-sales-upload: 매출 업로드 후 → anomaly/BEP 감지
- POST /learning/after-review-batch: 리뷰 업로드 후 → 반복 키워드 메모리
- POST /learning/nudge-profile: 프로필 증류 트리거 (쿨다운 포함)
"""
import asyncio
from datetime import datetime, timezone

from fastapi import APIRouter
from pydantic import BaseModel

from app.services import memory_service
from app.services.gemini_service import _get_supabase

router = APIRouter()


class HookRequest(BaseModel):
    store_id: str


class HookResult(BaseModel):
    memories_created: int
    details: dict[str, int]


# ═══════════════════════════════════════════════════════
# 매출 업로드 후 → anomaly + BEP 감지
# ═══════════════════════════════════════════════════════


@router.post("/after-sales-upload", response_model=HookResult)
async def after_sales_upload(req: HookRequest):
    """
    매출 CSV 업로드 또는 수동 입력 후 호출.
    007 migration의 detect_sales_anomaly + detect_bep_milestone 실행.
    """
    sb = _get_supabase()
    if sb is None:
        return HookResult(memories_created=0, details={})

    try:
        result = await asyncio.to_thread(
            lambda: sb.rpc("run_daily_memory_capture", {"p_store_id": req.store_id}).execute()
        )
        details: dict[str, int] = {}
        total = 0
        for row in result.data or []:
            evt = row.get("event_type", "")
            cnt = int(row.get("count", 0))
            details[evt] = cnt
            total += cnt
        return HookResult(memories_created=total, details=details)
    except Exception:
        return HookResult(memories_created=0, details={})


# ═══════════════════════════════════════════════════════
# 리뷰 일괄 업로드 후 → 반복 키워드 customer_insight
# ═══════════════════════════════════════════════════════


class ReviewBatchRequest(BaseModel):
    store_id: str
    # 프론트에서 이미 분석한 키워드 전달 (frontend tokenizer 사용)
    positive_keywords: list[str] = []
    negative_keywords: list[str] = []
    review_count: int = 0


@router.post("/after-review-batch", response_model=HookResult)
async def after_review_batch(req: ReviewBatchRequest):
    """
    리뷰 일괄 업로드 완료 후 호출.
    반복 키워드(3회 이상)를 customer_insight 메모리로 저장.
    """
    created = 0

    # 긍정 키워드 상위 5개
    for kw in req.positive_keywords[:5]:
        memory_id = await memory_service.insert_memory(
            store_id=req.store_id,
            category="customer_insight",
            content=f"긍정 리뷰에 반복 등장: '{kw}' — 강점 포인트",
            importance=6,
            confidence=0.8,
            source_type="review_batch",
            source_ref=f"positive-{datetime.now(timezone.utc).strftime('%Y%m%d')}",
        )
        if memory_id:
            created += 1

    # 부정 키워드 상위 5개 (더 중요)
    for kw in req.negative_keywords[:5]:
        memory_id = await memory_service.insert_memory(
            store_id=req.store_id,
            category="customer_insight",
            content=f"부정 리뷰에 반복 등장: '{kw}' — 개선 포인트 고려",
            importance=8,
            confidence=0.85,
            source_type="review_batch",
            source_ref=f"negative-{datetime.now(timezone.utc).strftime('%Y%m%d')}",
        )
        if memory_id:
            created += 1

    return HookResult(
        memories_created=created,
        details={
            "positive": len(req.positive_keywords[:5]),
            "negative": len(req.negative_keywords[:5]),
        },
    )


# ═══════════════════════════════════════════════════════
# 프로필 증류 nudge (중복 호출 방지 쿨다운 포함)
# ═══════════════════════════════════════════════════════


@router.post("/nudge-profile", response_model=dict)
async def nudge_profile(req: HookRequest):
    """
    매장에 20개 이상 메모리 쌓이면 자동 distill 수행.
    중복 호출 방지 (7일 쿨다운).
    """
    sb = _get_supabase()
    if sb is None:
        return {"distilled": False, "reason": "no-supabase"}

    try:
        # 현재 메모리 개수
        count_result = await asyncio.to_thread(
            lambda: sb.table("agent_memory")
            .select("id", count="exact")
            .eq("store_id", req.store_id)
            .is_("archived_at", "null")
            .execute()
        )
        memory_count = count_result.count or 0

        if memory_count < 20:
            return {"distilled": False, "reason": "not-enough-memories", "count": memory_count}

        # 마지막 증류 시점 확인 (stores.agent_profile에 distilled_at 포함)
        store_row = await asyncio.to_thread(
            lambda: sb.table("stores")
            .select("agent_profile")
            .eq("id", req.store_id)
            .limit(1)
            .execute()
        )
        if store_row.data:
            profile = store_row.data[0].get("agent_profile") or {}
            last = profile.get("_distilled_at")
            if last:
                last_dt = datetime.fromisoformat(last.replace("Z", "+00:00"))
                if (datetime.now(timezone.utc) - last_dt).days < 7:
                    return {"distilled": False, "reason": "cooldown", "days_left": 7 - (datetime.now(timezone.utc) - last_dt).days}

        # 증류 실행 (agent_briefing의 distill 로직 재사용)
        from app.routers.agent_briefing import distill_profile, DistillRequest

        result = await distill_profile(DistillRequest(store_id=req.store_id))

        # distilled_at 마커 업데이트
        updated_profile = dict(result.agent_profile)
        updated_profile["_distilled_at"] = datetime.now(timezone.utc).isoformat()
        await asyncio.to_thread(
            lambda: sb.table("stores")
            .update({"agent_profile": updated_profile})
            .eq("id", req.store_id)
            .execute()
        )

        return {
            "distilled": True,
            "memory_count": result.memory_count,
            "profile_keys": list(updated_profile.keys()),
        }
    except Exception as e:
        return {"distilled": False, "reason": "error", "error": str(e)[:200]}
