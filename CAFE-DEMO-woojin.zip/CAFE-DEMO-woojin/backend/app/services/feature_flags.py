"""
I5 — Feature flags (자체 OSS, 외부 의존 X)

원리:
  - flag 정의는 settings.feature_flags JSON 또는 DB feature_flags 테이블
  - 매장별 override: store_feature_flags(store_id, flag_key, enabled)
  - 평가 우선순위: store override > global default > False

Use:
    from app.services.feature_flags import is_enabled
    if await is_enabled("new_pos_ui", store_id=user_id):
        ...
"""
import asyncio
import logging
from typing import Optional

from app.services.gemini_service import _get_supabase

logger = logging.getLogger("feature_flags")

# 기본 flag 정의 (전역)
DEFAULT_FLAGS: dict[str, dict] = {
    "agent_self_correction": {"enabled": True, "description": "AI 답변 자가 검증 (E1)"},
    "instagram_publish": {"enabled": False, "description": "Instagram 직접 게시 (Beta)"},
    "advanced_anomaly_rules": {"enabled": True, "description": "이상치 룰 빌더 고급 모드"},
    "voice_input_stt": {"enabled": True, "description": "음성 입력 (STT)"},
    "demo_seeder": {"enabled": True, "description": "데모 데이터 시더"},
    "n8n_workflow": {"enabled": False, "description": "n8n 셀프호스팅 자동화"},
    "english_locale": {"enabled": True, "description": "영어 i18n"},
    "pos_auto_sync": {"enabled": False, "description": "POS 폴링 동기화 (Beta)"},
}

# 메모리 캐시 (5분 TTL)
_flag_cache: dict[str, tuple[bool, float]] = {}


async def is_enabled(flag_key: str, store_id: Optional[str] = None) -> bool:
    """
    flag 평가. 매장별 override가 있으면 그것 우선, 없으면 전역 default.
    """
    import time
    now = time.time()
    cache_key = f"{flag_key}:{store_id or 'global'}"
    cached = _flag_cache.get(cache_key)
    if cached and now - cached[1] < 300:
        return cached[0]

    sb = _get_supabase()

    # 1) 매장별 override
    if sb and store_id:
        try:
            res = await asyncio.to_thread(
                lambda: sb.table("store_feature_flags")
                .select("enabled")
                .eq("store_id", store_id)
                .eq("flag_key", flag_key)
                .limit(1)
                .single()
                .execute()
            )
            if res.data:
                value = bool(res.data["enabled"])
                _flag_cache[cache_key] = (value, now)
                return value
        except Exception:
            pass

    # 2) 전역 DB
    if sb:
        try:
            res = await asyncio.to_thread(
                lambda: sb.table("feature_flags")
                .select("enabled")
                .eq("flag_key", flag_key)
                .limit(1)
                .single()
                .execute()
            )
            if res.data:
                value = bool(res.data["enabled"])
                _flag_cache[cache_key] = (value, now)
                return value
        except Exception:
            pass

    # 3) DEFAULT_FLAGS fallback
    value = DEFAULT_FLAGS.get(flag_key, {}).get("enabled", False)
    _flag_cache[cache_key] = (value, now)
    return value


async def list_flags() -> list[dict]:
    """현재 모든 flag 상태 (default + DB override)."""
    return [
        {"key": k, "enabled": v["enabled"], "description": v["description"]}
        for k, v in DEFAULT_FLAGS.items()
    ]


def invalidate_cache(flag_key: Optional[str] = None) -> None:
    """flag 변경 시 호출. 특정 키 또는 전체."""
    if flag_key:
        keys = [k for k in _flag_cache if k.startswith(f"{flag_key}:")]
        for k in keys:
            _flag_cache.pop(k, None)
    else:
        _flag_cache.clear()
