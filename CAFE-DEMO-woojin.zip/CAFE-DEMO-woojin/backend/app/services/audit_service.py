"""
Phase 6 #11 — Agent action audit log service.

기록 대상:
  memory_delete    — 메모리 삭제 (망각권)
  memory_create    — 수동 메모리 추가
  feedback         — AI 제안 반응
  learning_toggle  — 학습 on/off
  profile_switch   — owner ↔ manager
  anomaly_rule_*   — 룰 변경

철학: 실패하면 조용히 넘어간다 — 감사 로그가 본 작업을 막으면 안 됨.
"""
import asyncio
from typing import Any, Optional

from app.services.gemini_service import _get_supabase


async def log_action(
    store_id: str,
    action: str,
    actor_id: Optional[str] = None,
    actor_role: Optional[str] = None,
    target_type: Optional[str] = None,
    target_id: Optional[str] = None,
    before: Optional[dict[str, Any]] = None,
    after: Optional[dict[str, Any]] = None,
    ip: Optional[str] = None,
    user_agent: Optional[str] = None,
) -> Optional[str]:
    """
    감사 로그 INSERT. 반환: 로그 id (실패 시 None).

    fire-and-forget으로 호출해도 안전하게 — 예외 무시.
    """
    sb = _get_supabase()
    if sb is None:
        return None

    payload: dict[str, Any] = {
        "store_id": store_id,
        "action": action,
    }
    if actor_id:
        payload["actor_id"] = actor_id
    if actor_role:
        payload["actor_role"] = actor_role
    if target_type:
        payload["target_type"] = target_type
    if target_id:
        payload["target_id"] = target_id
    if before is not None:
        payload["before"] = before
    if after is not None:
        payload["after"] = after
    if ip:
        payload["ip"] = ip[:64]
    if user_agent:
        payload["user_agent"] = user_agent[:200]

    try:
        result = await asyncio.to_thread(
            lambda: sb.table("agent_audit_log").insert(payload).execute()
        )
        if result.data:
            return result.data[0]["id"]
    except Exception:
        # 감사 로그 실패가 본 작업을 막으면 안 됨
        pass
    return None


async def list_audit_logs(
    store_id: str,
    action: Optional[str] = None,
    limit: int = 50,
) -> list[dict[str, Any]]:
    """본 매장 감사 로그 조회 (관리자 화면용)."""
    sb = _get_supabase()
    if sb is None:
        return []

    try:
        query = (
            sb.table("agent_audit_log")
            .select("id, action, actor_role, target_type, target_id, before, after, created_at")
            .eq("store_id", store_id)
            .order("created_at", desc=True)
            .limit(limit)
        )
        if action:
            query = query.eq("action", action)
        result = await asyncio.to_thread(lambda: query.execute())
        return result.data or []
    except Exception:
        return []
