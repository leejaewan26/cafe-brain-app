"""
Phase 6 #10: 메모리 자동 압축 — 같은 카테고리에 5+ 메모리가 30일 이상 쌓이면
Gemini가 정제된 1개로 압축 + 원본 archived.

원리:
- 검색·프롬프트에서 메모리 너무 많으면 신호 분산. 압축으로 핵심만 남김.
- 원본은 삭제 X, archived_at 세팅 → "잊어줘" 요청 시 영구 삭제 가능.

cron 호출:
- distill_worker_loop과 동일한 polling (1시간마다)
- 또는 매주 1회 별도 schedule (현재는 distill 안에서 함께)
"""
import asyncio
from typing import Any

from app.services.gemini_service import _get_supabase, generate_insight
from app.services.memory_service import insert_memory


COMPRESS_PROMPT_TEMPLATE = """
아래는 어느 카페 매장에 축적된 카테고리 '{category}' 메모리 {count}개입니다.
비슷한 패턴이 반복되는 메모리들입니다.

이들을 하나의 정제된 메모리로 **압축** 해주세요.

원본 메모리:
{memories_text}

규칙:
- 핵심 패턴·인사이트만 추출
- 구체적 수치·날짜는 평균·범위로 일반화
- 1~3문장 이내, 200자 이하
- 원본보다 정보 가치가 ↑ 되어야 함

압축된 한 줄 메모리만 출력 (설명·코드블록 X):
""".strip()


async def compress_memory_group(
    store_id: str,
    category: str,
    min_group_size: int = 5,
) -> dict[str, Any]:
    """
    한 카테고리 그룹을 압축. 결과:
      {compressed_id, original_count, compressed_content} 또는 {skipped: reason}
    """
    sb = _get_supabase()
    if sb is None:
        return {"skipped": "no-supabase"}

    # 1) 압축 대상 메모리 fetch
    try:
        result = await asyncio.to_thread(
            lambda: sb.rpc(
                "fetch_memories_for_compression",
                {
                    "p_store_id": store_id,
                    "p_category": category,
                    "p_limit": 20,
                },
            ).execute()
        )
        memories = result.data or []
    except Exception as e:
        return {"skipped": f"fetch-failed: {str(e)[:80]}"}

    if len(memories) < min_group_size:
        return {"skipped": f"below-threshold ({len(memories)})"}

    # 2) Gemini로 압축
    memories_text = "\n".join(
        f"  {i+1}. {m['content']} (중요도 {m['importance']})"
        for i, m in enumerate(memories[:20])
    )
    prompt = COMPRESS_PROMPT_TEMPLATE.format(
        category=category,
        count=len(memories),
        memories_text=memories_text,
    )

    try:
        compressed = await generate_insight(prompt, show_watermark=False)
        compressed = compressed.strip()
        if len(compressed) < 10 or len(compressed) > 500:
            return {"skipped": f"compression-quality-fail (len={len(compressed)})"}
    except Exception as e:
        return {"skipped": f"gemini-failed: {str(e)[:80]}"}

    # 3) 압축 메모리 INSERT (importance 9, 신뢰도 높음)
    new_id = await insert_memory(
        store_id=store_id,
        category=category,  # type: ignore[arg-type]
        content=f"[압축 메모리 {len(memories)}개→1] {compressed}",
        importance=9,
        confidence=0.85,
        source_type="memory_compressor",
        source_ref=f"{category}-compressed",
    )

    if not new_id:
        return {"skipped": "insert-failed"}

    # 4) 원본들 archived 처리
    original_ids = [m["id"] for m in memories]
    try:
        await asyncio.to_thread(
            lambda: sb.table("agent_memory")
            .update({"archived_at": "now()"})
            .in_("id", original_ids)
            .execute()
        )
    except Exception:
        pass  # 압축 자체는 성공, archived 실패는 다음 사이클에 처리

    return {
        "compressed_id": new_id,
        "original_count": len(memories),
        "compressed_content": compressed,
    }


async def run_compression_for_store(store_id: str) -> dict[str, Any]:
    """매장의 모든 압축 후보 카테고리에 대해 압축 실행."""
    sb = _get_supabase()
    if sb is None:
        return {"compressed": [], "skipped": []}

    # 후보 카테고리 조회
    try:
        result = await asyncio.to_thread(
            lambda: sb.rpc(
                "find_memory_compression_candidates",
                {"p_store_id": store_id, "p_min_group_size": 5, "p_min_age_days": 30},
            ).execute()
        )
        candidates = result.data or []
    except Exception:
        return {"compressed": [], "skipped": ["rpc-failed"]}

    compressed_results = []
    skipped_results = []

    for cand in candidates:
        cat = cand["category"]
        result = await compress_memory_group(store_id, cat)
        if "compressed_id" in result:
            compressed_results.append({"category": cat, **result})
        else:
            skipped_results.append({"category": cat, **result})

    return {"compressed": compressed_results, "skipped": skipped_results}
