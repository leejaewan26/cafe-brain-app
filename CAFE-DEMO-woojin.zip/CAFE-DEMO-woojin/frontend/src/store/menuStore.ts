// 메뉴·레시피 Zustand 스토어 - 샘플 5개 내장
import { create } from 'zustand'
import { persist } from 'zustand/middleware'
import type { MenuItem } from '@/types/menu'

interface MenuState {
  menus: MenuItem[]
  addMenu: (menu: Omit<MenuItem, 'id' | 'totalCost' | 'createdAt'>) => string
  updateMenu: (id: string, updates: Partial<MenuItem>) => void
  deleteMenu: (id: string) => void
  setRecipe: (id: string, recipe: string) => void
}

// ─── 샘플 메뉴 5개 ───
const SAMPLE_MENUS: MenuItem[] = [
  {
    id: 'menu-01',
    name: '시그니처 아이스 아메리카노',
    category: 'coffee',
    ingredients: [
      { id: 'ing-01-1', name: '에스프레소 원두', unitPrice: 80, amount: 18, unit: 'g' },
      { id: 'ing-01-2', name: '얼음', unitPrice: 5, amount: 200, unit: 'g' },
      { id: 'ing-01-3', name: '정수', unitPrice: 1, amount: 200, unit: 'ml' },
    ],
    totalCost: 80 * 18 / 1000 * 1000 + 5 * 0.2 + 1 * 0.2,
    salePrice: 5500,
    notes: '더블샷 기본 제공, 원두: 에티오피아+콜롬비아 블렌드',
    createdAt: '2024-03-01',
  },
  {
    id: 'menu-02',
    name: '카라멜 마키아토',
    category: 'coffee',
    ingredients: [
      { id: 'ing-02-1', name: '에스프레소 원두', unitPrice: 80, amount: 18, unit: 'g' },
      { id: 'ing-02-2', name: '우유', unitPrice: 3, amount: 200, unit: 'ml' },
      { id: 'ing-02-3', name: '카라멜 시럽', unitPrice: 15, amount: 20, unit: 'ml' },
      { id: 'ing-02-4', name: '바닐라 시럽', unitPrice: 12, amount: 10, unit: 'ml' },
    ],
    totalCost: 1440 + 600 + 300 + 120,
    salePrice: 6000,
    notes: '스팀밀크 → 에스프레소 순으로 부어 마블 연출',
    createdAt: '2024-03-01',
  },
  {
    id: 'menu-03',
    name: '딸기 케이크',
    category: 'dessert',
    ingredients: [
      { id: 'ing-03-1', name: '국내산 딸기', unitPrice: 25, amount: 100, unit: 'g' },
      { id: 'ing-03-2', name: '생크림', unitPrice: 8, amount: 80, unit: 'ml' },
      { id: 'ing-03-3', name: '스펀지 케이크', unitPrice: 6, amount: 120, unit: 'g' },
      { id: 'ing-03-4', name: '설탕', unitPrice: 2, amount: 30, unit: 'g' },
    ],
    totalCost: 2500 + 640 + 720 + 60,
    salePrice: 7500,
    notes: '시즌 한정 메뉴 (2~4월), 당일 제조 원칙',
    createdAt: '2024-03-01',
  },
  {
    id: 'menu-04',
    name: '아보카도 토스트',
    category: 'food',
    ingredients: [
      { id: 'ing-04-1', name: '아보카도', unitPrice: 18, amount: 100, unit: 'g' },
      { id: 'ing-04-2', name: '사워도우 빵', unitPrice: 10, amount: 80, unit: 'g' },
      { id: 'ing-04-3', name: '달걀', unitPrice: 5, amount: 50, unit: 'g' },
      { id: 'ing-04-4', name: '레몬즙', unitPrice: 8, amount: 10, unit: 'ml' },
      { id: 'ing-04-5', name: '올리브오일', unitPrice: 20, amount: 5, unit: 'ml' },
    ],
    totalCost: 1800 + 800 + 250 + 80 + 100,
    salePrice: 8500,
    notes: '반숙 달걀 옵션 가능, 플레이팅 미세 소금 추가',
    createdAt: '2024-03-01',
  },
  {
    id: 'menu-05',
    name: '말차 라떼',
    category: 'non_coffee',
    ingredients: [
      { id: 'ing-05-1', name: '말차 파우더', unitPrice: 50, amount: 8, unit: 'g' },
      { id: 'ing-05-2', name: '우유', unitPrice: 3, amount: 250, unit: 'ml' },
      { id: 'ing-05-3', name: '설탕 시럽', unitPrice: 5, amount: 15, unit: 'ml' },
    ],
    totalCost: 400 + 750 + 75,
    salePrice: 6500,
    notes: '아이스/핫 선택 가능, 오트밀크 변경 시 +500원',
    createdAt: '2024-03-01',
  },
]

// 재료비 합계 계산 유틸
export function calcTotalCost(ingredients: MenuItem['ingredients']): number {
  return ingredients.reduce((sum, ing) => {
    // 단가(원/100g 기준으로 정규화) × 사용량
    return sum + (ing.unitPrice * ing.amount) / 100
  }, 0)
}

export const useMenuStore = create<MenuState>()(
  persist(
    (set) => ({
      menus: SAMPLE_MENUS,

      addMenu: (menuData) => {
        const id = `menu-${Date.now()}`
        const totalCost = calcTotalCost(menuData.ingredients)
        set((state) => ({
          menus: [
            ...state.menus,
            { ...menuData, id, totalCost, createdAt: new Date().toISOString().split('T')[0] },
          ],
        }))
        return id
      },

      updateMenu: (id, updates) =>
        set((state) => ({
          menus: state.menus.map((m) => {
            if (m.id !== id) return m
            const updated = { ...m, ...updates }
            // 재료 변경 시 원가 재계산
            if (updates.ingredients) {
              updated.totalCost = calcTotalCost(updates.ingredients)
            }
            return updated
          }),
        })),

      deleteMenu: (id) =>
        set((state) => ({ menus: state.menus.filter((m) => m.id !== id) })),

      setRecipe: (id, recipe) =>
        set((state) => ({
          menus: state.menus.map((m) => (m.id === id ? { ...m, recipe } : m)),
        })),
    }),
    { name: 'cafe-brain-menus' }
  )
)
