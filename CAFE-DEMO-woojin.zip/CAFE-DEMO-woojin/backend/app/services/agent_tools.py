"""
Phase 6: Tool Use — 에이전트가 직접 데이터·기능을 호출
Gemini의 function calling으로 텍스트 응답 + 실제 액션 가능.

도구 목록 (안전한 것만):
  - get_sales_summary       매출 통계 조회 (period: today/week/month)
  - search_my_memories      메모리 의미 검색 (학습된 패턴 활용)
  - list_menus              현재 등록된 메뉴 목록
  - get_recent_reviews      최근 리뷰 N개 (감정·키워드 분석용)
  - get_trend_snapshot      가장 최근 트렌드 분석 결과 (캐시)
  - get_active_alerts       오늘의 미해결 알림·이상 이벤트

설계 원칙:
  - WRITE 작업 (메뉴 등록, 결제 등)은 Tool Use 안 함 → 사용자 명시 동의 필요
  - 모든 도구는 store_id 기반 RLS 안에서만 동작
  - 실패 시 빈 결과 반환 (에이전트 응답 망가뜨리지 않음)
"""
import asyncio
from datetime import date, timedelta, timezone, datetime

# KST = UTC+9 (Asia/Seoul)
KST = timezone(timedelta(hours=9))
from typing import Any, Optional

from app.services.gemini_service import _get_supabase
from app.services import memory_service


# ═══════════════════════════════════════════════════════
# Tool 함수 (실제 구현)
# ═══════════════════════════════════════════════════════


async def get_sales_summary(store_id: str, period: str = "week") -> dict:
    """매출 요약. period: today | week | month"""
    sb = _get_supabase()
    if sb is None:
        return {"error": "DB 연결 안 됨"}

    today = date.today()
    if period == "today":
        start = today
    elif period == "month":
        start = today.replace(day=1)
    else:  # week
        start = today - timedelta(days=7)

    try:
        result = await asyncio.to_thread(
            lambda: sb.table("sales_records")
            .select("revenue, cost, quantity, sale_date, menu_name")
            .eq("store_id", store_id)
            .gte("sale_date", start.isoformat())
            .lte("sale_date", today.isoformat())
            .execute()
        )
        rows = result.data or []
        total_revenue = sum(float(r.get("revenue", 0)) for r in rows)
        total_cost = sum(float(r.get("cost", 0)) for r in rows)
        total_qty = sum(int(r.get("quantity", 0)) for r in rows)

        # 메뉴별 집계 Top 5
        by_menu: dict[str, float] = {}
        for r in rows:
            m = r.get("menu_name", "?")
            by_menu[m] = by_menu.get(m, 0) + float(r.get("revenue", 0))
        top_menus = sorted(by_menu.items(), key=lambda x: x[1], reverse=True)[:5]

        return {
            "period": period,
            "start_date": start.isoformat(),
            "end_date": today.isoformat(),
            "total_revenue": round(total_revenue),
            "total_cost": round(total_cost),
            "gross_margin": round(total_revenue - total_cost),
            "margin_rate_pct": round((1 - total_cost / total_revenue) * 100, 1) if total_revenue > 0 else 0,
            "transaction_count": len(rows),
            "items_sold": total_qty,
            "top_menus": [{"menu": m, "revenue": round(v)} for m, v in top_menus],
        }
    except Exception as e:
        return {"error": f"매출 조회 실패: {str(e)[:100]}"}


async def search_my_memories(store_id: str, query: str, limit: int = 5) -> dict:
    """학습된 메모리에서 관련 항목 검색"""
    try:
        memories = await memory_service.search_memories(
            store_id=store_id, categories=None, limit=limit
        )
        # 간이 키워드 매칭 (의미 검색은 Phase 6/3 pgvector에서)
        q_lower = query.lower()
        scored = []
        for m in memories:
            content = (m.get("content") or "").lower()
            score = sum(1 for w in q_lower.split() if w in content)
            scored.append((score, m))
        scored.sort(key=lambda x: x[0], reverse=True)
        return {
            "query": query,
            "matches": [
                {
                    "category": m["category"],
                    "content": m["content"],
                    "importance": m["importance"],
                }
                for _, m in scored[:limit]
            ],
        }
    except Exception:
        return {"matches": []}


async def list_menus(store_id: str) -> dict:
    """현재 등록된 메뉴 목록 (이름·가격·카테고리)"""
    sb = _get_supabase()
    if sb is None:
        return {"menus": []}

    try:
        result = await asyncio.to_thread(
            lambda: sb.table("menus")
            .select("name, category, sale_price, total_cost")
            .eq("store_id", store_id)
            .order("name")
            .execute()
        )
        rows = result.data or []
        return {
            "count": len(rows),
            "menus": [
                {
                    "name": r["name"],
                    "category": r.get("category"),
                    "price": int(r.get("sale_price") or 0),
                    "cost": int(r.get("total_cost") or 0),
                    "margin_pct": round(
                        (1 - (r.get("total_cost") or 0) / r["sale_price"]) * 100, 1
                    ) if r.get("sale_price") else 0,
                }
                for r in rows
            ],
        }
    except Exception:
        return {"menus": []}


async def get_recent_reviews(store_id: str, limit: int = 10) -> dict:
    """최근 리뷰 (별점·키워드 빠른 파악용)"""
    sb = _get_supabase()
    if sb is None:
        return {"reviews": []}

    try:
        result = await asyncio.to_thread(
            lambda: sb.table("reviews")
            .select("nickname, rating, content, date, platform")
            .eq("store_id", store_id)
            .order("date", desc=True)
            .limit(limit)
            .execute()
        )
        rows = result.data or []
        avg = sum(int(r.get("rating", 0)) for r in rows) / len(rows) if rows else 0
        neg_count = sum(1 for r in rows if int(r.get("rating", 5)) <= 2)
        return {
            "count": len(rows),
            "average_rating": round(avg, 2),
            "negative_count": neg_count,
            "reviews": [
                {
                    "nickname": r.get("nickname"),
                    "rating": r.get("rating"),
                    "content": (r.get("content") or "")[:200],
                    "date": r.get("date"),
                    "platform": r.get("platform"),
                }
                for r in rows
            ],
        }
    except Exception:
        return {"reviews": []}


async def get_active_alerts(store_id: str) -> dict:
    """오늘의 미해결 알림·이상 이벤트 (event 카테고리 메모리)"""
    try:
        memories = await memory_service.search_memories(
            store_id=store_id, categories=["event"], limit=10
        )
        return {
            "count": len(memories),
            "alerts": [
                {
                    "content": m["content"],
                    "importance": m["importance"],
                    "created_at": m["created_at"],
                }
                for m in memories
            ],
        }
    except Exception:
        return {"alerts": []}


async def get_low_stock_ingredients(store_id: str, threshold_days: int = 7) -> dict:
    """I9 — 재고 부족 재료 조회. 최근 매출 패턴 대비 보유량으로 X일분 미만 산정."""
    sb = _get_supabase()
    if sb is None:
        return {"low_stock": [], "note": "Supabase 미설정"}
    try:
        ing_res = await asyncio.to_thread(
            lambda: sb.table("ingredients")
            .select("id, name, unit, unit_price, current_stock, min_stock")
            .eq("store_id", store_id)
            .execute()
        )
        ingredients = ing_res.data or []
        low = []
        for ing in ingredients:
            current = float(ing.get("current_stock") or 0)
            min_stock = float(ing.get("min_stock") or 0)
            if min_stock > 0 and current <= min_stock:
                low.append({
                    "name": ing["name"],
                    "current": current,
                    "min": min_stock,
                    "unit": ing.get("unit"),
                    "estimated_cost_to_replenish_krw": float(ing.get("unit_price") or 0) * max(0, min_stock * 2 - current),
                })
        return {"low_stock": low, "count": len(low), "threshold_days": threshold_days}
    except Exception as e:
        return {"low_stock": [], "error": str(e)[:100]}


async def get_today_schedule(store_id: str) -> dict:
    """I9 — 오늘 근무 일정 (실제 schema: schedules + employees JOIN)."""
    sb = _get_supabase()
    if sb is None:
        return {"shifts": [], "note": "Supabase 미설정"}
    today = datetime.now(KST)
    today_iso = today.date().isoformat()
    day_index = today.weekday()  # 0=월
    # week_start = 그 주의 월요일 (Mon) 또는 일요일(Sun) — 003 schema는 명시 X, 월요일 가정
    monday = (today - timedelta(days=day_index)).date().isoformat()

    try:
        # schedules + employees JOIN
        res = await asyncio.to_thread(
            lambda: sb.table("schedules")
            .select("start_hour, end_hour, employees(name, hourly_rate)")
            .eq("store_id", store_id)
            .eq("week_start", monday)
            .eq("day_index", day_index)
            .order("start_hour")
            .execute()
        )
        rows = res.data or []
        shifts = []
        total_hours = 0.0
        total_wage = 0
        for r in rows:
            emp = r.get("employees") or {}
            start_h = int(r.get("start_hour") or 0)
            end_h = int(r.get("end_hour") or 0)
            hours = max(0, end_h - start_h)
            wage = int(hours * float(emp.get("hourly_rate") or 9860))
            shifts.append({
                "name": emp.get("name", "이름 미등록"),
                "start_hour": start_h,
                "end_hour": end_h,
                "hours": hours,
                "wage_krw": wage,
            })
            total_hours += hours
            total_wage += wage
        return {
            "date": today_iso,
            "shifts": shifts,
            "total_count": len(shifts),
            "total_hours": round(total_hours, 1),
            "estimated_wage_krw": total_wage,
        }
    except Exception as e:
        return {"shifts": [], "error": str(e)[:100]}


async def get_finances_summary(store_id: str, month_offset: int = 0) -> dict:
    """I9 — 회계 요약 (이번 달 / 지난 달). 매출·매입·인건비·순이익."""
    sb = _get_supabase()
    if sb is None:
        return {"note": "Supabase 미설정"}

    target_date = datetime.now(KST).replace(day=1)
    if month_offset:
        # dateutil 없이 month 이동 (안정적)
        new_month = target_date.month + month_offset
        new_year = target_date.year
        while new_month <= 0:
            new_month += 12
            new_year -= 1
        while new_month > 12:
            new_month -= 12
            new_year += 1
        target_date = target_date.replace(year=new_year, month=new_month)
    month_str = target_date.strftime("%Y-%m")

    try:
        # 매출
        sales_res = await asyncio.to_thread(
            lambda: sb.rpc("monthly_revenue", {"p_store_id": store_id, "p_month": month_str}).execute()
        )
        revenue = (sales_res.data or [{}])[0].get("total", 0) if sales_res.data else 0
    except Exception:
        # RPC 없으면 직접 집계
        try:
            sales_res = await asyncio.to_thread(
                lambda: sb.table("sales_records")
                .select("revenue")
                .eq("store_id", store_id)
                .gte("sale_date", f"{month_str}-01")
                .lte("sale_date", f"{month_str}-31")
                .execute()
            )
            revenue = sum(int(r.get("revenue") or 0) for r in (sales_res.data or []))
        except Exception:
            revenue = 0

    # 인건비 (이번 달 schedules + employees JOIN — 주 4주 가정)
    try:
        wage_res = await asyncio.to_thread(
            lambda: sb.table("schedules")
            .select("start_hour, end_hour, week_start, employees(hourly_rate)")
            .eq("store_id", store_id)
            .gte("week_start", f"{month_str}-01")
            .lte("week_start", f"{month_str}-31")
            .execute()
        )
        labor_cost = 0
        for r in (wage_res.data or []):
            emp = r.get("employees") or {}
            hours = max(0, int(r.get("end_hour") or 0) - int(r.get("start_hour") or 0))
            labor_cost += int(hours * float(emp.get("hourly_rate") or 9860))
    except Exception:
        labor_cost = 0

    return {
        "month": month_str,
        "revenue_krw": revenue,
        "labor_cost_krw": labor_cost,
        "estimated_net_krw": revenue - labor_cost,
        "note": "원가/임대료 등은 별도 회계 모듈에서 정확히 계산하세요",
    }


async def get_trend_snapshot(store_id: str) -> dict:
    """최근 트렌드 스냅샷 (ai_cache에 저장된 trend_strategic_report)"""
    sb = _get_supabase()
    if sb is None:
        return {"available": False}
    try:
        result = await asyncio.to_thread(
            lambda: sb.table("ai_cache")
            .select("response, expires_at, created_at")
            .like("cache_key", "%trend_strategic_report%")
            .order("created_at", desc=True)
            .limit(1)
            .execute()
        )
        if not result.data:
            return {"available": False, "hint": "/trends 페이지에서 분석 받기 먼저 필요"}
        row = result.data[0]
        # 응답에서 첫 600자만 (요약용)
        return {
            "available": True,
            "summary": (row.get("response") or "")[:600],
            "cached_at": row.get("created_at"),
        }
    except Exception:
        return {"available": False}


# ═══════════════════════════════════════════════════════
# Gemini Function Calling 스키마
# ═══════════════════════════════════════════════════════

# Gemini SDK용 도구 선언
TOOL_DECLARATIONS = [
    {
        "name": "get_sales_summary",
        "description": "현재 매장의 매출 통계 조회. 합계·메뉴별·기간별 분석 가능. period는 'today', 'week', 'month' 중 선택.",
        "parameters": {
            "type": "object",
            "properties": {
                "period": {
                    "type": "string",
                    "enum": ["today", "week", "month"],
                    "description": "조회 기간",
                },
            },
            "required": [],
        },
    },
    {
        "name": "search_my_memories",
        "description": "AI가 학습한 매장 메모리에서 키워드 관련 항목 검색. '비 오는 날 매출'처럼 과거 패턴 회상 시 사용.",
        "parameters": {
            "type": "object",
            "properties": {
                "query": {"type": "string", "description": "검색 키워드"},
                "limit": {"type": "integer", "description": "결과 개수 (기본 5)"},
            },
            "required": ["query"],
        },
    },
    {
        "name": "list_menus",
        "description": "현재 매장 등록 메뉴 목록 조회. 이름·가격·원가·마진율 반환.",
        "parameters": {"type": "object", "properties": {}, "required": []},
    },
    {
        "name": "get_recent_reviews",
        "description": "최근 리뷰 N개 조회. 평균 별점·부정 리뷰 수 포함.",
        "parameters": {
            "type": "object",
            "properties": {
                "limit": {"type": "integer", "description": "리뷰 개수 (기본 10)"},
            },
            "required": [],
        },
    },
    {
        "name": "get_active_alerts",
        "description": "오늘의 미해결 알림·이상 이벤트 조회 (매출 급락, BEP 등 자동 감지).",
        "parameters": {"type": "object", "properties": {}, "required": []},
    },
    {
        "name": "get_trend_snapshot",
        "description": "최근 트렌드 분석 보고서 요약 (캐시 기반, 비용 0).",
        "parameters": {"type": "object", "properties": {}, "required": []},
    },
    {
        "name": "get_low_stock_ingredients",
        "description": "I9 — 재고 부족(min_stock 이하) 재료 목록 + 보충 비용 추정. 사장님이 '뭐 떨어졌어?' 같은 질문 시 사용.",
        "parameters": {
            "type": "object",
            "properties": {
                "threshold_days": {"type": "integer", "description": "X일분 미만 임계 (기본 7)"},
            },
            "required": [],
        },
    },
    {
        "name": "get_today_schedule",
        "description": "I9 — 오늘 직원 근무 일정 조회 (출근/퇴근 시각, 총 인건비 추정). '오늘 누구 일해?' 같은 질문에 사용.",
        "parameters": {"type": "object", "properties": {}, "required": []},
    },
    {
        "name": "get_finances_summary",
        "description": "I9 — 이번 달/지난 달 회계 요약 (매출·인건비·추정 순이익). '이번달 얼마 벌었어?' 같은 질문에 사용. month_offset=-1이면 지난 달.",
        "parameters": {
            "type": "object",
            "properties": {
                "month_offset": {"type": "integer", "description": "0=이번달 (기본), -1=지난달"},
            },
            "required": [],
        },
    },
]

# 함수 이름 → 비동기 핸들러 매핑
TOOL_HANDLERS: dict[str, Any] = {
    "get_sales_summary": get_sales_summary,
    "search_my_memories": search_my_memories,
    "list_menus": list_menus,
    "get_recent_reviews": get_recent_reviews,
    "get_active_alerts": get_active_alerts,
    "get_trend_snapshot": get_trend_snapshot,
    # I9 추가
    "get_low_stock_ingredients": get_low_stock_ingredients,
    "get_today_schedule": get_today_schedule,
    "get_finances_summary": get_finances_summary,
}


async def execute_tool(name: str, args: dict, store_id: str) -> dict:
    """
    Gemini가 호출 요청한 도구를 실제로 실행.
    store_id는 항상 자동 주입 (사용자가 다른 매장 데이터 못 봄).
    """
    handler = TOOL_HANDLERS.get(name)
    if not handler:
        return {"error": f"알 수 없는 도구: {name}"}
    try:
        # store_id는 항상 첫 인자로 자동 주입
        return await handler(store_id, **args)
    except TypeError:
        # store_id 안 받는 도구도 있을 수 있음 (현재는 전부 받지만 안전)
        try:
            return await handler(**args)
        except Exception as e:
            return {"error": str(e)[:100]}
    except Exception as e:
        return {"error": str(e)[:100]}
