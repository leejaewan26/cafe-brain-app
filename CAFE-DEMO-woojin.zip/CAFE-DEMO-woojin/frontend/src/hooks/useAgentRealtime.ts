// Phase 6 #2: Supabase Realtime — 새 에이전트 메모리 즉시 푸시
//
// 구독 대상: agent_memory INSERT 이벤트 (RLS로 본인 매장만)
// 트리거 카테고리: event, goal (sales_anomaly·BEP 등 중요 이벤트)
// 동작: toast 알림 + (옵션) Web Push
//
// 사용처: AppLayout에 useAgentRealtime() 한 번 호출 → 모든 인증 페이지에서 활성
import { useEffect } from 'react'
import toast from 'react-hot-toast'
import { supabase } from '@/lib/supabase'
import { useAuthStore } from '@/store/authStore'

// 즉시 알림 보낼 카테고리
const ALERT_CATEGORIES = new Set(['event', 'goal'])

// 카테고리·source_type별 사람이 읽기 좋은 라벨
const SOURCE_LABEL: Record<string, { emoji: string; title: string }> = {
  sales_anomaly: { emoji: '📉', title: '매출 이상 감지' },
  bep_reached:   { emoji: '🎯', title: 'BEP 달성!' },
  review_new:    { emoji: '⭐', title: '새 리뷰' },
  trend_report:  { emoji: '🔥', title: '트렌드 시그널' },
}

interface MemoryRow {
  id: string
  store_id: string
  category: string
  content: string
  importance: number
  source_type: string | null
  created_at: string
}

export function useAgentRealtime() {
  const user = useAuthStore((s) => s.user)

  useEffect(() => {
    if (!user) return

    const channel = supabase
      .channel(`agent_memory_${user.id}`)
      .on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'agent_memory',
          filter: `store_id=eq.${user.id}`,
        },
        (payload) => {
          const row = payload.new as MemoryRow
          if (!row || !ALERT_CATEGORIES.has(row.category)) return

          const label = SOURCE_LABEL[row.source_type ?? ''] ?? {
            emoji: '🔔',
            title: '에이전트 알림',
          }

          // 토스트 알림 (4초)
          toast(
            `${label.emoji} ${label.title}\n${row.content.slice(0, 80)}${row.content.length > 80 ? '…' : ''}`,
            {
              duration: 5000,
              style: {
                background: '#2C1810',
                color: '#fff',
                fontWeight: 500,
                fontSize: 13,
                whiteSpace: 'pre-wrap',
                maxWidth: 380,
                border: '2px solid #D4A574',
              },
              icon: undefined,  // 위 텍스트의 emoji 사용
            },
          )

          // Web Push (권한 있고 PushManager 등록됐을 때만)
          if (typeof window !== 'undefined' && 'Notification' in window && Notification.permission === 'granted') {
            try {
              new Notification(`${label.emoji} ${label.title}`, {
                body: row.content.slice(0, 120),
                icon: '/cafe-icon.svg',
                tag: `agent-${row.id}`,
              })
            } catch {/* 조용히 */}
          }
        },
      )
      .subscribe()

    return () => {
      void supabase.removeChannel(channel)
    }
  }, [user])
}
