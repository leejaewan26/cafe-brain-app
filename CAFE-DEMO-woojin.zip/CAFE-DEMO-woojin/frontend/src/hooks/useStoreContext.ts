// useStoreContext 훅 - 매장 정보를 AI 프롬프트 컨텍스트로 주입하는 핵심 훅
//
// Phase 3·4 보강: 영업시간 / 월 고정비 / 인건비 비율 / 활성 프로필 역할까지 포함.
// AI가 시간대·재무·권한 문맥을 알고 더 정확한 답변 가능.
import { useCallback } from 'react'
import { useAuthStore } from '@/store/authStore'
import { useProfileStore } from '@/store/profileStore'
import type { Store } from '@/types/store'

export interface StoreContext {
  storeName: string
  ownerName: string
  districtType: string
  menuCount: number
  employeeCount: number
  avgMonthlySales: number
  ambianceKeywords: string[]
  targetLaborRatio: number
  // Phase 3·4 보강
  openHour?: number
  closeHour?: number
  monthlyFixedCost?: number
  activeProfileRole?: string
  activeProfileName?: string
}

/**
 * 모든 AI 프롬프트에 주입할 매장 컨텍스트를 생성하는 훅
 * 온보딩에서 수집한 데이터 + Phase 3 영업시간 + 활성 프로필을 LLM이
 * 이해하기 쉬운 마크다운 형식으로 변환.
 */
export function useStoreContext() {
  const { storeInfo, setStoreInfo } = useAuthStore()
  const activeProfile = useProfileStore((s) => s.activeProfile)

  // AI 프롬프트 컨텍스트 문자열 생성
  const buildPromptContext = useCallback((): string => {
    if (!storeInfo) return '[매장 정보 없음 — 온보딩 미완료]'

    // Phase 3·4 신규 필드 (있을 때만 표시)
    const openH = storeInfo.open_hour ?? 6
    const closeH = storeInfo.close_hour ?? 22
    const fixedCost = storeInfo.monthly_fixed_cost ?? 0
    const laborRatio = Math.round((storeInfo.target_labor_ratio ?? 0.25) * 100)

    // 활성 프로필 (권한별 답변에 활용)
    const profileLine = activeProfile
      ? `- 현재 사용자: ${activeProfile.name} (${activeProfile.role === 'owner' ? '사장' : '점장·매니저'})`
      : ''

    return `
[매장 정보 컨텍스트]
- 매장명: ${storeInfo.store_name}
- 대표자: ${storeInfo.owner_name}
- 상권: ${storeInfo.district_type}
- 평균 메뉴 수: ${storeInfo.menu_count}개
- 직원 수: ${storeInfo.employee_count}명
- 월 평균 매출: ${storeInfo.avg_monthly_sales.toLocaleString('ko-KR')}원
- 월 고정비(임대+인건비+관리비): ${fixedCost > 0 ? fixedCost.toLocaleString('ko-KR') + '원' : '미입력'}
- 목표 인건비 비율: ${laborRatio}%
- 매장 분위기: ${storeInfo.ambiance_keywords.join(', ') || '미설정'}
- 영업 시간: ${openH}시 ~ ${closeH}시 (KST)
${profileLine}
`.trim()
  }, [storeInfo, activeProfile])

  // 구조화된 컨텍스트 객체 반환
  const getStoreContext = useCallback((): StoreContext | null => {
    if (!storeInfo) return null
    return {
      storeName: storeInfo.store_name,
      ownerName: storeInfo.owner_name,
      districtType: storeInfo.district_type,
      menuCount: storeInfo.menu_count,
      employeeCount: storeInfo.employee_count,
      avgMonthlySales: storeInfo.avg_monthly_sales,
      ambianceKeywords: storeInfo.ambiance_keywords,
      targetLaborRatio: storeInfo.target_labor_ratio,
      openHour: storeInfo.open_hour ?? undefined,
      closeHour: storeInfo.close_hour ?? undefined,
      monthlyFixedCost: storeInfo.monthly_fixed_cost ?? undefined,
      activeProfileRole: activeProfile?.role,
      activeProfileName: activeProfile?.name,
    }
  }, [storeInfo, activeProfile])

  // 매장 정보 업데이트
  const updateStoreInfo = useCallback(
    (info: Store) => {
      setStoreInfo(info)
    },
    [setStoreInfo]
  )

  return {
    storeInfo,
    buildPromptContext,
    getStoreContext,
    updateStoreInfo,
    hasStoreInfo: !!storeInfo,
  }
}
