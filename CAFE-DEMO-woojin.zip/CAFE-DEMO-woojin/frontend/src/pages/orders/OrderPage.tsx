// 발주 관리 페이지 (Issue #8)
// 점장: 요청 작성 + 내 요청 조회
// 사장: 승인 대기 리스트 + 승인/반려
// 공통: 전체 이력, 파일 다운로드
import { useEffect, useMemo, useState } from 'react'
// ESC/aria-modal — Batch 3 Round 1 접근성 개선
import { Link } from 'react-router-dom'
import {
  ShoppingCart, ChevronLeft, Plus, Check, X, Download, Loader2,
  Truck, Package, Trash2,
} from 'lucide-react'
import toast from 'react-hot-toast'
import { useAuthStore } from '@/store/authStore'
import { useProfileStore, canAccess } from '@/store/profileStore'
import { useOrderStore, ORDER_STATUS_META, type Order, type OrderItem } from '@/store/orderStore'
import ExportMenu from '@/components/ExportMenu'
import { cn, formatCurrency } from '@/lib/utils'

type Tab = 'pending' | 'my' | 'history'

export default function OrderPage() {
  const storeId = useAuthStore((s) => s.user?.id)
  const activeProfile = useProfileStore((s) => s.activeProfile)
  const { orders, loading, fetchOrders } = useOrderStore()

  const [tab, setTab] = useState<Tab>(
    canAccess(activeProfile, 'order_approval') ? 'pending' : 'my'
  )
  const [showCreate, setShowCreate] = useState(false)

  useEffect(() => {
    if (storeId) void fetchOrders(storeId)
  }, [storeId, fetchOrders])

  const isOwner = activeProfile?.role === 'owner'

  const pendingOrders = useMemo(
    () => orders.filter((o) => o.status === 'pending'),
    [orders]
  )

  const myOrders = useMemo(
    () =>
      activeProfile
        ? orders.filter((o) => o.requested_by_profile_id === activeProfile.id)
        : [],
    [orders, activeProfile]
  )

  const activeOrders = tab === 'pending' ? pendingOrders
    : tab === 'my' ? myOrders
    : orders

  return (
    <div className="min-h-screen bg-[#FAFAF8]">
      <header className="bg-[#2C1810] text-white px-4 py-3 flex items-center gap-3">
        <Link to="/dashboard" className="hover:text-[#D4A574] transition-colors">
          <ChevronLeft size={20} />
        </Link>
        <ShoppingCart size={18} className="text-[#D4A574]" />
        <h1 className="font-bold text-base flex-1">발주 관리</h1>
        {/* Day 4-1: 발주 이력 내보내기 */}
        {orders.length > 0 && (
          <ExportMenu
            rows={orders as unknown as Record<string, unknown>[]}
            title="발주이력"
            printableId="print-orders-report"
            size="sm"
          />
        )}
        <button
          onClick={() => setShowCreate(true)}
          className="flex items-center gap-1 px-3 py-1.5 bg-[#D4A574] text-[#2C1810] rounded-lg text-xs font-semibold hover:bg-[#c4956a] transition-colors"
        >
          <Plus size={13} /> 새 발주 요청
        </button>
      </header>

      {/* 탭 네비 */}
      <div className="flex bg-white border-b border-gray-100 px-2 pt-2 overflow-x-auto">
        {isOwner && (
          <TabButton active={tab === 'pending'} onClick={() => setTab('pending')} label={`📥 승인 대기 ${pendingOrders.length > 0 ? `(${pendingOrders.length})` : ''}`} />
        )}
        <TabButton active={tab === 'my'} onClick={() => setTab('my')} label="✏️ 내 요청" />
        <TabButton active={tab === 'history'} onClick={() => setTab('history')} label="📋 전체 이력" />
      </div>

      <main className="max-w-2xl mx-auto px-4 py-4 pb-24" id="print-orders-report">
        <div className="print-only mb-4">
          <h1>발주 이력 리포트</h1>
          <p style={{ fontSize: '10pt', color: '#666' }}>
            생성일: {new Date().toLocaleDateString('ko-KR')} · 총 {orders.length}건
          </p>
        </div>
        {loading && (
          <div className="flex items-center justify-center py-10">
            <Loader2 className="w-6 h-6 animate-spin text-[#D4A574]" />
          </div>
        )}

        {!loading && activeOrders.length === 0 && (
          <div className="bg-white rounded-2xl p-10 text-center text-gray-400 border border-gray-100">
            <Package size={28} className="mx-auto mb-2 opacity-30" />
            <p className="text-sm">{tab === 'pending' ? '승인 대기 중인 발주가 없어요' : '발주 이력이 없어요'}</p>
          </div>
        )}

        <div className="space-y-3">
          {activeOrders.map((order) => (
            <OrderCard key={order.id} order={order} />
          ))}
        </div>
      </main>

      {showCreate && (
        <CreateOrderModal
          onClose={() => setShowCreate(false)}
          onCreated={() => { setShowCreate(false); setTab('my') }}
        />
      )}
    </div>
  )
}

// ─── 탭 버튼 ───
function TabButton({ active, onClick, label }: { active: boolean; onClick: () => void; label: string }) {
  return (
    <button
      onClick={onClick}
      className={cn(
        'shrink-0 px-4 py-2.5 text-sm font-medium rounded-t-lg transition-all duration-200 whitespace-nowrap',
        active ? 'bg-[#2C1810] text-white' : 'text-gray-500 hover:text-[#2C1810] hover:bg-gray-50'
      )}
    >
      {label}
    </button>
  )
}

// ─── 발주 카드 ───
function OrderCard({ order }: { order: Order }) {
  const activeProfile = useProfileStore((s) => s.activeProfile)
  const { approveOrder, rejectOrder, markOrdered, markReceived } = useOrderStore()
  const [expanded, setExpanded] = useState(false)
  const [actioning, setActioning] = useState(false)
  const isOwner = activeProfile?.role === 'owner'
  const meta = ORDER_STATUS_META[order.status]

  const totalEstimate = order.items.reduce(
    (s, i) => s + (i.estimated_total ?? (i.estimated_unit_price ?? 0) * i.quantity),
    0
  )

  const handleApprove = async () => {
    if (!activeProfile) return
    setActioning(true)
    try {
      await approveOrder(order.id, activeProfile.id, activeProfile.name)
      toast.success('발주가 승인되었어요')
    } catch (e) {
      toast.error(e instanceof Error ? e.message : '승인 실패')
    } finally { setActioning(false) }
  }

  const handleReject = async () => {
    if (!activeProfile) return
    const reason = prompt('반려 사유를 입력해주세요 (필수)')
    if (!reason || !reason.trim()) {
      toast.error('반려 사유는 필수입니다')
      return
    }
    setActioning(true)
    try {
      await rejectOrder(order.id, reason.trim(), activeProfile.name)
      toast.success('발주가 반려되었어요')
    } catch (e) {
      toast.error(e instanceof Error ? e.message : '반려 실패')
    } finally { setActioning(false) }
  }

  const handleDownload = async (format: 'xlsx' | 'csv') => {
    // 동적 import로 번들 크기 최소화
    if (format === 'xlsx') {
      try {
        const XLSX = await import('xlsx')
        const wsData = [
          ['발주 요청서'],
          ['매장', '발주처', order.supplier_name],
          ['요청자', order.requested_by_name],
          ['상태', meta.label],
          ['요청일', new Date(order.requested_at).toLocaleString('ko-KR')],
          [],
          ['품목', '수량', '단위', '단가', '합계', '비고'],
          ...order.items.map((i) => [
            i.ingredient_name,
            i.quantity,
            i.unit,
            i.estimated_unit_price ?? '',
            i.estimated_total ?? (i.estimated_unit_price ?? 0) * i.quantity,
            i.item_notes ?? '',
          ]),
          [],
          ['예상 합계', '', '', '', totalEstimate],
        ]
        const wb = XLSX.utils.book_new()
        const ws = XLSX.utils.aoa_to_sheet(wsData)
        XLSX.utils.book_append_sheet(wb, ws, '발주')
        XLSX.writeFile(wb, `발주_${order.supplier_name}_${order.requested_at.slice(0, 10)}.xlsx`)
      } catch {
        toast.error('엑셀 다운로드 실패 — CSV로 대신 저장합니다')
        handleDownload('csv')
      }
    } else {
      // CSV fallback
      const rows = [
        ['품목', '수량', '단위', '단가', '합계', '비고'],
        ...order.items.map((i) => [
          i.ingredient_name,
          String(i.quantity),
          i.unit,
          String(i.estimated_unit_price ?? ''),
          String(i.estimated_total ?? ''),
          i.item_notes ?? '',
        ]),
      ]
      const csv = rows.map((r) => r.map((c) => `"${c.replace(/"/g, '""')}"`).join(',')).join('\n')
      const blob = new Blob(['\uFEFF' + csv], { type: 'text/csv;charset=utf-8;' })
      const url = URL.createObjectURL(blob)
      const a = document.createElement('a')
      a.href = url
      a.download = `order_${order.requested_at.slice(0, 10)}.csv`
      a.click()
      URL.revokeObjectURL(url)
    }
  }

  return (
    <div className="bg-white rounded-2xl border border-gray-100 shadow-sm">
      <div className="p-4">
        <div className="flex items-start gap-3">
          <div className="w-10 h-10 rounded-xl bg-[#D4A574]/15 flex items-center justify-center shrink-0">
            <Package size={18} className="text-[#D4A574]" />
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 mb-1">
              <p className="font-semibold text-[#2C1810] truncate">{order.supplier_name}</p>
              <span className={cn('text-[10px] font-bold px-2 py-0.5 rounded-full', meta.bg, meta.color)}>
                {meta.label}
              </span>
            </div>
            <p className="text-xs text-gray-500">
              요청자 {order.requested_by_name} · {new Date(order.requested_at).toLocaleString('ko-KR')}
            </p>
            <p className="text-xs text-gray-400 mt-0.5">
              {order.items.length}개 품목 · 예상 {formatCurrency(totalEstimate)}
            </p>
            {order.rejected_reason && (
              <p className="text-xs text-red-600 bg-red-50 rounded-lg p-2 mt-2">
                반려 사유: {order.rejected_reason}
              </p>
            )}
          </div>
        </div>

        {/* 액션 버튼 */}
        <div className="flex items-center gap-2 mt-3 pl-12 flex-wrap">
          <button
            onClick={() => setExpanded(!expanded)}
            className="text-xs text-gray-500 hover:text-[#2C1810] px-2 py-1 rounded-lg hover:bg-gray-50"
          >
            {expanded ? '접기' : '품목 보기'}
          </button>

          {/* 사장: 승인/반려 */}
          {isOwner && order.status === 'pending' && (
            <>
              <button onClick={handleApprove} disabled={actioning}
                className="flex items-center gap-1 px-2.5 py-1 bg-green-600 text-white rounded-lg text-xs font-medium hover:bg-green-700 disabled:opacity-50">
                <Check size={12} /> 승인
              </button>
              <button onClick={handleReject} disabled={actioning}
                className="flex items-center gap-1 px-2.5 py-1 bg-red-500 text-white rounded-lg text-xs font-medium hover:bg-red-600 disabled:opacity-50">
                <X size={12} /> 반려
              </button>
            </>
          )}

          {/* 사장: 발주 완료 / 수령 완료 */}
          {isOwner && order.status === 'approved' && (
            <button onClick={() => markOrdered(order.id)}
              className="flex items-center gap-1 px-2.5 py-1 bg-purple-600 text-white rounded-lg text-xs font-medium hover:bg-purple-700">
              <Truck size={12} /> 발주 완료
            </button>
          )}
          {order.status === 'ordered' && (
            <button onClick={() => markReceived(order.id)}
              className="flex items-center gap-1 px-2.5 py-1 bg-green-600 text-white rounded-lg text-xs font-medium hover:bg-green-700">
              <Check size={12} /> 수령 확인
            </button>
          )}

          {/* 다운로드 */}
          <div className="ml-auto flex gap-1">
            <button onClick={() => handleDownload('xlsx')}
              className="flex items-center gap-1 px-2.5 py-1 border border-gray-200 text-gray-600 rounded-lg text-xs hover:bg-gray-50">
              <Download size={11} /> xlsx
            </button>
            <button onClick={() => handleDownload('csv')}
              className="flex items-center gap-1 px-2.5 py-1 border border-gray-200 text-gray-600 rounded-lg text-xs hover:bg-gray-50">
              <Download size={11} /> csv
            </button>
          </div>
        </div>
      </div>

      {/* 품목 상세 */}
      {expanded && (
        <div className="border-t border-gray-100 p-4 bg-[#FAFAF8]">
          <table className="w-full text-xs">
            <thead>
              <tr className="text-gray-500 border-b border-gray-200">
                <th className="text-left py-1.5 font-medium">품목</th>
                <th className="text-right py-1.5 font-medium">수량</th>
                <th className="text-right py-1.5 font-medium">단가</th>
                <th className="text-right py-1.5 font-medium">합계</th>
              </tr>
            </thead>
            <tbody>
              {order.items.map((i) => (
                <tr key={i.id} className="border-b border-gray-100 last:border-0">
                  <td className="py-1.5">{i.ingredient_name}{i.item_notes && <span className="text-gray-400 ml-1">({i.item_notes})</span>}</td>
                  <td className="text-right py-1.5">{i.quantity} {i.unit}</td>
                  <td className="text-right py-1.5 text-gray-500">
                    {i.estimated_unit_price ? formatCurrency(i.estimated_unit_price) : '-'}
                  </td>
                  <td className="text-right py-1.5 font-medium">
                    {formatCurrency(i.estimated_total ?? (i.estimated_unit_price ?? 0) * i.quantity)}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          {order.notes && (
            <p className="text-xs text-gray-500 mt-3 p-2 bg-white rounded-lg">📝 {order.notes}</p>
          )}
        </div>
      )}
    </div>
  )
}

// ─── 발주 생성 모달 ───
function CreateOrderModal({ onClose, onCreated }: { onClose: () => void; onCreated: () => void }) {
  const storeId = useAuthStore((s) => s.user?.id)
  const activeProfile = useProfileStore((s) => s.activeProfile)
  const { createOrder } = useOrderStore()

  const [supplierName, setSupplierName] = useState('')
  const [supplierPhone, setSupplierPhone] = useState('')
  const [notes, setNotes] = useState('')
  const [items, setItems] = useState<Array<Omit<OrderItem, 'id' | 'order_id'>>>([
    { ingredient_name: '', quantity: 1, unit: '개', estimated_unit_price: null, estimated_total: null, item_notes: null },
  ])
  const [saving, setSaving] = useState(false)

  const addItem = () => setItems([...items, {
    ingredient_name: '', quantity: 1, unit: '개',
    estimated_unit_price: null, estimated_total: null, item_notes: null,
  }])

  const updateItem = (idx: number, patch: Partial<OrderItem>) => {
    setItems(items.map((i, n) => (n === idx ? { ...i, ...patch } : i)))
  }

  const removeItem = (idx: number) => {
    setItems(items.filter((_, n) => n !== idx))
  }

  const handleSubmit = async () => {
    if (!storeId || !activeProfile) return
    if (!supplierName.trim()) { toast.error('발주처를 입력하세요'); return }
    const validItems = items.filter((i) => i.ingredient_name.trim() && i.quantity > 0)
    if (validItems.length === 0) { toast.error('품목을 1개 이상 입력하세요'); return }

    setSaving(true)
    try {
      await createOrder(storeId, activeProfile.id, activeProfile.name, {
        supplier_name: supplierName.trim(),
        supplier_phone: supplierPhone.trim() || undefined,
        notes: notes.trim() || undefined,
        items: validItems,
      })
      toast.success('발주 요청이 제출되었어요')
      onCreated()
    } catch (e) {
      toast.error(e instanceof Error ? e.message : '제출 실패')
    } finally {
      setSaving(false)
    }
  }

  // ESC 키로 모달 종료 (접근성)
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose()
    }
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [onClose])

  return (
    <div
      className="fixed inset-0 bg-black/50 flex items-end md:items-center justify-center z-50 md:p-4"
      role="dialog"
      aria-modal="true"
      aria-labelledby="new-order-title"
      onClick={(e) => { if (e.target === e.currentTarget) onClose() }}
    >
      <div className="bg-white w-full md:max-w-2xl md:rounded-2xl rounded-t-3xl max-h-[90vh] overflow-y-auto">
        <header className="sticky top-0 bg-white border-b border-gray-100 p-4 flex items-center justify-between z-10">
          <h2 id="new-order-title" className="font-bold text-[#2C1810]">새 발주 요청</h2>
          <button onClick={onClose} aria-label="닫기" className="p-1.5 hover:bg-gray-100 rounded-full">
            <X size={18} />
          </button>
        </header>

        <div className="p-4 space-y-4">
          {/* 발주처 */}
          <div>
            <label className="text-xs font-semibold text-gray-600 block mb-1.5">발주처 *</label>
            <input value={supplierName} onChange={(e) => setSupplierName(e.target.value)}
              className="w-full px-3 py-2 rounded-xl border border-gray-200 text-sm focus:outline-none focus:ring-2 focus:ring-[#D4A574]"
              placeholder="예) 쿠팡, OO식자재" />
          </div>
          <div>
            <label className="text-xs font-semibold text-gray-600 block mb-1.5">발주처 연락처</label>
            <input value={supplierPhone} onChange={(e) => setSupplierPhone(e.target.value)}
              className="w-full px-3 py-2 rounded-xl border border-gray-200 text-sm focus:outline-none focus:ring-2 focus:ring-[#D4A574]" />
          </div>

          {/* 품목 리스트 */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <label className="text-xs font-semibold text-gray-600">품목 *</label>
              <button onClick={addItem} className="text-xs text-[#D4A574] font-semibold hover:text-[#c4956a]">
                <Plus size={11} className="inline" /> 품목 추가
              </button>
            </div>
            <div className="space-y-2">
              {items.map((item, idx) => (
                <div key={idx} className="grid grid-cols-12 gap-2 items-start">
                  <input value={item.ingredient_name}
                    onChange={(e) => updateItem(idx, { ingredient_name: e.target.value })}
                    className="col-span-5 px-2 py-1.5 rounded-lg border border-gray-200 text-xs focus:outline-none focus:ring-1 focus:ring-[#D4A574]"
                    placeholder="품목명" />
                  <input type="number" value={item.quantity || ''}
                    onChange={(e) => updateItem(idx, { quantity: Number(e.target.value) || 0 })}
                    className="col-span-2 px-2 py-1.5 rounded-lg border border-gray-200 text-xs focus:outline-none focus:ring-1 focus:ring-[#D4A574]"
                    placeholder="수량" />
                  <input value={item.unit}
                    onChange={(e) => updateItem(idx, { unit: e.target.value })}
                    className="col-span-2 px-2 py-1.5 rounded-lg border border-gray-200 text-xs focus:outline-none focus:ring-1 focus:ring-[#D4A574]"
                    placeholder="단위" />
                  <input type="number" value={item.estimated_unit_price || ''}
                    onChange={(e) => updateItem(idx, { estimated_unit_price: Number(e.target.value) || null })}
                    className="col-span-2 px-2 py-1.5 rounded-lg border border-gray-200 text-xs focus:outline-none focus:ring-1 focus:ring-[#D4A574]"
                    placeholder="단가" />
                  <button onClick={() => removeItem(idx)} className="col-span-1 p-1.5 text-red-400 hover:bg-red-50 rounded-lg">
                    <Trash2 size={13} />
                  </button>
                </div>
              ))}
            </div>
          </div>

          {/* 메모 */}
          <div>
            <label className="text-xs font-semibold text-gray-600 block mb-1.5">메모</label>
            <textarea value={notes} onChange={(e) => setNotes(e.target.value)}
              className="w-full px-3 py-2 rounded-xl border border-gray-200 text-sm focus:outline-none focus:ring-2 focus:ring-[#D4A574] resize-none"
              rows={2} placeholder="배송일 요청, 특이사항 등" />
          </div>
        </div>

        <footer className="sticky bottom-0 bg-white border-t border-gray-100 p-4 flex gap-2">
          <button onClick={onClose} className="flex-1 py-2.5 border border-gray-200 rounded-xl text-sm text-gray-600 hover:bg-gray-50">
            취소
          </button>
          <button onClick={handleSubmit} disabled={saving}
            className="flex-1 py-2.5 bg-[#2C1810] text-white rounded-xl text-sm font-semibold hover:bg-[#3d2418] disabled:opacity-50">
            {saving ? <Loader2 size={14} className="inline animate-spin" /> : '요청 제출'}
          </button>
        </footer>
      </div>
    </div>
  )
}
