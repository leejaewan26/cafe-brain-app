"""
F6 — GDPR/PIPA 데이터 이동·삭제권 (Right to data portability + erasure).

엔드포인트:
- GET  /api/data/export?store_id=...    → JSON ZIP (모든 매장 데이터)
- POST /api/data/erase                  → 전체 매장 데이터 삭제 (탈퇴용)

원칙:
- 본인 매장 데이터만 (Bearer 토큰의 sub == store_id 검증은 RLS가 처리)
- 비밀번호·결제 토큰 등 민감 정보는 export X
- erase는 cascade — agent_memory, audit_log, latency_log, anomaly_rules,
  push_subscriptions 등 모두 정리
"""
import asyncio
import io
import json
import zipfile
from datetime import datetime, timezone
from typing import Any

from fastapi import APIRouter, Header, HTTPException
from fastapi.responses import StreamingResponse

from app.services.gemini_service import _get_supabase

router = APIRouter()

# 매장 데이터가 있는 테이블 — store_id 컬럼 가진 모든 테이블
EXPORTABLE_TABLES = [
    "stores",                    # 본인만 (id == store_id)
    "agent_memory",
    "agent_audit_log",
    "agent_anomaly_rules",
    "agent_briefing_log",
    "agent_feedback",
    "ai_cache",
    "sales_records",
    "menus",
    "ingredients",
    "orders",
    "reviews",
    "chat_history",
    "push_subscriptions",
    "store_operating_hours",
]


async def _fetch_table(sb: Any, table: str, store_id: str) -> list[dict]:
    try:
        if table == "stores":
            res = await asyncio.to_thread(
                lambda: sb.table(table).select("*").eq("id", store_id).execute()
            )
        else:
            res = await asyncio.to_thread(
                lambda: sb.table(table).select("*").eq("store_id", store_id).execute()
            )
        rows = res.data or []
        # 민감 정보 제거
        for r in rows:
            for k in list(r.keys()):
                if k in ("password_hash", "payment_token", "card_token", "stripe_customer_id"):
                    r[k] = "[REDACTED]"
        return rows
    except Exception:
        # 해당 테이블 없거나 권한 없을 시 스킵
        return []


@router.get("/export")
async def export_my_data(
    store_id: str = Header(..., alias="X-Store-Id"),
):
    """
    본인 매장 전체 데이터를 ZIP으로 반환.
    Content-Type: application/zip
    """
    sb = _get_supabase()
    if sb is None:
        raise HTTPException(status_code=503, detail="Supabase 미설정")

    # 모든 테이블 병렬 fetch
    tasks = {tbl: _fetch_table(sb, tbl, store_id) for tbl in EXPORTABLE_TABLES}
    results: dict[str, list[dict]] = {}
    for tbl, task in tasks.items():
        results[tbl] = await task

    # M10: Storage 이미지도 포함 (store-logos, receipts 등)
    storage_files: list[tuple[str, bytes]] = []
    try:
        # 매장 로고
        for bucket_name in ("store-logos", "receipts", "menu-images"):
            try:
                file_list = await asyncio.to_thread(
                    lambda b=bucket_name: sb.storage.from_(b).list(store_id, {"limit": 100})
                )
                for f in (file_list or []):
                    name = f.get("name") if isinstance(f, dict) else getattr(f, "name", None)
                    if not name:
                        continue
                    full_path = f"{store_id}/{name}"
                    try:
                        data = await asyncio.to_thread(
                            lambda b=bucket_name, p=full_path: sb.storage.from_(b).download(p)
                        )
                        if data:
                            storage_files.append((f"storage/{bucket_name}/{name}", data))
                    except Exception:
                        pass
            except Exception:
                pass
    except Exception:
        pass  # Storage 미설정/권한 오류는 조용히 스킵

    # ZIP 생성
    buf = io.BytesIO()
    exported_at = datetime.now(timezone.utc).isoformat()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:
        # 메타
        meta = {
            "exported_at": exported_at,
            "store_id": store_id,
            "tables": {tbl: len(rows) for tbl, rows in results.items()},
            "storage_files": len(storage_files),
            "storage_size_bytes": sum(len(d) for _, d in storage_files),
            "spec_version": "1.1",
            "format": "JSON per table + storage/* binary files",
            "license": "본인 데이터, 자유롭게 사용·재가공 가능",
        }
        zf.writestr("MANIFEST.json", json.dumps(meta, ensure_ascii=False, indent=2))

        # 각 테이블 JSON
        for tbl, rows in results.items():
            if rows:
                zf.writestr(
                    f"{tbl}.json",
                    json.dumps(rows, ensure_ascii=False, indent=2, default=str),
                )

        # M10: Storage 이미지
        for path, data in storage_files:
            zf.writestr(path, data)

        # README
        readme = f"""# Cafe Brain — 데이터 내보내기

내보낸 시각: {exported_at}
매장 ID: {store_id}

## 포함된 테이블
{chr(10).join(f'- {tbl}.json ({len(rows)}건)' for tbl, rows in results.items() if rows)}

## 주의 사항
- 비밀번호·결제 토큰은 [REDACTED]로 마스킹되어 있습니다
- 본인 매장 데이터만 포함됩니다 (RLS 격리)
- 이 파일은 GDPR/PIPA 데이터 이동권 행사에 활용 가능합니다
- 해지를 원하시면 설정 > 회원 탈퇴 또는 /api/data/erase 호출
"""
        zf.writestr("README.md", readme)

    buf.seek(0)
    filename = f"cafe-brain-data-{store_id[:8]}-{datetime.now().strftime('%Y%m%d')}.zip"
    return StreamingResponse(
        buf,
        media_type="application/zip",
        headers={
            "Content-Disposition": f'attachment; filename="{filename}"',
        },
    )


@router.post("/erase")
async def erase_my_data(
    store_id: str = Header(..., alias="X-Store-Id"),
):
    """
    전체 매장 데이터 영구 삭제 (회원 탈퇴 동등).
    cascade — 모든 관련 테이블에서 store_id 매칭 row 삭제.
    Auth.users.id 자체 삭제는 별도 (Supabase admin API).
    """
    sb = _get_supabase()
    if sb is None:
        raise HTTPException(status_code=503, detail="Supabase 미설정")

    deleted_counts: dict[str, int] = {}
    # 외래키 cascade를 위해 의존성 깊은 순으로
    erase_order = [
        "agent_audit_log",
        "agent_briefing_log",
        "agent_anomaly_rules",
        "agent_feedback",
        "agent_memory",
        "ai_cache",
        "chat_history",
        "push_subscriptions",
        "store_operating_hours",
        "ingredients",
        "menus",
        "orders",
        "reviews",
        "sales_records",
        "stores",  # 마지막
    ]
    for tbl in erase_order:
        try:
            if tbl == "stores":
                res = await asyncio.to_thread(
                    lambda t=tbl: sb.table(t).delete().eq("id", store_id).execute()
                )
            else:
                res = await asyncio.to_thread(
                    lambda t=tbl: sb.table(t).delete().eq("store_id", store_id).execute()
                )
            deleted_counts[tbl] = len(res.data or [])
        except Exception as e:
            deleted_counts[tbl] = 0
            # 일부 테이블 없을 수 있음 — 계속 진행

    return {
        "erased": True,
        "store_id": store_id,
        "deleted_counts": deleted_counts,
        "note": "Auth 계정 자체 삭제는 Supabase Admin에서 별도 처리됩니다",
    }
