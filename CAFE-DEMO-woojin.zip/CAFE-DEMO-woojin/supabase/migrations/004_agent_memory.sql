-- Batch 2 Sub-2A: 능동형 에이전트 개인 학습 메모리 시스템
-- Issue #10 대비 Foundation — 지금부터 데이터 축적, 런칭 시점엔 풍부한 매장 프로필 확보
-- 상세 설계: docs/agent-personalization.md 참조

-- ══════════════════════════════════════════════════════════
-- 1. agent_memory — 구조화된 장기 기억
-- ══════════════════════════════════════════════════════════
CREATE TABLE IF NOT EXISTS public.agent_memory (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  store_id uuid NOT NULL REFERENCES public.stores(id) ON DELETE CASCADE,

  -- 메모리 카테고리 (검색·필터용)
  category text NOT NULL CHECK (category IN (
    'business_pattern',     -- 요일/시간/시즌 패턴
    'customer_insight',     -- 고객 피드백 반복 키워드
    'decision_history',     -- 가격·메뉴·정책 변경 이력
    'preference',           -- 사장님 성향·선호 스타일
    'event',                -- 특이 이벤트 (매출 급락, 리뷰 폭증)
    'goal',                 -- 목표·KPI
    'accepted_suggestion',  -- 수용한 AI 제안 (+ 실제 효과)
    'rejected_suggestion'   -- 거부한 제안 (반복 방지)
  )),

  -- 자연어 메모리 내용 (1-3줄)
  content text NOT NULL CHECK (char_length(content) <= 1000),

  -- 랭킹용 메타데이터
  importance int NOT NULL DEFAULT 5 CHECK (importance BETWEEN 1 AND 10),
  confidence numeric NOT NULL DEFAULT 0.7 CHECK (confidence BETWEEN 0 AND 1),

  -- 사용 추적 (더 자주 쓰일수록 강화)
  use_count int NOT NULL DEFAULT 0,
  last_used_at timestamptz,
  last_reinforced_at timestamptz NOT NULL DEFAULT now(),

  -- 원천 추적 (설명 가능성)
  source_type text,       -- 'sales_anomaly', 'user_feedback', 'chat_extraction', 'review_trend'
  source_ref text,        -- 참조 레코드 ID (sales_records, chat_history 등)

  -- 라이프사이클
  created_at timestamptz NOT NULL DEFAULT now(),
  expires_at timestamptz,  -- null=영구
  archived_at timestamptz  -- 사용자 "잊어줘" or 노후화 시 설정
);

CREATE INDEX IF NOT EXISTS idx_memory_store_active
  ON public.agent_memory(store_id, importance DESC, last_used_at DESC NULLS LAST)
  WHERE archived_at IS NULL;

CREATE INDEX IF NOT EXISTS idx_memory_category
  ON public.agent_memory(store_id, category)
  WHERE archived_at IS NULL;

-- RLS: 본인 매장 메모리만 조회·수정 가능
ALTER TABLE public.agent_memory ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "agent_memory: 본인 매장만 접근" ON public.agent_memory;
CREATE POLICY "agent_memory: 본인 매장만 접근" ON public.agent_memory
  FOR ALL USING (store_id = auth.uid());

COMMENT ON TABLE public.agent_memory IS
  'Issue #10: 능동형 에이전트가 매장별로 축적하는 개인 맞춤 장기 기억. 시간이 쌓일수록 응답이 개인화됨.';


-- ══════════════════════════════════════════════════════════
-- 2. agent_feedback — AI 제안에 대한 사용자 반응
-- ══════════════════════════════════════════════════════════
CREATE TABLE IF NOT EXISTS public.agent_feedback (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  store_id uuid NOT NULL REFERENCES public.stores(id) ON DELETE CASCADE,

  -- 어떤 AI 출력에 대한 피드백인지
  source_type text NOT NULL,  -- 'sales_insight', 'review_reply', 'marketing_draft', 'agent_briefing', 'chat_message'
  source_ref text NOT NULL,   -- 해당 출력 식별자

  -- 반응 (4가지 + 선택적 코멘트)
  reaction text NOT NULL CHECK (reaction IN (
    'helpful',     -- 👍 유용했어요
    'irrelevant',  -- 👎 관련 없어요
    'applied',     -- ✨ 실제로 적용했어요
    'muted'        -- 🔇 이런 알림·제안 꺼주세요
  )),
  note text,

  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_feedback_store
  ON public.agent_feedback(store_id, created_at DESC);

CREATE INDEX IF NOT EXISTS idx_feedback_source
  ON public.agent_feedback(source_type, source_ref);

ALTER TABLE public.agent_feedback ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "agent_feedback: 본인 매장만 접근" ON public.agent_feedback;
CREATE POLICY "agent_feedback: 본인 매장만 접근" ON public.agent_feedback
  FOR ALL USING (store_id = auth.uid());

COMMENT ON TABLE public.agent_feedback IS
  '사용자의 AI 제안 반응. 학습 루프의 신호 — 어떤 제안이 효과적이었는지 축적.';


-- ══════════════════════════════════════════════════════════
-- 3. agent_briefing_log — 능동 에이전트 발화 이력
-- ══════════════════════════════════════════════════════════
CREATE TABLE IF NOT EXISTS public.agent_briefing_log (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  store_id uuid NOT NULL REFERENCES public.stores(id) ON DELETE CASCADE,

  -- 트리거 유형 (Batch 4에서 활용)
  trigger_type text NOT NULL CHECK (trigger_type IN (
    'daily_briefing',      -- 일일 아침 브리핑
    'sales_anomaly',       -- 매출 이상 감지
    'bep_milestone',       -- BEP 달성·근접
    'review_surge',        -- 리뷰 폭증
    'reorder_reminder',    -- 재주문 시점
    'manual'               -- 수동 호출
  )),

  -- 참고한 메모리 (설명 가능성)
  context_memories uuid[] DEFAULT '{}'::uuid[],

  -- 프롬프트·응답 스냅샷 (디버깅·감사 추적)
  prompt_snapshot text,
  response text NOT NULL,

  -- 사용자 반응 (나중에 업데이트됨)
  user_reaction text,

  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_briefing_store_time
  ON public.agent_briefing_log(store_id, created_at DESC);

ALTER TABLE public.agent_briefing_log ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "agent_briefing_log: 본인 매장만 접근" ON public.agent_briefing_log;
CREATE POLICY "agent_briefing_log: 본인 매장만 접근" ON public.agent_briefing_log
  FOR ALL USING (store_id = auth.uid());


-- ══════════════════════════════════════════════════════════
-- 4. stores.agent_profile — 메모리 증류 요약 (프롬프트 주입용)
-- ══════════════════════════════════════════════════════════
ALTER TABLE public.stores
  ADD COLUMN IF NOT EXISTS agent_profile jsonb NOT NULL DEFAULT '{}'::jsonb;

ALTER TABLE public.stores
  ADD COLUMN IF NOT EXISTS agent_learning_enabled boolean NOT NULL DEFAULT true;

COMMENT ON COLUMN public.stores.agent_profile IS
  'agent_memory에서 주기적으로 증류된 매장 프로필 요약. 프롬프트 컨텍스트로 주입됨.';

COMMENT ON COLUMN public.stores.agent_learning_enabled IS
  '사용자 제어: AI 학습 on/off (프라이버시 권리)';


-- ══════════════════════════════════════════════════════════
-- 5. 유틸 함수: 관련 메모리 검색 (에이전트에서 호출)
-- ══════════════════════════════════════════════════════════
CREATE OR REPLACE FUNCTION public.search_relevant_memories(
  p_store_id uuid,
  p_categories text[] DEFAULT NULL,  -- null이면 전체
  p_limit int DEFAULT 10
)
RETURNS TABLE (
  id uuid,
  category text,
  content text,
  importance int,
  confidence numeric,
  created_at timestamptz
) AS $$
BEGIN
  RETURN QUERY
  SELECT m.id, m.category, m.content, m.importance, m.confidence, m.created_at
  FROM public.agent_memory m
  WHERE m.store_id = p_store_id
    AND m.archived_at IS NULL
    AND (m.expires_at IS NULL OR m.expires_at > now())
    AND (p_categories IS NULL OR m.category = ANY(p_categories))
  ORDER BY
    -- 랭킹 공식: 중요도(70%) + 최신성(30%)
    (m.importance * 0.7 +
     CASE
       WHEN m.last_reinforced_at > now() - interval '7 days' THEN 3.0
       WHEN m.last_reinforced_at > now() - interval '30 days' THEN 1.5
       ELSE 0.5
     END * 0.3
    ) * m.confidence DESC,
    m.last_used_at DESC NULLS LAST
  LIMIT p_limit;

  -- 조회된 메모리의 use_count·last_used_at 업데이트 (별도 UPDATE로)
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;


-- ══════════════════════════════════════════════════════════
-- 6. 유틸 함수: 메모리 사용 기록 (에이전트 발화 후 호출)
-- ══════════════════════════════════════════════════════════
CREATE OR REPLACE FUNCTION public.mark_memories_used(
  p_memory_ids uuid[]
) RETURNS void AS $$
BEGIN
  UPDATE public.agent_memory
  SET use_count = use_count + 1,
      last_used_at = now()
  WHERE id = ANY(p_memory_ids);
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;
