// G2 — 데모 시더
// 가입 후 매장에 데이터가 0이면 "샘플 데이터 채우기" 버튼으로 30일치 가짜 데이터를 INSERT.
// 실제 사장님이 자기 데이터 넣기 전 '체험 모드'로 사용.
//
// 시드 데이터 구조:
// - sales_records: 30일 × 평균 25건 = ~750 rows (시간대 분포 + 날씨 패턴)
// - menus: 12개 (시그니처 + 베이직)
// - reviews: 20건 (별점·키워드 분포)
// - ingredients: 15개 (재료 + 단가)
import { supabase } from '@/lib/supabase'
import toast from 'react-hot-toast'

const DEMO_MENUS = [
  { name: '아메리카노', price: 4500, cost: 1200, category: '커피' },
  { name: '카페라떼', price: 5000, cost: 1500, category: '커피' },
  { name: '바닐라라떼', price: 5500, cost: 1700, category: '커피' },
  { name: '아이스 아메리카노', price: 4500, cost: 1300, category: '커피' },
  { name: '카푸치노', price: 5000, cost: 1500, category: '커피' },
  { name: '카라멜 마끼아또', price: 6000, cost: 1900, category: '커피' },
  { name: '말차라떼', price: 5500, cost: 1800, category: '논커피' },
  { name: '딸기라떼', price: 6000, cost: 2000, category: '논커피' },
  { name: '청포도 에이드', price: 5500, cost: 1500, category: '에이드' },
  { name: '레몬 에이드', price: 5000, cost: 1300, category: '에이드' },
  { name: '크로플', price: 6500, cost: 2500, category: '디저트' },
  { name: '바스크 치즈케이크', price: 7500, cost: 2800, category: '디저트' },
]

const DEMO_INGREDIENTS = [
  { name: '원두 (블렌드)', unit: 'kg', unit_price: 25000, supplier: '블루보틀 도매' },
  { name: '우유', unit: 'L', unit_price: 1800, supplier: '서울우유' },
  { name: '바닐라 시럽', unit: '병', unit_price: 12000, supplier: '모닌' },
  { name: '카라멜 시럽', unit: '병', unit_price: 12000, supplier: '모닌' },
  { name: '말차 가루', unit: 'kg', unit_price: 45000, supplier: '교토말차' },
  { name: '딸기 시럽', unit: '병', unit_price: 14000, supplier: '아이즈락' },
  { name: '청포도 농축액', unit: '병', unit_price: 18000, supplier: '오뚜기' },
  { name: '레몬', unit: 'kg', unit_price: 6500, supplier: '농협' },
  { name: '크로플 반죽', unit: 'EA', unit_price: 1500, supplier: '뚜레쥬르 직거래' },
  { name: '치즈케이크 베이스', unit: 'EA', unit_price: 3000, supplier: '뚜레쥬르 직거래' },
  { name: '종이컵 (12oz)', unit: '박스', unit_price: 25000, supplier: '환경포장' },
  { name: '컵홀더', unit: '박스', unit_price: 18000, supplier: '환경포장' },
  { name: '빨대 (옥수수)', unit: '박스', unit_price: 35000, supplier: '에코빨대' },
  { name: '냅킨', unit: '박스', unit_price: 15000, supplier: '환경포장' },
  { name: '얼음', unit: 'kg', unit_price: 800, supplier: '동네 얼음공장' },
]

const DEMO_REVIEWS = [
  { rating: 5, content: '커피 맛이 정말 좋아요! 사장님이 친절하시고 매장도 깔끔해요.' },
  { rating: 5, content: '말차라떼 너무 맛있어요. 또 올게요!' },
  { rating: 4, content: '디저트가 다양해서 좋네요. 가격이 조금만 더 저렴하면…' },
  { rating: 5, content: '인스타에서 보고 왔는데 분위기 진짜 좋아요!' },
  { rating: 3, content: '주문이 좀 늦게 나오는 편이에요. 맛은 좋습니다.' },
  { rating: 4, content: '아이스 아메리카노 진하고 좋아요.' },
  { rating: 5, content: '크로플 추천! 겉바속촉 ㅎㅎ' },
  { rating: 5, content: '직장 근처라 자주 와요. 단골 손님 인사도 해주시고 따뜻해요.' },
  { rating: 4, content: '와이파이 잘 되고 좌석이 많아 좋아요.' },
  { rating: 2, content: '주말에 너무 시끄러워요. 평일에 가시는 걸 추천합니다.' },
  { rating: 5, content: '바스크 치즈케이크 진심 맛있어요. 인스타 감성!' },
  { rating: 4, content: '딸기라떼 시즌 메뉴 너무 좋아요.' },
  { rating: 5, content: '바리스타분 친절하시고 라떼아트도 예뻐요.' },
  { rating: 3, content: '바닐라라떼 단맛이 너무 강해서 절반 시럽으로 부탁했어요.' },
  { rating: 5, content: '강아지 동반 가능해서 좋아요!' },
  { rating: 4, content: '청포도 에이드 진짜 청량해요.' },
  { rating: 5, content: '주차 편하고 좌석 넓어 편안해요.' },
  { rating: 3, content: '메뉴가 좀 더 다양했으면 좋겠어요.' },
  { rating: 5, content: '아침 출근 전 단골입니다. 항상 같은 음료인데도 매번 친절하시네요.' },
  { rating: 4, content: '디저트 무게에 비해 가격이 좀 있는 편.' },
]

/**
 * 매장 데이터를 30일치 데모 데이터로 채움.
 * 이미 데이터가 있으면 prompt로 confirm.
 */
export async function seedDemoData(storeId: string): Promise<{ ok: boolean; counts: Record<string, number> }> {
  const today = new Date()

  // 1) 기존 데이터 체크
  const [{ count: salesCount }, { count: menuCount }] = await Promise.all([
    supabase.from('sales_records').select('id', { count: 'exact', head: true }).eq('store_id', storeId),
    supabase.from('menus').select('id', { count: 'exact', head: true }).eq('store_id', storeId),
  ])

  if ((salesCount ?? 0) > 0 || (menuCount ?? 0) > 0) {
    const ok = confirm(
      `이미 ${salesCount ?? 0}건의 매출 / ${menuCount ?? 0}건의 메뉴가 있어요.\n\n` +
      `데모 데이터를 추가하시겠어요? (기존 데이터는 유지됩니다)`
    )
    if (!ok) return { ok: false, counts: {} }
  }

  const counts: Record<string, number> = {}

  // 2) 메뉴
  const menus = DEMO_MENUS.map((m) => ({ store_id: storeId, ...m, is_active: true }))
  const { data: menuData, error: menuErr } = await supabase.from('menus').insert(menus).select('id, name, price, cost')
  if (menuErr) throw menuErr
  counts.menus = menuData?.length ?? 0

  // 3) 재료 (notes·supplier에 데모 마커)
  const ingredients = DEMO_INGREDIENTS.map((i) => ({
    store_id: storeId,
    ...i,
    supplier: `${i.supplier} (데모)`,
    notes: '데모 데이터',
  }))
  const { data: ingData, error: ingErr } = await supabase.from('ingredients').insert(ingredients).select('id')
  if (ingErr) throw ingErr
  counts.ingredients = ingData?.length ?? 0

  // 4) 매출 (30일치, 일평균 25건, 시간대 분포)
  const salesRows: Array<Record<string, unknown>> = []
  for (let d = 30; d >= 0; d--) {
    const date = new Date(today)
    date.setDate(date.getDate() - d)
    const dateStr = date.toISOString().split('T')[0]
    const isWeekend = date.getDay() === 0 || date.getDay() === 6
    const baseCount = isWeekend ? 35 : 22
    const dailyCount = baseCount + Math.floor(Math.random() * 8)

    for (let i = 0; i < dailyCount; i++) {
      // 시간대 가중치: 11~13시 점심, 14~17시 오후 피크, 18~20 저녁
      const hour = pickHourSlot()
      const menu = menuData![Math.floor(Math.random() * menuData!.length)]
      const qty = 1 + (Math.random() < 0.15 ? 1 : 0)
      salesRows.push({
        store_id: storeId,
        sale_date: dateStr,
        menu_name: menu.name,
        quantity: qty,
        revenue: menu.price * qty,
        cost: (menu.cost ?? 0) * qty,
        hour_slot: hour,
        discount: 0,
      })
    }
  }
  // chunked insert (Supabase는 1000개씩이 안전)
  for (let i = 0; i < salesRows.length; i += 500) {
    const chunk = salesRows.slice(i, i + 500)
    const { error } = await supabase.from('sales_records').insert(chunk)
    if (error) throw error
  }
  counts.sales = salesRows.length

  // 5) 리뷰 (날짜는 최근 14일에 분산)
  const reviewRows = DEMO_REVIEWS.map((r, i) => {
    const date = new Date(today)
    date.setDate(date.getDate() - Math.floor(i * 14 / DEMO_REVIEWS.length))
    return {
      store_id: storeId,
      rating: r.rating,
      content: r.content,
      author: '익명',
      created_at: date.toISOString(),
      replied: false,
    }
  })
  const { error: reviewErr } = await supabase.from('reviews').insert(reviewRows)
  if (reviewErr) throw reviewErr
  counts.reviews = reviewRows.length

  toast.success(`데모 데이터 ${Object.values(counts).reduce((a, b) => a + b, 0)}건 추가됨 ✨`)
  return { ok: true, counts }
}

function pickHourSlot(): number {
  const r = Math.random()
  if (r < 0.05) return 7 + Math.floor(Math.random() * 3)         // 7~9시 (출근길)
  if (r < 0.30) return 11 + Math.floor(Math.random() * 2)        // 11~12시 (점심)
  if (r < 0.55) return 13 + Math.floor(Math.random() * 4)        // 13~16시 (오후)
  if (r < 0.80) return 17 + Math.floor(Math.random() * 3)        // 17~19시 (퇴근길)
  return 20 + Math.floor(Math.random() * 2)                       // 20~21시 (저녁)
}
