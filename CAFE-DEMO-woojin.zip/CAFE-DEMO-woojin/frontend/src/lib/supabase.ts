// Supabase 클라이언트 초기화
import { createClient } from '@supabase/supabase-js'

// 환경변수에서 Supabase 접속 정보 로드 (절대 하드코딩 금지)
const supabaseUrl = (import.meta.env['VITE_SUPABASE_URL'] ?? '') as string
const supabaseAnonKey = (import.meta.env['VITE_SUPABASE_ANON_KEY'] ?? '') as string

if (!supabaseUrl || !supabaseAnonKey) {
  console.warn('Supabase URL과 Anon Key가 .env 파일에 설정되어 있지 않습니다.')
}

export const supabase = createClient(
  supabaseUrl || 'https://placeholder.supabase.co',
  supabaseAnonKey || 'placeholder-anon-key'
)

// 타입 익스포트
export type { Session, User } from '@supabase/supabase-js'
