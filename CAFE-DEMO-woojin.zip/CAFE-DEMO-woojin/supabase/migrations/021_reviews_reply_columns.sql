-- L4 — 리뷰 답글 컬럼 보강
ALTER TABLE reviews
  ADD COLUMN IF NOT EXISTS reply_content TEXT,
  ADD COLUMN IF NOT EXISTS reply_posted_externally BOOLEAN DEFAULT FALSE,
  ADD COLUMN IF NOT EXISTS reply_at TIMESTAMPTZ,
  ADD COLUMN IF NOT EXISTS reply_auto_generated BOOLEAN DEFAULT FALSE;

CREATE INDEX IF NOT EXISTS idx_reviews_replied ON reviews(store_id, replied);
