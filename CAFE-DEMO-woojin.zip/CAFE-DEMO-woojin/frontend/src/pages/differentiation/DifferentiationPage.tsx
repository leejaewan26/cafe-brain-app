// J3 + J4 + J5 + J6 — 차별화 기능 통합 페이지
import { useEffect, useRef, useState } from 'react'
import { Link } from 'react-router-dom'
import {
  ChevronLeft, Sparkles, Camera, GraduationCap, Mic, BarChart3,
  Loader2, MicOff, Check, X, Award,
} from 'lucide-react'
import { useAuthStore } from '@/store/authStore'
import { useSTT } from '@/hooks/useSTT'
import { cn } from '@/lib/utils'
import toast from 'react-hot-toast'

type Tab = 'cleanliness' | 'quiz' | 'voice' | 'benchmark'

export default function DifferentiationPage() {
  const [tab, setTab] = useState<Tab>('cleanliness')
  return (
    <div className="min-h-screen bg-[#FAFAF8]">
      <header className="bg-white border-b border-gray-100 sticky top-0 z-10">
        <div className="max-w-3xl mx-auto px-4 py-3 flex items-center gap-3">
          <Link to="/dashboard" className="text-gray-400 hover:text-[#2C1810]">
            <ChevronLeft size={18} />
          </Link>
          <h1 className="text-base font-bold text-[#2C1810] flex items-center gap-1.5">
            <Sparkles size={15} className="text-[#D4A574]" /> 카페 브레인 라보
          </h1>
        </div>
        <nav className="max-w-3xl mx-auto px-4 flex gap-1 border-b border-gray-100 overflow-x-auto">
          {[
            { id: 'cleanliness' as const, label: '청결 진단', icon: Camera },
            { id: 'quiz' as const, label: '직원 퀴즈', icon: GraduationCap },
            { id: 'voice' as const, label: '음성 메모', icon: Mic },
            { id: 'benchmark' as const, label: '동네 벤치마크', icon: BarChart3 },
          ].map((t) => {
            const Icon = t.icon
            return (
              <button
                key={t.id}
                onClick={() => setTab(t.id)}
                className={cn(
                  'flex items-center gap-1.5 px-3 py-2.5 text-xs font-semibold transition-colors border-b-2 whitespace-nowrap',
                  tab === t.id
                    ? 'border-[#2C1810] text-[#2C1810]'
                    : 'border-transparent text-gray-400 hover:text-[#2C1810]'
                )}
              >
                <Icon size={13} /> {t.label}
              </button>
            )
          })}
        </nav>
      </header>
      <main className="max-w-3xl mx-auto px-4 py-5">
        {tab === 'cleanliness' && <CleanlinessTab />}
        {tab === 'quiz' && <QuizTab />}
        {tab === 'voice' && <VoiceMemoTab />}
        {tab === 'benchmark' && <BenchmarkTab />}
      </main>
    </div>
  )
}

// ═══════════════════════════════════════════════════════
// J3 — 청결 진단
// ═══════════════════════════════════════════════════════

interface CleanlinessResult {
  score: number
  grade: string
  issues: string[]
  recommendations: string[]
  raw_observations: string
}

function CleanlinessTab() {
  const user = useAuthStore((s) => s.user)
  const fileRef = useRef<HTMLInputElement>(null)
  const [area, setArea] = useState<'전체' | '카운터' | '홀' | '주방' | '화장실'>('전체')
  const [loading, setLoading] = useState(false)
  const [result, setResult] = useState<CleanlinessResult | null>(null)

  const onFile = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file || !user) return
    if (file.size > 10 * 1024 * 1024) return toast.error('10MB 이하 사진만')
    setLoading(true)
    setResult(null)
    try {
      const reader = new FileReader()
      const dataUrl = await new Promise<string>((res, rej) => {
        reader.onload = () => res(reader.result as string)
        reader.onerror = () => rej(new Error('파일 읽기 실패'))
        reader.readAsDataURL(file)
      })
      const r = await fetch('/api/v1/differentiation/cleanliness', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'X-Store-Id': user.id },
        body: JSON.stringify({ image_base64: dataUrl, mime_type: file.type, area }),
      })
      if (!r.ok) throw new Error('분석 실패')
      setResult(await r.json())
    } catch (e) {
      toast.error(e instanceof Error ? e.message : '오류')
    } finally {
      setLoading(false)
      if (fileRef.current) fileRef.current.value = ''
    }
  }

  return (
    <div className="space-y-4">
      <div className="bg-white rounded-2xl border border-gray-100 p-5">
        <h2 className="text-sm font-bold text-[#2C1810] mb-1">매장 청결 AI 진단</h2>
        <p className="text-xs text-gray-500 mb-3 leading-relaxed">
          매장 사진을 업로드하면 식약처 기준으로 위생 점수를 매깁니다. 영업감독 대비, 매장 셀프 체크에 활용하세요.
        </p>
        <div className="flex gap-2 mb-3">
          {(['전체', '카운터', '홀', '주방', '화장실'] as const).map((a) => (
            <button
              key={a}
              onClick={() => setArea(a)}
              className={cn(
                'px-2.5 py-1 rounded-full text-xs font-medium',
                area === a ? 'bg-[#2C1810] text-white' : 'bg-gray-100 text-gray-500'
              )}
            >
              {a}
            </button>
          ))}
        </div>
        <input ref={fileRef} type="file" accept="image/*" onChange={onFile} className="hidden" />
        <button
          onClick={() => fileRef.current?.click()}
          disabled={loading}
          className="w-full py-3 border-2 border-dashed border-[#D4A574] bg-[#D4A574]/5 rounded-xl text-sm font-semibold text-[#2C1810] flex items-center justify-center gap-2 disabled:opacity-50"
        >
          {loading ? <><Loader2 size={14} className="animate-spin" /> AI가 분석 중…</> : <><Camera size={14} /> 사진 업로드</>}
        </button>
      </div>

      {result && (
        <div className="bg-white rounded-2xl border-2 shadow-sm p-5"
             style={{ borderColor: gradeColor(result.grade) + '60' }}>
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-xs text-gray-400 uppercase">청결 점수</h3>
              <div className="flex items-baseline gap-2 mt-0.5">
                <span className="text-4xl font-bold tabular-nums" style={{ color: gradeColor(result.grade) }}>
                  {result.score}
                </span>
                <span className="text-xl font-bold" style={{ color: gradeColor(result.grade) }}>{result.grade}</span>
              </div>
            </div>
            <Award size={32} style={{ color: gradeColor(result.grade) }} />
          </div>

          {result.issues.length > 0 && (
            <div className="mb-3">
              <h4 className="text-xs font-bold text-red-600 mb-1.5">⚠️ 발견된 문제</h4>
              <ul className="text-xs text-gray-700 space-y-1 pl-4 list-disc">
                {result.issues.map((iss, i) => <li key={i}>{iss}</li>)}
              </ul>
            </div>
          )}

          {result.recommendations.length > 0 && (
            <div className="mb-3">
              <h4 className="text-xs font-bold text-green-600 mb-1.5">✅ 개선 권고</h4>
              <ul className="text-xs text-gray-700 space-y-1 pl-4 list-disc">
                {result.recommendations.map((r, i) => <li key={i}>{r}</li>)}
              </ul>
            </div>
          )}

          <details className="text-xs text-gray-500 mt-3">
            <summary className="cursor-pointer hover:text-[#2C1810]">관찰 상세</summary>
            <p className="mt-2 leading-relaxed">{result.raw_observations}</p>
          </details>
        </div>
      )}
    </div>
  )
}

function gradeColor(grade: string): string {
  return grade === 'A' ? '#22C55E' : grade === 'B' ? '#4A90A4' : grade === 'C' ? '#F59E0B' : '#EF4444'
}

// ═══════════════════════════════════════════════════════
// J4 — 직원 퀴즈
// ═══════════════════════════════════════════════════════

interface QuizQuestion {
  question: string
  type: string
  choices?: string[]
  answer: string
  explanation: string
}

function QuizTab() {
  const user = useAuthStore((s) => s.user)
  const [difficulty, setDifficulty] = useState<'easy' | 'medium' | 'hard'>('medium')
  const [count, setCount] = useState(5)
  const [questions, setQuestions] = useState<QuizQuestion[]>([])
  const [topic, setTopic] = useState('')
  const [loading, setLoading] = useState(false)
  const [revealed, setRevealed] = useState<Set<number>>(new Set())

  const generate = async () => {
    if (!user) return
    setLoading(true)
    setRevealed(new Set())
    try {
      const r = await fetch('/api/v1/differentiation/staff-quiz', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ store_id: user.id, difficulty, count }),
      })
      if (!r.ok) {
        const err = await r.json().catch(() => ({}))
        throw new Error(err.detail || '퀴즈 생성 실패')
      }
      const data = await r.json()
      setQuestions(data.questions)
      setTopic(data.topic_summary)
    } catch (e) {
      toast.error(e instanceof Error ? e.message : '오류')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="space-y-4">
      <div className="bg-white rounded-2xl border border-gray-100 p-5">
        <h2 className="text-sm font-bold text-[#2C1810] mb-1">직원 교육 퀴즈 자동 생성</h2>
        <p className="text-xs text-gray-500 mb-3">등록된 메뉴·레시피를 기반으로 퀴즈를 만들어 신입 바리스타 교육에 사용하세요.</p>
        <div className="grid grid-cols-2 gap-2 mb-3">
          <select
            value={difficulty}
            onChange={(e) => setDifficulty(e.target.value as typeof difficulty)}
            className="px-3 py-2 border border-gray-200 rounded-lg text-sm"
          >
            <option value="easy">쉬움</option>
            <option value="medium">보통</option>
            <option value="hard">어려움</option>
          </select>
          <select
            value={count}
            onChange={(e) => setCount(Number(e.target.value))}
            className="px-3 py-2 border border-gray-200 rounded-lg text-sm"
          >
            {[5, 10, 15, 20].map((c) => <option key={c} value={c}>{c}문제</option>)}
          </select>
        </div>
        <button
          onClick={generate}
          disabled={loading}
          className="w-full bg-[#2C1810] text-white py-2.5 rounded-lg text-sm font-semibold flex items-center justify-center gap-1.5 disabled:opacity-50"
        >
          {loading ? <><Loader2 size={14} className="animate-spin" /> 생성 중…</> : <><GraduationCap size={14} /> 퀴즈 만들기</>}
        </button>
      </div>

      {topic && (
        <div className="bg-[#FAFAF8] rounded-xl p-3 text-xs text-gray-600 leading-relaxed">
          📝 <strong>주제:</strong> {topic}
        </div>
      )}

      {questions.map((q, i) => (
        <article key={i} className="bg-white rounded-2xl border border-gray-100 p-4">
          <p className="font-bold text-sm text-[#2C1810] mb-3">
            Q{i + 1}. {q.question}
          </p>
          {q.type === 'mcq' && q.choices && (
            <ul className="space-y-1.5 mb-3">
              {q.choices.map((c, j) => (
                <li key={j} className="text-xs text-gray-700 px-3 py-2 bg-[#FAFAF8] rounded-lg">
                  {String.fromCharCode(65 + j)}. {c}
                </li>
              ))}
            </ul>
          )}
          <button
            onClick={() => setRevealed((p) => new Set(p).add(i))}
            className="text-xs font-semibold text-[#D4A574] hover:text-[#c4956a]"
          >
            {revealed.has(i) ? '답안 표시 중' : '정답 보기'}
          </button>
          {revealed.has(i) && (
            <div className="mt-2 p-3 bg-green-50 rounded-lg">
              <p className="text-xs font-bold text-green-700 mb-1">정답: {q.answer}</p>
              <p className="text-xs text-gray-600 leading-relaxed">{q.explanation}</p>
            </div>
          )}
        </article>
      ))}
    </div>
  )
}

// ═══════════════════════════════════════════════════════
// J5 — 음성 메모 자동 정리
// ═══════════════════════════════════════════════════════

interface MemoResult {
  summary: string
  categories: string[]
  action_items: string[]
  memories_saved: number
}

function VoiceMemoTab() {
  const user = useAuthStore((s) => s.user)
  const [result, setResult] = useState<MemoResult | null>(null)
  const [organizing, setOrganizing] = useState(false)
  const [transcript, setTranscript] = useState('')
  const stt = useSTT({
    onFinal: (t) => setTranscript((p) => (p + ' ' + t).trim()),
  })

  const organize = async () => {
    if (!user || transcript.trim().length < 10) return toast.error('10자 이상 녹음 또는 입력해주세요')
    setOrganizing(true)
    setResult(null)
    try {
      const r = await fetch('/api/v1/differentiation/voice-memo/organize', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ store_id: user.id, transcript: transcript.trim() }),
      })
      if (!r.ok) throw new Error('정리 실패')
      setResult(await r.json())
      toast.success('메모 정리 완료 ✨')
    } catch (e) {
      toast.error(e instanceof Error ? e.message : '오류')
    } finally {
      setOrganizing(false)
    }
  }

  return (
    <div className="space-y-4">
      <div className="bg-white rounded-2xl border border-gray-100 p-5">
        <h2 className="text-sm font-bold text-[#2C1810] mb-1">음성 메모 → 자동 정리</h2>
        <p className="text-xs text-gray-500 mb-3">출근길에 녹음하시면 카테고리별로 자동 분류 + 액션아이템 추출 + 메모리 저장.</p>
        {stt.supported ? (
          <button
            onClick={() => stt.listening ? stt.stop() : stt.start()}
            className={cn(
              'w-full py-3 rounded-xl text-sm font-semibold flex items-center justify-center gap-2 transition-colors',
              stt.listening
                ? 'bg-red-500 text-white'
                : 'bg-[#D4A574]/10 text-[#2C1810] hover:bg-[#D4A574]/20'
            )}
          >
            {stt.listening ? (
              <><MicOff size={14} /> 녹음 중지</>
            ) : (
              <><Mic size={14} /> 녹음 시작</>
            )}
          </button>
        ) : (
          <p className="text-xs text-amber-600">이 브라우저는 STT 미지원 — 직접 입력하세요</p>
        )}

        {(stt.interim || transcript) && (
          <textarea
            value={transcript + (stt.interim ? ' ' + stt.interim : '')}
            onChange={(e) => setTranscript(e.target.value)}
            className="w-full mt-3 px-3 py-2 border border-gray-200 rounded-lg text-sm min-h-[120px]"
            placeholder="녹음 텍스트 또는 직접 입력"
          />
        )}

        {transcript && (
          <button
            onClick={organize}
            disabled={organizing}
            className="w-full mt-3 bg-[#2C1810] text-white py-2.5 rounded-lg text-sm font-semibold disabled:opacity-50"
          >
            {organizing ? '정리 중…' : '🧠 AI로 정리하기'}
          </button>
        )}
      </div>

      {result && (
        <div className="bg-white rounded-2xl border border-gray-100 p-5 space-y-3">
          <div>
            <h3 className="text-xs text-gray-400 uppercase mb-1">요약</h3>
            <p className="text-sm text-[#2C1810]">{result.summary}</p>
          </div>
          {result.categories.length > 0 && (
            <div>
              <h3 className="text-xs text-gray-400 uppercase mb-1">카테고리</h3>
              <div className="flex flex-wrap gap-1">
                {result.categories.map((c, i) => (
                  <span key={i} className="text-[10px] px-2 py-0.5 bg-[#D4A574]/15 text-[#2C1810] rounded-full font-medium">
                    {c}
                  </span>
                ))}
              </div>
            </div>
          )}
          {result.action_items.length > 0 && (
            <div>
              <h3 className="text-xs text-gray-400 uppercase mb-1">오늘 할 일</h3>
              <ul className="text-sm text-gray-700 space-y-1">
                {result.action_items.map((a, i) => (
                  <li key={i} className="flex items-start gap-2">
                    <Check size={12} className="text-[#22C55E] mt-1 shrink-0" /> {a}
                  </li>
                ))}
              </ul>
            </div>
          )}
          {result.memories_saved > 0 && (
            <p className="text-xs text-gray-400 italic">
              📝 {result.memories_saved}개 메모리가 저장되어 AI가 학습합니다
            </p>
          )}
        </div>
      )}
    </div>
  )
}

// ═══════════════════════════════════════════════════════
// J6 — 동종업계 익명 벤치마크
// ═══════════════════════════════════════════════════════

interface BenchResult {
  my_value: number
  p25: number
  p50: number
  p75: number
  sample_size: number
  metric: string
  period: string
  note: string
  privacy_note: string
}

function BenchmarkTab() {
  const user = useAuthStore((s) => s.user)
  const [period, setPeriod] = useState<'7d' | '30d' | '90d'>('30d')
  const [result, setResult] = useState<BenchResult | null>(null)
  const [loading, setLoading] = useState(false)

  useEffect(() => {
    if (!user) return
    setLoading(true)
    fetch(`/api/v1/differentiation/benchmark/revenue-per-day?period=${period}`, {
      headers: { 'X-Store-Id': user.id },
    })
      .then((r) => r.ok ? r.json() : null)
      .then((d) => setResult(d))
      .finally(() => setLoading(false))
  }, [user, period])

  return (
    <div className="space-y-4">
      <div className="bg-white rounded-2xl border border-gray-100 p-5">
        <h2 className="text-sm font-bold text-[#2C1810] mb-1">동종업계 익명 벤치마크</h2>
        <p className="text-xs text-gray-500 mb-3">
          내 매장 매출이 다른 카페와 비교해 어디쯤인지 봅니다. 다른 매장 데이터는 절대 공개되지 않아요 (k-익명성).
        </p>
        <div className="flex gap-2">
          {(['7d', '30d', '90d'] as const).map((p) => (
            <button
              key={p}
              onClick={() => setPeriod(p)}
              className={cn(
                'flex-1 px-3 py-1.5 rounded-lg text-xs font-medium',
                period === p ? 'bg-[#2C1810] text-white' : 'bg-gray-100 text-gray-500'
              )}
            >
              {p === '7d' ? '7일' : p === '30d' ? '30일' : '90일'}
            </button>
          ))}
        </div>
      </div>

      {loading && (
        <div className="bg-white rounded-2xl p-8 text-center">
          <Loader2 size={20} className="animate-spin text-[#D4A574] mx-auto" />
        </div>
      )}

      {result && !loading && (
        <div className="bg-white rounded-2xl border border-gray-100 p-5">
          {result.sample_size < 10 ? (
            <div className="text-center py-6">
              <X size={24} className="text-amber-500 mx-auto mb-2" />
              <p className="text-sm font-semibold text-[#2C1810] mb-1">표본 부족</p>
              <p className="text-xs text-gray-500 leading-relaxed">{result.note}</p>
            </div>
          ) : (
            <>
              <div className="mb-4">
                <p className="text-xs text-gray-400 uppercase">내 일평균 매출</p>
                <p className="text-3xl font-bold text-[#2C1810] tabular-nums">
                  ₩{Math.round(result.my_value).toLocaleString()}
                </p>
              </div>

              {/* 분위수 막대 */}
              <div className="space-y-2 mb-4">
                <Quartile label="상위 25% 평균" value={result.p75} my={result.my_value} color="#22C55E" />
                <Quartile label="중앙값 (50%)" value={result.p50} my={result.my_value} color="#4A90A4" />
                <Quartile label="하위 25% 평균" value={result.p25} my={result.my_value} color="#F59E0B" />
              </div>

              <div className="bg-gradient-to-r from-[#D4A574]/15 to-[#D4A574]/5 rounded-xl p-3 mb-3">
                <p className="text-sm font-bold text-[#2C1810]">{result.note}</p>
              </div>

              <p className="text-[10px] text-gray-400 leading-relaxed">
                🔒 {result.privacy_note} (표본: {result.sample_size}개 매장)
              </p>
            </>
          )}
        </div>
      )}
    </div>
  )
}

function Quartile({ label, value, my, color }: { label: string; value: number; my: number; color: string }) {
  const max = Math.max(value, my)
  const myPct = max > 0 ? (my / max) * 100 : 0
  const valPct = max > 0 ? (value / max) * 100 : 0
  return (
    <div>
      <div className="flex items-center justify-between text-xs text-gray-500 mb-1">
        <span>{label}</span>
        <span className="tabular-nums" style={{ color }}>₩{Math.round(value).toLocaleString()}</span>
      </div>
      <div className="relative h-2 bg-gray-100 rounded-full overflow-hidden">
        <div className="absolute top-0 left-0 h-full" style={{ width: `${valPct}%`, background: color, opacity: 0.4 }} />
        <div className="absolute top-0 left-0 h-full" style={{ width: `${myPct}%`, background: '#2C1810' }} />
      </div>
    </div>
  )
}
