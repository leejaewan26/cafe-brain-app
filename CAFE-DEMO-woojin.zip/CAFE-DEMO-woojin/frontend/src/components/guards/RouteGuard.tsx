// 인증 + 프로필 라우팅 가드 (Issue #5 멀티프로필)
import { Navigate, Outlet } from 'react-router-dom'
import { useAuthStore } from '@/store/authStore'
import { useProfileStore, canAccess, type OwnerOnlyFeature } from '@/store/profileStore'
import { Loader2, Lock } from 'lucide-react'
import { useEffect, useState } from 'react'
import { supabase } from '@/lib/supabase'

/**
 * 로그인 + 온보딩 + 프로필 선택까지 모두 완료된 상태만 통과.
 * 미인증 → /login / 온보딩 미완 → /onboarding / 프로필 미선택 → /profile-select
 */
export function ProtectedRoute() {
  const { user, isOnboarded, setUser, setSession } = useAuthStore()
  const activeProfile = useProfileStore((s) => s.activeProfile)
  const [isChecking, setIsChecking] = useState(true)

  useEffect(() => {
    supabase.auth.getSession().then(({ data: { session } }) => {
      setSession(session)
      setUser(session?.user ?? null)
      setIsChecking(false)
    })
  }, [setUser, setSession])

  if (isChecking) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-[#FAFAF8]">
        <Loader2 className="w-8 h-8 animate-spin text-[#D4A574]" />
      </div>
    )
  }

  if (!user) return <Navigate to="/login" replace />
  if (!isOnboarded) return <Navigate to="/onboarding" replace />
  if (!activeProfile) return <Navigate to="/profile-select" replace />

  return <Outlet />
}

/**
 * 로그인 상태에서 /login 접근 시 리다이렉트
 */
export function PublicOnlyRoute() {
  const { user, isOnboarded } = useAuthStore()
  const activeProfile = useProfileStore((s) => s.activeProfile)

  if (user && isOnboarded && activeProfile) return <Navigate to="/dashboard" replace />
  if (user && isOnboarded && !activeProfile) return <Navigate to="/profile-select" replace />
  if (user && !isOnboarded) return <Navigate to="/onboarding" replace />

  return <Outlet />
}

/**
 * 사장 전용 페이지 가드 (Issue #5)
 * 점장·매니저 접근 시 권한 없음 화면 노출
 */
export function OwnerOnlyRoute({ feature }: { feature?: OwnerOnlyFeature }) {
  const activeProfile = useProfileStore((s) => s.activeProfile)

  if (!activeProfile) return <Navigate to="/profile-select" replace />
  if (canAccess(activeProfile, feature ?? 'account_delete')) return <Outlet />

  return (
    <div className="min-h-[60vh] flex items-center justify-center px-4">
      <div className="text-center max-w-md">
        <div className="w-16 h-16 rounded-full bg-gray-100 mx-auto mb-4 flex items-center justify-center">
          <Lock size={24} className="text-gray-400" />
        </div>
        <h2 className="text-xl font-bold text-[#2C1810] mb-2">사장 전용 기능입니다</h2>
        <p className="text-sm text-gray-500 mb-6">
          이 페이지는 사장 프로필만 접근할 수 있습니다.<br/>
          현재 프로필: <strong>{activeProfile.name}</strong> ({activeProfile.role === 'manager' ? '점장·매니저' : '사장'})
        </p>
        <a
          href="/profile-select"
          className="inline-block px-5 py-2.5 bg-[#2C1810] text-white rounded-xl text-sm font-semibold hover:bg-[#3d2418] transition-colors"
        >
          프로필 변경
        </a>
      </div>
    </div>
  )
}
