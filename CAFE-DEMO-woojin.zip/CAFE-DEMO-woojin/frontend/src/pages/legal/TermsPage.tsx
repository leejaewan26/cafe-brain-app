// Launch A3 — 이용약관
// 한국 카페 SaaS 표준 약관 템플릿. 결제·환불·면책 포함.
import { Link } from 'react-router-dom'
import { ArrowLeft, FileText } from 'lucide-react'

const EFFECTIVE_DATE = '2026-05-03'
const SERVICE_NAME = '카페 브레인'
const CONTACT_EMAIL = 'support@cafe-brain.app'

export default function TermsPage() {
  return (
    <div className="min-h-screen bg-[#FAFAF8] py-8 px-4">
      <div className="max-w-3xl mx-auto">
        <Link to="/" className="inline-flex items-center gap-1 text-sm text-gray-500 hover:text-[#2C1810] mb-6 transition-colors">
          <ArrowLeft size={14} /> 홈으로
        </Link>

        <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-6 md:p-10">
          <div className="flex items-center gap-3 mb-2">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#D4A574] to-[#2C1810] flex items-center justify-center">
              <FileText size={18} className="text-white" />
            </div>
            <h1 className="text-2xl font-bold text-[#2C1810]">이용약관</h1>
          </div>
          <p className="text-xs text-gray-400 mb-6">시행일: {EFFECTIVE_DATE}</p>

          <Article num="1" title="목적">
            본 약관은 {SERVICE_NAME}(이하 "서비스")의 이용 조건과 절차, 회사와 이용자의 권리·의무 및
            책임 사항을 규정합니다.
          </Article>

          <Article num="2" title="용어 정의">
            <Bullets items={[
              '"이용자": 본 약관에 따라 서비스를 이용하는 카페 사장 및 운영자',
              '"매장": 이용자가 등록한 영업장 단위',
              '"콘텐츠": AI가 생성한 인사이트·답글·메뉴 추천 등 결과물',
              '"학습 메모리": AI가 매장 운영 패턴을 학습한 정보',
            ]} />
          </Article>

          <Article num="3" title="약관의 효력 및 변경">
            <p className="mb-2">본 약관은 서비스에 게시함으로써 효력이 발생합니다.</p>
            <p>회사는 필요 시 약관을 변경할 수 있으며, 변경 시 시행일 7일 전 공지합니다.
              불리한 변경은 30일 전 공지하며, 이용자는 변경에 동의하지 않을 경우 회원 탈퇴할 수 있습니다.</p>
          </Article>

          <Article num="4" title="회원 가입">
            <Bullets items={[
              '이용자는 회사가 정한 양식에 따라 가입을 신청합니다',
              '회사는 다음의 경우 가입을 거절할 수 있습니다: 허위 정보, 타인 명의 도용, 영업 목적 위반',
              '실명 정보로 가입해야 하며, 정보 변경 시 즉시 갱신해야 합니다',
            ]} />
          </Article>

          <Article num="5" title="서비스 내용">
            <Bullets items={[
              'AI 매출 분석, 메뉴 추천, 리뷰 답글 자동 생성',
              '능동형 일일 브리핑, 이상치 감지, 트렌드 분석',
              '재료 원가 관리, 직원 스케줄링, 회계 보조',
              '서비스 내용은 회사의 정책 또는 법령에 따라 변경될 수 있습니다',
            ]} />
          </Article>

          <Article num="6" title="이용 요금 및 결제">
            <Bullets items={[
              '서비스는 무료 체험 + 유료 구독제로 제공됩니다',
              '결제는 토스페이먼츠 등 결제 대행사를 통해 처리됩니다',
              '구독은 매월/매년 자동 갱신되며, 갱신 7일 전 알림을 보냅니다',
              '청구된 요금은 가입 시점의 가격 정책에 따릅니다',
            ]} />
          </Article>

          <Article num="7" title="환불 정책">
            <Bullets items={[
              '결제 후 7일 이내에 서비스를 전혀 이용하지 않은 경우 전액 환불',
              '월간 구독: 결제일로부터 7일 이내 환불 가능',
              '연간 구독: 결제일로부터 7일 이내 전액, 그 후 사용 월수에 비례한 환불',
              '환불 요청은 고객센터(' + CONTACT_EMAIL + ')로 접수합니다',
            ]} />
          </Article>

          <Article num="8" title="이용자의 의무">
            <Bullets items={[
              '계정 정보를 안전하게 관리할 의무 (비밀번호 유출에 따른 손해는 본인 책임)',
              '서비스를 통한 불법·부정 행위 금지 (해킹, 자동화 봇, 권한 외 데이터 접근)',
              '타인의 개인정보·매장 정보를 무단 입력 금지',
              'AI 콘텐츠는 참고용이며, 최종 의사결정은 이용자 책임',
            ]} />
          </Article>

          <Article num="9" title="회사의 의무">
            <Bullets items={[
              '관련 법령과 본 약관이 금하는 행위를 하지 않음',
              '안정적인 서비스 제공을 위해 노력 (단, 99% SLA 등 보증 X)',
              '이용자의 개인정보를 보호 (별도 「개인정보처리방침」 참조)',
              '부득이한 사유로 서비스 중단 시 사전 공지',
            ]} />
          </Article>

          <Article num="10" title="지식재산권">
            <p className="mb-2">서비스에 포함된 모든 콘텐츠(코드, 디자인, 상표)의 저작권은 회사에 귀속됩니다.</p>
            <p>이용자가 입력한 데이터(매출, 메뉴, 리뷰)의 저작권은 이용자에게 귀속됩니다.
              회사는 서비스 제공·개선 목적으로만 해당 데이터를 활용합니다.</p>
            <p className="mt-2">AI가 생성한 콘텐츠는 이용자가 자유롭게 사용할 수 있으나,
              그 정확성·적법성에 대한 책임은 사용 주체에게 있습니다.</p>
          </Article>

          <Article num="11" title="서비스 중단·해지">
            <Bullets items={[
              '이용자는 언제든 회원 탈퇴를 요청할 수 있습니다',
              '회사는 다음의 경우 이용을 제한·해지할 수 있습니다: 약관 위반, 부정 결제, 타 이용자 침해',
              '해지 시 모든 개인정보·메모리는 즉시 파기됩니다 (법령 보관 기간 제외)',
            ]} />
          </Article>

          <Article num="12" title="면책 조항">
            <Bullets items={[
              '천재지변, 정전, 외부 API(Gemini 등) 장애로 인한 서비스 중단에 대해 면책',
              'AI 응답의 정확성을 보증하지 않으며, 이를 기반으로 한 의사결정 손해는 책임지지 않음',
              '이용자 간 거래·분쟁에 회사는 개입하지 않음',
              '회사의 손해 배상 한도: 직전 3개월 결제 금액',
            ]} />
          </Article>

          <Article num="13" title="분쟁 해결">
            <p className="mb-2">서비스 이용 중 발생한 분쟁은 우선 협의로 해결합니다.</p>
            <p>협의가 이루어지지 않을 경우, 회사 본점 소재지 관할 법원을 1심 관할 법원으로 합니다.
              준거법은 대한민국 법으로 합니다.</p>
          </Article>

          <Article num="14" title="문의">
            <div className="bg-[#FAFAF8] rounded-xl p-4 text-sm text-gray-700 leading-relaxed">
              <p>고객지원: <a href={`mailto:${CONTACT_EMAIL}`} className="text-[#D4A574] hover:underline">{CONTACT_EMAIL}</a></p>
              <p className="mt-1">서비스 내 [설정 &gt; FAQ]에서도 문의하실 수 있습니다.</p>
            </div>
          </Article>

          <p className="text-xs text-gray-400 mt-8">시행일: {EFFECTIVE_DATE}</p>
        </div>
      </div>
    </div>
  )
}

function Article({ num, title, children }: { num: string; title: string; children: React.ReactNode }) {
  return (
    <section className="mb-6">
      <h2 className="font-bold text-[#2C1810] text-base mb-2">제 {num} 조 ({title})</h2>
      <div className="text-sm text-gray-700 leading-relaxed">{children}</div>
    </section>
  )
}

function Bullets({ items }: { items: string[] }) {
  return (
    <ul className="list-disc pl-5 space-y-1 text-sm text-gray-700 leading-relaxed">
      {items.map((it, i) => <li key={i}>{it}</li>)}
    </ul>
  )
}
