// AI 어시스턴트 채팅 Zustand 스토어
// 대화 이력 로컬 저장 (Supabase 연동 준비)
import { create } from 'zustand'
import { persist } from 'zustand/middleware'

export interface ChatMessage {
  id: string
  role: 'user' | 'assistant'
  content: string
  timestamp: string
}

export interface ChatSession {
  id: string
  title: string          // 첫 번째 사용자 메시지 요약
  messages: ChatMessage[]
  createdAt: string
  updatedAt: string
}

interface ChatState {
  sessions: ChatSession[]
  activeSessionId: string | null
  isPanelOpen: boolean
  // 액션
  openPanel: () => void
  closePanel: () => void
  togglePanel: () => void
  newSession: () => string        // 새 세션 ID 반환
  setActiveSession: (id: string) => void
  addMessage: (sessionId: string, msg: Omit<ChatMessage, 'id' | 'timestamp'>) => void
  deleteSession: (id: string) => void
  clearAll: () => void
}

function genId() {
  return `${Date.now()}-${Math.random().toString(36).slice(2, 7)}`
}

function createNewSession(): ChatSession {
  return {
    id: genId(),
    title: '새 대화',
    messages: [],
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  }
}

export const useChatStore = create<ChatState>()(
  persist(
    (set) => ({
      sessions: [],
      activeSessionId: null,
      isPanelOpen: false,

      openPanel: () => set({ isPanelOpen: true }),
      closePanel: () => set({ isPanelOpen: false }),
      togglePanel: () => set((s) => ({ isPanelOpen: !s.isPanelOpen })),

      newSession: () => {
        const session = createNewSession()
        set((s) => ({
          sessions: [session, ...s.sessions],
          activeSessionId: session.id,
        }))
        return session.id
      },

      setActiveSession: (id) => set({ activeSessionId: id }),

      addMessage: (sessionId, msg) => {
        const newMsg: ChatMessage = {
          ...msg,
          id: genId(),
          timestamp: new Date().toISOString(),
        }
        set((s) => ({
          sessions: s.sessions.map((sess) => {
            if (sess.id !== sessionId) return sess
            const messages = [...sess.messages, newMsg]
            // 첫 사용자 메시지를 제목으로
            const firstUser = messages.find((m) => m.role === 'user')
            const title = firstUser
              ? firstUser.content.slice(0, 30) + (firstUser.content.length > 30 ? '…' : '')
              : '새 대화'
            return { ...sess, messages, title, updatedAt: new Date().toISOString() }
          }),
        }))
      },

      deleteSession: (id) =>
        set((s) => {
          const sessions = s.sessions.filter((sess) => sess.id !== id)
          return {
            sessions,
            activeSessionId: s.activeSessionId === id ? (sessions[0]?.id ?? null) : s.activeSessionId,
          }
        }),

      clearAll: () => set({ sessions: [], activeSessionId: null }),
    }),
    { name: 'cafe-brain-chat' }
  )
)
