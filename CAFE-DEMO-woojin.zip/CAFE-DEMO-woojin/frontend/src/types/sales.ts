// 매출·운영 분석 모듈 타입 정의
export interface SalesRecord {
  id: string
  store_id?: string
  sale_date: string       // 'YYYY-MM-DD'
  hour_slot: number       // 0–23
  day_of_week: number     // 0=일, 1=월, ... 6=토
  menu_name: string
  quantity: number
  revenue: number         // 매출액 (원)
  cost: number            // 원가 (원)
  discount: number        // 할인액 (원)
  created_at?: string
}

// CSV 컬럼 매핑 타입
export type CsvFieldKey = 'sale_date' | 'menu_name' | 'quantity' | 'revenue' | 'cost' | 'discount' | 'hour_slot'

export interface CsvMapping {
  sale_date: string
  menu_name: string
  quantity: string
  revenue: string
  cost: string
  discount: string
  hour_slot: string
}

// 메뉴별 집계 (4사분면용)
export interface MenuAggregate {
  menu_name: string
  total_qty: number
  total_revenue: number
  total_cost: number
  margin_rate: number     // % (매출 - 원가) / 매출 * 100
}

// 히트맵 셀
export interface HeatmapCell {
  day: number    // 0=일~6=토
  hour: number   // 0~23
  revenue: number
}

// 월별 집계
export interface MonthlyAggregate {
  month: string  // 'YYYY-MM'
  revenue: number
  cost: number
  profit: number
}

// BEP 계산 입력
export interface BepInput {
  monthly_fixed_cost: number  // 월 고정비
  avg_price: number           // 평균 판매가
  avg_cost: number            // 평균 원가
}

// BEP 계산 결과
export interface BepResult {
  daily_cups: number
  monthly_cups: number
  margin_per_cup: number
}

// 가격 시뮬레이션 결과
export interface PriceSimResult {
  menu_name: string
  current_cost: number
  new_cost: number
  current_price: number
  min_price: number
  price_diff: number
}
