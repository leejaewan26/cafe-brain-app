#!/usr/bin/env node
// L2 — 프론트 v1 마이그레이션 일괄 스크립트
// fetch('/api/X) → fetch('/api/v1/X) (이미 v1이면 skip)
import { readdir, readFile, writeFile } from 'node:fs/promises'
import path from 'node:path'

const ROOT = path.resolve(process.cwd(), 'src')

async function* walk(dir) {
  const entries = await readdir(dir, { withFileTypes: true })
  for (const e of entries) {
    const full = path.join(dir, e.name)
    if (e.isDirectory()) yield* walk(full)
    else if (e.isFile() && (full.endsWith('.tsx') || full.endsWith('.ts'))) yield full
  }
}

// 매칭: 인용부호 뒤 /api/ + (v1/이 아닌) 일반 문자
// (['"\`])/api/(?!v1/)([a-z\-_]+(?:/|\?))
const PATTERN = /(['"`])\/api\/(?!v1\/)([a-z][a-z0-9\-_]*(?:\/|\?|['"`]))/gi

let totalFiles = 0
let totalReplacements = 0

for await (const fp of walk(ROOT)) {
  const content = await readFile(fp, 'utf8')
  let count = 0
  const next = content.replace(PATTERN, (m, q, rest) => {
    count++
    return `${q}/api/v1/${rest}`
  })
  if (count > 0) {
    await writeFile(fp, next)
    totalFiles++
    totalReplacements += count
    console.log(`  ${fp.replace(ROOT, 'src')}: ${count}곳`)
  }
}

console.log(`\n✅ ${totalFiles}개 파일 / ${totalReplacements}개 fetch 호출 v1 마이그레이션 완료`)
