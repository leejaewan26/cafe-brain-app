// Bonus E5 — PWA 설치 권유 배너
// beforeinstallprompt 이벤트가 발생했을 때만 표시.
// 사용자가 X 누르면 7일간 다시 안 보임.
import { Download, X } from 'lucide-react'
import { useInstallPrompt } from '@/hooks/usePWA'

export default function PWAInstallBanner() {
  const { available, installed, dismissed, promptInstall, dismiss } = useInstallPrompt()

  if (!available || installed || dismissed) return null

  return (
    <div className="fixed bottom-4 left-1/2 -translate-x-1/2 z-50 max-w-sm w-[calc(100%-2rem)] bg-white rounded-2xl shadow-2xl border border-gray-100 p-4 animate-in slide-in-from-bottom-4 duration-300">
      <div className="flex items-start gap-3">
        <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#D4A574] to-[#2C1810] flex items-center justify-center shrink-0">
          <Download size={18} className="text-white" />
        </div>
        <div className="flex-1 min-w-0">
          <p className="text-sm font-bold text-[#2C1810]">홈 화면에 추가</p>
          <p className="text-xs text-gray-500 mt-0.5 leading-relaxed">
            앱처럼 빠르게 실행되고 오프라인에서도 마지막 데이터를 볼 수 있어요
          </p>
          <div className="flex gap-2 mt-3">
            <button
              onClick={promptInstall}
              className="flex-1 bg-[#2C1810] text-white text-xs font-semibold py-2 rounded-lg hover:bg-[#3A2519] transition-colors"
            >
              설치하기
            </button>
            <button
              onClick={dismiss}
              className="px-3 text-xs text-gray-400 hover:text-gray-600 transition-colors"
            >
              나중에
            </button>
          </div>
        </div>
        <button
          onClick={dismiss}
          className="p-1 text-gray-300 hover:text-gray-500 transition-colors -mr-1 -mt-1"
          aria-label="닫기"
        >
          <X size={14} />
        </button>
      </div>
    </div>
  )
}
