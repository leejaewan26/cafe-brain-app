-- ═══════════════════════════════════════════════════════════════
-- 017 — 토스 결제 구독 영속 (H1)
-- ═══════════════════════════════════════════════════════════════
-- subscriptions 테이블, billing_events (감사용), pg_cron 자동 결제
-- ═══════════════════════════════════════════════════════════════

-- ─── subscriptions ───────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS subscriptions (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  store_id        UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  plan_id         TEXT NOT NULL CHECK (plan_id IN ('monthly', 'yearly')),
  -- 빌링키는 토스에서 발급한 영구 결제 토큰 (재발급 X) — service_role 만 read
  billing_key     TEXT NOT NULL,
  customer_key    TEXT NOT NULL,
  amount_krw      INT NOT NULL,
  status          TEXT NOT NULL DEFAULT 'active'
                   CHECK (status IN ('active', 'past_due', 'canceling', 'canceled')),
  current_period_start TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  next_billing_at TIMESTAMPTZ NOT NULL,
  last_payment_id TEXT,
  cancel_reason   TEXT,
  canceled_at     TIMESTAMPTZ,
  created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_subscriptions_store ON subscriptions(store_id);
CREATE INDEX IF NOT EXISTS idx_subscriptions_status_next ON subscriptions(status, next_billing_at);
CREATE INDEX IF NOT EXISTS idx_subscriptions_payment ON subscriptions(last_payment_id);

-- RLS — 본인 매장 구독은 본인이 read OK (단, billing_key 컬럼은 view로 차단)
ALTER TABLE subscriptions ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "subscriptions_owner_read" ON subscriptions;
CREATE POLICY "subscriptions_owner_read" ON subscriptions
  FOR SELECT USING (auth.uid() = store_id);

-- 사장님은 직접 INSERT/UPDATE 못 함 — service_role만 허용
DROP POLICY IF EXISTS "subscriptions_service_write" ON subscriptions;
CREATE POLICY "subscriptions_service_write" ON subscriptions
  FOR ALL USING (auth.role() = 'service_role');

-- 본인이 read할 때 빌링키 마스킹용 view
CREATE OR REPLACE VIEW my_subscription AS
SELECT
  id, store_id, plan_id, amount_krw, status,
  current_period_start, next_billing_at, canceled_at, cancel_reason,
  created_at, updated_at,
  -- 빌링키 마스킹
  LEFT(billing_key, 12) || '***' AS billing_key_masked
FROM subscriptions
WHERE store_id = auth.uid();

-- ─── billing_events (감사·디버깅용) ──────────────────────────────
CREATE TABLE IF NOT EXISTS billing_events (
  id           UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  event_type   TEXT NOT NULL,
  status       TEXT,
  order_id     TEXT,
  payment_key  TEXT,
  amount_krw   INT,
  raw          JSONB,
  created_at   TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_billing_events_payment ON billing_events(payment_key);
CREATE INDEX IF NOT EXISTS idx_billing_events_order ON billing_events(order_id);
CREATE INDEX IF NOT EXISTS idx_billing_events_created ON billing_events(created_at DESC);

ALTER TABLE billing_events ENABLE ROW LEVEL SECURITY;
-- 사장님은 못 봄 (운영팀만)
DROP POLICY IF EXISTS "billing_events_service_only" ON billing_events;
CREATE POLICY "billing_events_service_only" ON billing_events
  FOR ALL USING (auth.role() = 'service_role');

-- ─── stores 컬럼 보강 ────────────────────────────────────────────
ALTER TABLE stores
  ADD COLUMN IF NOT EXISTS trial_ends_at TIMESTAMPTZ,
  ADD COLUMN IF NOT EXISTS subscription_status TEXT DEFAULT 'trial',
  ADD COLUMN IF NOT EXISTS last_trial_email_sent_at TIMESTAMPTZ;

-- 새 가입자에게 자동으로 14일 trial_ends_at 부여 (트리거)
CREATE OR REPLACE FUNCTION set_trial_ends_at()
RETURNS TRIGGER AS $$
BEGIN
  IF NEW.trial_ends_at IS NULL THEN
    NEW.trial_ends_at := NEW.created_at + INTERVAL '14 days';
  END IF;
  IF NEW.subscription_status IS NULL THEN
    NEW.subscription_status := 'trial';
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_stores_trial_ends_at ON stores;
CREATE TRIGGER trg_stores_trial_ends_at
  BEFORE INSERT ON stores
  FOR EACH ROW
  EXECUTE FUNCTION set_trial_ends_at();

-- ─── pg_cron — 매일 04:00 KST 정기결제 trigger ──────────────────
-- 실제 호출은 우리 백엔드의 /api/billing/cron/charge 가 함
-- Supabase에선 pg_cron으로 직접 HTTP 호출 (extension: pg_net 필요)
-- 또는 외부 스케줄러(Render Cron, GitHub Actions)에서 호출 권장

COMMENT ON TABLE subscriptions IS '토스 빌링키 기반 구독 — billing_key는 service_role만 읽기';
COMMENT ON TABLE billing_events IS '결제 이벤트 감사 로그 (운영팀 전용)';
