-- 매출 기록 테이블
CREATE TABLE IF NOT EXISTS public.sales_records (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  store_id uuid NOT NULL REFERENCES public.stores(id) ON DELETE CASCADE,
  sale_date date NOT NULL,
  hour_slot integer NOT NULL DEFAULT 9 CHECK (hour_slot BETWEEN 0 AND 23),
  day_of_week integer NOT NULL CHECK (day_of_week BETWEEN 0 AND 6),
  menu_name text NOT NULL,
  quantity integer NOT NULL DEFAULT 1,
  revenue numeric NOT NULL DEFAULT 0,
  cost numeric NOT NULL DEFAULT 0,
  discount numeric NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now()
);

-- 인덱스: 자주 쓰는 필터 기준
CREATE INDEX IF NOT EXISTS idx_sales_records_store_date ON public.sales_records(store_id, sale_date);
CREATE INDEX IF NOT EXISTS idx_sales_records_menu ON public.sales_records(store_id, menu_name);

-- RLS: 본인 매장 데이터만 접근
ALTER TABLE public.sales_records ENABLE ROW LEVEL SECURITY;

CREATE POLICY "sales_records: 본인 매장만 접근" ON public.sales_records
  FOR ALL USING (store_id = auth.uid());
