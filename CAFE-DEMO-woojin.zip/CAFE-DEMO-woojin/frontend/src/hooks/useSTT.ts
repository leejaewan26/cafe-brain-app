// G5 — Web Speech API 음성 인식 (STT)
// 한국어 실시간 받아쓰기. 마이크 권한 필요.
//
// 사용:
//   const stt = useSTT()
//   stt.start() / stt.stop()
//   stt.transcript — 누적된 인식 텍스트
//   stt.interim — 진행 중 인식 (확정 X)
//   stt.listening — 현재 듣는 중 여부
//
// 종료 시 onFinal(text) 콜백 호출.
import { useCallback, useEffect, useRef, useState } from 'react'

// 브라우저 호환 별칭
type SpeechRecognitionConstructor = new () => SpeechRecognition
interface SpeechRecognitionExt extends EventTarget {
  continuous: boolean
  interimResults: boolean
  lang: string
  start: () => void
  stop: () => void
  abort: () => void
  onresult: ((event: SpeechRecognitionEvent) => void) | null
  onerror: ((event: SpeechRecognitionErrorEvent) => void) | null
  onend: (() => void) | null
}
interface SpeechRecognitionEvent extends Event {
  results: SpeechRecognitionResultList
  resultIndex: number
}
interface SpeechRecognitionErrorEvent extends Event {
  error: string
}

interface SpeechRecognitionResult {
  isFinal: boolean
  readonly length: number
  [index: number]: SpeechRecognitionAlternative
}
interface SpeechRecognitionResultList {
  readonly length: number
  [index: number]: SpeechRecognitionResult
}
interface SpeechRecognitionAlternative {
  transcript: string
  confidence: number
}
type SpeechRecognition = SpeechRecognitionExt

interface UseSTTOptions {
  lang?: string                 // 'ko-KR' (기본)
  continuous?: boolean          // 연속 모드 (기본 true)
  onFinal?: (text: string) => void
}

export function useSTT(opts: UseSTTOptions = {}) {
  const lang = opts.lang ?? 'ko-KR'
  const continuous = opts.continuous ?? true

  const [supported, setSupported] = useState(false)
  const [listening, setListening] = useState(false)
  const [transcript, setTranscript] = useState('')
  const [interim, setInterim] = useState('')
  const [error, setError] = useState<string | null>(null)
  const recogRef = useRef<SpeechRecognition | null>(null)
  const finalizedRef = useRef('')
  const onFinalRef = useRef(opts.onFinal)
  onFinalRef.current = opts.onFinal

  useEffect(() => {
    if (typeof window === 'undefined') return
    const Ctor =
      (window as unknown as { SpeechRecognition?: SpeechRecognitionConstructor }).SpeechRecognition ||
      (window as unknown as { webkitSpeechRecognition?: SpeechRecognitionConstructor }).webkitSpeechRecognition
    setSupported(Boolean(Ctor))
  }, [])

  const start = useCallback(() => {
    if (typeof window === 'undefined') return
    const Ctor =
      (window as unknown as { SpeechRecognition?: SpeechRecognitionConstructor }).SpeechRecognition ||
      (window as unknown as { webkitSpeechRecognition?: SpeechRecognitionConstructor }).webkitSpeechRecognition
    if (!Ctor) {
      setError('이 브라우저는 음성 인식을 지원하지 않아요')
      return
    }
    if (recogRef.current) {
      try { recogRef.current.abort() } catch { /* ignore */ }
    }
    const recog = new Ctor() as SpeechRecognition
    recog.lang = lang
    recog.continuous = continuous
    recog.interimResults = true
    finalizedRef.current = ''
    setTranscript('')
    setInterim('')
    setError(null)

    recog.onresult = (event: SpeechRecognitionEvent) => {
      let finalText = ''
      let interimText = ''
      for (let i = event.resultIndex; i < event.results.length; i++) {
        const result = event.results[i]
        const text = result[0]?.transcript ?? ''
        if (result.isFinal) finalText += text
        else interimText += text
      }
      if (finalText) {
        finalizedRef.current = (finalizedRef.current + ' ' + finalText).trim()
        setTranscript(finalizedRef.current)
      }
      setInterim(interimText.trim())
    }
    recog.onerror = (e: SpeechRecognitionErrorEvent) => {
      setError(e.error)
      setListening(false)
    }
    recog.onend = () => {
      setListening(false)
      // 최종 텍스트 콜백
      if (finalizedRef.current && onFinalRef.current) {
        onFinalRef.current(finalizedRef.current)
      }
    }
    try {
      recog.start()
      recogRef.current = recog
      setListening(true)
    } catch (e) {
      setError(e instanceof Error ? e.message : '시작 실패')
    }
  }, [lang, continuous])

  const stop = useCallback(() => {
    try { recogRef.current?.stop() } catch { /* ignore */ }
    setListening(false)
  }, [])

  const reset = useCallback(() => {
    finalizedRef.current = ''
    setTranscript('')
    setInterim('')
    setError(null)
  }, [])

  // 컴포넌트 unmount 시 abort
  useEffect(() => {
    return () => {
      try { recogRef.current?.abort() } catch { /* ignore */ }
    }
  }, [])

  return { supported, listening, transcript, interim, error, start, stop, reset }
}
