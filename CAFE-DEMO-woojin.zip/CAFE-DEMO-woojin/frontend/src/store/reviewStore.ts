// 리뷰 관리 Zustand 스토어 - 샘플 20개 내장
import { create } from 'zustand'
import { persist } from 'zustand/middleware'
import type { Review, ReplyTone, KeywordInsight } from '@/types/review'

interface ReviewSettings {
  defaultTone: ReplyTone
}

interface ReviewState {
  reviews: Review[]
  reviewSettings: ReviewSettings
  keywordCache: KeywordInsight | null
  addReviews: (reviews: Omit<Review, 'id' | 'ai_reply' | 'reply_status' | 'is_selected'>[]) => void
  updateReview: (id: string, updates: Partial<Review>) => void
  deleteReview: (id: string) => void
  setReply: (id: string, reply: string) => void
  toggleSelect: (id: string) => void
  selectAll: (selected: boolean) => void
  clearReviews: () => void
  updateReviewSettings: (settings: Partial<ReviewSettings>) => void
  setKeywordCache: (cache: KeywordInsight | null) => void
}

// 샘플 리뷰 20개 (긍정 12, 부정 5, 짧은 3)
const SAMPLE_REVIEWS: Review[] = [
  { id: 'rv-01', nickname: '커피러버', rating: 5, date: '2024-03-01', platform: '네이버', content: '아이스 아메리카노가 정말 맛있어요! 원두 향이 진하고 산미가 딱 좋아서 자주 방문하게 될 것 같아요. 직원분들도 너무 친절하고 매장 분위기도 아늑해서 오래 있고 싶어졌어요.', ai_reply: '', reply_status: 'pending', is_selected: false },
  { id: 'rv-02', nickname: '달콤이', rating: 5, date: '2024-03-02', platform: '카카오', content: '라떼 아트가 너무 예쁘게 나와서 사진 찍느라 한참 걸렸어요 ㅎㅎ 카라멜 마키아토 달달하고 너무 맛있었습니다. 주말에 또 올게요!', ai_reply: '', reply_status: 'pending', is_selected: false },
  { id: 'rv-03', nickname: '카페탐방러', rating: 5, date: '2024-03-03', platform: '구글', content: '드립커피 종류가 다양해서 좋아요. 오늘은 에티오피아 원두로 마셨는데 과일향이 정말 풍부했습니다. 베이커리도 같이 먹었는데 완전 굿!', ai_reply: '', reply_status: 'pending', is_selected: false },
  { id: 'rv-04', nickname: '행복한하루', rating: 5, date: '2024-03-04', platform: '네이버', content: '크로플이 겉은 바삭하고 안은 촉촉해서 최고였어요. 아메리카노랑 같이 먹으니 정말 찰떡 조합이에요. 사장님도 친절하셔서 기분 좋게 먹었습니다.', ai_reply: '', reply_status: 'pending', is_selected: false },
  { id: 'rv-05', nickname: '단골손님', rating: 5, date: '2024-03-05', platform: '카카오', content: '매주 월요일마다 들르는 단골인데 항상 기분 좋게 만들어주는 카페예요. 바닐라 라떼는 진짜 시그니처 메뉴인 것 같아요. 리필도 가능해서 더 좋아요.', ai_reply: '', reply_status: 'pending', is_selected: false },
  { id: 'rv-06', nickname: '혼공족', rating: 4, date: '2024-03-06', platform: '구글', content: '혼자 공부하기 딱 좋은 환경이에요. 와이파이도 빠르고 콘센트도 곳곳에 있어서 노트북 들고 오기 좋아요. 얼그레이 티라미수 케이크 강추!', ai_reply: '', reply_status: 'pending', is_selected: false },
  { id: 'rv-07', nickname: '분위기맛집', rating: 5, date: '2024-03-07', platform: '네이버', content: '인테리어가 너무 예뻐요. 우드톤 감성이 취향저격이에요. 플랫화이트 맛도 좋고 커피 온도도 딱 맞게 나와서 한 방울도 안 남겼어요.', ai_reply: '', reply_status: 'pending', is_selected: false },
  { id: 'rv-08', nickname: '주말여행객', rating: 5, date: '2024-03-08', platform: '카카오', content: '관광 중에 우연히 들렀는데 대박이었어요. 콜드브루가 진하면서도 부드러워서 감탄했어요. 친구한테도 추천해줬어요. 오길 잘했다 싶었어요!', ai_reply: '', reply_status: 'pending', is_selected: false },
  { id: 'rv-09', nickname: '학생단골', rating: 4, date: '2024-03-09', platform: '네이버', content: '시험 기간마다 여기 와서 공부해요. 아메리카노 리필이 돼서 오래 있어도 눈치 안 보여서 좋아요. 다음에는 신메뉴 크림라떼 도전해볼게요.', ai_reply: '', reply_status: 'pending', is_selected: false },
  { id: 'rv-10', nickname: '오피스직장인', rating: 5, date: '2024-03-10', platform: '구글', content: '점심시간에 잠깐 들렀는데 아이스라떼가 정말 진하고 맛있어요. 직원분이 바쁜데도 환하게 웃어주셔서 기분이 좋았습니다. 또 올게요!', ai_reply: '', reply_status: 'pending', is_selected: false },
  { id: 'rv-11', nickname: '맛있는거좋아', rating: 4, date: '2024-03-11', platform: '카카오', content: '아보카도 토스트 먹어봤는데 재료가 신선하고 양도 많아서 완전 만족! 커피도 같이 시켰는데 세트 가격이 합리적이에요.', ai_reply: '', reply_status: 'pending', is_selected: false },
  { id: 'rv-12', nickname: '데이트코스', rating: 5, date: '2024-03-12', platform: '네이버', content: '남자친구랑 왔는데 분위기가 너무 로맨틱해요. 티라미수 케이크 나눠먹으면서 행복한 시간 보냈어요. 다음 데이트도 여기로 결정!', ai_reply: '', reply_status: 'pending', is_selected: false },
  { id: 'rv-13', nickname: '까다로운입맛', rating: 2, date: '2024-03-13', platform: '카카오', content: '솔직히 커피 맛은 보통이에요. 가격 대비 양이 좀 적다는 느낌이고 원두 신선도가 떨어지는 것 같았어요. 분위기는 좋지만 재방문할지 모르겠어요.', ai_reply: '', reply_status: 'pending', is_selected: false },
  { id: 'rv-14', nickname: '냉정한후기', rating: 2, date: '2024-03-14', platform: '구글', content: '주문 후 15분을 기다렸는데 다른 분들보다 늦게 나왔어요. 대기 시간이 너무 길었고 직원분이 실수로 다른 음료를 가져오셔서 당황스러웠어요.', ai_reply: '', reply_status: 'pending', is_selected: false },
  { id: 'rv-15', nickname: '불만족고객', rating: 3, date: '2024-03-15', platform: '네이버', content: '카라멜 마키아토를 주문했는데 카라멜 시럽이 거의 없었어요. 달달한 맛을 기대했는데 아메리카노 같았어요. 음료 퀄리티가 일정하지 않은 것 같아요.', ai_reply: '', reply_status: 'pending', is_selected: false },
  { id: 'rv-16', nickname: '실망방문자', rating: 3, date: '2024-03-16', platform: '카카오', content: '화장실이 좀 지저분해서 별 1개 깎았어요. 커피 맛은 좋은데 청결도가 아쉬웠어요. 위생 관리 좀 더 신경 써주시면 좋겠어요.', ai_reply: '', reply_status: 'pending', is_selected: false },
  { id: 'rv-17', nickname: '가격민감러', rating: 2, date: '2024-03-17', platform: '네이버', content: '아메리카노 한 잔에 6천원은 좀 비싸다고 느꼈어요. 맛은 좋은데 자주 오기에는 가격 부담이 있어요. 조금만 더 합리적이면 좋겠어요.', ai_reply: '', reply_status: 'pending', is_selected: false },
  { id: 'rv-18', nickname: '짧은리뷰1', rating: 5, date: '2024-03-18', platform: '구글', content: '맛있어요!', ai_reply: '', reply_status: 'pending', is_selected: false },
  { id: 'rv-19', nickname: '짧은리뷰2', rating: 1, date: '2024-03-19', platform: '카카오', content: '별로예요 다시는 안 올 것 같아요.', ai_reply: '', reply_status: 'pending', is_selected: false },
  { id: 'rv-20', nickname: '짧은리뷰3', rating: 3, date: '2024-03-20', platform: '네이버', content: '그냥 무난했어요.', ai_reply: '', reply_status: 'pending', is_selected: false },
]

export const useReviewStore = create<ReviewState>()(
  persist(
    (set) => ({
      reviews: SAMPLE_REVIEWS,
      reviewSettings: { defaultTone: 'formal' },
      keywordCache: null,

      addReviews: (newReviews) =>
        set((state) => ({
          keywordCache: null, // 새 리뷰 추가 시 키워드 캐시 무효화
          reviews: [
            ...state.reviews,
            ...newReviews.map((r, i) => ({
              ...r,
              id: `rv-import-${Date.now()}-${i}`,
              ai_reply: '',
              reply_status: 'pending' as const,
              is_selected: false,
            })),
          ],
        })),

      updateReview: (id, updates) =>
        set((state) => ({
          reviews: state.reviews.map((r) => (r.id === id ? { ...r, ...updates } : r)),
        })),

      deleteReview: (id) =>
        set((state) => ({ reviews: state.reviews.filter((r) => r.id !== id) })),

      setReply: (id, reply) =>
        set((state) => ({
          reviews: state.reviews.map((r) =>
            r.id === id ? { ...r, ai_reply: reply, reply_status: 'generated' } : r
          ),
        })),

      toggleSelect: (id) =>
        set((state) => ({
          reviews: state.reviews.map((r) => (r.id === id ? { ...r, is_selected: !r.is_selected } : r)),
        })),

      selectAll: (selected) =>
        set((state) => ({
          reviews: state.reviews.map((r) => ({ ...r, is_selected: selected })),
        })),

      clearReviews: () => set({ reviews: [] }),

      updateReviewSettings: (settings) =>
        set((state) => ({
          reviewSettings: { ...state.reviewSettings, ...settings },
        })),

      setKeywordCache: (cache) => set({ keywordCache: cache }),
    }),
    { name: 'cafe-brain-reviews' }
  )
)
