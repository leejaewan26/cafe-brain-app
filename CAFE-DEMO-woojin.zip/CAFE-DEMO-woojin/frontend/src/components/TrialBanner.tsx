// 체험 기간 배너 (Day 4-3)
// /ultrareview U06·U26 해결: 앱 내 "업그레이드 진입점" 제공
// Dashboard 최상단에 조건부 노출 (trial 상태일 때만)
import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { Zap, X } from 'lucide-react'
import { useAuth } from '@/hooks/useAuth'
import { track } from '@/lib/analytics'

interface SubscriptionStatus {
  status: 'trial' | 'active' | 'past_due' | 'canceled' | 'none'
  days_remaining: number
  can_upgrade: boolean
}

const DISMISS_KEY = 'cb_trial_banner_dismissed_at'

// 초기값을 localStorage에서 계산 (lazy initializer — effect에서 setState 회피)
function isInitiallyDismissed(): boolean {
  if (typeof window === 'undefined') return false
  const raw = localStorage.getItem(DISMISS_KEY)
  if (!raw) return false
  const dismissedAt = Number(raw)
  return Date.now() - dismissedAt < 24 * 60 * 60 * 1000
}

export default function TrialBanner() {
  const { user } = useAuth()
  const [sub, setSub] = useState<SubscriptionStatus | null>(null)
  const [dismissed, setDismissed] = useState<boolean>(isInitiallyDismissed)

  useEffect(() => {
    // 사용자 정보 없거나 이미 숨김 상태면 API 호출 스킵
    if (dismissed || !user?.id) return
    void (async () => {
      try {
        const res = await fetch(`/api/v1/billing/subscription/${user.id}`)
        if (res.ok) setSub(await res.json())
      } catch { /* 조용히 실패 */ }
    })()
  }, [user?.id, dismissed])

  const handleDismiss = () => {
    localStorage.setItem(DISMISS_KEY, String(Date.now()))
    setDismissed(true)
  }

  if (dismissed || !sub) return null
  if (sub.status !== 'trial' && sub.status !== 'none') return null

  const urgent = sub.status === 'trial' && sub.days_remaining <= 2
  const title = sub.status === 'trial'
    ? (urgent ? `⏰ 체험 기간 ${sub.days_remaining}일 남음` : `🎁 체험 기간 ${sub.days_remaining}일 남음`)
    : '🌱 시작해보세요'
  const desc = sub.status === 'trial'
    ? '지금 업그레이드하면 끊김 없이 이어서 사용할 수 있어요.'
    : '7일 무료 체험으로 모든 기능을 열어보세요.'

  return (
    <div className={`mx-4 mt-4 rounded-2xl p-4 flex items-center gap-3 border-2 ${
      urgent
        ? 'bg-red-50 border-red-400 dark:bg-red-900/20'
        : 'bg-gradient-to-r from-[#D4A574]/15 to-[#D4A574]/5 border-[#D4A574]'
    }`}>
      <div className={`shrink-0 w-10 h-10 rounded-xl flex items-center justify-center ${
        urgent ? 'bg-red-100 dark:bg-red-900/40' : 'bg-[#D4A574]/20'
      }`}>
        <Zap className={`w-5 h-5 ${urgent ? 'text-red-600' : 'text-[#D4A574]'}`} />
      </div>

      <div className="flex-1 min-w-0">
        <p className="font-bold text-[#2C1810] dark:text-gray-100 text-sm">{title}</p>
        <p className="text-xs text-gray-600 dark:text-gray-300 mt-0.5 truncate">{desc}</p>
      </div>

      <Link
        to="/billing"
        onClick={() => track('trial_banner_click', {
          status: sub.status,
          days_remaining: sub.days_remaining,
          urgent,
        })}
        className={`shrink-0 px-4 py-2 rounded-xl text-xs font-bold shadow-sm transition-all focus:outline-none focus-visible:ring-2 focus-visible:ring-[#D4A574] focus-visible:ring-offset-1 ${
          urgent
            ? 'bg-red-600 text-white hover:bg-red-700'
            : 'bg-[#2C1810] text-white hover:bg-[#3d2418]'
        }`}
      >
        {sub.status === 'trial' ? '지금 업그레이드' : '7일 체험 시작'}
      </Link>

      <button
        onClick={handleDismiss}
        className="shrink-0 p-1 text-gray-400 hover:text-gray-600 dark:hover:text-gray-200 focus:outline-none focus-visible:ring-2 focus-visible:ring-[#D4A574] rounded"
        aria-label="배너 숨기기 (24시간)"
      >
        <X size={16} />
      </button>
    </div>
  )
}
