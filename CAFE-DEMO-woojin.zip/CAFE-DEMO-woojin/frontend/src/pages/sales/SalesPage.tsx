// 매출·운영 분석 모듈 메인 페이지 - 탭 기반 레이아웃
import { useState, useRef, useMemo, useCallback } from 'react'
import { Link } from 'react-router-dom'
import {
  BarChart2, Upload, PenLine, TrendingUp, Calculator, Sparkles,
  ChevronLeft, Trash2, Plus, Loader2, AlertCircle, CheckCircle2,
} from 'lucide-react'
import {
  ScatterChart, Scatter, XAxis, YAxis, ZAxis, CartesianGrid, Tooltip as RechartsTooltip,
  ResponsiveContainer, LineChart, Line, Legend, Cell,
} from 'recharts'
import { useSalesStore } from '@/store/salesStore'
import { useStoreContext } from '@/hooks/useStoreContext'
import { useAuthStore } from '@/store/authStore'
import type { SalesRecord, MenuAggregate, BepInput, PriceSimResult } from '@/types/sales'
import { cn, formatCurrency } from '@/lib/utils'
import AiFeedback from '@/components/AiFeedback'
import { BepFloatingPopup } from '@/components/BepGauge'
import ReceiptUploader from '@/components/ReceiptUploader'
import ExportMenu from '@/components/ExportMenu'
import SalesForecast from './SalesForecast'

// Wave 5C: 매출 업로드 후 학습 훅 트리거
async function triggerSalesLearning(storeId: string) {
  try {
    await fetch('/api/v1/learning/after-sales-upload', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'X-Store-Id': storeId },
      body: JSON.stringify({ store_id: storeId }),
    })
    // 프로필 증류도 nudge (충분한 메모리 쌓이면 자동 실행)
    void fetch('/api/v1/learning/nudge-profile', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'X-Store-Id': storeId },
      body: JSON.stringify({ store_id: storeId }),
    })
  } catch {
    // 학습 실패는 사용자 주 플로우 방해 X
  }
}

// ─── 현지화 ───
const DAY_NAMES = ['일', '월', '화', '수', '목', '금', '토']

// ─── 유틸: ISO 날짜 → 요일 번호 ───
function getDayOfWeek(dateStr: string): number {
  return new Date(dateStr).getDay()
}

// ─── CSV 파서 ───
function parseCSVText(text: string): { headers: string[]; rows: Record<string, string>[] } {
  const lines = text.split('\n').filter((l) => l.trim())
  const headers = lines[0].split(',').map((h) => h.trim().replace(/"/g, ''))
  const rows = lines.slice(1).map((line) => {
    const values = line.split(',').map((v) => v.trim().replace(/"/g, ''))
    return Object.fromEntries(headers.map((h, i) => [h, values[i] ?? '']))
  })
  return { headers, rows }
}

// ─── 메뉴별 집계 ───
function aggregateByMenu(records: SalesRecord[]): MenuAggregate[] {
  const map = new Map<string, MenuAggregate>()
  for (const r of records) {
    const prev = map.get(r.menu_name) ?? {
      menu_name: r.menu_name, total_qty: 0, total_revenue: 0, total_cost: 0, margin_rate: 0,
    }
    prev.total_qty += r.quantity
    prev.total_revenue += r.revenue
    prev.total_cost += r.cost
    map.set(r.menu_name, prev)
  }
  return Array.from(map.values()).map((m) => ({
    ...m,
    margin_rate: m.total_revenue > 0
      ? Math.round(((m.total_revenue - m.total_cost) / m.total_revenue) * 100)
      : 0,
  }))
}

// ═══════════════════════════════════════════
// ─── Section 1: CSV 업로드 컴포넌트 ───
// ═══════════════════════════════════════════
function CsvUploadSection({ onImport }: { onImport: (records: SalesRecord[]) => void }) {
  const fileRef = useRef<HTMLInputElement>(null)
  const [csvHeaders, setCsvHeaders] = useState<string[]>([])
  const [csvRows, setCsvRows] = useState<Record<string, string>[]>([])
  const [mapping, setMapping] = useState<Record<string, string>>({})
  const [step, setStep] = useState<'idle' | 'mapping' | 'preview'>('idle')
  const [error, setError] = useState('')

  // 토스 포스 기본 헤더 매핑
  const requiredFields: { key: string; label: string; required: boolean }[] = [
    { key: 'sale_date', label: '날짜 *', required: true },
    { key: 'menu_name', label: '메뉴명 *', required: true },
    { key: 'quantity', label: '수량 *', required: true },
    { key: 'revenue', label: '매출액 *', required: true },
    { key: 'cost', label: '원가', required: false },
    { key: 'discount', label: '할인액', required: false },
    { key: 'hour_slot', label: '시간대(0-23)', required: false },
  ]

  // 자동 매핑 (헤더 유사도)
  const autoMapping: Record<string, string> = {
    날짜: 'sale_date', 일자: 'sale_date', date: 'sale_date',
    메뉴명: 'menu_name', 메뉴: 'menu_name', 상품명: 'menu_name', menu: 'menu_name',
    수량: 'quantity', qty: 'quantity',
    매출: 'revenue', 금액: 'revenue', 매출액: 'revenue',
    원가: 'cost', cost: 'cost',
    할인: 'discount', 할인액: 'discount',
    시간대: 'hour_slot', 시간: 'hour_slot', hour: 'hour_slot',
  }

  const handleFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return
    setError('')
    const reader = new FileReader()
    reader.onload = (ev) => {
      try {
        const text = ev.target?.result as string
        const { headers, rows } = parseCSVText(text)
        setCsvHeaders(headers)
        setCsvRows(rows)
        // 자동 매핑 시도
        const auto: Record<string, string> = {}
        headers.forEach((h) => {
          const key = autoMapping[h] ?? autoMapping[h.toLowerCase()]
          if (key) auto[key] = h
        })
        setMapping(auto)
        setStep('mapping')
      } catch {
        setError('CSV 파일 파싱 중 오류가 발생했습니다.')
      }
    }
    reader.readAsText(file, 'utf-8')
  }

  const handleImport = () => {
    const required = ['sale_date', 'menu_name', 'quantity', 'revenue']
    const missing = required.filter((r) => !mapping[r])
    if (missing.length > 0) {
      setError(`필수 컬럼 매핑이 필요합니다: ${missing.join(', ')}`)
      return
    }
    const records: SalesRecord[] = csvRows
      .filter((row) => row[mapping.sale_date])
      .map((row, i) => {
        const dateStr = row[mapping.sale_date] || ''
        return {
          id: `csv-${Date.now()}-${i}`,
          sale_date: dateStr,
          hour_slot: parseInt(row[mapping.hour_slot] || '9') || 9,
          day_of_week: getDayOfWeek(dateStr),
          menu_name: row[mapping.menu_name] || '',
          quantity: parseInt(row[mapping.quantity] || '1') || 1,
          revenue: parseFloat(row[mapping.revenue] || '0') || 0,
          cost: parseFloat(row[mapping.cost] || '0') || 0,
          discount: parseFloat(row[mapping.discount] || '0') || 0,
        }
      })
    onImport(records)
    setStep('idle')
    setCsvHeaders([])
    setCsvRows([])
    setMapping({})
    if (fileRef.current) fileRef.current.value = ''
  }

  return (
    <div className="bg-white rounded-2xl p-6 border border-gray-100 shadow-sm">
      <h3 className="font-bold text-[#2C1810] mb-4 flex items-center gap-2">
        <Upload size={18} className="text-[#D4A574]" />
        CSV/엑셀 업로드
      </h3>

      {step === 'idle' && (
        <div
          onClick={() => fileRef.current?.click()}
          className="border-2 border-dashed border-[#D4A574]/40 rounded-xl p-8 text-center cursor-pointer hover:border-[#D4A574] hover:bg-[#D4A574]/5 transition-all duration-200"
        >
          <Upload className="w-8 h-8 text-[#D4A574] mx-auto mb-2" />
          <p className="text-sm font-medium text-[#2C1810]">CSV 파일을 클릭하여 업로드</p>
          <p className="text-xs text-gray-400 mt-1">토스 포스 내보내기 형식 기본 지원</p>
          <input ref={fileRef} type="file" accept=".csv,.txt" className="hidden" onChange={handleFile} />
        </div>
      )}

      {step === 'mapping' && (
        <div className="space-y-4">
          <p className="text-sm text-gray-600">CSV 컬럼을 필드에 매핑해주세요:</p>
          <div className="grid grid-cols-2 gap-3">
            {requiredFields.map((field) => (
              <div key={field.key}>
                <label className="block text-xs font-medium text-gray-600 mb-1">{field.label}</label>
                <select
                  value={mapping[field.key] ?? ''}
                  onChange={(e) => setMapping({ ...mapping, [field.key]: e.target.value })}
                  className="w-full px-3 py-1.5 rounded-lg border border-gray-200 text-sm focus:outline-none focus:ring-2 focus:ring-[#D4A574]"
                >
                  <option value="">-- 선택 --</option>
                  {csvHeaders.map((h) => (
                    <option key={h} value={h}>{h}</option>
                  ))}
                </select>
              </div>
            ))}
          </div>
          {/* 미리보기 */}
          <div className="overflow-x-auto rounded-lg border border-gray-200">
            <table className="text-xs w-full">
              <thead className="bg-gray-50">
                <tr>
                  {csvHeaders.map((h) => (
                    <th key={h} className="px-3 py-2 text-left text-gray-600 font-medium">{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {csvRows.slice(0, 3).map((row, i) => (
                  <tr key={i} className="border-t border-gray-100">
                    {csvHeaders.map((h) => (
                      <td key={h} className="px-3 py-1.5 text-gray-700">{row[h]}</td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          {error && <p className="text-red-500 text-xs">{error}</p>}
          <div className="flex gap-2">
            <button onClick={() => setStep('idle')} className="px-4 py-2 rounded-xl border border-gray-200 text-sm text-gray-600 hover:bg-gray-50 transition-colors duration-200">
              취소
            </button>
            <button onClick={handleImport} className="flex-1 py-2 rounded-xl bg-[#2C1810] text-white text-sm font-semibold hover:bg-[#3d2418] transition-colors duration-200">
              {csvRows.length}행 가져오기
            </button>
          </div>
        </div>
      )}
    </div>
  )
}

// ═══════════════════════════════════════
// ─── Section 2: 수동 입력 폼 ───
// ═══════════════════════════════════════
function ManualEntrySection({ onAdd, existingMenus }: {
  onAdd: (rec: SalesRecord) => void
  existingMenus: string[]
}) {
  const [form, setForm] = useState({
    sale_date: new Date().toISOString().split('T')[0],
    menu_name: '',
    quantity: 1,
    revenue: 0,
    cost: 0,
    hour_slot: 9,
    discount: 0,
  })
  const [success, setSuccess] = useState(false)

  const handleAdd = () => {
    if (!form.menu_name || !form.sale_date) return
    const rec: SalesRecord = {
      id: `manual-${Date.now()}`,
      ...form,
      day_of_week: getDayOfWeek(form.sale_date),
    }
    onAdd(rec)
    setForm({ ...form, menu_name: '', quantity: 1, revenue: 0, cost: 0 })
    setSuccess(true)
    setTimeout(() => setSuccess(false), 2000)
  }

  return (
    <div className="bg-white rounded-2xl p-6 border border-gray-100 shadow-sm">
      <h3 className="font-bold text-[#2C1810] mb-4 flex items-center gap-2">
        <PenLine size={18} className="text-[#D4A574]" />
        수동 입력
      </h3>
      <div className="grid grid-cols-2 gap-3">
        <div className="col-span-2">
          <label className="block text-xs font-medium text-gray-600 mb-1">날짜</label>
          <input type="date" value={form.sale_date} onChange={(e) => setForm({ ...form, sale_date: e.target.value })}
            className="w-full px-3 py-2 rounded-xl border border-gray-200 text-sm focus:outline-none focus:ring-2 focus:ring-[#D4A574]" />
        </div>
        <div className="col-span-2">
          <label className="block text-xs font-medium text-gray-600 mb-1">메뉴명</label>
          <input list="menu-list" value={form.menu_name} onChange={(e) => setForm({ ...form, menu_name: e.target.value })}
            placeholder="메뉴명 입력"
            className="w-full px-3 py-2 rounded-xl border border-gray-200 text-sm focus:outline-none focus:ring-2 focus:ring-[#D4A574]" />
          <datalist id="menu-list">
            {existingMenus.map((m) => <option key={m} value={m} />)}
          </datalist>
        </div>
        {[
          { label: '수량', key: 'quantity', type: 'number' },
          { label: '매출액(원)', key: 'revenue', type: 'number' },
          { label: '원가(원)', key: 'cost', type: 'number' },
          { label: '시간대(0-23)', key: 'hour_slot', type: 'number' },
        ].map(({ label, key, type }) => (
          <div key={key}>
            <label className="block text-xs font-medium text-gray-600 mb-1">{label}</label>
            <input type={type} value={(form as Record<string, unknown>)[key] as number}
              onChange={(e) => setForm({ ...form, [key]: parseFloat(e.target.value) || 0 })}
              className="w-full px-3 py-2 rounded-xl border border-gray-200 text-sm focus:outline-none focus:ring-2 focus:ring-[#D4A574]" />
          </div>
        ))}
      </div>
      <button onClick={handleAdd}
        className="w-full mt-4 py-2.5 rounded-xl bg-[#D4A574] text-white text-sm font-semibold hover:bg-[#c4956a] transition-colors duration-200 flex items-center justify-center gap-2">
        <Plus size={16} />
        데이터 추가
      </button>
      {success && (
        <p className="text-green-600 text-xs text-center mt-2 flex items-center justify-center gap-1">
          <CheckCircle2 size={12} /> 추가되었습니다
        </p>
      )}
    </div>
  )
}

// ═══════════════════════════════════════
// ─── Section 3: 4사분면 차트 ───
// ═══════════════════════════════════════
const QUADRANT_COLORS: Record<string, string> = {
  'Star (고마진·고판매)': '#22c55e',
  'Cash Cow (저마진·고판매)': '#3b82f6',
  'Question (고마진·저판매)': '#f59e0b',
  'Dog (저마진·저판매)': '#ef4444',
}

// 차트 팔레트 (Wave 5E 다크모드)
import { useChartColors, tooltipStyle } from '@/lib/chartTheme'

function QuadrantChartSection({ menus }: { menus: MenuAggregate[] }) {
  const chart = useChartColors()
  const medianQty = useMemo(() => {
    if (!menus.length) return 0
    const sorted = [...menus].sort((a, b) => a.total_qty - b.total_qty)
    return sorted[Math.floor(sorted.length / 2)].total_qty
  }, [menus])

  const medianMargin = useMemo(() => {
    if (!menus.length) return 0
    const sorted = [...menus].sort((a, b) => a.margin_rate - b.margin_rate)
    return sorted[Math.floor(sorted.length / 2)].margin_rate
  }, [menus])

  const data = menus.map((m) => {
    const isHighQty = m.total_qty >= medianQty
    const isHighMargin = m.margin_rate >= medianMargin
    const quadrant = isHighMargin && isHighQty ? 'Star (고마진·고판매)'
      : !isHighMargin && isHighQty ? 'Cash Cow (저마진·고판매)'
      : isHighMargin ? 'Question (고마진·저판매)'
      : 'Dog (저마진·저판매)'
    return { x: m.total_qty, y: m.margin_rate, z: m.total_revenue, name: m.menu_name, quadrant }
  })

  return (
    <div className="bg-white rounded-2xl p-6 border border-gray-100 shadow-sm">
      <h3 className="font-bold text-[#2C1810] mb-1 flex items-center gap-2">
        <BarChart2 size={18} className="text-[#D4A574]" />
        메뉴 4사분면 매트릭스
      </h3>
      <p className="text-xs text-gray-400 mb-4">X: 판매량 | Y: 마진율(%) | 크기: 매출액</p>
      {data.length === 0 ? (
        <EmptyPlaceholder />
      ) : (
        <>
          <ResponsiveContainer width="100%" height={280}>
            <ScatterChart margin={{ top: 10, right: 20, bottom: 10, left: 10 }}>
              <CartesianGrid strokeDasharray="3 3" stroke={chart.grid} />
              <XAxis type="number" dataKey="x" name="판매량" tick={{ fill: chart.tick, fontSize: 11 }} label={{ value: '판매량(잔)', position: 'bottom', offset: -5, style: { fontSize: 11, fill: chart.text } }} />
              <YAxis type="number" dataKey="y" name="마진율" domain={[0, 100]} tick={{ fill: chart.tick, fontSize: 11 }} label={{ value: '마진율(%)', angle: -90, position: 'insideLeft', style: { fontSize: 11, fill: chart.text } }} />
              <ZAxis type="number" dataKey="z" range={[60, 400]} name="매출액" />
              <RechartsTooltip cursor={{ strokeDasharray: '3 3' }}
                content={({ payload }) => {
                  if (!payload?.length) return null
                  const d = payload[0].payload
                  return (
                    <div style={tooltipStyle(chart)} className="rounded-xl shadow-lg">
                      <p className="font-bold mb-1" style={{ color: chart.primary }}>{d.name}</p>
                      <p>판매량: {d.x}잔</p>
                      <p>마진율: {d.y}%</p>
                      <p>매출: {formatCurrency(d.z)}</p>
                      <p className="mt-1" style={{ color: chart.muted }}>{d.quadrant}</p>
                    </div>
                  )
                }}
              />
              <Scatter data={data} name="메뉴">
                {data.map((entry, index) => (
                  <Cell key={index} fill={QUADRANT_COLORS[entry.quadrant] ?? '#8884d8'} fillOpacity={0.8} />
                ))}
              </Scatter>
            </ScatterChart>
          </ResponsiveContainer>
          {/* 범례 */}
          <div className="flex flex-wrap gap-2 mt-2">
            {Object.entries(QUADRANT_COLORS).map(([label, color]) => (
              <div key={label} className="flex items-center gap-1 text-xs text-gray-600">
                <div className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: color }} />
                {label}
              </div>
            ))}
          </div>
        </>
      )}
    </div>
  )
}

// ═══════════════════════════════════════
// ─── Section 4: 히트맵 ───
// ═══════════════════════════════════════
function HeatmapSection({ records }: { records: SalesRecord[] }) {
  const HOURS = Array.from({ length: 16 }, (_, i) => i + 7) // 7~22시

  const heatData = useMemo(() => {
    const grid: Record<string, number> = {}
    let max = 0
    for (const r of records) {
      const key = `${r.day_of_week}-${r.hour_slot}`
      grid[key] = (grid[key] ?? 0) + r.revenue
      if (grid[key] > max) max = grid[key]
    }
    return { grid, max }
  }, [records])

  const getColor = (val: number) => {
    if (!heatData.max) return '#f3f4f6'
    const ratio = val / heatData.max
    if (ratio > 0.75) return '#2C1810'
    if (ratio > 0.5) return '#6b3d2a'
    if (ratio > 0.25) return '#D4A574'
    if (ratio > 0) return '#f0d9c0'
    return '#f9f9f9'
  }

  return (
    <div className="bg-white rounded-2xl p-6 border border-gray-100 shadow-sm">
      <h3 className="font-bold text-[#2C1810] mb-1 flex items-center gap-2">
        <TrendingUp size={18} className="text-[#D4A574]" />
        시간대·요일별 매출 히트맵
      </h3>
      <p className="text-xs text-gray-400 mb-4">색이 진할수록 매출 높음</p>
      {records.length === 0 ? <EmptyPlaceholder /> : (
        <div className="overflow-x-auto">
          <table className="text-xs border-collapse w-full">
            <thead>
              <tr>
                <th className="w-10 text-gray-400 font-normal pb-1" />
                {DAY_NAMES.map((d) => (
                  <th key={d} className="text-center text-gray-500 font-medium pb-1 w-10">{d}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {HOURS.map((h) => (
                <tr key={h}>
                  <td className="text-right pr-2 text-gray-400 font-normal py-0.5">{h}시</td>
                  {Array.from({ length: 7 }, (_, day) => {
                    const val = heatData.grid[`${day}-${h}`] ?? 0
                    return (
                      <td key={day} className="p-0.5">
                        <div
                          className="w-8 h-6 rounded text-center leading-6 text-[10px] font-medium"
                          style={{ backgroundColor: getColor(val), color: val / heatData.max > 0.5 ? '#fff' : '#666' }}
                          title={`${DAY_NAMES[day]}요일 ${h}시: ${formatCurrency(val)}`}
                        >
                          {val > 0 ? Math.round(val / 1000) + 'k' : ''}
                        </div>
                      </td>
                    )
                  })}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  )
}

// ═══════════════════════════════════════
// ─── Section 5: 월별 매출 추이 ───
// ═══════════════════════════════════════
function MonthlyChartSection({ records }: { records: SalesRecord[] }) {
  const chart = useChartColors()
  const monthlyData = useMemo(() => {
    const map = new Map<string, { revenue: number; cost: number }>()
    for (const r of records) {
      const month = r.sale_date.slice(0, 7)
      const prev = map.get(month) ?? { revenue: 0, cost: 0 }
      prev.revenue += r.revenue
      prev.cost += r.cost
      map.set(month, prev)
    }
    return Array.from(map.entries())
      .sort(([a], [b]) => a.localeCompare(b))
      .map(([month, v]) => ({ month, ...v, profit: v.revenue - v.cost }))
  }, [records])

  return (
    <div className="bg-white rounded-2xl p-6 border border-gray-100 shadow-sm">
      <h3 className="font-bold text-[#2C1810] mb-4 flex items-center gap-2">
        <TrendingUp size={18} className="text-[#D4A574]" />
        월별 매출 추이
      </h3>
      {monthlyData.length === 0 ? <EmptyPlaceholder /> : (
        <ResponsiveContainer width="100%" height={240}>
          <LineChart data={monthlyData} margin={{ top: 10, right: 20, left: 0, bottom: 25 }}>
            <CartesianGrid strokeDasharray="3 3" stroke={chart.grid} vertical={false} />
            <XAxis
              dataKey="month"
              tick={{ fontSize: 10, fill: chart.tick }}
              interval="preserveStartEnd"
              minTickGap={30}
              tickFormatter={(v) => v.slice(2).replace('-', '/')}
              tickLine={false}
              axisLine={{ stroke: chart.grid }}
            />
            <YAxis
              tick={{ fontSize: 10, fill: chart.tick }}
              tickFormatter={(v) => `${(v / 10000).toFixed(0)}만`}
              width={50}
              tickLine={false}
              axisLine={false}
            />
            <RechartsTooltip formatter={(v: unknown) => formatCurrency(Number(v))} contentStyle={tooltipStyle(chart)} />
            <Legend wrapperStyle={{ color: chart.text, fontSize: 11, paddingTop: 8 }} iconType="circle" />
            <Line type="monotone" dataKey="revenue" stroke={chart.primary} strokeWidth={2} dot={{ fill: chart.primary, r: 3 }} activeDot={{ r: 5 }} name="매출" />
            <Line type="monotone" dataKey="profit" stroke={chart.accent} strokeWidth={2} dot={{ fill: chart.accent, r: 3 }} activeDot={{ r: 5 }} name="순이익" strokeDasharray="5 5" />
          </LineChart>
        </ResponsiveContainer>
      )}
    </div>
  )
}

// ═══════════════════════════════════════
// ─── Section 6: BEP 계산기 ───
// ═══════════════════════════════════════
function BepCalculatorSection() {
  const [input, setInput] = useState<BepInput>({
    monthly_fixed_cost: 3000000,
    avg_price: 5000,
    avg_cost: 1500,
  })

  const result = useMemo(() => {
    const margin = input.avg_price - input.avg_cost
    if (margin <= 0) return null
    const monthly = Math.ceil(input.monthly_fixed_cost / margin)
    const daily = Math.ceil(monthly / 30)
    return { monthly, daily, margin_per_cup: margin }
  }, [input])

  return (
    <div className="bg-white rounded-2xl p-6 border border-gray-100 shadow-sm">
      <h3 className="font-bold text-[#2C1810] mb-4 flex items-center gap-2">
        <Calculator size={18} className="text-[#D4A574]" />
        손익분기점(BEP) 계산기
      </h3>
      <div className="space-y-3">
        {[
          { label: '월 고정비 (임대료+인건비+관리비)', key: 'monthly_fixed_cost', unit: '원' },
          { label: '주력 메뉴 평균 판매가', key: 'avg_price', unit: '원' },
          { label: '주력 메뉴 평균 원가', key: 'avg_cost', unit: '원' },
        ].map(({ label, key, unit }) => (
          <div key={key}>
            <label className="block text-xs font-medium text-gray-600 mb-1">{label}</label>
            <div className="flex items-center gap-2">
              <input
                type="number"
                value={(input as unknown as Record<string, number>)[key]}
                onChange={(e) => setInput({ ...input, [key]: parseFloat(e.target.value) || 0 })}
                className="flex-1 px-3 py-2 rounded-xl border border-gray-200 text-sm focus:outline-none focus:ring-2 focus:ring-[#D4A574]"
              />
              <span className="text-sm text-gray-500">{unit}</span>
            </div>
          </div>
        ))}
      </div>
      {result ? (
        <div className="mt-4 bg-[#2C1810] rounded-xl p-4 text-white">
          <p className="text-xs text-[#D4A574] mb-2">❖ 손익분기점</p>
          <div className="grid grid-cols-2 gap-3 text-center">
            <div className="bg-white/10 rounded-lg p-3">
              <p className="text-2xl font-bold">{result.daily.toLocaleString()}</p>
              <p className="text-xs text-[#D4A574] mt-0.5">일 목표 판매량(잔)</p>
            </div>
            <div className="bg-white/10 rounded-lg p-3">
              <p className="text-2xl font-bold">{result.monthly.toLocaleString()}</p>
              <p className="text-xs text-[#D4A574] mt-0.5">월 목표 판매량(잔)</p>
            </div>
          </div>
          <p className="text-xs text-white/60 mt-2 text-center">
            잔당 마진 {formatCurrency(result.margin_per_cup)}
          </p>
        </div>
      ) : (
        <div className="mt-4 p-3 bg-red-50 rounded-xl text-red-600 text-xs">
          판매가가 원가보다 높아야 합니다.
        </div>
      )}
    </div>
  )
}

// ═══════════════════════════════════════
// ─── Section 7: 가격 시뮬레이션 ───
// ═══════════════════════════════════════
function PriceSimulationSection({ menus }: { menus: MenuAggregate[] }) {
  const [increaseRate, setIncreaseRate] = useState(10)
  const [targetMargin, setTargetMargin] = useState(65)

  const results: PriceSimResult[] = useMemo(() => {
    return menus.map((m) => {
      const avgCost = m.total_cost / m.total_qty
      const avgPrice = m.total_revenue / m.total_qty
      const newCost = avgCost * (1 + increaseRate / 100)
      const minPrice = newCost / (1 - targetMargin / 100)
      return {
        menu_name: m.menu_name,
        current_cost: Math.round(avgCost),
        new_cost: Math.round(newCost),
        current_price: Math.round(avgPrice),
        min_price: Math.round(minPrice),
        price_diff: Math.round(minPrice - avgPrice),
      }
    })
  }, [menus, increaseRate, targetMargin])

  return (
    <div className="bg-white rounded-2xl p-6 border border-gray-100 shadow-sm">
      <h3 className="font-bold text-[#2C1810] mb-4 flex items-center gap-2">
        <TrendingUp size={18} className="text-[#D4A574]" />
        가격 인상 시뮬레이션
      </h3>
      <div className="flex gap-4 mb-4">
        <div className="flex-1">
          <label className="block text-xs font-medium text-gray-600 mb-1">원재료 인상률 (%)</label>
          <input type="number" value={increaseRate} onChange={(e) => setIncreaseRate(parseFloat(e.target.value) || 0)}
            className="w-full px-3 py-2 rounded-xl border border-gray-200 text-sm focus:outline-none focus:ring-2 focus:ring-[#D4A574]" />
        </div>
        <div className="flex-1">
          <label className="block text-xs font-medium text-gray-600 mb-1">목표 마진율 (%)</label>
          <input type="number" value={targetMargin} onChange={(e) => setTargetMargin(parseFloat(e.target.value) || 0)}
            className="w-full px-3 py-2 rounded-xl border border-gray-200 text-sm focus:outline-none focus:ring-2 focus:ring-[#D4A574]" />
        </div>
      </div>
      {results.length === 0 ? <EmptyPlaceholder /> : (
        <div className="overflow-x-auto">
          <table className="text-xs w-full border-collapse">
            <thead>
              <tr className="border-b border-gray-200">
                {['메뉴', '현재원가', '새원가', '현재가', '최소가', '인상필요'].map((h) => (
                  <th key={h} className="py-2 px-2 text-left text-gray-500 font-medium">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {results.map((r) => (
                <tr key={r.menu_name} className="border-b border-gray-50 hover:bg-gray-50">
                  <td className="py-2 px-2 font-medium text-[#2C1810]">{r.menu_name}</td>
                  <td className="py-2 px-2 text-gray-600">{r.current_cost.toLocaleString()}</td>
                  <td className="py-2 px-2 text-orange-600">{r.new_cost.toLocaleString()}</td>
                  <td className="py-2 px-2 text-gray-600">{r.current_price.toLocaleString()}</td>
                  <td className="py-2 px-2 text-[#2C1810] font-semibold">{r.min_price.toLocaleString()}</td>
                  <td className={cn('py-2 px-2 font-semibold', r.price_diff > 0 ? 'text-red-500' : 'text-green-500')}>
                    {r.price_diff > 0 ? `+${r.price_diff.toLocaleString()}` : '유지'}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  )
}

// ═══════════════════════════════════════
// ─── Section 8: 휴무일 추천 ───
// ═══════════════════════════════════════
function HolidayRecommendSection({ records }: { records: SalesRecord[] }) {
  const [laborPerDay, setLaborPerDay] = useState(150000)
  const [variableCostRatio, setVariableCostRatio] = useState(0.3)

  const dailyAnalysis = useMemo(() => {
    const map = new Map<number, { revenue: number; days: Set<string> }>()
    for (const r of records) {
      const prev = map.get(r.day_of_week) ?? { revenue: 0, days: new Set() }
      prev.revenue += r.revenue
      prev.days.add(r.sale_date)
      map.set(r.day_of_week, prev)
    }
    return Array.from({ length: 7 }, (_, day) => {
      const d = map.get(day)
      if (!d || d.days.size === 0) return { day, avg_revenue: 0, net_profit: -laborPerDay }
      const avg_revenue = d.revenue / d.days.size
      const net_profit = avg_revenue * (1 - variableCostRatio) - laborPerDay
      return { day, avg_revenue, net_profit }
    })
  }, [records, laborPerDay, variableCostRatio])

  const recommendedDay = useMemo(
    () => dailyAnalysis.reduce((min, cur) => cur.net_profit < min.net_profit ? cur : min, dailyAnalysis[0]),
    [dailyAnalysis]
  )

  return (
    <div className="bg-white rounded-2xl p-6 border border-gray-100 shadow-sm">
      <h3 className="font-bold text-[#2C1810] mb-4 flex items-center gap-2">
        <Calculator size={18} className="text-[#D4A574]" />
        최적 휴무일 추천
      </h3>
      <div className="flex gap-4 mb-4">
        <div className="flex-1">
          <label className="block text-xs font-medium text-gray-600 mb-1">일 인건비 (원)</label>
          <input type="number" value={laborPerDay} onChange={(e) => setLaborPerDay(parseFloat(e.target.value) || 0)}
            className="w-full px-3 py-2 rounded-xl border border-gray-200 text-sm focus:outline-none focus:ring-2 focus:ring-[#D4A574]" />
        </div>
        <div className="flex-1">
          <label className="block text-xs font-medium text-gray-600 mb-1">변동비율 (%)</label>
          <input type="number" value={variableCostRatio * 100} onChange={(e) => setVariableCostRatio((parseFloat(e.target.value) || 0) / 100)}
            className="w-full px-3 py-2 rounded-xl border border-gray-200 text-sm focus:outline-none focus:ring-2 focus:ring-[#D4A574]" />
        </div>
      </div>
      {records.length === 0 ? <EmptyPlaceholder /> : (
        <>
          <div className="space-y-2 mb-4">
            {dailyAnalysis.map(({ day, net_profit }) => {
              const isRec = day === recommendedDay?.day
              const maxProfit = Math.max(...dailyAnalysis.map((d) => Math.abs(d.net_profit)))
              const barWidth = maxProfit > 0 ? (Math.abs(net_profit) / maxProfit) * 100 : 0
              return (
                <div key={day} className={cn('flex items-center gap-3 rounded-xl p-2', isRec && 'bg-red-50/50 ring-1 ring-red-200')}>
                  <span className={cn('w-6 text-sm font-bold', isRec ? 'text-red-600' : 'text-gray-600')}>{DAY_NAMES[day]}</span>
                  <div className="flex-1 bg-gray-100 rounded-full h-2 overflow-hidden">
                    <div className={cn('h-2 rounded-full', net_profit >= 0 ? 'bg-[#2C1810]' : 'bg-red-300')}
                      style={{ width: `${barWidth}%` }} />
                  </div>
                  <span className={cn('text-xs font-medium w-20 text-right', net_profit >= 0 ? 'text-[#2C1810]' : 'text-red-500')}>
                    {formatCurrency(net_profit)}
                  </span>
                  {isRec && <span className="text-xs bg-red-100 text-red-600 px-2 py-0.5 rounded-full font-medium">추천</span>}
                </div>
              )
            })}
          </div>
          {recommendedDay && (
            <div className="bg-[#2C1810] rounded-xl p-4 text-white text-sm">
              <p className="font-bold text-[#D4A574] mb-1">🗓 추천 휴무일: {DAY_NAMES[recommendedDay.day]}요일</p>
              <p className="text-white/70 text-xs">순이익이 가장 낮아 영업 손실이 최소화됩니다</p>
            </div>
          )}
        </>
      )}
    </div>
  )
}

// ═══════════════════════════════════════
// ─── Section 9: AI 인사이트 ───
// ═══════════════════════════════════════
function AiInsightSection({ records, menus }: { records: SalesRecord[]; menus: MenuAggregate[] }) {
  const { buildPromptContext } = useStoreContext()
  const [insight, setInsight] = useState('')
  const [insightRef, setInsightRef] = useState('')  // 피드백 연결용 고유 참조
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState('')

  const topMenu = useMemo(
    () => menus.sort((a, b) => b.total_revenue - a.total_revenue)[0]?.menu_name ?? '없음',
    [menus]
  )

  const totalRevenue = records.reduce((s, r) => s + r.revenue, 0)
  const avgMargin = menus.length
    ? Math.round(menus.reduce((s, m) => s + m.margin_rate, 0) / menus.length)
    : 0

  const lowDay = useMemo(() => {
    const map = new Map<number, number>()
    records.forEach((r) => map.set(r.day_of_week, (map.get(r.day_of_week) ?? 0) + r.revenue))
    if (!map.size) return '데이터 없음'
    const minDay = Array.from(map.entries()).sort(([, a], [, b]) => a - b)[0][0]
    return DAY_NAMES[minDay] + '요일'
  }, [records])

  const handleGenerate = async () => {
    if (records.length === 0) {
      setError('먼저 매출 데이터를 업로드해주세요.')
      return
    }
    setIsLoading(true)
    setError('')
    setInsight('')
    try {
      const res = await fetch('/api/v1/sales/ai-insight', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          store_context: buildPromptContext(),
          stats_summary: `총 매출: ${formatCurrency(totalRevenue)}, 평균 마진율: ${avgMargin}%, 총 데이터: ${records.length}건`,
          top_menu: topMenu,
          low_day: lowDay,
        }),
      })
      if (!res.ok) throw new Error(`서버 오류: ${res.status}`)
      const data = await res.json()
      setInsight(data.insight)
      setInsightRef(`sales-insight-${Date.now()}`)
    } catch (e) {
      const msg = e instanceof Error ? e.message : '오류 발생'
      if (msg.includes('Failed to fetch') || msg.includes('Load failed')) {
        setError('백엔드 서버가 실행 중이지 않습니다.\n터미널에서 백엔드를 먼저 시작해주세요.')
      } else {
        setError(msg)
      }
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="bg-white rounded-2xl p-6 border border-gray-100 shadow-sm">
      <h3 className="font-bold text-[#2C1810] mb-2 flex items-center gap-2">
        <Sparkles size={18} className="text-[#D4A574]" />
        AI 경영 인사이트
      </h3>
      {/* 요약 수치 */}
      <div className="grid grid-cols-3 gap-3 mb-4">
        {[
          { label: '분석 데이터', value: `${records.length}건` },
          { label: '총 매출', value: `${(totalRevenue / 10000).toFixed(0)}만원` },
          { label: '평균 마진율', value: `${avgMargin}%` },
        ].map(({ label, value }) => (
          <div key={label} className="bg-[#FAFAF8] rounded-xl p-3 text-center">
            <p className="text-xs text-gray-400">{label}</p>
            <p className="text-lg font-bold text-[#2C1810]">{value}</p>
          </div>
        ))}
      </div>

      <button onClick={handleGenerate} disabled={isLoading || records.length === 0}
        className="w-full py-3 rounded-xl bg-gradient-to-r from-[#2C1810] to-[#D4A574] text-white font-semibold text-sm hover:opacity-90 transition-opacity duration-200 disabled:opacity-40 flex items-center justify-center gap-2">
        {isLoading ? <><Loader2 size={16} className="animate-spin" /> 분석 중...</> : <><Sparkles size={16} /> AI 인사이트 생성</>}
      </button>

      {error && (
        <div className="mt-3 p-3 bg-orange-50 border border-orange-100 rounded-xl">
          <p className="text-sm text-orange-700 flex items-start gap-2">
            <AlertCircle size={14} className="mt-0.5 shrink-0" />
            <span className="whitespace-pre-line">{error}</span>
          </p>
          {error.includes('백엔드') && (
            <div className="mt-2 bg-gray-800 rounded-lg p-3 text-xs text-green-400 font-mono">
              cd backend<br />
              pip install -r requirements.txt<br />
              uvicorn app.main:app --reload
            </div>
          )}
        </div>
      )}

      {insight && (
        <div className="mt-4 bg-[#FAFAF8] border border-[#D4A574]/30 rounded-xl p-4">
          <p className="text-sm text-gray-700 leading-relaxed whitespace-pre-line">{insight}</p>
          {/* AI 피드백 수집 (학습 루프) */}
          <AiFeedback sourceType="sales_insight" sourceRef={insightRef} />
        </div>
      )}
    </div>
  )
}

// ─── 빈 상태 플레이스홀더 ───
function EmptyPlaceholder() {
  return (
    <div className="flex flex-col items-center justify-center py-8 text-gray-400">
      <Upload size={28} className="mb-2 opacity-40" />
      <p className="text-sm">데이터를 먼저 업로드해주세요</p>
    </div>
  )
}

// ═══════════════════════════════════════
// ─── 메인 SalesPage ───
// ═══════════════════════════════════════
const TABS = ['📥 데이터 입력', '📊 분석 차트', '🔮 매출 예측', '🧮 BEP·시뮬레이션', '✨ AI 인사이트']

export default function SalesPage() {
  const [activeTab, setActiveTab] = useState(0)
  const { records, addRecords, clearRecords } = useSalesStore()
  const userId = useAuthStore((s) => s.user?.id)

  const menus = useMemo(() => aggregateByMenu(records), [records])
  const existingMenus = useMemo(() => [...new Set(records.map((r) => r.menu_name))], [records])

  // Wave 5C: 매출 데이터 추가 시 학습 훅 트리거 (디바운스)
  const handleAddRecords = useCallback((recs: SalesRecord[]) => {
    addRecords(recs)
    if (userId && recs.length > 0) {
      // 5초 디바운스로 연속 추가 시 1번만 호출
      setTimeout(() => void triggerSalesLearning(userId), 5000)
    }
  }, [addRecords, userId])

  return (
    <div className="min-h-screen bg-[#FAFAF8]">
      {/* 헤더 */}
      <header className="bg-[#2C1810] text-white px-4 py-3 flex items-center gap-3">
        <Link to="/dashboard" className="hover:text-[#D4A574] transition-colors duration-200">
          <ChevronLeft size={20} />
        </Link>
        <BarChart2 size={18} className="text-[#D4A574]" />
        <h1 className="font-bold text-base flex-1">매출·운영 분석</h1>
        {records.length > 0 && (
          <div className="flex items-center gap-3">
            <span className="text-xs text-[#D4A574]">{records.length}건</span>
            {/* Day 4-1: 데이터 내보내기 */}
            <ExportMenu
              rows={records as unknown as Record<string, unknown>[]}
              title="매출데이터"
              printableId="print-sales-report"
              size="sm"
            />
            <button onClick={clearRecords} className="text-white/50 hover:text-white/80 transition-colors duration-200" aria-label="모든 데이터 삭제">
              <Trash2 size={16} />
            </button>
          </div>
        )}
      </header>

      {/* 탭 네비게이션 */}
      <div className="flex overflow-x-auto scrollbar-hide bg-white border-b border-gray-100 px-2 pt-2">
        {TABS.map((tab, i) => (
          <button key={tab} onClick={() => setActiveTab(i)}
            className={cn(
              'shrink-0 px-4 py-2.5 text-sm font-medium rounded-t-lg transition-all duration-200 whitespace-nowrap',
              activeTab === i
                ? 'bg-[#2C1810] text-white'
                : 'text-gray-500 hover:text-[#2C1810] hover:bg-gray-50'
            )}>
            {tab}
          </button>
        ))}
      </div>

      {/* 탭 콘텐츠 */}
      <main className="max-w-2xl mx-auto px-4 py-6 space-y-4">
        {/* ─ Tab 0: 데이터 입력 ─ */}
        {activeTab === 0 && (
          <>
            {/* Wave 5G: 영수증 사진 OCR (CSV 모르는 사장님도 가능) */}
            <ReceiptUploader onImport={handleAddRecords} />
            <CsvUploadSection onImport={handleAddRecords} />
            <ManualEntrySection onAdd={(rec) => handleAddRecords([rec])} existingMenus={existingMenus} />
            {records.length > 0 && (
              <div className="bg-green-50 border border-green-200 rounded-xl p-3 text-sm text-green-700 flex items-center gap-2">
                <CheckCircle2 size={16} />
                {records.length}건의 매출 데이터가 로드되었습니다. 분석 차트 탭을 확인하세요.
              </div>
            )}
          </>
        )}

        {/* ─ Tab 1: 분석 차트 ─ Day 4-2: 인쇄 대상 컨테이너 */}
        {activeTab === 1 && (
          <div id="print-sales-report">
            {/* 인쇄 전용 헤더 — 화면에선 숨김 */}
            <div className="print-only mb-4">
              <h1>매출 분석 리포트</h1>
              <p style={{ fontSize: '10pt', color: '#666' }}>
                생성일: {new Date().toLocaleDateString('ko-KR')} · 총 {records.length}건
              </p>
            </div>
            <QuadrantChartSection menus={menus} />
            <HeatmapSection records={records} />
            <MonthlyChartSection records={records} />
            <div className="print-footer">카페 브레인 · cafebrain.app</div>
          </div>
        )}

        {/* ─ Tab 2: 매출 예측 (Issue #2) ─ */}
        {activeTab === 2 && <SalesForecast records={records} />}

        {/* ─ Tab 3: BEP·시뮬레이션 ─ Day 4-2: 인쇄 대상 컨테이너 */}
        {activeTab === 3 && (
          <div id="print-bep-report">
            <div className="print-only mb-4">
              <h1>BEP·손익분기점 리포트</h1>
              <p style={{ fontSize: '10pt', color: '#666' }}>
                생성일: {new Date().toLocaleDateString('ko-KR')}
              </p>
            </div>
            <BepCalculatorSection />
            <PriceSimulationSection menus={menus} />
            <HolidayRecommendSection records={records} />
            <div className="print-footer">카페 브레인 · cafebrain.app</div>
          </div>
        )}

        {/* ─ Tab 4: AI 인사이트 ─ */}
        {activeTab === 4 && (
          <AiInsightSection records={records} menus={menus} />
        )}
      </main>

      {/* BEP 플로팅 팝업 (Issue #1) */}
      <BepFloatingPopup />
    </div>
  )
}
