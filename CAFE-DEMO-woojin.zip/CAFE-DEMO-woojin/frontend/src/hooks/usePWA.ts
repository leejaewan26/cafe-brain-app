// Bonus E5+E6 — PWA 설치 프롬프트 + 오프라인 상태 훅
// - beforeinstallprompt 이벤트 캐치 → 사용자 클릭 시 promptInstall()
// - 사용자 거부 후 7일간 다시 안 띄움
// - online/offline navigator.onLine 모니터링
// - SW 등록 (one-shot, main.tsx에서 호출)
import { useCallback, useEffect, useRef, useState } from 'react'

const DISMISSED_KEY = 'cafe-brain-pwa-dismissed-until'
const DISMISS_DAYS = 7

interface BeforeInstallPromptEvent extends Event {
  prompt: () => Promise<void>
  userChoice: Promise<{ outcome: 'accepted' | 'dismissed'; platform: string }>
}

/**
 * Service Worker 등록 — 한 번만 호출 (main.tsx).
 * 환경변수 `VITE_DISABLE_SW=1` 이면 등록 스킵 (개발 편의).
 */
export async function registerServiceWorker() {
  if (typeof window === 'undefined') return
  if (!('serviceWorker' in navigator)) return
  if (import.meta.env.VITE_DISABLE_SW === '1') return

  try {
    await navigator.serviceWorker.register('/sw.js', { scope: '/' })
  } catch {
    // 등록 실패해도 앱은 정상 동작
  }
}

/**
 * 로그아웃 시 API 캐시 비우기 — 다음 사용자 데이터 누출 방지.
 */
export async function clearApiCache() {
  if (typeof window === 'undefined') return
  if (!('serviceWorker' in navigator)) return
  try {
    const reg = await navigator.serviceWorker.getRegistration()
    reg?.active?.postMessage({ type: 'CLEAR_API_CACHE' })
  } catch { /* ignore */ }
}

export function useInstallPrompt() {
  const [available, setAvailable] = useState(false)
  const [installed, setInstalled] = useState(false)
  const [dismissed, setDismissed] = useState(false)
  const eventRef = useRef<BeforeInstallPromptEvent | null>(null)

  useEffect(() => {
    if (typeof window === 'undefined') return

    // 이미 PWA 모드로 실행 중인지
    const standalone =
      window.matchMedia('(display-mode: standalone)').matches ||
      ('standalone' in window.navigator && (window.navigator as Navigator & { standalone?: boolean }).standalone === true)
    if (standalone) {
      setInstalled(true)
      return
    }

    // 사용자 사전 거부 + 7일 미경과
    const dismissedUntil = Number(localStorage.getItem(DISMISSED_KEY) || '0')
    if (dismissedUntil > Date.now()) {
      setDismissed(true)
      return
    }

    const onBeforeInstall = (e: Event) => {
      e.preventDefault()
      eventRef.current = e as BeforeInstallPromptEvent
      setAvailable(true)
    }
    const onInstalled = () => {
      setInstalled(true)
      setAvailable(false)
      eventRef.current = null
    }

    window.addEventListener('beforeinstallprompt', onBeforeInstall)
    window.addEventListener('appinstalled', onInstalled)

    return () => {
      window.removeEventListener('beforeinstallprompt', onBeforeInstall)
      window.removeEventListener('appinstalled', onInstalled)
    }
  }, [])

  const promptInstall = useCallback(async () => {
    const e = eventRef.current
    if (!e) {
      setAvailable(false)
      return
    }
    try {
      await e.prompt()
      const result = await e.userChoice
      if (result.outcome === 'dismissed') {
        const until = Date.now() + DISMISS_DAYS * 86400 * 1000
        localStorage.setItem(DISMISSED_KEY, String(until))
        setDismissed(true)
      }
    } catch { /* ignore */ }
    eventRef.current = null
    setAvailable(false)
  }, [])

  const dismiss = useCallback(() => {
    const until = Date.now() + DISMISS_DAYS * 86400 * 1000
    localStorage.setItem(DISMISSED_KEY, String(until))
    setDismissed(true)
    setAvailable(false)
  }, [])

  return { available, installed, dismissed, promptInstall, dismiss }
}

export function useOnlineStatus() {
  const [online, setOnline] = useState<boolean>(() =>
    typeof navigator === 'undefined' ? true : navigator.onLine
  )

  useEffect(() => {
    if (typeof window === 'undefined') return
    const goOnline = () => setOnline(true)
    const goOffline = () => setOnline(false)
    window.addEventListener('online', goOnline)
    window.addEventListener('offline', goOffline)
    return () => {
      window.removeEventListener('online', goOnline)
      window.removeEventListener('offline', goOffline)
    }
  }, [])

  return online
}
