// 프로필 선택 진입 화면 (Issue #5)
// 넷플릭스 스타일 프로필 선택 UX
import { useCallback, useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { Plus, Lock, Loader2 } from 'lucide-react'
import toast from 'react-hot-toast'
import { supabase } from '@/lib/supabase'
import { useAuthStore } from '@/store/authStore'
import { useProfileStore, type Profile, type ProfileRole } from '@/store/profileStore'
import { cn } from '@/lib/utils'

const AVATAR_EMOJIS = ['☕', '👨‍💼', '👩‍💼', '🧑‍🍳', '👨‍🍳', '👩‍🍳', '✨', '🌟']
const AVATAR_COLORS = ['#D4A574', '#2C1810', '#4A90A4', '#7B6CB0', '#5A9E6F', '#E07A5F']

export default function ProfileSelectPage() {
  const navigate = useNavigate()
  const user = useAuthStore((s) => s.user)
  const { profiles, setProfiles, setActiveProfile } = useProfileStore()

  const [loading, setLoading] = useState(true)
  const [showAdd, setShowAdd] = useState(false)
  const [pinPrompt, setPinPrompt] = useState<Profile | null>(null)
  const [pinInput, setPinInput] = useState('')
  const [pinError, setPinError] = useState('')

  const loadProfiles = useCallback(async () => {
    if (!user) return
    setLoading(true)
    try {
      const { data, error } = await supabase
        .from('profiles')
        .select('*')
        .eq('store_id', user.id)
        .order('created_at', { ascending: true })
      if (error) throw error
      setProfiles((data ?? []) as Profile[])
    } catch (e) {
      const msg = e instanceof Error ? e.message : '프로필 로드 실패'
      toast.error(msg)
    } finally {
      setLoading(false)
    }
  }, [user, setProfiles])

  // 초기 로드
  useEffect(() => {
    if (!user) {
      navigate('/login')
      return
    }
    void loadProfiles()
  }, [user, navigate, loadProfiles])

  const handleSelectProfile = (profile: Profile) => {
    if (profile.pin_hash) {
      // PIN 요구
      setPinPrompt(profile)
      setPinInput('')
      setPinError('')
      return
    }
    enterAsProfile(profile)
  }

  const enterAsProfile = async (profile: Profile) => {
    setActiveProfile(profile)
    try {
      await supabase
        .from('profiles')
        .update({ last_active_at: new Date().toISOString() })
        .eq('id', profile.id)
    } catch {/* 실패해도 진입은 진행 */}
    navigate('/dashboard')
  }

  const submitPin = async () => {
    if (!pinPrompt) return
    if (pinInput.length < 4) {
      setPinError('PIN은 4자리 이상입니다')
      return
    }
    // per-profile salt (프로필 id) 사용
    const hashed = await hashPin(pinInput, pinPrompt.id)
    if (hashed !== pinPrompt.pin_hash) {
      setPinError('PIN이 일치하지 않습니다')
      return
    }
    await enterAsProfile(pinPrompt)
  }

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-[#FAFAF8]">
        <Loader2 className="w-8 h-8 animate-spin text-[#D4A574]" />
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#2C1810] via-[#3d2418] to-[#2C1810] flex items-center justify-center px-4">
      <div className="max-w-2xl w-full">
        <header className="text-center mb-10">
          <h1
            className="text-3xl md:text-4xl font-normal text-white mb-3"
            style={{ fontFamily: "'Copernicus', 'Charter', serif" }}
          >
            프로필을 선택해주세요
          </h1>
          <p className="text-[#D4A574] text-sm">매장에서 누가 사용하시나요?</p>
        </header>

        <div className="grid grid-cols-2 md:grid-cols-3 gap-4 md:gap-6">
          {profiles.map((p) => (
            <ProfileCard
              key={p.id}
              profile={p}
              onSelect={() => handleSelectProfile(p)}
            />
          ))}
          {profiles.length < 3 && (
            <button
              onClick={() => setShowAdd(true)}
              className="aspect-square rounded-2xl border-2 border-dashed border-[#D4A574]/40 text-[#D4A574] hover:border-[#D4A574] hover:bg-white/5 transition-colors duration-200 flex flex-col items-center justify-center gap-2"
            >
              <Plus size={28} />
              <span className="text-sm font-medium">프로필 추가</span>
            </button>
          )}
        </div>

        {/* 로그아웃 링크 */}
        <div className="text-center mt-10">
          <button
            onClick={async () => {
              await supabase.auth.signOut()
              useAuthStore.getState().reset()
              useProfileStore.getState().reset()
              navigate('/login')
            }}
            className="text-[#D4A574]/70 text-sm hover:text-[#D4A574] transition-colors"
          >
            다른 계정으로 로그인
          </button>
        </div>
      </div>

      {/* PIN 입력 모달 */}
      {pinPrompt && (
        <div className="fixed inset-0 bg-black/60 flex items-center justify-center z-50 px-4">
          <div className="bg-white rounded-2xl p-6 max-w-sm w-full">
            <div className="flex items-center gap-3 mb-4">
              <div
                className="w-12 h-12 rounded-xl flex items-center justify-center text-2xl"
                style={{ backgroundColor: pinPrompt.avatar_color }}
              >
                {pinPrompt.avatar_emoji}
              </div>
              <div>
                <h3 className="font-bold text-[#2C1810]">{pinPrompt.name}</h3>
                <p className="text-xs text-gray-400">PIN을 입력하세요</p>
              </div>
            </div>
            <input
              type="password"
              inputMode="numeric"
              pattern="[0-9]*"
              maxLength={6}
              value={pinInput}
              onChange={(e) => setPinInput(e.target.value.replace(/\D/g, ''))}
              onKeyDown={(e) => e.key === 'Enter' && submitPin()}
              autoFocus
              className="w-full px-4 py-3 text-center text-2xl font-mono tracking-widest rounded-xl border border-gray-200 focus:outline-none focus:ring-2 focus:ring-[#D4A574]"
              placeholder="••••"
            />
            {pinError && <p className="text-red-500 text-xs mt-2">{pinError}</p>}
            <div className="flex gap-2 mt-4">
              <button
                onClick={() => setPinPrompt(null)}
                className="flex-1 py-2 border border-gray-200 rounded-xl text-sm text-gray-600 hover:bg-gray-50"
              >
                취소
              </button>
              <button
                onClick={submitPin}
                className="flex-1 py-2 bg-[#2C1810] text-white rounded-xl text-sm font-semibold hover:bg-[#3d2418]"
              >
                확인
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 프로필 추가 모달 */}
      {showAdd && (
        <AddProfileModal
          storeId={user?.id ?? ''}
          onClose={() => setShowAdd(false)}
          onCreated={async () => {
            setShowAdd(false)
            await loadProfiles()
          }}
        />
      )}
    </div>
  )
}

// ─── 프로필 카드 ───
function ProfileCard({ profile, onSelect }: { profile: Profile; onSelect: () => void }) {
  return (
    <button
      onClick={onSelect}
      className="group aspect-square rounded-2xl bg-white/5 border border-white/10 hover:border-[#D4A574] hover:bg-white/10 transition-all duration-200 flex flex-col items-center justify-center gap-2 relative overflow-hidden"
    >
      <div
        className={cn(
          'w-16 h-16 md:w-20 md:h-20 rounded-2xl flex items-center justify-center text-3xl md:text-4xl shadow-lg',
          'group-hover:scale-105 transition-transform duration-200'
        )}
        style={{ backgroundColor: profile.avatar_color }}
      >
        {profile.avatar_emoji}
      </div>
      <div className="text-center">
        <p className="text-white font-semibold text-sm md:text-base">{profile.name}</p>
        <p className="text-[#D4A574] text-xs mt-0.5">
          {profile.role === 'owner' ? '사장' : '점장·매니저'}
        </p>
      </div>
      {profile.pin_hash && (
        <Lock size={12} className="absolute top-2 right-2 text-[#D4A574]/60" />
      )}
    </button>
  )
}

// ─── 프로필 추가 모달 ───
function AddProfileModal({
  storeId,
  onClose,
  onCreated,
}: {
  storeId: string
  onClose: () => void
  onCreated: () => void
}) {
  const [name, setName] = useState('')
  const [role, setRole] = useState<ProfileRole>('manager')
  const [avatar, setAvatar] = useState(AVATAR_EMOJIS[0])
  const [color, setColor] = useState(AVATAR_COLORS[0])
  const [pin, setPin] = useState('')
  const [saving, setSaving] = useState(false)

  const handleCreate = async () => {
    if (!name.trim()) {
      toast.error('이름을 입력하세요')
      return
    }
    setSaving(true)
    try {
      // 1단계: 프로필 생성 (pin_hash 없이)
      const { data: created, error } = await supabase
        .from('profiles')
        .insert({
          store_id: storeId,
          name: name.trim(),
          role,
          avatar_emoji: avatar,
          avatar_color: color,
        })
        .select()
        .single()
      if (error) throw error

      // 2단계: PIN 설정 시 프로필 id를 salt로 해싱해 업데이트
      if (pin.length >= 4 && created) {
        const pin_hash = await hashPin(pin, created.id)
        await supabase.from('profiles').update({ pin_hash }).eq('id', created.id)
      }

      toast.success('프로필이 추가되었어요')
      onCreated()
    } catch (e) {
      const msg = e instanceof Error ? e.message : '프로필 생성 실패'
      toast.error(msg)
    } finally {
      setSaving(false)
    }
  }

  return (
    <div className="fixed inset-0 bg-black/60 flex items-center justify-center z-50 px-4">
      <div className="bg-white rounded-2xl p-6 max-w-md w-full space-y-4">
        <h3 className="font-bold text-[#2C1810] text-lg">새 프로필</h3>

        <div>
          <label className="block text-xs font-semibold text-gray-600 mb-1.5">이름</label>
          <input
            value={name}
            onChange={(e) => setName(e.target.value)}
            maxLength={20}
            className="w-full px-3 py-2 rounded-xl border border-gray-200 text-sm focus:outline-none focus:ring-2 focus:ring-[#D4A574]"
            placeholder="예) 점장님"
          />
        </div>

        <div>
          <label className="block text-xs font-semibold text-gray-600 mb-1.5">역할</label>
          <div className="grid grid-cols-2 gap-2">
            {([
              { v: 'owner', l: '사장', d: '전체 기능 접근' },
              { v: 'manager', l: '점장·매니저', d: '재무·인건비 제외' },
            ] as const).map(({ v, l, d }) => (
              <button
                key={v}
                onClick={() => setRole(v)}
                className={cn(
                  'p-3 rounded-xl border-2 text-left transition-all duration-200',
                  role === v
                    ? 'border-[#D4A574] bg-[#D4A574]/5'
                    : 'border-gray-100 hover:border-gray-200'
                )}
              >
                <p className="text-sm font-semibold text-[#2C1810]">{l}</p>
                <p className="text-xs text-gray-500 mt-0.5">{d}</p>
              </button>
            ))}
          </div>
        </div>

        <div>
          <label className="block text-xs font-semibold text-gray-600 mb-1.5">아바타</label>
          <div className="flex flex-wrap gap-1.5">
            {AVATAR_EMOJIS.map((e) => (
              <button
                key={e}
                onClick={() => setAvatar(e)}
                className={cn(
                  'w-10 h-10 rounded-xl text-xl transition-all duration-200',
                  avatar === e ? 'bg-[#D4A574]/20 ring-2 ring-[#D4A574]' : 'bg-gray-100 hover:bg-gray-200'
                )}
              >
                {e}
              </button>
            ))}
          </div>
          <div className="flex flex-wrap gap-1.5 mt-2">
            {AVATAR_COLORS.map((c) => (
              <button
                key={c}
                onClick={() => setColor(c)}
                className={cn(
                  'w-7 h-7 rounded-full transition-all duration-200',
                  color === c ? 'ring-2 ring-offset-2 ring-[#D4A574]' : ''
                )}
                style={{ backgroundColor: c }}
                aria-label={`색상 ${c}`}
              />
            ))}
          </div>
        </div>

        <div>
          <label className="block text-xs font-semibold text-gray-600 mb-1.5">
            PIN <span className="text-gray-400 font-normal">(선택사항)</span>
          </label>
          <input
            type="password"
            inputMode="numeric"
            maxLength={6}
            value={pin}
            onChange={(e) => setPin(e.target.value.replace(/\D/g, ''))}
            className="w-full px-3 py-2 rounded-xl border border-gray-200 text-sm focus:outline-none focus:ring-2 focus:ring-[#D4A574]"
            placeholder="비우면 PIN 없이 바로 진입"
          />
          <p className="text-[10px] text-gray-400 mt-1">
            💡 PIN을 설정하지 않으면 프로필 선택만으로 바로 진입합니다. 필요한 경우만 설정하세요.
          </p>
        </div>

        <div className="flex gap-2 pt-2">
          <button
            onClick={onClose}
            className="flex-1 py-2 border border-gray-200 rounded-xl text-sm text-gray-600 hover:bg-gray-50"
          >
            취소
          </button>
          <button
            onClick={handleCreate}
            disabled={saving}
            className="flex-1 py-2 bg-[#2C1810] text-white rounded-xl text-sm font-semibold hover:bg-[#3d2418] disabled:opacity-50"
          >
            {saving ? '생성 중...' : '생성'}
          </button>
        </div>
      </div>
    </div>
  )
}

// ─── PIN 해시 (Critical C1: per-user salt 강화) ───
// 각 프로필마다 고유 salt 사용해서 rainbow table 공격 완화.
// salt = profile.id (UUID, 프로필 생성 시 서버가 할당).
// 완전한 해결책은 서버 bcrypt RPC지만 Wave 3에서 마이그레이션 예정.
async function hashPin(pin: string, profileSalt: string = 'bootstrap'): Promise<string> {
  const encoder = new TextEncoder()
  // 반복 해싱(1000회)으로 brute force 비용 증가
  let data = encoder.encode(`${pin}:${profileSalt}:cafe-brain-v2`)
  for (let i = 0; i < 1000; i++) {
    const buf = await crypto.subtle.digest('SHA-256', data)
    data = new Uint8Array(buf)
  }
  return Array.from(data)
    .map((b) => b.toString(16).padStart(2, '0'))
    .join('')
}
