// AI 제안 피드백 위젯 (Issue #10 Foundation)
// 모든 AI 출력 하단에 배치 — 사용자의 반응이 학습 신호가 됨
// 사용 예:
//   <AiFeedback sourceType="sales_insight" sourceRef={`sales-${timestamp}`} />
import { useState } from 'react'
import { ThumbsUp, ThumbsDown, Sparkles, BellOff, Check } from 'lucide-react'
import { useAuthStore } from '@/store/authStore'
import { cn } from '@/lib/utils'

export type FeedbackSourceType =
  | 'sales_insight'
  | 'review_reply'
  | 'marketing_draft'
  | 'marketing_seo'
  | 'menu_recipe'
  | 'menu_recommend'
  | 'menu_manual'
  | 'chat_message'
  | 'agent_briefing'

export type FeedbackReaction = 'helpful' | 'irrelevant' | 'applied' | 'muted'

interface AiFeedbackProps {
  sourceType: FeedbackSourceType
  sourceRef: string
  compact?: boolean       // 좁은 공간용
  className?: string
  showLabels?: boolean    // 버튼 옆 텍스트 표시 (기본 아이콘만)
}

const REACTION_META: Record<FeedbackReaction, {
  icon: React.ElementType
  label: string
  color: string
  bg: string
  title: string
}> = {
  helpful: {
    icon: ThumbsUp,
    label: '도움됨',
    color: 'text-green-600',
    bg: 'hover:bg-green-50',
    title: '👍 유용했어요 — 비슷한 제안 더 자주 보여드릴게요',
  },
  applied: {
    icon: Sparkles,
    label: '적용함',
    color: 'text-[#D4A574]',
    bg: 'hover:bg-[#D4A574]/10',
    title: '✨ 실제 적용했어요 — 효과 추적해서 학습에 반영합니다',
  },
  irrelevant: {
    icon: ThumbsDown,
    label: '아니에요',
    color: 'text-gray-500',
    bg: 'hover:bg-gray-100',
    title: '👎 관련 없어요 — 이런 제안 덜 보여드릴게요',
  },
  muted: {
    icon: BellOff,
    label: '그만',
    color: 'text-red-500',
    bg: 'hover:bg-red-50',
    title: '🔇 이런 유형 그만 — 다시는 이런 제안 드리지 않겠습니다',
  },
}

export default function AiFeedback({
  sourceType,
  sourceRef,
  compact = false,
  className,
  showLabels = false,
}: AiFeedbackProps) {
  const user = useAuthStore((s) => s.user)
  const storeInfo = useAuthStore((s) => s.storeInfo)

  const [submitted, setSubmitted] = useState<FeedbackReaction | null>(null)
  const [signal, setSignal] = useState('')
  const [submitting, setSubmitting] = useState(false)

  const storeId = storeInfo?.id ?? user?.id

  const handleReact = async (reaction: FeedbackReaction) => {
    if (!storeId || submitted || submitting) return
    setSubmitting(true)
    try {
      const res = await fetch('/api/v1/agent/feedback', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-Store-Id': storeId,
        },
        body: JSON.stringify({
          store_id: storeId,
          source_type: sourceType,
          source_ref: sourceRef,
          reaction,
        }),
      })
      if (res.ok) {
        const data = await res.json()
        setSubmitted(reaction)
        setSignal(data.learning_signal ?? '감사합니다!')
      }
    } catch {
      // 실패해도 사용자는 몰라도 됨 (조용히)
    } finally {
      setSubmitting(false)
    }
  }

  // 피드백 완료 상태
  if (submitted) {
    return (
      <div
        className={cn(
          'flex items-center gap-1.5 text-xs text-gray-500 mt-2',
          className
        )}
        role="status"
        aria-live="polite"
      >
        <Check size={11} className="text-green-500" />
        <span>{signal || '반응이 기록되었어요'}</span>
      </div>
    )
  }

  // 평상 상태
  return (
    <div
      className={cn(
        'flex items-center gap-1 flex-wrap',
        compact ? 'mt-1.5' : 'mt-2',
        className
      )}
      role="group"
      aria-label="AI 제안에 대한 피드백"
    >
      <span className="text-[10px] text-gray-400 mr-1">이 제안 어때요?</span>
      {(Object.keys(REACTION_META) as FeedbackReaction[]).map((key) => {
        const meta = REACTION_META[key]
        const Icon = meta.icon
        return (
          <button
            key={key}
            onClick={() => handleReact(key)}
            disabled={submitting}
            title={meta.title}
            aria-label={meta.title}
            className={cn(
              'flex items-center gap-1 px-1.5 py-1 rounded-md transition-colors duration-200 disabled:opacity-50',
              meta.color,
              meta.bg,
              compact ? 'text-[10px]' : 'text-xs'
            )}
          >
            <Icon size={compact ? 10 : 12} aria-hidden="true" />
            {showLabels && <span>{meta.label}</span>}
          </button>
        )
      })}
    </div>
  )
}
