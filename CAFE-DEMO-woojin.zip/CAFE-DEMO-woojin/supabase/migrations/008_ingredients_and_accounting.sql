-- Issue #18: 재료 단가 DB + 메뉴 연결
-- Issue #20: 회계 (월별 손익 집계용 고정비 항목)

-- ══════════════════════════════════════════════════════════
-- Issue #18: 재료 단가 마스터 테이블
-- ══════════════════════════════════════════════════════════
CREATE TABLE IF NOT EXISTS public.ingredients (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  store_id uuid NOT NULL REFERENCES public.stores(id) ON DELETE CASCADE,

  name text NOT NULL,                     -- 재료명 ("원두", "우유" 등)
  unit text NOT NULL,                     -- 기본 단위 ("g", "ml", "kg", "L", "개")
  unit_price numeric NOT NULL DEFAULT 0 CHECK (unit_price >= 0),
  supplier text,                          -- 공급처 (옵션)
  notes text,

  updated_at timestamptz NOT NULL DEFAULT now(),
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_ingredients_store ON public.ingredients(store_id);
CREATE UNIQUE INDEX IF NOT EXISTS idx_ingredients_name_store
  ON public.ingredients(store_id, name);

ALTER TABLE public.ingredients ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "ingredients: 본인 매장" ON public.ingredients;
CREATE POLICY "ingredients: 본인 매장" ON public.ingredients
  FOR ALL USING (store_id = auth.uid());

COMMENT ON TABLE public.ingredients IS
  'Issue #18: 재료 단가 마스터. 단가 변경 시 메뉴 원가 자동 재계산의 기준.';


-- ══════════════════════════════════════════════════════════
-- Issue #20: 회계 — 월별 고정비 항목
-- (stores.monthly_fixed_cost는 총액만 있었음. 세부 분류 추가)
-- ══════════════════════════════════════════════════════════
CREATE TABLE IF NOT EXISTS public.accounting_fixed_costs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  store_id uuid NOT NULL REFERENCES public.stores(id) ON DELETE CASCADE,

  category text NOT NULL CHECK (category IN (
    'rent',          -- 임대료
    'labor',         -- 인건비 (자동 계산 가능하지만 고정 계약분)
    'utilities',     -- 공과금 (전기·가스·수도)
    'communication', -- 통신비
    'insurance',     -- 보험
    'loan',          -- 대출 상환
    'tax',           -- 세금
    'other'          -- 기타
  )),
  label text NOT NULL,                    -- 항목 이름 ("임대료", "KT 인터넷" 등)
  monthly_amount numeric NOT NULL CHECK (monthly_amount >= 0),
  notes text,

  active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_fixed_costs_store
  ON public.accounting_fixed_costs(store_id)
  WHERE active = true;

ALTER TABLE public.accounting_fixed_costs ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "accounting_fixed_costs: 본인 매장" ON public.accounting_fixed_costs;
CREATE POLICY "accounting_fixed_costs: 본인 매장" ON public.accounting_fixed_costs
  FOR ALL USING (store_id = auth.uid());


-- 월별 P&L 뷰 (매출 - 원재료 - 고정비)
CREATE OR REPLACE VIEW public.monthly_pnl AS
SELECT
  s.store_id,
  to_char(s.sale_date, 'YYYY-MM') AS month,
  SUM(s.revenue) AS total_revenue,
  SUM(s.cost) AS total_cost_of_goods,
  SUM(s.revenue - s.cost) AS gross_profit,
  SUM(s.revenue - s.cost) - COALESCE(
    (SELECT SUM(monthly_amount)
      FROM public.accounting_fixed_costs f
      WHERE f.store_id = s.store_id AND f.active = true),
    0
  ) AS net_profit,
  count(DISTINCT s.sale_date) AS operating_days
FROM public.sales_records s
GROUP BY s.store_id, to_char(s.sale_date, 'YYYY-MM');

COMMENT ON VIEW public.monthly_pnl IS
  'Issue #20: 월별 손익 요약. 순이익 = 매출 - 원재료 - 고정비(활성).';
