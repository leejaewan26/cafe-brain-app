// 메뉴·레시피 & 교육 매뉴얼 모듈 메인 페이지
// 탭: 메뉴 목록 | 메뉴 등록 | 교육 매뉴얼
import { useState, useRef } from 'react'
import { Link } from 'react-router-dom'
import {
  ChevronLeft, Plus, Sparkles, Loader2, Copy, Check,
  Trash2, Edit3, ChevronDown, ChevronUp, AlertCircle,
  BookOpen, ClipboardList, Lightbulb, Download, Search,
  Coffee, Leaf, Cake, UtensilsCrossed, Package, X,
} from 'lucide-react'
import { useMenuStore, calcTotalCost } from '@/store/menuStore'
import { useStoreContext } from '@/hooks/useStoreContext'
import type { MenuItem, MenuCategory, Ingredient, ManualType, OutputFormat } from '@/types/menu'
import { CATEGORY_LABELS, MANUAL_TYPE_LABELS } from '@/types/menu'
import { cn } from '@/lib/utils'

// ─── 카테고리 아이콘 ───
const CATEGORY_ICONS: Record<MenuCategory, React.ComponentType<{ size?: number; className?: string }>> = {
  coffee: Coffee,
  non_coffee: Leaf,
  dessert: Cake,
  food: UtensilsCrossed,
  other: Package,
}

const CATEGORY_COLORS: Record<MenuCategory, string> = {
  coffee: 'bg-amber-100 text-amber-700',
  non_coffee: 'bg-green-100 text-green-700',
  dessert: 'bg-pink-100 text-pink-700',
  food: 'bg-orange-100 text-orange-700',
  other: 'bg-gray-100 text-gray-600',
}

// ─── 원가비중 색상 ───
function costRatioColor(ratio: number) {
  if (ratio <= 30) return 'text-green-600'
  if (ratio <= 40) return 'text-amber-500'
  return 'text-red-500'
}

// ─── 복사 버튼 ───
function CopyButton({ text }: { text: string }) {
  const [copied, setCopied] = useState(false)
  return (
    <button
      onClick={async () => { await navigator.clipboard.writeText(text); setCopied(true); setTimeout(() => setCopied(false), 2000) }}
      className="flex items-center gap-1 px-2.5 py-1.5 bg-[#2C1810] text-white rounded-lg text-xs hover:bg-[#3d2418] transition-all duration-200"
    >
      {copied ? <><Check size={11} /> 복사됨</> : <><Copy size={11} /> 복사</>}
    </button>
  )
}

// ──────────────────────────────────────────────────────
// ─── 재료 편집 서브컴포넌트 ───
// ──────────────────────────────────────────────────────
function IngredientsEditor({
  ingredients,
  onChange,
}: {
  ingredients: Ingredient[]
  onChange: (ings: Ingredient[]) => void
}) {
  const addIng = () =>
    onChange([...ingredients, { id: `ing-${Date.now()}`, name: '', unitPrice: 0, amount: 0, unit: 'g' }])

  const updateIng = (idx: number, field: keyof Ingredient, value: string | number) => {
    const updated = ingredients.map((ing, i) => (i === idx ? { ...ing, [field]: value } : ing))
    onChange(updated)
  }

  const removeIng = (idx: number) => onChange(ingredients.filter((_, i) => i !== idx))

  return (
    <div>
      <div className="space-y-2 mb-2">
        {ingredients.map((ing, idx) => (
          <div key={ing.id} className="flex gap-2 items-center">
            <input
              value={ing.name}
              onChange={(e) => updateIng(idx, 'name', e.target.value)}
              placeholder="재료명"
              className="flex-1 px-2.5 py-1.5 rounded-lg border border-gray-200 text-xs focus:outline-none focus:ring-2 focus:ring-[#D4A574]"
            />
            <input
              type="number"
              value={ing.unitPrice || ''}
              onChange={(e) => updateIng(idx, 'unitPrice', Number(e.target.value))}
              placeholder="단가"
              className="w-16 px-2 py-1.5 rounded-lg border border-gray-200 text-xs focus:outline-none focus:ring-2 focus:ring-[#D4A574] text-right"
            />
            <span className="text-xs text-gray-400">원/100</span>
            <input
              type="number"
              value={ing.amount || ''}
              onChange={(e) => updateIng(idx, 'amount', Number(e.target.value))}
              placeholder="량"
              className="w-14 px-2 py-1.5 rounded-lg border border-gray-200 text-xs focus:outline-none focus:ring-2 focus:ring-[#D4A574] text-right"
            />
            <select
              value={ing.unit}
              onChange={(e) => updateIng(idx, 'unit', e.target.value)}
              className="w-12 px-1 py-1.5 rounded-lg border border-gray-200 text-xs focus:outline-none"
            >
              {['g', 'ml', '개', 'T'].map((u) => <option key={u}>{u}</option>)}
            </select>
            <button onClick={() => removeIng(idx)} className="text-gray-300 hover:text-red-400 transition-colors">
              <X size={14} />
            </button>
          </div>
        ))}
      </div>
      <button
        onClick={addIng}
        className="flex items-center gap-1 text-xs text-[#D4A574] hover:text-[#c4956a] transition-colors"
      >
        <Plus size={13} /> 재료 추가
      </button>
    </div>
  )
}

// ──────────────────────────────────────────────────────
// ─── 메뉴 등록/수정 폼 ───
// ──────────────────────────────────────────────────────
function MenuForm({
  initial,
  onSave,
  onCancel,
}: {
  initial?: MenuItem
  onSave: (data: Omit<MenuItem, 'id' | 'totalCost' | 'createdAt'>) => void
  onCancel: () => void
}) {
  const [name, setName] = useState(initial?.name ?? '')
  const [category, setCategory] = useState<MenuCategory>(initial?.category ?? 'coffee')
  // Lazy initializer로 Date.now() 렌더 중 호출 방지 (React 19 purity 규칙)
  const [ingredients, setIngredients] = useState<Ingredient[]>(() =>
    initial?.ingredients ?? [
      { id: `ing-${Date.now()}`, name: '', unitPrice: 0, amount: 0, unit: 'g' },
    ]
  )
  const [salePrice, setSalePrice] = useState(initial?.salePrice ?? 0)
  const [notes, setNotes] = useState(initial?.notes ?? '')
  const [targetRatio, setTargetRatio] = useState(30)

  const totalCost = calcTotalCost(ingredients)
  const actualRatio = salePrice > 0 ? Math.round((totalCost / salePrice) * 100) : 0
  // 적정 판매가 추천: totalCost / (targetRatio/100)
  const recommendedPrice = totalCost > 0 ? Math.ceil(totalCost / (targetRatio / 100) / 100) * 100 : 0

  const handleSave = () => {
    if (!name.trim()) return
    onSave({ name, category, ingredients, salePrice, notes, photoUrl: initial?.photoUrl, recipe: initial?.recipe })
  }

  return (
    <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-5 space-y-4">
      <h3 className="font-bold text-[#2C1810] flex items-center gap-2">
        <Edit3 size={16} className="text-[#D4A574]" />
        {initial ? '메뉴 수정' : '메뉴 등록'}
      </h3>

      {/* 메뉴명 + 카테고리 */}
      <div className="grid grid-cols-2 gap-3">
        <div>
          <label className="block text-xs font-semibold text-gray-600 mb-1">메뉴명 *</label>
          <input
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="예) 시그니처 라떼"
            className="w-full px-3 py-2 rounded-xl border border-gray-200 text-sm focus:outline-none focus:ring-2 focus:ring-[#D4A574]"
          />
        </div>
        <div>
          <label className="block text-xs font-semibold text-gray-600 mb-1">카테고리</label>
          <div className="flex flex-wrap gap-1">
            {(Object.entries(CATEGORY_LABELS) as [MenuCategory, string][]).map(([k, v]) => (
              <button
                key={k}
                onClick={() => setCategory(k)}
                className={cn(
                  'px-2.5 py-1 rounded-full text-xs font-medium border transition-all duration-200',
                  category === k ? 'bg-[#2C1810] text-white border-[#2C1810]' : 'border-gray-200 text-gray-600'
                )}
              >
                {v}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* 재료 목록 */}
      <div>
        <label className="block text-xs font-semibold text-gray-600 mb-2">재료 목록</label>
        <IngredientsEditor ingredients={ingredients} onChange={setIngredients} />
      </div>

      {/* 원가 계산 패널 */}
      <div className="bg-[#FAFAF8] rounded-xl p-3 border border-gray-100">
        <div className="flex items-center justify-between flex-wrap gap-3">
          <div>
            <p className="text-xs text-gray-500">재료비 합계</p>
            <p className="text-lg font-bold text-[#2C1810]">{totalCost.toFixed(0)}원</p>
          </div>
          <div className="flex items-center gap-2">
            <label className="text-xs text-gray-500">판매가</label>
            <input
              type="number"
              value={salePrice || ''}
              onChange={(e) => setSalePrice(Number(e.target.value))}
              className="w-24 px-2 py-1.5 rounded-lg border border-gray-200 text-sm text-right focus:outline-none focus:ring-2 focus:ring-[#D4A574]"
            />
            <span className="text-xs text-gray-500">원</span>
          </div>
          <div className="text-center">
            <p className="text-xs text-gray-500">원가비중</p>
            <p className={cn('text-lg font-bold', costRatioColor(actualRatio))}>{actualRatio}%</p>
          </div>
          <div>
            <div className="flex items-center gap-1 mb-1">
              <label className="text-xs text-gray-500">목표 원가비중</label>
              <input
                type="number"
                value={targetRatio}
                onChange={(e) => setTargetRatio(Number(e.target.value))}
                className="w-12 px-1 py-0.5 rounded border border-gray-200 text-xs text-right focus:outline-none"
              />
              <span className="text-xs text-gray-500">%</span>
            </div>
            <p className="text-xs text-[#D4A574] font-semibold">
              추천 판매가: {recommendedPrice.toLocaleString()}원
            </p>
          </div>
        </div>
      </div>

      {/* 메모 */}
      <div>
        <label className="block text-xs font-semibold text-gray-600 mb-1">메모</label>
        <textarea
          value={notes}
          onChange={(e) => setNotes(e.target.value)}
          placeholder="특이사항, 서빙 가이드 등"
          rows={2}
          className="w-full px-3 py-2 rounded-xl border border-gray-200 text-sm focus:outline-none focus:ring-2 focus:ring-[#D4A574] resize-none"
        />
      </div>

      <div className="flex gap-2">
        <button onClick={onCancel} className="px-4 py-2 rounded-xl border border-gray-200 text-sm text-gray-600 hover:bg-gray-50 transition-colors">
          취소
        </button>
        <button
          onClick={handleSave}
          disabled={!name.trim()}
          className="flex-1 py-2 rounded-xl bg-[#2C1810] text-white text-sm font-semibold hover:bg-[#3d2418] transition-colors disabled:opacity-50"
        >
          저장
        </button>
      </div>
    </div>
  )
}

// ──────────────────────────────────────────────────────
// ─── 메뉴 카드 ───
// ──────────────────────────────────────────────────────
function MenuCard({ menu, onEdit, onDelete }: {
  menu: MenuItem
  onEdit: () => void
  onDelete: () => void
}) {
  const { setRecipe } = useMenuStore()
  const { storeInfo } = useStoreContext()
  const [expanded, setExpanded] = useState(false)
  const [isGenRecipe, setIsGenRecipe] = useState(false)
  const [recipeError, setRecipeError] = useState('')

  const CategoryIcon = CATEGORY_ICONS[menu.category]
  const costRatio = menu.salePrice > 0 ? Math.round((menu.totalCost / menu.salePrice) * 100) : 0

  const handleGenRecipe = async () => {
    setIsGenRecipe(true)
    setRecipeError('')
    try {
      const res = await fetch('/api/v1/menu/recipe', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          menu_name: menu.name,
          category: menu.category,
          ingredients: menu.ingredients.map((i) => `${i.name} ${i.amount}${i.unit}`),
          notes: menu.notes ?? '',
          store_name: storeInfo?.store_name ?? '우리 카페',
        }),
      })
      if (!res.ok) throw new Error(`서버 오류: ${res.status}`)
      const data = await res.json()
      setRecipe(menu.id, data.recipe)
      setExpanded(true)
    } catch (e) {
      const msg = e instanceof Error ? e.message : '오류'
      setRecipeError(msg.includes('Failed to fetch') ? '백엔드 서버를 시작해주세요' : msg)
    } finally {
      setIsGenRecipe(false)
    }
  }

  return (
    <div className="bg-white rounded-2xl border border-gray-100 shadow-sm hover:shadow-md transition-all duration-200">
      <div className="p-4">
        {/* 헤더 */}
        <div className="flex items-start gap-3 mb-3">
          <div className={cn('w-10 h-10 rounded-xl flex items-center justify-center shrink-0', CATEGORY_COLORS[menu.category])}>
            <CategoryIcon size={18} />
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 flex-wrap">
              <h3 className="font-bold text-[#2C1810] text-sm">{menu.name}</h3>
              <span className={cn('text-xs px-2 py-0.5 rounded-full font-medium', CATEGORY_COLORS[menu.category])}>
                {CATEGORY_LABELS[menu.category]}
              </span>
            </div>
            {menu.notes && <p className="text-xs text-gray-400 mt-0.5 truncate">{menu.notes}</p>}
          </div>
          <div className="flex gap-1.5 shrink-0">
            <button onClick={onEdit} className="p-1.5 rounded-lg hover:bg-gray-100 text-gray-400 hover:text-[#2C1810] transition-colors">
              <Edit3 size={13} />
            </button>
            <button onClick={onDelete} className="p-1.5 rounded-lg hover:bg-red-50 text-gray-400 hover:text-red-500 transition-colors">
              <Trash2 size={13} />
            </button>
          </div>
        </div>

        {/* 재료 목록 (간이) */}
        <div className="flex flex-wrap gap-1 mb-3">
          {menu.ingredients.slice(0, 4).map((ing) => (
            <span key={ing.id} className="text-xs bg-gray-50 text-gray-500 px-2 py-0.5 rounded-full border border-gray-100">
              {ing.name}
            </span>
          ))}
          {menu.ingredients.length > 4 && (
            <span className="text-xs text-gray-400">+{menu.ingredients.length - 4}개</span>
          )}
        </div>

        {/* 가격 정보 */}
        <div className="flex items-center gap-3 bg-[#FAFAF8] rounded-xl px-3 py-2 mb-3">
          <div className="text-center">
            <p className="text-xs text-gray-400">재료비</p>
            <p className="text-sm font-bold text-[#2C1810]">{menu.totalCost.toFixed(0)}원</p>
          </div>
          <div className="flex-1 text-center">
            <p className="text-xs text-gray-400">원가비중</p>
            <p className={cn('text-sm font-bold', costRatioColor(costRatio))}>{costRatio}%</p>
          </div>
          <div className="text-center">
            <p className="text-xs text-gray-400">판매가</p>
            <p className="text-sm font-bold text-[#D4A574]">{menu.salePrice.toLocaleString()}원</p>
          </div>
          <div className="text-center">
            <p className="text-xs text-gray-400">순이익</p>
            <p className="text-sm font-bold text-green-600">{(menu.salePrice - menu.totalCost).toFixed(0)}원</p>
          </div>
        </div>

        {/* 액션 버튼 */}
        <div className="flex gap-2">
          <button
            onClick={handleGenRecipe}
            disabled={isGenRecipe}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-gradient-to-r from-[#2C1810] to-[#D4A574] text-white rounded-xl text-xs font-medium hover:opacity-90 transition-opacity disabled:opacity-50"
          >
            {isGenRecipe ? <Loader2 size={12} className="animate-spin" /> : <Sparkles size={12} />}
            레시피 생성
          </button>
          {menu.recipe && (
            <button
              onClick={() => setExpanded(!expanded)}
              className="flex items-center gap-1 px-3 py-1.5 border border-gray-200 text-gray-500 rounded-xl text-xs hover:bg-gray-50 transition-colors"
            >
              레시피 보기 {expanded ? <ChevronUp size={11} /> : <ChevronDown size={11} />}
            </button>
          )}
        </div>
        {recipeError && (
          <p className="text-xs text-orange-600 mt-2 flex items-center gap-1">
            <AlertCircle size={11} /> {recipeError}
          </p>
        )}
      </div>

      {/* 레시피 전개 */}
      {expanded && menu.recipe && (
        <div className="border-t border-gray-100 p-4 bg-[#FAFAF8] rounded-b-2xl">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-bold text-[#2C1810] flex items-center gap-1.5">
              <BookOpen size={13} className="text-[#D4A574]" /> 레시피 문서
            </span>
            <CopyButton text={menu.recipe} />
          </div>
          <div className="text-xs text-gray-700 leading-relaxed whitespace-pre-line bg-white rounded-xl p-3 border border-gray-100 max-h-64 overflow-y-auto">
            {menu.recipe}
          </div>
          <p className="text-xs text-gray-400 mt-2 italic">ⓘ AI가 생성한 콘텐츠입니다</p>
        </div>
      )}
    </div>
  )
}

// ──────────────────────────────────────────────────────
// ─── AI 시그니처 메뉴 추천 ───
// ──────────────────────────────────────────────────────
function SignatureRecommend({ storeName, storeInfo }: { storeName: string; storeInfo: ReturnType<typeof useStoreContext>['storeInfo'] }) {
  const [result, setResult] = useState('')
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState('')

  const handleRecommend = async () => {
    setIsLoading(true)
    setError('')
    setResult('')
    try {
      const res = await fetch('/api/v1/menu/recommend', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          store_name: storeName,
          district_type: storeInfo?.district_type ?? '주거',
          ambiance: storeInfo?.ambiance_keywords?.join(', ') ?? '아늑한 카페',
          menu_count: storeInfo?.menu_count ?? 10,
        }),
      })
      if (!res.ok) throw new Error(`서버 오류: ${res.status}`)
      const data = await res.json()
      setResult(data.recommendations)
    } catch (e) {
      const msg = e instanceof Error ? e.message : '오류'
      setError(msg.includes('Failed to fetch') ? '백엔드 서버를 시작해주세요' : msg)
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-5">
      <div className="flex items-center gap-2 mb-3">
        <Lightbulb size={16} className="text-[#D4A574]" />
        <h3 className="font-bold text-[#2C1810] text-sm">AI 시그니처 메뉴 추천</h3>
        <span className="text-xs px-2 py-0.5 rounded-full bg-amber-100 text-amber-700">논커피 포함 3가지</span>
      </div>
      <p className="text-xs text-gray-400 mb-4">
        매장 분위기·상권 데이터 기반으로 차별화된 시그니처 메뉴 3가지를 제안해드립니다.
      </p>
      {error && (
        <div className="mb-3 flex items-center gap-2 p-2 bg-orange-50 border border-orange-200 rounded-xl text-xs text-orange-600">
          <AlertCircle size={12} /> {error}
        </div>
      )}
      <button
        onClick={handleRecommend}
        disabled={isLoading}
        className="w-full py-2.5 bg-gradient-to-r from-[#2C1810] to-[#D4A574] text-white rounded-xl text-sm font-semibold hover:opacity-90 transition-opacity disabled:opacity-50 flex items-center justify-center gap-2"
      >
        {isLoading ? <><Loader2 size={14} className="animate-spin" /> 추천 생성 중...</> : <><Sparkles size={14} /> AI 신메뉴 3종 추천받기</>}
      </button>
      {result && (
        <div className="mt-4">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-semibold text-[#2C1810]">추천 결과</span>
            <CopyButton text={result} />
          </div>
          <div className="text-sm text-gray-700 leading-relaxed whitespace-pre-line bg-[#FAFAF8] rounded-xl p-3 border border-gray-100">
            {result}
          </div>
          <p className="text-xs text-gray-400 mt-2 italic">ⓘ AI가 생성한 콘텐츠입니다</p>
        </div>
      )}
    </div>
  )
}

// ──────────────────────────────────────────────────────
// ─── 교육 매뉴얼 탭 ───
// ──────────────────────────────────────────────────────
function ManualTab({ storeName }: { storeName: string }) {
  const [manualType, setManualType] = useState<ManualType>('open_checklist')
  const [outputFormat, setOutputFormat] = useState<OutputFormat>('checklist')
  const [machineBrand, setMachineBrand] = useState('')
  const [milkLocation, setMilkLocation] = useState('')
  const [extraInfo, setExtraInfo] = useState('')
  const [result, setResult] = useState('')
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState('')
  const textAreaRef = useRef<HTMLTextAreaElement>(null)

  const handleGenerate = async () => {
    setIsLoading(true)
    setError('')
    setResult('')
    try {
      const res = await fetch('/api/v1/menu/manual', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          manual_type: manualType,
          output_format: outputFormat,
          store_name: storeName,
          machine_brand: machineBrand || '라마르조코',
          milk_location: milkLocation || '냉장고 2번 칸',
          extra_info: extraInfo,
        }),
      })
      if (!res.ok) throw new Error(`서버 오류: ${res.status}`)
      const data = await res.json()
      setResult(data.content)
    } catch (e) {
      const msg = e instanceof Error ? e.message : '오류'
      setError(msg.includes('Failed to fetch') ? '백엔드 서버를 시작해주세요' : msg)
    } finally {
      setIsLoading(false)
    }
  }

  const handlePdfExport = () => {
    if (!result) return
    // PDF 내보내기: 새 탭에서 인쇄 다이얼로그
    const printWindow = window.open('', '_blank')
    if (!printWindow) return
    printWindow.document.write(`
      <!DOCTYPE html>
      <html lang="ko">
      <head>
        <meta charset="UTF-8">
        <title>${MANUAL_TYPE_LABELS[manualType]} - ${storeName}</title>
        <style>
          @import url('https://cdn.jsdelivr.net/gh/orioncactus/pretendard/dist/web/static/pretendard.css');
          body { font-family: 'Pretendard', sans-serif; padding: 40px; max-width: 800px; margin: 0 auto; color: #2C1810; }
          h1 { font-size: 24px; margin-bottom: 8px; }
          .subtitle { color: #D4A574; font-size: 14px; margin-bottom: 32px; }
          pre { white-space: pre-wrap; font-family: 'Pretendard', sans-serif; line-height: 1.8; font-size: 14px; }
          .badge { background: #D4A574; color: white; padding: 2px 8px; border-radius: 999px; font-size: 12px; }
          .footer { margin-top: 40px; font-size: 11px; color: #999; border-top: 1px solid #eee; padding-top: 16px; }
        </style>
      </head>
      <body>
        <h1>${MANUAL_TYPE_LABELS[manualType]}</h1>
        <p class="subtitle">📍 ${storeName} &nbsp; 생성일: ${new Date().toLocaleDateString('ko-KR')}</p>
        <pre>${result}</pre>
        <div class="footer">ⓘ AI가 생성한 콘텐츠입니다 · Cafe Brain</div>
      </body>
      </html>
    `)
    printWindow.document.close()
    printWindow.focus()
    setTimeout(() => {
      printWindow.print()
      printWindow.close()
    }, 500)
  }

  const FORMAT_LABELS: Record<OutputFormat, string> = {
    checklist: '✅ 체크리스트',
    table: '📊 표',
    step_guide: '📋 단계별 가이드',
  }

  return (
    <div className="space-y-5">
      {/* 매뉴얼 타입 선택 */}
      <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-4">
        <h3 className="text-sm font-bold text-[#2C1810] mb-3 flex items-center gap-2">
          <ClipboardList size={15} className="text-[#D4A574]" /> 생성할 문서 선택
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
          {(Object.entries(MANUAL_TYPE_LABELS) as [ManualType, string][]).map(([type, label]) => (
            <button
              key={type}
              onClick={() => setManualType(type)}
              className={cn(
                'text-left px-4 py-3 rounded-xl border-2 text-sm font-medium transition-all duration-200',
                manualType === type
                  ? 'border-[#2C1810] bg-[#2C1810] text-white'
                  : 'border-gray-100 text-gray-600 hover:border-gray-200 hover:bg-gray-50'
              )}
            >
              {label}
            </button>
          ))}
        </div>
      </div>

      {/* 출력 형식 + 매장 특수 사항 */}
      <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-4 space-y-4">
        <h3 className="text-sm font-bold text-[#2C1810] flex items-center gap-2">
          <Edit3 size={15} className="text-[#D4A574]" /> 맞춤 설정
        </h3>

        {/* 출력 형식 */}
        <div>
          <label className="block text-xs font-semibold text-gray-600 mb-2">출력 형식</label>
          <div className="flex gap-2">
            {(Object.entries(FORMAT_LABELS) as [OutputFormat, string][]).map(([fmt, label]) => (
              <button
                key={fmt}
                onClick={() => setOutputFormat(fmt)}
                className={cn(
                  'px-3 py-1.5 rounded-full text-xs font-medium border transition-all duration-200',
                  outputFormat === fmt
                    ? 'bg-[#D4A574] text-white border-[#D4A574]'
                    : 'border-gray-200 text-gray-600 hover:border-gray-300'
                )}
              >
                {label}
              </button>
            ))}
          </div>
        </div>

        {/* 매장 특수 사항 */}
        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="block text-xs font-semibold text-gray-600 mb-1">에스프레소 머신 브랜드</label>
            <input
              value={machineBrand}
              onChange={(e) => setMachineBrand(e.target.value)}
              placeholder="예) 라마르조코 리네아"
              className="w-full px-3 py-2 rounded-xl border border-gray-200 text-sm focus:outline-none focus:ring-2 focus:ring-[#D4A574]"
            />
          </div>
          <div>
            <label className="block text-xs font-semibold text-gray-600 mb-1">우유 보관 위치</label>
            <input
              value={milkLocation}
              onChange={(e) => setMilkLocation(e.target.value)}
              placeholder="예) 냉장고 2번 칸"
              className="w-full px-3 py-2 rounded-xl border border-gray-200 text-sm focus:outline-none focus:ring-2 focus:ring-[#D4A574]"
            />
          </div>
        </div>
        <div>
          <label className="block text-xs font-semibold text-gray-600 mb-1">추가 특이사항</label>
          <textarea
            value={extraInfo}
            onChange={(e) => setExtraInfo(e.target.value)}
            placeholder="예) 매장 운영 시간 8시~22시, 주차 2시간 무료 제공"
            rows={2}
            className="w-full px-3 py-2.5 rounded-xl border border-gray-200 text-sm focus:outline-none focus:ring-2 focus:ring-[#D4A574] resize-none"
          />
        </div>

        {error && (
          <div className="flex items-center gap-2 p-2 bg-orange-50 border border-orange-200 rounded-xl text-xs text-orange-600">
            <AlertCircle size={12} /> {error}
            <button onClick={() => setError('')} className="ml-auto">✕</button>
          </div>
        )}

        <button
          onClick={handleGenerate}
          disabled={isLoading}
          className="w-full py-3 bg-gradient-to-r from-[#2C1810] to-[#D4A574] text-white rounded-xl font-semibold text-sm hover:opacity-90 transition-opacity disabled:opacity-50 flex items-center justify-center gap-2 shadow-md"
        >
          {isLoading
            ? <><Loader2 size={16} className="animate-spin" /> 문서 생성 중...</>
            : <><Sparkles size={16} /> AI 교육 매뉴얼 생성</>}
        </button>
      </div>

      {/* 생성 결과 */}
      {result && (
        <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-4">
          <div className="flex items-center justify-between mb-3">
            <h3 className="font-bold text-[#2C1810] text-sm flex items-center gap-2">
              <ClipboardList size={14} className="text-[#D4A574]" />
              {MANUAL_TYPE_LABELS[manualType]}
            </h3>
            <div className="flex gap-2">
              <CopyButton text={result} />
              <button
                onClick={handlePdfExport}
                className="flex items-center gap-1.5 px-3 py-1.5 bg-green-600 text-white rounded-lg text-xs font-medium hover:bg-green-700 transition-colors"
              >
                <Download size={12} /> PDF 내보내기
              </button>
            </div>
          </div>
          <textarea
            ref={textAreaRef}
            value={result}
            onChange={(e) => setResult(e.target.value)}
            rows={20}
            className="w-full px-3 py-2.5 rounded-xl border border-gray-200 text-sm focus:outline-none focus:ring-2 focus:ring-[#D4A574] resize-none font-mono leading-relaxed"
          />
          <p className="text-xs text-gray-400 mt-2 italic">ⓘ AI가 생성한 콘텐츠입니다</p>
        </div>
      )}
    </div>
  )
}

// ══════════════════════════════════════════════════════
// ─── 메인 MenuPage ───
// ══════════════════════════════════════════════════════
export default function MenuPage() {
  const { menus, addMenu, updateMenu, deleteMenu } = useMenuStore()
  const { storeInfo } = useStoreContext()
  const storeName = storeInfo?.store_name ?? '우리 카페'

  const [activeTab, setActiveTab] = useState<'list' | 'add' | 'manual'>('list')
  const [categoryFilter, setCategoryFilter] = useState<MenuCategory | 'all'>('all')
  const [editingMenu, setEditingMenu] = useState<MenuItem | null>(null)
  const [searchQuery, setSearchQuery] = useState('')

  // 필터링
  const filteredMenus = menus.filter((m) => {
    if (categoryFilter !== 'all' && m.category !== categoryFilter) return false
    if (searchQuery && !m.name.toLowerCase().includes(searchQuery.toLowerCase())) return false
    return true
  })

  const avgCostRatio = menus.length
    ? Math.round(menus.reduce((s, m) => s + (m.salePrice > 0 ? (m.totalCost / m.salePrice) * 100 : 0), 0) / menus.length)
    : 0

  const handleSaveMenu = (data: Omit<MenuItem, 'id' | 'totalCost' | 'createdAt'>) => {
    if (editingMenu) {
      updateMenu(editingMenu.id, data)
      setEditingMenu(null)
    } else {
      addMenu(data)
    }
    setActiveTab('list')
  }

  const TAB_CONFIG = [
    { id: 'list' as const, label: '📋 메뉴 목록', count: menus.length },
    { id: 'add' as const, label: editingMenu ? '✏️ 수정' : '➕ 메뉴 등록' },
    { id: 'manual' as const, label: '📖 교육 매뉴얼' },
  ]

  return (
    <div className="min-h-screen bg-[#FAFAF8]">
      {/* 헤더 */}
      <header className="bg-[#2C1810] text-white px-4 py-3 flex items-center gap-3">
        <Link to="/dashboard" className="hover:text-[#D4A574] transition-colors duration-200">
          <ChevronLeft size={20} />
        </Link>
        <UtensilsCrossed size={18} className="text-[#D4A574]" />
        <h1 className="font-bold text-base flex-1">메뉴·레시피 & 교육 매뉴얼</h1>
        <span className="text-xs text-[#D4A574]">{menus.length}개 메뉴</span>
      </header>

      {/* 통계 바 */}
      <div className="bg-white border-b border-gray-100 px-4 py-3">
        <div className="max-w-4xl mx-auto grid grid-cols-4 gap-4 text-center">
          {[
            { label: '전체 메뉴', value: menus.length, unit: '개', color: 'text-[#2C1810]' },
            { label: '평균 원가비중', value: avgCostRatio, unit: '%', color: costRatioColor(avgCostRatio) },
            { label: '커피 메뉴', value: menus.filter((m) => m.category === 'coffee').length, unit: '개', color: 'text-amber-600' },
            { label: '레시피 생성', value: menus.filter((m) => m.recipe).length, unit: '개', color: 'text-green-600' },
          ].map((stat) => (
            <div key={stat.label}>
              <p className={cn('text-xl font-black', stat.color)}>{stat.value}<span className="text-xs font-normal text-gray-400">{stat.unit}</span></p>
              <p className="text-xs text-gray-400">{stat.label}</p>
            </div>
          ))}
        </div>
      </div>

      {/* 탭 */}
      <div className="flex bg-white border-b border-gray-100 px-4">
        {TAB_CONFIG.map((tab) => (
          <button
            key={tab.id}
            onClick={() => { setActiveTab(tab.id); if (tab.id !== 'add') setEditingMenu(null) }}
            className={cn(
              'px-4 py-2.5 text-sm font-medium transition-all duration-200 whitespace-nowrap',
              activeTab === tab.id ? 'border-b-2 border-[#2C1810] text-[#2C1810]' : 'text-gray-400 hover:text-gray-600'
            )}
          >
            {tab.label}
            {'count' in tab && tab.count !== undefined && (
              <span className="ml-1 text-xs text-gray-400">({tab.count})</span>
            )}
          </button>
        ))}
      </div>

      <main className="max-w-4xl mx-auto px-4 py-5 space-y-4">

        {/* ─── 메뉴 목록 탭 ─── */}
        {activeTab === 'list' && (
          <>
            {/* 검색 + 필터 */}
            <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-4">
              <div className="flex items-center gap-3 flex-wrap">
                {/* 검색 */}
                <div className="flex items-center gap-2 flex-1 min-w-[140px] bg-gray-50 rounded-xl px-3 py-2">
                  <Search size={14} className="text-gray-400" />
                  <input
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="메뉴 검색"
                    className="bg-transparent text-sm outline-none flex-1 placeholder:text-gray-300"
                  />
                </div>
                {/* 카테고리 필터 */}
                <div className="flex gap-1 flex-wrap">
                  <button
                    onClick={() => setCategoryFilter('all')}
                    className={cn('px-3 py-1.5 rounded-full text-xs font-medium border transition-all duration-200',
                      categoryFilter === 'all' ? 'bg-[#2C1810] text-white border-[#2C1810]' : 'border-gray-200 text-gray-600 hover:border-gray-300')}
                  >
                    전체
                  </button>
                  {(Object.entries(CATEGORY_LABELS) as [MenuCategory, string][]).map(([k, v]) => (
                    <button
                      key={k}
                      onClick={() => setCategoryFilter(k)}
                      className={cn('px-3 py-1.5 rounded-full text-xs font-medium border transition-all duration-200',
                        categoryFilter === k ? `${CATEGORY_COLORS[k]} border-transparent` : 'border-gray-200 text-gray-600 hover:border-gray-300')}
                    >
                      {v}
                    </button>
                  ))}
                </div>
                <button
                  onClick={() => { setEditingMenu(null); setActiveTab('add') }}
                  className="flex items-center gap-1.5 px-4 py-2 bg-[#D4A574] text-white rounded-xl text-sm font-semibold hover:bg-[#c4956a] transition-colors"
                >
                  <Plus size={15} /> 새 메뉴
                </button>
              </div>
            </div>

            {/* 메뉴 카드 그리드 */}
            {filteredMenus.length === 0 ? (
              <div className="text-center py-16 text-gray-400">
                <UtensilsCrossed size={36} className="mx-auto mb-3 opacity-30" />
                <p className="text-sm">메뉴가 없습니다. 새 메뉴를 등록해보세요!</p>
              </div>
            ) : (
              <div className="grid md:grid-cols-2 gap-4">
                {filteredMenus.map((menu) => (
                  <MenuCard
                    key={menu.id}
                    menu={menu}
                    onEdit={() => { setEditingMenu(menu); setActiveTab('add') }}
                    onDelete={() => { if (confirm(`"${menu.name}"를 삭제할까요?`)) deleteMenu(menu.id) }}
                  />
                ))}
              </div>
            )}

            {/* AI 시그니처 추천 */}
            <SignatureRecommend storeName={storeName} storeInfo={storeInfo} />
          </>
        )}

        {/* ─── 메뉴 등록/수정 탭 ─── */}
        {activeTab === 'add' && (
          <MenuForm
            initial={editingMenu ?? undefined}
            onSave={handleSaveMenu}
            onCancel={() => { setEditingMenu(null); setActiveTab('list') }}
          />
        )}

        {/* ─── 교육 매뉴얼 탭 ─── */}
        {activeTab === 'manual' && <ManualTab storeName={storeName} />}
      </main>
    </div>
  )
}
