// 테스트용 목 데이터 (5개 시나리오 공통)

export const MOCK_USER = {
  id: 'user-test-uuid-0001',
  email: 'owner@cafe-test.com',
  user_metadata: { name: '김사장' },
}

export const MOCK_SESSION = {
  access_token: 'mock-access-token',
  refresh_token: 'mock-refresh',
  token_type: 'bearer',
  expires_in: 3600,
  expires_at: Math.floor(Date.now() / 1000) + 3600,
  user: MOCK_USER,
}

export const MOCK_STORE = {
  id: MOCK_USER.id,
  store_name: '테스트 카페',
  owner_name: '김사장',
  district_type: '오피스',
  menu_count: 10,
  employee_count: 3,
  avg_monthly_sales: 7500000,
  ambiance_keywords: ['모던', '아늑한'],
  target_labor_ratio: 0.25,
  monthly_fixed_cost: 3_000_000,
  logo_url: null,
  agent_profile: {},
  agent_learning_enabled: true,
  created_at: new Date().toISOString(),
}

export const MOCK_OWNER_PROFILE = {
  id: 'profile-owner-001',
  store_id: MOCK_USER.id,
  name: '김사장',
  role: 'owner',
  avatar_emoji: '👨‍💼',
  avatar_color: '#D4A574',
  pin_hash: null,
  active: true,
  permissions: {},
  created_at: new Date().toISOString(),
  last_active_at: new Date().toISOString(),
}

export const MOCK_MANAGER_PROFILE = {
  id: 'profile-manager-001',
  store_id: MOCK_USER.id,
  name: '박점장',
  role: 'manager',
  avatar_emoji: '🧑‍💼',
  avatar_color: '#4A90A4',
  pin_hash: null,
  active: true,
  permissions: {},
  created_at: new Date().toISOString(),
  last_active_at: null,
}

export const MOCK_SALES_CSV = [
  'sale_date,menu_name,quantity,revenue,cost,hour_slot',
  '2026-04-15,아이스 아메리카노,5,22500,6000,10',
  '2026-04-15,카페라떼,3,15000,4500,11',
  '2026-04-16,아이스 아메리카노,8,36000,9600,14',
  '2026-04-16,크로플,4,20000,8000,15',
  '2026-04-17,아이스 아메리카노,6,27000,7200,10',
  '2026-04-17,바닐라 라떼,5,27500,8500,12',
].join('\n')

export const MOCK_AI_INSIGHT = `이번 달 ${MOCK_STORE.store_name}의 매출 분석 결과 아이스 아메리카노가 압도적 1위 메뉴입니다. 오피스 상권 특성상 점심시간(11-13시) 회전율이 가장 높으니, 이 시간대 POS 효율화가 매출 +8% 효과로 이어질 수 있습니다. 매출 낮은 수요일은 '라떼 무료 업그레이드' 같은 소규모 프로모션을 추천드립니다.`

export const MOCK_REVIEW_REPLY = `테스트 고객님, 카페 방문해주셔서 진심으로 감사드립니다. 아이스 아메리카노를 마음에 들어하셨다니 저희도 기쁩니다. 다음 방문 시에는 새로 출시된 크로플도 한번 드셔보세요. 늘 좋은 커피로 보답하겠습니다 ☕\n\nⓘ AI가 생성한 답글입니다.`

export const MOCK_BRIEFING = `김사장님, 어제 매출 ${(85000).toLocaleString()}원으로 평일 평균보다 12% 높았어요. 지난주 수요일 아이스 아메리카노 판매가 늘었듯, 오늘도 점심 직장인 트래픽이 집중될 가능성이 있습니다. 10-11시 사이 직원 1명 더 투입하면 회전율이 좋아질 거예요.`
