// K4 — 세금계산서 발행 신청
import { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { ChevronLeft, FileText, Loader2 } from 'lucide-react'
import toast from 'react-hot-toast'
import { useAuthStore } from '@/store/authStore'

export default function TaxInvoicePage() {
  const navigate = useNavigate()
  const user = useAuthStore((s) => s.user)
  const [paymentKey, setPaymentKey] = useState('')
  const [businessNo, setBusinessNo] = useState('')
  const [businessName, setBusinessName] = useState('')
  const [representative, setRepresentative] = useState('')
  const [email, setEmail] = useState(user?.email ?? '')
  const [submitting, setSubmitting] = useState(false)

  const submit = async () => {
    if (!user) return
    if (!paymentKey || !businessNo || !businessName || !representative || !email) {
      toast.error('모든 필드를 입력해주세요')
      return
    }
    setSubmitting(true)
    try {
      const r = await fetch('/api/v1/billing/tax-invoice/request', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          store_id: user.id,
          payment_key: paymentKey,
          business_no: businessNo,
          business_name: businessName,
          representative,
          tax_invoice_email: email,
        }),
      })
      if (!r.ok) {
        const err = await r.json().catch(() => ({}))
        throw new Error(err.detail || '신청 실패')
      }
      const data = await r.json()
      toast.success(`세금계산서 신청 완료 — 공급가 ₩${data.supply_amount.toLocaleString()}`)
      navigate('/billing')
    } catch (e) {
      toast.error(e instanceof Error ? e.message : '오류')
    } finally {
      setSubmitting(false)
    }
  }

  return (
    <div className="min-h-screen bg-[#FAFAF8] py-8 px-4">
      <div className="max-w-md mx-auto">
        <div className="flex items-center gap-2 mb-5">
          <Link to="/billing" className="text-gray-400 hover:text-[#2C1810]">
            <ChevronLeft size={18} />
          </Link>
          <h1 className="text-lg font-bold text-[#2C1810] flex items-center gap-1.5">
            <FileText size={16} className="text-[#D4A574]" />
            세금계산서 발행 신청
          </h1>
        </div>

        <div className="bg-white rounded-2xl border border-gray-100 p-5 space-y-3">
          <Field label="결제 번호 (paymentKey)" required>
            <input
              value={paymentKey}
              onChange={(e) => setPaymentKey(e.target.value)}
              placeholder="결제 영수증 메일에 포함됨"
              className="w-full px-3 py-2 border border-gray-200 rounded-lg text-sm font-mono"
            />
          </Field>
          <Field label="사업자등록번호" required>
            <input
              value={businessNo}
              onChange={(e) => setBusinessNo(e.target.value)}
              placeholder="123-45-67890 또는 1234567890"
              className="w-full px-3 py-2 border border-gray-200 rounded-lg text-sm font-mono"
            />
          </Field>
          <Field label="상호 (사업자명)" required>
            <input
              value={businessName}
              onChange={(e) => setBusinessName(e.target.value)}
              placeholder="(주)카페브레인"
              className="w-full px-3 py-2 border border-gray-200 rounded-lg text-sm"
            />
          </Field>
          <Field label="대표자명" required>
            <input
              value={representative}
              onChange={(e) => setRepresentative(e.target.value)}
              placeholder="홍길동"
              className="w-full px-3 py-2 border border-gray-200 rounded-lg text-sm"
            />
          </Field>
          <Field label="발행 이메일" required>
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full px-3 py-2 border border-gray-200 rounded-lg text-sm"
            />
          </Field>

          <button
            onClick={submit}
            disabled={submitting}
            className="w-full py-2.5 bg-[#2C1810] text-white rounded-xl text-sm font-semibold disabled:opacity-50 flex items-center justify-center gap-1.5"
          >
            {submitting ? <Loader2 size={14} className="animate-spin" /> : <FileText size={14} />}
            발행 신청
          </button>

          <p className="text-[10px] text-gray-400 leading-relaxed text-center">
            영업일 1~2일 내 발행 후 이메일로 발송됩니다. 부가세 10% 분리 표기.
          </p>
        </div>
      </div>
    </div>
  )
}

function Field({ label, required, children }: { label: string; required?: boolean; children: React.ReactNode }) {
  return (
    <div>
      <label className="text-xs font-semibold text-gray-600 mb-1 block">
        {label} {required && <span className="text-red-500">*</span>}
      </label>
      {children}
    </div>
  )
}
