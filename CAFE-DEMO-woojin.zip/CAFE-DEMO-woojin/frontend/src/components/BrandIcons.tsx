// 브랜드 SVG 아이콘 — 실제 브랜드 가이드라인 기반 재현
// lucide-react는 상표권 이슈로 브랜드 정확한 로고를 제공하지 않음.
// 여기서 직접 SVG로 그려서 카페 브레인 마케팅 페이지에 사용.
//
// 사용:
//   <InstagramIcon size={24} />
//   <BrandIcons.Instagram size={24} />  (또는 alias)
//
// 모든 아이콘:
//  - 24x24 viewBox 표준 (lucide와 호환)
//  - 라운드된 모서리 + 브랜드 그라디언트
//  - className으로 추가 스타일링 가능
import * as React from 'react'

interface BrandIconProps {
  size?: number
  className?: string
  ariaLabel?: string
}

// ─── Instagram (공식 8색 그라디언트) ─────────────────────
export function InstagramIcon({ size = 24, className, ariaLabel = 'Instagram' }: BrandIconProps) {
  const id = React.useId()
  return (
    <svg
      viewBox="0 0 24 24"
      width={size}
      height={size}
      className={className}
      role="img"
      aria-label={ariaLabel}
    >
      <defs>
        <radialGradient id={`ig-${id}`} cx="30%" cy="107%" r="150%">
          <stop offset="0%" stopColor="#FDF497" />
          <stop offset="5%" stopColor="#FDF497" />
          <stop offset="45%" stopColor="#FD5949" />
          <stop offset="60%" stopColor="#D6249F" />
          <stop offset="90%" stopColor="#285AEB" />
        </radialGradient>
      </defs>
      <rect x="2" y="2" width="20" height="20" rx="6" fill={`url(#ig-${id})`} />
      <rect
        x="6"
        y="6"
        width="12"
        height="12"
        rx="4"
        fill="none"
        stroke="white"
        strokeWidth="1.6"
      />
      <circle cx="12" cy="12" r="3.2" fill="none" stroke="white" strokeWidth="1.6" />
      <circle cx="17" cy="7" r="0.9" fill="white" />
    </svg>
  )
}

// ─── Instagram Story (카메라 + 그라디언트 링) ──────────
export function InstagramStoryIcon({ size = 24, className, ariaLabel = 'Instagram Story' }: BrandIconProps) {
  const id = React.useId()
  return (
    <svg
      viewBox="0 0 24 24"
      width={size}
      height={size}
      className={className}
      role="img"
      aria-label={ariaLabel}
    >
      <defs>
        <linearGradient id={`story-${id}`} x1="0%" y1="100%" x2="100%" y2="0%">
          <stop offset="0%" stopColor="#FEDA77" />
          <stop offset="35%" stopColor="#F58529" />
          <stop offset="65%" stopColor="#DD2A7B" />
          <stop offset="100%" stopColor="#8134AF" />
        </linearGradient>
      </defs>
      {/* 외곽 그라디언트 링 */}
      <circle cx="12" cy="12" r="10" fill="none" stroke={`url(#story-${id})`} strokeWidth="2" />
      {/* 안쪽 흰 링 */}
      <circle cx="12" cy="12" r="8" fill="none" stroke="white" strokeWidth="1" />
      {/* 카메라 본체 */}
      <rect x="6.5" y="8" width="11" height="9" rx="2" fill={`url(#story-${id})`} />
      <circle cx="12" cy="12.5" r="2.4" fill="white" />
      <circle cx="12" cy="12.5" r="1.4" fill={`url(#story-${id})`} />
    </svg>
  )
}

// ─── Threads (공식 로고 — 끊긴 @ 형태) ──────────────────
export function ThreadsIcon({ size = 24, className, ariaLabel = 'Threads' }: BrandIconProps) {
  return (
    <svg
      viewBox="0 0 24 24"
      width={size}
      height={size}
      className={className}
      fill="currentColor"
      role="img"
      aria-label={ariaLabel}
    >
      <path d="M12.186 24h-.007c-3.581-.024-6.334-1.205-8.184-3.509C2.35 18.44 1.5 15.586 1.472 12.01v-.017c.03-3.579.879-6.43 2.525-8.482C5.845 1.205 8.6.024 12.18 0h.014c2.746.02 5.043.725 6.826 2.098 1.677 1.29 2.858 3.13 3.509 5.467l-2.04.569c-1.104-3.96-3.898-5.984-8.304-6.015-2.91.022-5.11.936-6.54 2.717C4.307 6.504 3.616 8.914 3.589 12c.027 3.086.718 5.496 2.057 7.164 1.43 1.78 3.631 2.695 6.54 2.717 2.623-.02 4.358-.631 5.8-2.045 1.647-1.613 1.618-3.593 1.09-4.798-.31-.71-.873-1.3-1.634-1.75-.192 1.352-.622 2.446-1.284 3.272-.886 1.102-2.14 1.704-3.73 1.79-1.202.065-2.361-.218-3.259-.801-1.063-.689-1.685-1.74-1.752-2.964-.065-1.19.408-2.285 1.33-3.082.88-.76 2.119-1.207 3.583-1.291a13.853 13.853 0 0 1 3.02.142c-.126-.742-.375-1.332-.75-1.757-.513-.586-1.308-.883-2.359-.89h-.029c-.844 0-1.992.232-2.721 1.32L7.734 7.847c.98-1.454 2.568-2.256 4.478-2.256h.044c3.194.02 5.097 1.975 5.287 5.388.108.046.216.094.321.142 1.49.7 2.58 1.761 3.154 3.07.797 1.82.871 4.79-1.548 7.158-1.85 1.81-4.094 2.628-7.277 2.65zm1.003-11.69c-.242 0-.487.007-.739.021-1.836.103-2.98.946-2.916 2.143.067 1.256 1.452 1.839 2.784 1.767 1.224-.065 2.818-.543 3.086-3.71a10.5 10.5 0 0 0-2.215-.221z" />
    </svg>
  )
}

// ─── Naver (공식 그린 #03C75A) ──────────────────────────
export function NaverBlogIcon({ size = 24, className, ariaLabel = 'Naver Blog' }: BrandIconProps) {
  return (
    <svg
      viewBox="0 0 24 24"
      width={size}
      height={size}
      className={className}
      role="img"
      aria-label={ariaLabel}
    >
      <rect width="24" height="24" rx="5" fill="#03C75A" />
      <path
        d="M14.79 12.215 9.27 4.5H4.5v15h4.71v-7.715L14.73 19.5h4.77v-15h-4.71v7.715Z"
        fill="white"
      />
    </svg>
  )
}

// ─── KakaoTalk (공식 옐로우 #FEE500 + 갈색 말풍선) ──────
export function KakaoIcon({ size = 24, className, ariaLabel = 'KakaoTalk' }: BrandIconProps) {
  return (
    <svg
      viewBox="0 0 24 24"
      width={size}
      height={size}
      className={className}
      role="img"
      aria-label={ariaLabel}
    >
      <rect width="24" height="24" rx="5" fill="#FEE500" />
      <path
        d="M12 5.5c-4.418 0-8 2.846-8 6.357 0 2.272 1.5 4.265 3.762 5.379l-.71 2.6c-.07.255.213.46.434.314L10.534 18a10.97 10.97 0 0 0 1.466.094c4.418 0 8-2.847 8-6.358S16.418 5.5 12 5.5Z"
        fill="#3C1E1E"
      />
    </svg>
  )
}

// ─── YouTube Shorts (빨강 + 흰 ▶ + 텍스트 작은 S) ──────
export function YouTubeShortsIcon({ size = 24, className, ariaLabel = 'YouTube Shorts' }: BrandIconProps) {
  const id = React.useId()
  return (
    <svg
      viewBox="0 0 24 24"
      width={size}
      height={size}
      className={className}
      role="img"
      aria-label={ariaLabel}
    >
      <defs>
        <linearGradient id={`yt-${id}`} x1="50%" y1="0%" x2="50%" y2="100%">
          <stop offset="0%" stopColor="#FF4444" />
          <stop offset="100%" stopColor="#D40000" />
        </linearGradient>
      </defs>
      <rect width="24" height="24" rx="5" fill={`url(#yt-${id})`} />
      <path
        d="M9.5 7v10l7-5z"
        fill="white"
      />
      {/* Shorts 번개 */}
      <path
        d="M14.6 6.5l-2.6 4h2l-1 3 2.6-4h-2l1-3z"
        fill="white"
        opacity="0.85"
      />
    </svg>
  )
}

// ─── Poster (이미지 프레임 + 카페 브레인 카라멜) ─────────
export function PosterIcon({ size = 24, className, ariaLabel = 'Poster' }: BrandIconProps) {
  const id = React.useId()
  return (
    <svg
      viewBox="0 0 24 24"
      width={size}
      height={size}
      className={className}
      role="img"
      aria-label={ariaLabel}
    >
      <defs>
        <linearGradient id={`poster-${id}`} x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#F4C887" />
          <stop offset="100%" stopColor="#D4A574" />
        </linearGradient>
      </defs>
      <rect x="2" y="3" width="20" height="18" rx="3" fill={`url(#poster-${id})`} />
      <rect x="4.5" y="5.5" width="15" height="9" rx="1.5" fill="white" opacity="0.95" />
      {/* 산·달 풍경 */}
      <circle cx="16.5" cy="8.5" r="1.5" fill="#D4A574" />
      <path
        d="M5 14.5 L9 10 L12 13 L15 9 L19 14.5 Z"
        fill="#2C1810"
        opacity="0.85"
      />
      {/* 텍스트 라인 */}
      <rect x="4.5" y="16" width="9" height="1.2" rx="0.6" fill="white" opacity="0.9" />
      <rect x="4.5" y="18" width="6" height="1" rx="0.5" fill="white" opacity="0.7" />
    </svg>
  )
}

// ─── Brand Icons 묶음 (객체 접근용) ─────────────────────
export const BrandIcons = {
  Instagram: InstagramIcon,
  InstagramStory: InstagramStoryIcon,
  Threads: ThreadsIcon,
  NaverBlog: NaverBlogIcon,
  Kakao: KakaoIcon,
  YouTubeShorts: YouTubeShortsIcon,
  Poster: PosterIcon,
} as const
