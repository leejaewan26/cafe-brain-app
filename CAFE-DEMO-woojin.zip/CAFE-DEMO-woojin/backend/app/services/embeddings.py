"""
Phase 6 #4: Gemini Embeddings 래퍼 — 텍스트 → 768차원 벡터.

모델: text-embedding-004 (한국어 지원, 768d)
용도: agent_memory.content → embedding 컬럼

비용: 무료 한도 일 1500건 이내 (Gemini API). 메모리 INSERT 시 자동 생성.

폴백:
- API 실패·키 누락 시 None 반환
- memory_service가 embedding 없이도 INSERT 진행 (검색은 키워드만)
"""
import asyncio
from typing import Optional

import google.generativeai as genai

from app.config import settings


EMBEDDING_MODEL = "models/text-embedding-004"
EMBEDDING_DIMENSIONS = 768


async def generate_embedding(text: str) -> Optional[list[float]]:
    """
    텍스트 → 768d 벡터.

    Args:
        text: 임베딩 대상 (메모리 content 등). 8K 토큰 한도.

    Returns:
        [float, float, ...] 길이 768 또는 None (실패).
    """
    if not settings.gemini_api_key or not text or not text.strip():
        return None

    # 너무 길면 자르기 (모델 한도 + 비용 절감)
    truncated = text[:2000]

    def _sync_call() -> Optional[list[float]]:
        try:
            genai.configure(api_key=settings.gemini_api_key)
            result = genai.embed_content(
                model=EMBEDDING_MODEL,
                content=truncated,
                task_type="retrieval_document",
            )
            embedding = result.get("embedding")
            if embedding and len(embedding) == EMBEDDING_DIMENSIONS:
                return list(embedding)
        except Exception as e:
            print(f"[embeddings] 실패: {str(e)[:120]}")
        return None

    return await asyncio.to_thread(_sync_call)


async def generate_query_embedding(query: str) -> Optional[list[float]]:
    """
    검색 쿼리용 임베딩 (task_type='retrieval_query' — document와 다름).
    Gemini Embeddings는 query/document 별로 최적화된 벡터를 만듦.
    """
    if not settings.gemini_api_key or not query or not query.strip():
        return None

    def _sync_call() -> Optional[list[float]]:
        try:
            genai.configure(api_key=settings.gemini_api_key)
            result = genai.embed_content(
                model=EMBEDDING_MODEL,
                content=query[:1000],
                task_type="retrieval_query",
            )
            embedding = result.get("embedding")
            if embedding and len(embedding) == EMBEDDING_DIMENSIONS:
                return list(embedding)
        except Exception as e:
            print(f"[embeddings] query 실패: {str(e)[:120]}")
        return None

    return await asyncio.to_thread(_sync_call)
