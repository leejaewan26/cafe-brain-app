"""
결제·구독 라우터 (Day 3-1)

토스페이먼츠 Payment Widget 연동 + 7일 무료 체험 → 월 구독 전환.

플로우:
  1. 가입 시 자동으로 trial_ends_at = now + 7일 부여
  2. /billing 에서 월/연 플랜 선택 → POST /api/billing/checkout → clientKey 반환
  3. 프론트 토스 Widget으로 카드 등록 → 토스가 authKey 반환
  4. 프론트 POST /api/billing/confirm {authKey, customerKey, amount}
  5. 서버가 토스 API 호출로 결제 확정 → subscriptions row 생성
  6. 이후 매달 /api/billing/cron/charge (pg_cron) 로 자동 결제

MVP 범위 (Day 3-1):
  ✅ clientKey 발급 + checkout 메타
  ✅ 구독 상태 조회 (/subscription)
  ⚠️ 실제 billingKey 호출은 토스 테스트 환경 키 필요 — mock 구현 (프로덕션 스위치)

설계 원칙:
  - 민감한 billingKey는 Supabase subscriptions 테이블의 서비스 키 영역에만 저장
  - 멱등성: 동일 customerKey + orderId 재요청 시 기존 결과 반환
  - 환불·해지 정책은 별도 이슈
"""
import asyncio
import base64
import hashlib
import hmac
import json
import logging
import os
import uuid
from datetime import datetime, timedelta, timezone
from typing import Any, Literal, Optional

import httpx
from fastapi import APIRouter, BackgroundTasks, Header, HTTPException, Request
from pydantic import BaseModel, Field

from app.services.email_service import (
    send_payment_success_email,
    send_welcome_email,
    send_trial_expiring_email,
    get_store_email,
)
from app.services.gemini_service import _get_supabase

logger = logging.getLogger("billing")

router = APIRouter()

# H1 — 14일 무료 체험
TRIAL_DAYS = 14


# ═══════════════════════════════════════════════════════
# 스키마
# ═══════════════════════════════════════════════════════

PlanId = Literal["monthly", "yearly"]


class Plan(BaseModel):
    id: PlanId
    name: str
    price_krw: int
    description: str
    features: list[str]
    recommended: bool = False
    discount_percent: int = 0


# 플랜 카탈로그 (단일 소스 진실)
PLANS: dict[str, Plan] = {
    "monthly": Plan(
        id="monthly",
        name="월 구독",
        price_krw=30000,
        description="매월 자동 결제. 언제든 해지 가능",
        features=[
            "AI 매출 분석 (월 1000회)",
            "리뷰 자동 답글 무제한",
            "SNS 마케팅 카피 생성",
            "영수증 OCR 자동 입력",
            "멀티 프로필 (최대 3명)",
            "다크모드 · 인쇄 · PDF 내보내기",
        ],
    ),
    "yearly": Plan(
        id="yearly",
        name="연 구독 (17% 할인)",
        price_krw=300000,
        description="1년치 한 번에 결제. 월 평균 25,000원",
        features=[
            "월 구독 전체 혜택 +",
            "우선 고객 지원 (24시간 내)",
            "베타 기능 선출시 체험",
            "연 2회 1:1 운영 컨설팅",
        ],
        recommended=True,
        discount_percent=17,
    ),
}


class CheckoutRequest(BaseModel):
    plan_id: PlanId
    store_id: str = Field(..., min_length=1, max_length=80)
    customer_email: str
    customer_name: str


class CheckoutResponse(BaseModel):
    order_id: str
    amount: int
    plan_name: str
    client_key: str
    customer_key: str
    success_url: str
    fail_url: str


class ConfirmRequest(BaseModel):
    order_id: str
    payment_key: str
    amount: int


class ConfirmResponse(BaseModel):
    success: bool
    subscription_id: str
    status: Literal["active", "trial", "failed"]
    next_billing_at: Optional[str] = None


class SubscriptionStatus(BaseModel):
    store_id: str
    status: Literal["trial", "active", "past_due", "canceled", "none"]
    plan_id: Optional[PlanId] = None
    trial_ends_at: Optional[str] = None
    current_period_end: Optional[str] = None
    days_remaining: int = 0
    can_upgrade: bool = True


# ═══════════════════════════════════════════════════════
# 엔드포인트
# ═══════════════════════════════════════════════════════


@router.get("/plans", response_model=list[Plan])
async def list_plans():
    """가능한 요금제 목록 — 가격표·설정 화면·랜딩페이지에서 조회."""
    return list(PLANS.values())


@router.post("/checkout", response_model=CheckoutResponse)
async def create_checkout(req: CheckoutRequest):
    """
    결제 세션 생성 — 토스 Payment Widget 로드에 필요한 메타데이터 반환.

    프론트는 이 응답을 받아:
      window.TossPayments(client_key).widgets({customerKey}).renderPaymentMethods()
    """
    plan = PLANS.get(req.plan_id)
    if not plan:
        raise HTTPException(400, f"알 수 없는 플랜: {req.plan_id}")

    # 토스 클라이언트 키 (환경변수, 없으면 테스트 키)
    client_key = os.getenv(
        "TOSS_CLIENT_KEY",
        "test_ck_docs_Ovk5rk1EwkEbP0W43n07xlzm",  # 공식 테스트 키
    )

    # 멱등한 주문 ID (store_id + plan + 날짜)
    today = datetime.now(timezone.utc).strftime("%Y%m%d")
    order_id = f"cb_{today}_{req.store_id[:8]}_{req.plan_id}_{uuid.uuid4().hex[:6]}"

    # 고객 키 — 매장별 고유 (빌링키 발급용)
    customer_key = f"cust_{req.store_id}"

    # 성공·실패 리다이렉트 (프론트 경로)
    base_url = os.getenv("APP_BASE_URL", "https://cafebrain.app")

    return CheckoutResponse(
        order_id=order_id,
        amount=plan.price_krw,
        plan_name=plan.name,
        client_key=client_key,
        customer_key=customer_key,
        success_url=f"{base_url}/billing/success?plan={req.plan_id}",
        fail_url=f"{base_url}/billing/fail",
    )


@router.post("/confirm", response_model=ConfirmResponse)
async def confirm_payment(req: ConfirmRequest):
    """
    토스 결제 확정 — 프론트에서 widget.requestPayment() 성공 후 호출.

    실제 구현:
      POST https://api.tosspayments.com/v1/payments/confirm
      Authorization: Basic base64(SECRET_KEY:)
      { paymentKey, orderId, amount }

    여기서는 토스 시크릿 키 없이 동작하도록 mock — 프로덕션은 TOSS_SECRET_KEY 설정 시 실 호출.
    """
    secret_key = os.getenv("TOSS_SECRET_KEY", "")

    if not secret_key:
        # MVP mock: 금액·주문ID 검증만 통과시키고 성공 응답
        next_at = (datetime.now(timezone.utc) + timedelta(days=30)).isoformat()
        return ConfirmResponse(
            success=True,
            subscription_id=f"sub_mock_{req.order_id}",
            status="active",
            next_billing_at=next_at,
        )

    # 프로덕션: 실제 토스 API 호출
    import base64
    import httpx
    auth = base64.b64encode(f"{secret_key}:".encode()).decode()
    async with httpx.AsyncClient(timeout=10.0) as client:
        resp = await client.post(
            "https://api.tosspayments.com/v1/payments/confirm",
            headers={"Authorization": f"Basic {auth}", "Content-Type": "application/json"},
            json={
                "paymentKey": req.payment_key,
                "orderId": req.order_id,
                "amount": req.amount,
            },
        )
        if resp.status_code >= 400:
            raise HTTPException(resp.status_code, detail=resp.json())
        data = resp.json()

    next_at = (datetime.now(timezone.utc) + timedelta(days=30)).isoformat()
    return ConfirmResponse(
        success=True,
        subscription_id=data.get("orderId", req.order_id),
        status="active",
        next_billing_at=next_at,
    )


@router.get("/subscription/{store_id}", response_model=SubscriptionStatus)
async def get_subscription(store_id: str):
    """
    매장의 현재 구독 상태 조회 (H1 — Supabase 영속).

    우선순위:
      1. subscriptions 테이블 active row → active/past_due
      2. stores.subscription_status 컬럼 → trial 등
      3. stores.created_at 기준 14일 이내 → trial
      4. 그 외 → none

    Supabase 미설정 시 graceful degrade: stores.created_at 기반 trial 추정.
    """
    sb = _get_supabase()
    now = datetime.now(timezone.utc)

    # 1) 활성 구독 조회
    if sb is not None:
        try:
            sub_res = await asyncio.to_thread(
                lambda: sb.table("subscriptions")
                .select("*")
                .eq("store_id", store_id)
                .in_("status", ["active", "past_due"])
                .order("created_at", desc=True)
                .limit(1)
                .execute()
            )
            sub_rows = sub_res.data or []
            if sub_rows:
                sub = sub_rows[0]
                next_at = sub.get("next_billing_at")
                days = 0
                if next_at:
                    try:
                        next_dt = datetime.fromisoformat(next_at.replace("Z", "+00:00"))
                        days = max(0, (next_dt - now).days)
                    except Exception:
                        pass
                return SubscriptionStatus(
                    store_id=store_id,
                    status=sub.get("status", "active"),
                    plan_id=sub.get("plan_id"),
                    current_period_end=next_at,
                    days_remaining=days,
                    can_upgrade=False,
                )
        except Exception as e:
            logger.warning("subscriptions 조회 실패: %s", e)

    # 2) stores.created_at 기반 trial
    if sb is not None:
        try:
            store_res = await asyncio.to_thread(
                lambda: sb.table("stores")
                .select("created_at, trial_ends_at, subscription_status")
                .eq("id", store_id)
                .limit(1)
                .single()
                .execute()
            )
            row = store_res.data or {}
            # trial_ends_at 컬럼 우선
            trial_end_str = row.get("trial_ends_at")
            if not trial_end_str and row.get("created_at"):
                created = datetime.fromisoformat(row["created_at"].replace("Z", "+00:00"))
                trial_end_dt = created + timedelta(days=TRIAL_DAYS)
                trial_end_str = trial_end_dt.isoformat()
            if trial_end_str:
                trial_end_dt = datetime.fromisoformat(trial_end_str.replace("Z", "+00:00"))
                days = max(0, (trial_end_dt - now).days)
                if days > 0:
                    return SubscriptionStatus(
                        store_id=store_id,
                        status="trial",
                        trial_ends_at=trial_end_str,
                        days_remaining=days,
                        can_upgrade=True,
                    )
        except Exception as e:
            logger.debug("stores 조회 실패: %s", e)

    # 3) fallback (Supabase 미연결 등)
    return SubscriptionStatus(
        store_id=store_id,
        status="none",
        days_remaining=0,
        can_upgrade=True,
    )


# ═══════════════════════════════════════════════════════
# H1 — 빌링키 발급 + 자동 정기결제
# ═══════════════════════════════════════════════════════


class BillingKeyRequest(BaseModel):
    """프론트 → 토스 카드 등록 후 받은 authKey로 빌링키 발급."""
    store_id: str = Field(..., min_length=1)
    auth_key: str
    customer_key: str
    plan_id: PlanId = "monthly"


async def _toss_post(path: str, body: dict, secret_key: str) -> dict[str, Any]:
    """토스 API POST helper. Basic Auth = base64(secret_key:)."""
    auth = base64.b64encode(f"{secret_key}:".encode()).decode()
    async with httpx.AsyncClient(timeout=15.0) as client:
        r = await client.post(
            f"https://api.tosspayments.com{path}",
            headers={
                "Authorization": f"Basic {auth}",
                "Content-Type": "application/json",
            },
            json=body,
        )
        if r.status_code >= 400:
            try:
                err = r.json()
            except Exception:
                err = {"message": r.text[:200]}
            raise HTTPException(r.status_code, detail=err)
        return r.json()


@router.post("/issue-billing-key")
async def issue_billing_key(req: BillingKeyRequest):
    """
    토스 카드 등록 위젯 성공 후 발급받은 authKey로 빌링키 발급 + 첫 결제 + 구독 영속.

    실제 호출:
      POST /v1/billing/authorizations/issue
      body: { authKey, customerKey }
    """
    plan = PLANS.get(req.plan_id)
    if not plan:
        raise HTTPException(400, f"잘못된 플랜: {req.plan_id}")

    secret_key = os.getenv("TOSS_SECRET_KEY", "")

    # ─── Mock 모드 (시크릿 없을 때) ───
    if not secret_key:
        billing_key = f"mock_billing_{uuid.uuid4().hex[:16]}"
        sub_id = await _persist_subscription(
            store_id=req.store_id,
            plan_id=req.plan_id,
            billing_key=billing_key,
            customer_key=req.customer_key,
            amount=plan.price_krw,
        )
        return {
            "success": True,
            "subscription_id": sub_id,
            "billing_key_masked": billing_key[:12] + "***",
            "next_billing_at": (datetime.now(timezone.utc) + timedelta(days=30)).isoformat(),
            "mode": "mock",
        }

    # ─── 실 호출 ───
    issued = await _toss_post(
        "/v1/billing/authorizations/issue",
        {"authKey": req.auth_key, "customerKey": req.customer_key},
        secret_key,
    )
    billing_key = issued["billingKey"]

    # 첫 결제 즉시
    order_id = f"first_{uuid.uuid4().hex[:12]}"
    paid = await _toss_post(
        f"/v1/billing/{billing_key}",
        {
            "customerKey": req.customer_key,
            "amount": plan.price_krw,
            "orderId": order_id,
            "orderName": f"카페 브레인 {plan.name}",
        },
        secret_key,
    )

    sub_id = await _persist_subscription(
        store_id=req.store_id,
        plan_id=req.plan_id,
        billing_key=billing_key,
        customer_key=req.customer_key,
        amount=plan.price_krw,
        last_payment_id=paid.get("paymentKey"),
    )

    # 영수증 메일 (실패해도 무시)
    try:
        info = await get_store_email(req.store_id)
        if info:
            email, name = info
            await send_payment_success_email(email, name, plan.price_krw, plan.name)
    except Exception as e:
        logger.warning("영수증 메일 발송 실패: %s", e)

    return {
        "success": True,
        "subscription_id": sub_id,
        "billing_key_masked": billing_key[:12] + "***",
        "next_billing_at": (datetime.now(timezone.utc) + timedelta(days=30)).isoformat(),
        "first_payment_amount": plan.price_krw,
        "mode": "production",
    }


async def _persist_subscription(
    store_id: str,
    plan_id: str,
    billing_key: str,
    customer_key: str,
    amount: int,
    last_payment_id: Optional[str] = None,
) -> str:
    """subscriptions 테이블에 row 저장 (upsert)."""
    sb = _get_supabase()
    if sb is None:
        # Supabase 없으면 in-memory return
        return f"sub_local_{uuid.uuid4().hex[:8]}"

    sub_id = str(uuid.uuid4())
    next_billing = (datetime.now(timezone.utc) + timedelta(days=30)).isoformat()
    row = {
        "id": sub_id,
        "store_id": store_id,
        "plan_id": plan_id,
        "billing_key": billing_key,
        "customer_key": customer_key,
        "amount_krw": amount,
        "status": "active",
        "current_period_start": datetime.now(timezone.utc).isoformat(),
        "next_billing_at": next_billing,
        "last_payment_id": last_payment_id,
        "created_at": datetime.now(timezone.utc).isoformat(),
    }
    try:
        await asyncio.to_thread(lambda: sb.table("subscriptions").insert(row).execute())
        # stores.subscription_status도 동기화
        await asyncio.to_thread(
            lambda: sb.table("stores")
            .update({"subscription_status": "active"})
            .eq("id", store_id)
            .execute()
        )
    except Exception as e:
        logger.warning("subscriptions insert 실패: %s", e)
    return sub_id


# ═══════════════════════════════════════════════════════
# H1 — Webhook (토스 → 우리 서버, 결제 상태 변경 알림)
# ═══════════════════════════════════════════════════════


def _verify_toss_signature(raw_body: bytes, signature: str, webhook_secret: str) -> bool:
    """토스 웹훅 서명 검증 (HMAC-SHA256)."""
    if not webhook_secret:
        return True  # 시크릿 미설정 시 검증 패스 (개발용)
    expected = hmac.new(
        webhook_secret.encode(), raw_body, hashlib.sha256
    ).hexdigest()
    return hmac.compare_digest(expected, signature.lower())


@router.post("/webhook")
async def toss_webhook(
    request: Request,
    bg: BackgroundTasks,
    signature: str = Header(default="", alias="TossPayments-Signature"),
):
    """
    토스 웹훅 수신.

    이벤트 종류 (eventType):
      - PAYMENT_STATUS_CHANGED: DONE / CANCELED / FAILED
      - BILLING_AUTH_ISSUED
      - DEPOSIT_CALLBACK (가상계좌)

    빠르게 200 응답 + 무거운 처리는 백그라운드.
    """
    raw = await request.body()
    webhook_secret = os.getenv("TOSS_WEBHOOK_SECRET", "")
    if signature and not _verify_toss_signature(raw, signature, webhook_secret):
        raise HTTPException(401, "서명 불일치")

    try:
        payload = json.loads(raw.decode("utf-8"))
    except Exception:
        raise HTTPException(400, "JSON 파싱 실패")

    bg.add_task(_handle_webhook_event, payload)
    return {"received": True}


async def _handle_webhook_event(payload: dict[str, Any]) -> None:
    """웹훅 이벤트 처리 (백그라운드)."""
    event_type = payload.get("eventType") or payload.get("type") or "UNKNOWN"
    data = payload.get("data") or {}

    sb = _get_supabase()
    if sb is None:
        logger.info("webhook %s: Supabase 미설정 — 스킵", event_type)
        return

    try:
        if event_type in ("PAYMENT_STATUS_CHANGED", "PAYMENT.DONE"):
            status = data.get("status", "DONE")
            order_id = data.get("orderId")
            payment_key = data.get("paymentKey")
            amount = data.get("totalAmount") or data.get("amount") or 0

            # subscriptions.last_payment_id 매칭하여 상태 갱신
            new_status = "active" if status == "DONE" else "past_due" if status == "FAILED" else "canceled"
            if payment_key:
                await asyncio.to_thread(
                    lambda: sb.table("subscriptions")
                    .update({"status": new_status, "updated_at": datetime.now(timezone.utc).isoformat()})
                    .eq("last_payment_id", payment_key)
                    .execute()
                )
            # 결제 이력 별도 테이블
            await asyncio.to_thread(
                lambda: sb.table("billing_events").insert({
                    "id": str(uuid.uuid4()),
                    "event_type": event_type,
                    "status": status,
                    "order_id": order_id,
                    "payment_key": payment_key,
                    "amount_krw": amount,
                    "raw": payload,
                    "created_at": datetime.now(timezone.utc).isoformat(),
                }).execute()
            )
            logger.info("webhook %s 처리: status=%s order=%s", event_type, status, order_id)
        else:
            # 그 외는 로그만
            await asyncio.to_thread(
                lambda: sb.table("billing_events").insert({
                    "id": str(uuid.uuid4()),
                    "event_type": event_type,
                    "raw": payload,
                    "created_at": datetime.now(timezone.utc).isoformat(),
                }).execute()
            )
    except Exception as e:
        logger.error("webhook 처리 예외 %s: %s", event_type, e)


# ═══════════════════════════════════════════════════════
# H1 — 정기결제 cron (pg_cron 또는 외부 스케줄러가 매일 호출)
# ═══════════════════════════════════════════════════════


@router.post("/cron/charge")
async def cron_recurring_charge(
    cron_key: str = Header(default="", alias="X-Cron-Key"),
):
    """
    매일 호출 — next_billing_at <= now 인 active 구독을 자동 결제.

    보호: X-Cron-Key 헤더가 settings.agent_admin_key 와 일치해야 함.
    """
    expected = os.getenv("CRON_SECRET", "") or os.getenv("AGENT_ADMIN_KEY", "")
    if not expected or cron_key != expected:
        raise HTTPException(403, "cron 권한 없음")

    sb = _get_supabase()
    if sb is None:
        return {"charged": 0, "note": "Supabase 미설정"}

    now = datetime.now(timezone.utc)
    secret_key = os.getenv("TOSS_SECRET_KEY", "")

    # 1) canceling 상태 — 다음 결제일 도래 시 결제 안 하고 canceled로 전환 (H1 critical bug fix)
    canceling_res = await asyncio.to_thread(
        lambda: sb.table("subscriptions")
        .select("*")
        .eq("status", "canceling")
        .lte("next_billing_at", now.isoformat())
        .execute()
    )
    canceling_subs = canceling_res.data or []
    canceled_count = 0
    for sub in canceling_subs:
        await asyncio.to_thread(
            lambda s=sub: sb.table("subscriptions")
            .update({"status": "canceled"})
            .eq("id", s["id"])
            .execute()
        )
        await asyncio.to_thread(
            lambda s=sub: sb.table("stores")
            .update({"subscription_status": "canceled"})
            .eq("id", s["store_id"])
            .execute()
        )
        canceled_count += 1

    # 2) active 상태 — 결제 도래분
    res = await asyncio.to_thread(
        lambda: sb.table("subscriptions")
        .select("*")
        .eq("status", "active")
        .lte("next_billing_at", now.isoformat())
        .limit(100)
        .execute()
    )
    subs = res.data or []
    succeeded = 0
    failed = 0

    for sub in subs:
        try:
            order_id = f"recurring_{uuid.uuid4().hex[:12]}"
            if secret_key:
                # 실 결제
                payment_res = await _toss_post(
                    f"/v1/billing/{sub['billing_key']}",
                    {
                        "customerKey": sub["customer_key"],
                        "amount": sub["amount_krw"],
                        "orderId": order_id,
                        "orderName": "카페 브레인 정기결제",
                    },
                    secret_key,
                )
                last_payment_id = payment_res.get("paymentKey")
            else:
                last_payment_id = f"mock_{order_id}"
            # next_billing_at 30일 뒤로 + last_payment_id 갱신
            next_at = (now + timedelta(days=30)).isoformat()
            await asyncio.to_thread(
                lambda s=sub, na=next_at, lpi=last_payment_id: sb.table("subscriptions")
                .update({
                    "next_billing_at": na,
                    "current_period_start": now.isoformat(),
                    "last_payment_id": lpi,
                })
                .eq("id", s["id"])
                .execute()
            )
            # 영수증 메일
            try:
                from app.routers.billing import PLANS as _PLANS  # noqa
                info = await get_store_email(sub["store_id"])
                if info:
                    email, name = info
                    plan_name = _PLANS.get(sub["plan_id"]).name if sub["plan_id"] in _PLANS else sub["plan_id"]
                    await send_payment_success_email(email, name, sub["amount_krw"], plan_name)
            except Exception:
                pass
            succeeded += 1
        except Exception as e:
            logger.error("정기결제 실패 sub=%s: %s", sub.get("id"), e)
            await asyncio.to_thread(
                lambda s=sub: sb.table("subscriptions")
                .update({"status": "past_due"})
                .eq("id", s["id"])
                .execute()
            )
            failed += 1

    return {
        "charged": succeeded,
        "failed": failed,
        "total_due": len(subs),
        "auto_canceled": canceled_count,
    }


# ═══════════════════════════════════════════════════════
# H1 — 해지
# ═══════════════════════════════════════════════════════


class CancelRequest(BaseModel):
    store_id: str
    reason: Optional[str] = None


# ═══════════════════════════════════════════════════════
# K1 — 결제 환불 (Toss /v1/payments/{paymentKey}/cancel)
# ═══════════════════════════════════════════════════════


class RefundRequest(BaseModel):
    payment_key: str
    cancel_reason: str = Field(..., min_length=2, max_length=200)
    cancel_amount: Optional[int] = None  # 부분 환불 (없으면 전액)
    store_id: str  # 권한 검증용


class RefundResponse(BaseModel):
    refunded: bool
    amount_refunded: int
    cancel_amount: Optional[int]
    payment_key: str
    note: str


@router.post("/refund", response_model=RefundResponse)
async def refund_payment(req: RefundRequest):
    """
    K1 — Toss 결제 환불.

    정책 (한국 전자상거래법):
      - 결제 후 7일 이내: 100% 환불 가능
      - 7~30일: 사용분 차감 후 환불 (월 구독은 일할 계산)
      - 30일 이후: 환불 불가 (다음 결제 해지만 가능)

    실제 호출:
      POST /v1/payments/{paymentKey}/cancel
      body: { cancelReason, cancelAmount? }
    """
    sb = _get_supabase()
    if sb is None:
        raise HTTPException(503, "Supabase 미설정")

    # 1) 권한 검증 — 본인 매장 결제만 환불 가능
    payment_check = await asyncio.to_thread(
        lambda: sb.table("subscriptions")
        .select("id, store_id, amount_krw, current_period_start")
        .eq("last_payment_id", req.payment_key)
        .eq("store_id", req.store_id)
        .limit(1)
        .single()
        .execute()
    )
    sub_row = payment_check.data
    if not sub_row:
        raise HTTPException(404, "해당 결제를 찾을 수 없거나 권한이 없습니다")

    # 2) 환불 가능 기간 검증 (7일 이내 100% / 30일 이내 부분)
    period_start = datetime.fromisoformat(sub_row["current_period_start"].replace("Z", "+00:00"))
    days_since = (datetime.now(timezone.utc) - period_start).days
    if days_since > 30:
        raise HTTPException(400, "결제 후 30일 이내만 환불 가능합니다")

    # 3) 부분 환불 금액 자동 계산 (요청 없으면)
    full_amount = int(sub_row["amount_krw"])
    if req.cancel_amount is None:
        if days_since <= 7:
            cancel_amount = full_amount
        else:
            # 일할 계산 — 사용분 차감
            used = (days_since / 30) * full_amount
            cancel_amount = max(0, int(full_amount - used))
    else:
        cancel_amount = req.cancel_amount
        if cancel_amount > full_amount:
            raise HTTPException(400, "환불 금액이 결제 금액을 초과합니다")

    # 4) Toss 호출
    secret_key = os.getenv("TOSS_SECRET_KEY", "")
    if not secret_key:
        # Mock — 로그만
        logger.info("MOCK 환불: payment=%s amount=%s", req.payment_key, cancel_amount)
        ok = True
    else:
        try:
            await _toss_post(
                f"/v1/payments/{req.payment_key}/cancel",
                {
                    "cancelReason": req.cancel_reason[:200],
                    "cancelAmount": cancel_amount,
                },
                secret_key,
            )
            ok = True
        except HTTPException:
            raise
        except Exception as e:
            raise HTTPException(500, f"환불 호출 실패: {str(e)[:100]}")

    # 5) DB 업데이트 — 전액 환불이면 canceled, 부분이면 active 유지
    new_status = "canceled" if cancel_amount >= full_amount else "active"
    await asyncio.to_thread(
        lambda: sb.table("subscriptions")
        .update({"status": new_status, "canceled_at": datetime.now(timezone.utc).isoformat()})
        .eq("id", sub_row["id"])
        .execute()
    )
    # 감사
    await asyncio.to_thread(
        lambda: sb.table("billing_events").insert({
            "id": str(uuid.uuid4()),
            "event_type": "REFUND",
            "payment_key": req.payment_key,
            "amount_krw": cancel_amount,
            "raw": {"reason": req.cancel_reason, "days_since": days_since},
            "created_at": datetime.now(timezone.utc).isoformat(),
        }).execute()
    )

    return RefundResponse(
        refunded=ok,
        amount_refunded=cancel_amount,
        cancel_amount=cancel_amount,
        payment_key=req.payment_key,
        note=f"{cancel_amount:,}원 환불됨 (결제 후 {days_since}일 경과)",
    )


# ═══════════════════════════════════════════════════════
# K2 — Dunning (결제 실패 후 재시도 cron)
# ═══════════════════════════════════════════════════════


@router.post("/cron/dunning")
async def cron_dunning(
    cron_key: str = Header(default="", alias="X-Cron-Key"),
):
    """
    past_due 상태 구독의 결제 자동 재시도.

    스케줄: 매일 호출.
    재시도: past_due 진입 후 1, 3, 7일에 시도. 모두 실패 시 canceled.
    """
    expected = os.getenv("CRON_SECRET", "") or os.getenv("AGENT_ADMIN_KEY", "") or settings.agent_admin_key
    if cron_key != expected:
        raise HTTPException(403, "권한 없음")

    sb = _get_supabase()
    if sb is None:
        raise HTTPException(503, "Supabase 미설정")

    secret_key = os.getenv("TOSS_SECRET_KEY", "")
    now = datetime.now(timezone.utc)

    # past_due 진입 후 N일 (next_billing_at에서 N일 경과한 것)
    res = await asyncio.to_thread(
        lambda: sb.table("subscriptions")
        .select("*")
        .eq("status", "past_due")
        .limit(200)
        .execute()
    )
    subs = res.data or []
    retried = 0
    succeeded = 0
    final_canceled = 0

    for sub in subs:
        try:
            next_at = datetime.fromisoformat(sub["next_billing_at"].replace("Z", "+00:00"))
            days_overdue = (now - next_at).days
            # 1, 3, 7일에 재시도 (그 외 날엔 skip)
            if days_overdue not in (1, 3, 7) and days_overdue < 7:
                continue

            if days_overdue > 7:
                # 8일 이상 — 최종 해지
                await asyncio.to_thread(
                    lambda s=sub: sb.table("subscriptions")
                    .update({"status": "canceled", "canceled_at": now.isoformat(),
                             "cancel_reason": "결제 실패 8일 — 자동 해지"})
                    .eq("id", s["id"])
                    .execute()
                )
                await asyncio.to_thread(
                    lambda s=sub: sb.table("stores")
                    .update({"subscription_status": "canceled"})
                    .eq("id", s["store_id"])
                    .execute()
                )
                final_canceled += 1
                continue

            # 재시도
            order_id = f"dunning_{uuid.uuid4().hex[:12]}"
            if secret_key:
                payment_res = await _toss_post(
                    f"/v1/billing/{sub['billing_key']}",
                    {
                        "customerKey": sub["customer_key"],
                        "amount": sub["amount_krw"],
                        "orderId": order_id,
                        "orderName": "카페 브레인 정기결제 (재시도)",
                    },
                    secret_key,
                )
                last_pid = payment_res.get("paymentKey")
            else:
                last_pid = f"mock_{order_id}"
            # 성공 — active 복귀
            new_next = (now + timedelta(days=30)).isoformat()
            await asyncio.to_thread(
                lambda s=sub, na=new_next, lpi=last_pid: sb.table("subscriptions")
                .update({
                    "status": "active",
                    "next_billing_at": na,
                    "last_payment_id": lpi,
                    "current_period_start": now.isoformat(),
                })
                .eq("id", s["id"])
                .execute()
            )
            succeeded += 1
            retried += 1
        except Exception as e:
            logger.warning("dunning 재시도 실패 sub=%s: %s", sub.get("id"), e)
            retried += 1

    return {
        "retried": retried,
        "succeeded": succeeded,
        "final_canceled": final_canceled,
        "past_due_total": len(subs),
    }


# ═══════════════════════════════════════════════════════
# K3 — 카드 정보 변경 (기존 빌링키 폐기 후 신규 발급)
# ═══════════════════════════════════════════════════════


class UpdateCardRequest(BaseModel):
    store_id: str
    auth_key: str  # 새 카드 등록 위젯 결과
    customer_key: str


@router.post("/update-card")
async def update_card(req: UpdateCardRequest):
    """
    카드 변경 — 새 카드 등록 → 신규 빌링키 발급 → 기존 active 구독에 교체.

    절차:
      1. 새 authKey로 빌링키 발급
      2. 기존 active 구독 row의 billing_key를 새 것으로 교체
      3. 기존 빌링키는 별도 invalidate (Toss는 자동 — 한 customer_key당 활성 1개)
    """
    sb = _get_supabase()
    if sb is None:
        raise HTTPException(503, "Supabase 미설정")

    secret_key = os.getenv("TOSS_SECRET_KEY", "")

    if not secret_key:
        # Mock
        new_billing_key = f"mock_billing_{uuid.uuid4().hex[:16]}"
    else:
        issued = await _toss_post(
            "/v1/billing/authorizations/issue",
            {"authKey": req.auth_key, "customerKey": req.customer_key},
            secret_key,
        )
        new_billing_key = issued["billingKey"]

    # 기존 active subscription 갱신
    res = await asyncio.to_thread(
        lambda: sb.table("subscriptions")
        .update({"billing_key": new_billing_key, "updated_at": datetime.now(timezone.utc).isoformat()})
        .eq("store_id", req.store_id)
        .in_("status", ["active", "past_due"])
        .execute()
    )
    rows_updated = len(res.data or [])
    if rows_updated == 0:
        raise HTTPException(400, "활성 구독이 없습니다 — 신규 가입을 사용하세요")

    # past_due였으면 active로 복귀 + 즉시 결제
    pd_res = await asyncio.to_thread(
        lambda: sb.table("subscriptions")
        .select("id, amount_krw, customer_key")
        .eq("store_id", req.store_id)
        .eq("status", "past_due")
        .execute()
    )
    for sub in (pd_res.data or []):
        try:
            order_id = f"card_update_charge_{uuid.uuid4().hex[:12]}"
            if secret_key:
                await _toss_post(
                    f"/v1/billing/{new_billing_key}",
                    {
                        "customerKey": sub["customer_key"],
                        "amount": sub["amount_krw"],
                        "orderId": order_id,
                        "orderName": "카페 브레인 — 카드 변경 후 즉시 결제",
                    },
                    secret_key,
                )
            await asyncio.to_thread(
                lambda s=sub: sb.table("subscriptions")
                .update({"status": "active"})
                .eq("id", s["id"])
                .execute()
            )
        except Exception:
            pass

    return {
        "card_updated": True,
        "billing_key_masked": new_billing_key[:12] + "***",
        "rows_updated": rows_updated,
    }


# ═══════════════════════════════════════════════════════
# K4 — 세금계산서 / 현금영수증
# ═══════════════════════════════════════════════════════


class TaxInvoiceRequest(BaseModel):
    store_id: str
    payment_key: str
    business_no: str = Field(..., pattern=r"^\d{3}-\d{2}-\d{5}$|^\d{10}$")
    business_name: str
    representative: str
    tax_invoice_email: str


@router.post("/tax-invoice/request")
async def request_tax_invoice(req: TaxInvoiceRequest):
    """
    세금계산서 발행 요청.

    실제 발행은 외부 솔루션 (popbill, kakao 정산, 빌게이트 등).
    여기선 Supabase에 요청 row만 저장 — 운영자가 처리하거나 popbill API로 자동화 가능.
    """
    sb = _get_supabase()
    if sb is None:
        raise HTTPException(503, "Supabase 미설정")

    # 결제 본인 검증
    pay_res = await asyncio.to_thread(
        lambda: sb.table("subscriptions")
        .select("amount_krw")
        .eq("last_payment_id", req.payment_key)
        .eq("store_id", req.store_id)
        .single()
        .execute()
    )
    if not pay_res.data:
        raise HTTPException(404, "결제를 찾을 수 없습니다")

    amount = int(pay_res.data["amount_krw"])
    supply_amount = int(amount / 1.1)  # VAT 분리
    vat = amount - supply_amount

    row = {
        "id": str(uuid.uuid4()),
        "store_id": req.store_id,
        "payment_key": req.payment_key,
        "business_no": re.sub(r"\D", "", req.business_no),
        "business_name": req.business_name,
        "representative": req.representative,
        "email": req.tax_invoice_email,
        "supply_amount": supply_amount,
        "vat": vat,
        "total_amount": amount,
        "status": "requested",
        "created_at": datetime.now(timezone.utc).isoformat(),
    }
    await asyncio.to_thread(lambda: sb.table("tax_invoices").insert(row).execute())

    # 즉시 외부 popbill API 호출 (POPBILL_API_KEY 있으면)
    popbill_key = os.getenv("POPBILL_LINK_ID", "") + os.getenv("POPBILL_SECRET_KEY", "")
    if popbill_key:
        # popbill 호출은 별도 모듈 — 여기선 stub
        logger.info("popbill 발행 요청 (stub) for %s", row["id"])

    return {
        "requested": True,
        "invoice_id": row["id"],
        "supply_amount": supply_amount,
        "vat": vat,
        "total_amount": amount,
        "note": "영업일 1~2일 내 사장님 이메일로 발송됩니다",
    }


class CashReceiptRequest(BaseModel):
    payment_key: str
    phone_or_business_no: str = Field(..., pattern=r"^\d{10,11}$")
    receipt_type: Literal["personal", "business"] = "personal"


@router.post("/cash-receipt")
async def issue_cash_receipt(req: CashReceiptRequest):
    """
    현금영수증 발행 (개인 / 사업자).

    Toss API: POST /v1/cash-receipts/{paymentKey}
    body: { type: "소득공제" | "지출증빙", registrationNumber }
    """
    secret_key = os.getenv("TOSS_SECRET_KEY", "")
    if not secret_key:
        return {"issued": False, "note": "Toss 시크릿 키 미설정 — mock 모드"}

    try:
        await _toss_post(
            f"/v1/cash-receipts/{req.payment_key}",
            {
                "type": "소득공제" if req.receipt_type == "personal" else "지출증빙",
                "registrationNumber": req.phone_or_business_no,
            },
            secret_key,
        )
        return {"issued": True}
    except HTTPException:
        raise


import re  # K4 — business_no 정규화에 사용


@router.post("/cancel")
async def cancel_subscription(req: CancelRequest):
    """
    해지 — 다음 결제일까지는 active 유지, 이후 종료.
    플로우:
      1. subscriptions.status = 'canceling'
      2. cron이 다음 결제일에 'canceled'로 변경 (자동 결제 X)
    """
    sb = _get_supabase()
    if sb is None:
        raise HTTPException(503, "Supabase 미설정")

    res = await asyncio.to_thread(
        lambda: sb.table("subscriptions")
        .update({
            "status": "canceling",
            "cancel_reason": req.reason,
            "canceled_at": datetime.now(timezone.utc).isoformat(),
        })
        .eq("store_id", req.store_id)
        .eq("status", "active")
        .execute()
    )
    return {"canceled": True, "rows_affected": len(res.data or [])}
