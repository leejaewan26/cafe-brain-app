-- Wave 5A: 보안 강화
-- 1) monthly_pnl 뷰에 SECURITY INVOKER 적용 (RLS 상속)
-- 2) profiles 테이블에 active 컬럼 (비활성화 가능)
-- 3) 사장만 타 프로필 수정 가능 RLS 강화

-- ═══════════════════════════════════════════════════════
-- 1. monthly_pnl 뷰 보안 (RLS 상속)
-- ═══════════════════════════════════════════════════════
DROP VIEW IF EXISTS public.monthly_pnl;

CREATE VIEW public.monthly_pnl WITH (security_invoker = true) AS
SELECT
  s.store_id,
  to_char(s.sale_date, 'YYYY-MM') AS month,
  SUM(s.revenue) AS total_revenue,
  SUM(s.cost) AS total_cost_of_goods,
  SUM(s.revenue - s.cost) AS gross_profit,
  SUM(s.revenue - s.cost) - COALESCE(
    (SELECT SUM(monthly_amount)
      FROM public.accounting_fixed_costs f
      WHERE f.store_id = s.store_id AND f.active = true),
    0
  ) AS net_profit,
  count(DISTINCT s.sale_date) AS operating_days
FROM public.sales_records s
GROUP BY s.store_id, to_char(s.sale_date, 'YYYY-MM');

COMMENT ON VIEW public.monthly_pnl IS
  'Issue #20 월별 손익. SECURITY INVOKER로 RLS 상속 — 본인 매장만 조회.';

-- ═══════════════════════════════════════════════════════
-- 2. profiles 활성화 플래그 (비활성 프로필은 로그인 불가)
-- ═══════════════════════════════════════════════════════
ALTER TABLE public.profiles
  ADD COLUMN IF NOT EXISTS active boolean NOT NULL DEFAULT true;

COMMENT ON COLUMN public.profiles.active IS
  '사장이 점장·매니저 프로필을 일시 비활성화 가능 (해고·휴직 대응)';

-- ═══════════════════════════════════════════════════════
-- 3. 프로필 권한 세분화 (사장이 점장의 세부 기능 on/off 가능)
-- ═══════════════════════════════════════════════════════
ALTER TABLE public.profiles
  ADD COLUMN IF NOT EXISTS permissions jsonb NOT NULL DEFAULT '{}'::jsonb;

COMMENT ON COLUMN public.profiles.permissions IS
  '프로필별 세부 권한 오버라이드. 기본: role 기준. 사장이 {"can_create_order": true} 등으로 커스텀.';

-- ═══════════════════════════════════════════════════════
-- 4. pg_cron 등록 헬퍼 (매장별 매일 메모리 캡처)
-- ═══════════════════════════════════════════════════════
-- 주의: pg_cron extension은 Supabase Dashboard에서 먼저 활성화 필요

CREATE OR REPLACE FUNCTION public.run_all_stores_memory_capture()
RETURNS int AS $$
DECLARE
  store_row record;
  total_events int := 0;
  result_row record;
BEGIN
  FOR store_row IN SELECT id FROM public.stores WHERE agent_learning_enabled = true
  LOOP
    FOR result_row IN SELECT * FROM public.run_daily_memory_capture(store_row.id)
    LOOP
      total_events := total_events + COALESCE(result_row.count, 0);
    END LOOP;
  END LOOP;
  RETURN total_events;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

COMMENT ON FUNCTION public.run_all_stores_memory_capture IS
  'pg_cron용: 매일 모든 매장의 메모리 캡처 실행. 반환: 감지된 총 이벤트 수.';

-- pg_cron 스케줄 예시 (Supabase Dashboard에서 활성화 후 실행):
-- SELECT cron.schedule(
--   'daily-memory-capture',
--   '0 8 * * *',  -- 매일 오전 8시 (KST)
--   $$SELECT public.run_all_stores_memory_capture()$$
-- );
