// 대시보드 홈 — 각 모듈 핵심 지표 위젯 연동 (4단계 최종 통합)
// 데이터 소스: menuStore, reviewStore, chatStore, authStore(storeInfo)
import { useMemo } from 'react'
import { Link } from 'react-router-dom'
import { useStoreContext } from '@/hooks/useStoreContext'
import { useMenuStore } from '@/store/menuStore'
import { useReviewStore } from '@/store/reviewStore'
import { useChatStore } from '@/store/chatStore'
import {
  Star, BookOpen,
  MessageCircle, TrendingUp, AlertCircle, Coffee,
  ChevronRight, Sparkles, Megaphone,
} from 'lucide-react'
import BepGauge from '@/components/BepGauge'
import TrialBanner from '@/components/TrialBanner'
import DemoSeederButton from '@/components/DemoSeederButton'
import PullToRefreshIndicator from '@/components/PullToRefreshIndicator'
import { usePullToRefresh } from '@/hooks/usePullToRefresh'
import { useAgentBriefing } from '@/hooks/useAgentBriefing'

// ─── 위젯 공통 카드 ───
interface StatCardProps {
  label: string
  value: string | number
  sub?: string
  icon: React.ElementType
  color: string
  href: string
  badge?: string
  badgeOk?: boolean
}

function StatCard({ label, value, sub, icon: Icon, color, href, badge, badgeOk }: StatCardProps) {
  return (
    <Link
      to={href}
      className="group bg-white rounded-2xl p-4 border border-gray-100 shadow-sm hover:shadow-md hover:border-[#D4A574]/40 transition-all duration-200 flex flex-col gap-3"
    >
      <div className="flex items-center justify-between">
        <div className="w-9 h-9 rounded-xl flex items-center justify-center" style={{ backgroundColor: `${color}18` }}>
          <Icon size={18} style={{ color }} />
        </div>
        {badge && (
          <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${badgeOk ? 'bg-green-100 text-green-700' : 'bg-amber-100 text-amber-700'}`}>
            {badge}
          </span>
        )}
      </div>
      <div>
        <p className="text-2xl font-bold text-[#2C1810] leading-none">{value}</p>
        <p className="text-xs text-gray-500 mt-1">{label}</p>
        {sub && <p className="text-xs text-gray-400 mt-0.5">{sub}</p>}
      </div>
      <div className="flex items-center gap-1 text-xs text-[#D4A574] font-medium opacity-0 group-hover:opacity-100 transition-opacity">
        자세히 보기 <ChevronRight size={12} />
      </div>
    </Link>
  )
}

// ─── 빠른 액션 버튼 ───
const QUICK_ACTIONS = [
  { label: '매출 CSV 업로드', icon: TrendingUp, href: '/sales', color: '#2C1810' },
  { label: '리뷰 답글 생성',   icon: Star,       href: '/reviews', color: '#4A90A4' },
  { label: '마케팅 문구 생성', icon: Megaphone,  href: '/marketing', color: '#7B6CB0' },
  { label: '새 메뉴 등록',     icon: BookOpen,   href: '/menu', color: '#5A9E6F' },
]

// ─── 메인 컴포넌트 ───
export default function DashboardPage() {
  const { storeInfo } = useStoreContext()
  const { menus } = useMenuStore()
  const { reviews } = useReviewStore()
  const { sessions } = useChatStore()

  // Issue #10: 능동형 에이전트 — 하루 1회 자동 브리핑
  useAgentBriefing()

  // ─ 메뉴 지표 계산 ─
  const menuStats = useMemo(() => {
    const totalMenus = menus.length
    const coffeeCount = menus.filter(m => m.category === 'coffee').length
    const avgCostRatio = totalMenus > 0
      ? Math.round(menus.reduce((sum, m) => {
          const ratio = m.salePrice > 0 ? (m.totalCost / m.salePrice) * 100 : 0
          return sum + ratio
        }, 0) / totalMenus)
      : 0
    return { totalMenus, coffeeCount, avgCostRatio }
  }, [menus])

  // ─ 리뷰 지표 계산 ─
  const reviewStats = useMemo(() => {
    const total = reviews.length
    const pending = reviews.filter(r => r.reply_status === 'pending').length
    const avgRating = total > 0
      ? (reviews.reduce((s, r) => s + r.rating, 0) / total).toFixed(1)
      : '0.0'
    const negCount = reviews.filter(r => r.rating <= 2).length
    return { total, pending, avgRating, negCount }
  }, [reviews])

  // ─ 채팅 지표 계산 ─
  const chatStats = useMemo(() => {
    const totalSessions = sessions.length
    const totalMsgs = sessions.reduce((s, sess) => s + sess.messages.length, 0)
    return { totalSessions, totalMsgs }
  }, [sessions])

  // 현재 시간대별 인사말
  const hour = new Date().getHours()
  const greeting = hour < 12 ? '좋은 아침이에요' : hour < 18 ? '안녕하세요' : '수고하셨어요'

  // I8: 모바일 풀-투-리프레시
  const { pullDistance, refreshing } = usePullToRefresh({
    onRefresh: () => {
      // window.location.reload()는 너무 무거움 — 핵심 store만 리프레시
      window.location.reload()
    },
  })

  return (
    <div className="max-w-3xl mx-auto px-4 py-6 space-y-6">
      <PullToRefreshIndicator pullDistance={pullDistance} refreshing={refreshing} />
      {/* Day 4-3: 체험·업그레이드 배너 (trial 상태일 때만 렌더) */}
      <TrialBanner />
      <DemoSeederButton />

      {/* ─── 환영 배너 ─── */}
      <div className="bg-gradient-to-r from-[#2C1810] via-[#3d2418] to-[#2C1810] rounded-2xl p-5 text-white relative overflow-hidden">
        <div className="absolute inset-0 opacity-5 pointer-events-none" style={{ backgroundImage: 'radial-gradient(circle at 80% 20%, #D4A574 0%, transparent 50%)' }} />
        <div className="relative">
          <p className="text-[#D4A574] text-sm font-medium mb-1">
            <Sparkles size={12} className="inline mr-1" />{greeting},
          </p>
          <h1 className="text-xl font-bold">{storeInfo?.owner_name ?? '사장님'}님! ☕</h1>
          <p className="text-white/60 text-sm mt-1">
            {storeInfo?.store_name ?? '카페 브레인'}과 함께 스마트하게 운영하세요.
          </p>
          {storeInfo?.ambiance_keywords && storeInfo.ambiance_keywords.length > 0 && (
            <div className="flex gap-1.5 flex-wrap mt-3">
              {storeInfo.ambiance_keywords.slice(0, 3).map(kw => (
                <span key={kw} className="px-2.5 py-0.5 text-xs bg-white/10 text-[#D4A574] rounded-full border border-[#D4A574]/30">
                  {kw}
                </span>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* ─── BEP 게이지 (Issue #1) ─── */}
      <section>
        <h2 className="text-sm font-bold text-gray-400 uppercase tracking-wider mb-3">🎯 이번 달 목표</h2>
        <BepGauge variant="full" />
      </section>

      {/* ─── 핵심 지표 위젯 그리드 ─── */}
      <section>
        <h2 className="text-sm font-bold text-gray-400 uppercase tracking-wider mb-3">📊 실시간 지표</h2>
        <div className="grid grid-cols-2 gap-3">

          {/* 메뉴 위젯 */}
          <StatCard
            label="등록 메뉴"
            value={menuStats.totalMenus}
            sub={`커피 ${menuStats.coffeeCount}개 · 평균 원가율 ${menuStats.avgCostRatio}%`}
            icon={BookOpen}
            color="#5A9E6F"
            href="/menu"
            badge={menuStats.avgCostRatio < 35 ? '원가 양호' : '원가 점검'}
            badgeOk={menuStats.avgCostRatio < 35}
          />

          {/* 리뷰 위젯 */}
          <StatCard
            label="전체 리뷰"
            value={reviewStats.total}
            sub={`미답글 ${reviewStats.pending}건 · 평균 ⭐${reviewStats.avgRating}`}
            icon={Star}
            color="#4A90A4"
            href="/reviews"
            badge={reviewStats.pending > 0 ? `${reviewStats.pending}건 대기` : '모두 완료'}
            badgeOk={reviewStats.pending === 0}
          />

          {/* AI 채팅 위젯 */}
          <StatCard
            label="AI 대화"
            value={chatStats.totalSessions}
            sub={`총 ${chatStats.totalMsgs}개 메시지`}
            icon={MessageCircle}
            color="#E07A5F"
            href="/chat"
          />

          {/* 부정 리뷰 알림 위젯 */}
          <StatCard
            label="주의 리뷰"
            value={reviewStats.negCount}
            sub="별점 1–2점 리뷰"
            icon={AlertCircle}
            color={reviewStats.negCount > 0 ? '#e57373' : '#9B9B9B'}
            href="/reviews"
            badge={reviewStats.negCount > 0 ? '답글 필요' : '이상 없음'}
            badgeOk={reviewStats.negCount === 0}
          />
        </div>
      </section>

      {/* ─── 매장 정보 요약 ─── */}
      {storeInfo && (
        <section className="bg-white rounded-2xl border border-gray-100 shadow-sm">
          <div className="flex items-center justify-between px-4 pt-4 pb-2">
            <h2 className="text-sm font-bold text-[#2C1810]">
              <Coffee size={14} className="inline mr-1.5 text-[#D4A574]" />내 매장
            </h2>
          </div>
          <div className="grid grid-cols-3 gap-px bg-gray-100 border-t border-gray-100">
            {[
              { label: '메뉴 수', value: storeInfo.menu_count },
              { label: '직원 수', value: storeInfo.employee_count },
              { label: '상권', value: storeInfo.district_type },
            ].map(item => (
              <div key={item.label} className="bg-white px-4 py-3 text-center last:rounded-br-2xl first:rounded-bl-2xl">
                <p className="text-lg font-bold text-[#D4A574]">{item.value}</p>
                <p className="text-xs text-gray-400 mt-0.5">{item.label}</p>
              </div>
            ))}
          </div>
        </section>
      )}

      {/* ─── 빠른 액션 ─── */}
      <section>
        <h2 className="text-sm font-bold text-gray-400 uppercase tracking-wider mb-3">⚡ 빠른 실행</h2>
        <div className="grid grid-cols-2 gap-3">
          {QUICK_ACTIONS.map(({ label, icon: Icon, href, color }) => (
            <Link
              key={href}
              to={href}
              className="flex items-center gap-3 bg-white border border-gray-100 rounded-xl px-3.5 py-3 hover:shadow-md hover:border-[#D4A574]/40 transition-all duration-200 group"
            >
              <div className="w-8 h-8 rounded-lg flex items-center justify-center shrink-0" style={{ backgroundColor: `${color}15` }}>
                <Icon size={15} style={{ color }} />
              </div>
              <span className="text-xs font-semibold text-[#2C1810] leading-tight">{label}</span>
            </Link>
          ))}
        </div>
      </section>

      {/* 하단 여백 (모바일 탭바용) */}
      <div className="h-4" />
    </div>
  )
}
