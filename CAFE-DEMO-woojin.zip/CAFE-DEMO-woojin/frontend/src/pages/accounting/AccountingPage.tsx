// 회계 — 월별 P&L + 고정비 관리 (Issue #20)
// 사장 전용 (재무 권한 필요)
import { useCallback, useEffect, useMemo, useState } from 'react'
import { Link } from 'react-router-dom'
import {
  Wallet, ChevronLeft, Plus, Edit3, X, Loader2,
  DollarSign, Lock,
} from 'lucide-react'
import {
  LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip as RechartsTooltip,
  ResponsiveContainer, Bar, BarChart, Legend,
} from 'recharts'
import toast from 'react-hot-toast'
import { supabase } from '@/lib/supabase'
import { useAuthStore } from '@/store/authStore'
import { useProfileStore, canAccess } from '@/store/profileStore'
import { formatCurrency, cn } from '@/lib/utils'
import ExportMenu from '@/components/ExportMenu'

interface FixedCost {
  id: string
  store_id: string
  category: 'rent' | 'labor' | 'utilities' | 'communication' | 'insurance' | 'loan' | 'tax' | 'other'
  label: string
  monthly_amount: number
  notes?: string | null
  active: boolean
}

interface MonthlyPnL {
  store_id: string
  month: string
  total_revenue: number
  total_cost_of_goods: number
  gross_profit: number
  net_profit: number
  operating_days: number
}

const CATEGORY_META: Record<FixedCost['category'], { label: string; color: string; bg: string }> = {
  rent:          { label: '임대료',     color: 'text-blue-700',   bg: 'bg-blue-100' },
  labor:         { label: '인건비(고정)', color: 'text-purple-700', bg: 'bg-purple-100' },
  utilities:     { label: '공과금',     color: 'text-amber-700',  bg: 'bg-amber-100' },
  communication: { label: '통신비',     color: 'text-indigo-700', bg: 'bg-indigo-100' },
  insurance:     { label: '보험',       color: 'text-green-700',  bg: 'bg-green-100' },
  loan:          { label: '대출상환',   color: 'text-red-700',    bg: 'bg-red-100' },
  tax:           { label: '세금',       color: 'text-gray-700',   bg: 'bg-gray-200' },
  other:         { label: '기타',       color: 'text-gray-600',   bg: 'bg-gray-100' },
}

export default function AccountingPage() {
  const user = useAuthStore((s) => s.user)
  const activeProfile = useProfileStore((s) => s.activeProfile)
  const canEdit = canAccess(activeProfile, 'financial_info')

  const [costs, setCosts] = useState<FixedCost[]>([])
  const [pnl, setPnl] = useState<MonthlyPnL[]>([])
  const [loading, setLoading] = useState(true)
  const [tab, setTab] = useState<'pnl' | 'costs'>('pnl')
  const [showAdd, setShowAdd] = useState(false)
  const [editingId, setEditingId] = useState<string | null>(null)

  const loadData = useCallback(async () => {
    if (!user) return
    const [costsRes, pnlRes] = await Promise.all([
      supabase.from('accounting_fixed_costs').select('*').eq('store_id', user.id).order('category'),
      supabase.from('monthly_pnl').select('*').eq('store_id', user.id).order('month', { ascending: false }).limit(12),
    ])
    if (costsRes.error) toast.error(costsRes.error.message)
    else setCosts((costsRes.data ?? []) as FixedCost[])
    if (pnlRes.error) console.warn('P&L load:', pnlRes.error.message)
    else setPnl(((pnlRes.data ?? []) as MonthlyPnL[]).reverse())
    setLoading(false)
  }, [user])

  useEffect(() => {
    // eslint-disable-next-line react-hooks/set-state-in-effect
    void loadData()
  }, [loadData])

  const totalFixed = useMemo(
    () => costs.filter((c) => c.active).reduce((s, c) => s + c.monthly_amount, 0),
    [costs]
  )

  const currentMonth = pnl[pnl.length - 1]

  return (
    <div className="min-h-screen bg-[#FAFAF8] dark:bg-[#1A1A1A]">
      <header className="bg-[#2C1810] text-white px-4 py-3 flex items-center gap-3">
        <Link to="/dashboard" className="hover:text-[#D4A574]"><ChevronLeft size={20} /></Link>
        <Wallet size={18} className="text-[#D4A574]" />
        <h1 className="font-bold text-base flex-1">회계·손익</h1>
        {/* Day 4-1: PnL·고정비 내보내기 */}
        {(pnl.length > 0 || costs.length > 0) && (
          <ExportMenu
            rows={(tab === 'pnl' ? pnl : costs) as unknown as Record<string, unknown>[]}
            title={tab === 'pnl' ? '월별손익' : '고정비목록'}
            printableId="print-accounting-report"
            size="sm"
          />
        )}
      </header>

      <div className="flex bg-white dark:bg-gray-800 border-b border-gray-100 dark:border-gray-700 px-2 pt-2">
        {[
          { id: 'pnl' as const, label: '📈 월별 손익' },
          { id: 'costs' as const, label: '💸 고정비 관리' },
        ].map(({ id, label }) => (
          <button key={id} onClick={() => setTab(id)}
            className={cn('shrink-0 px-4 py-2.5 text-sm font-medium rounded-t-lg',
              tab === id ? 'bg-[#2C1810] text-white' : 'text-gray-500 hover:bg-gray-50 dark:hover:bg-gray-700')}>
            {label}
          </button>
        ))}
      </div>

      <main className="max-w-3xl mx-auto px-4 py-4 space-y-4 pb-24" id="print-accounting-report">
        <div className="print-only mb-4">
          <h1>회계·손익 리포트</h1>
          <p style={{ fontSize: '10pt', color: '#666' }}>
            생성일: {new Date().toLocaleDateString('ko-KR')}
          </p>
        </div>
        {!canEdit && (
          <div className="flex items-center gap-2 p-3 bg-amber-50 border border-amber-100 rounded-xl text-xs text-amber-700">
            <Lock size={12} /> 조회만 가능합니다. 사장 프로필로 전환 필요.
          </div>
        )}

        {loading && <div className="flex items-center justify-center py-10"><Loader2 className="w-6 h-6 animate-spin text-[#D4A574]" /></div>}

        {/* ─── 월별 손익 탭 ─── */}
        {!loading && tab === 'pnl' && (
          <>
            {/* 이번 달 요약 */}
            {currentMonth ? (
              <div className="bg-white dark:bg-gray-800 rounded-2xl p-5 border border-gray-100 dark:border-gray-700 shadow-sm">
                <div className="flex items-center justify-between mb-4">
                  <div>
                    <h3 className="font-bold text-[#2C1810] dark:text-gray-100">{currentMonth.month} 손익</h3>
                    <p className="text-xs text-gray-400">{currentMonth.operating_days}일 영업</p>
                  </div>
                  <span className={cn('text-[10px] font-bold px-2 py-0.5 rounded-full',
                    currentMonth.net_profit >= 0 ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700')}>
                    {currentMonth.net_profit >= 0 ? '흑자' : '적자'}
                  </span>
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <PnLCell label="매출" value={currentMonth.total_revenue} />
                  <PnLCell label="원재료비" value={-currentMonth.total_cost_of_goods} />
                  <PnLCell label="매출총이익" value={currentMonth.gross_profit} sub="매출-원재료" />
                  <PnLCell label="고정비" value={-totalFixed} sub={`${costs.filter((c) => c.active).length}개 항목`} />
                </div>
                <div className="mt-4 pt-4 border-t border-gray-100 dark:border-gray-700">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-[#2C1810] dark:text-gray-100">순이익</span>
                    <span className={cn('text-xl font-black',
                      currentMonth.net_profit >= 0 ? 'text-green-600' : 'text-red-600')}>
                      {formatCurrency(currentMonth.net_profit)}
                    </span>
                  </div>
                  <p className="text-[10px] text-gray-400 mt-1">
                    영업이익률 {currentMonth.total_revenue > 0
                      ? ((currentMonth.net_profit / currentMonth.total_revenue) * 100).toFixed(1)
                      : '0.0'}%
                  </p>
                </div>
              </div>
            ) : (
              <div className="bg-white dark:bg-gray-800 rounded-2xl p-8 text-center text-gray-400 border border-gray-100 dark:border-gray-700">
                <DollarSign size={28} className="mx-auto mb-2 opacity-30" />
                <p className="text-sm">매출 데이터를 업로드하면 손익이 계산됩니다</p>
              </div>
            )}

            {/* 월별 추이 차트 */}
            {pnl.length > 1 && (
              <div className="bg-white dark:bg-gray-800 rounded-2xl p-4 border border-gray-100 dark:border-gray-700 shadow-sm">
                <h3 className="text-sm font-bold text-[#2C1810] dark:text-gray-100 mb-3">월별 손익 추이</h3>
                <ResponsiveContainer width="100%" height={280}>
                  <BarChart data={pnl} margin={{ top: 10, right: 12, bottom: 35, left: 0 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="var(--border-hair)" vertical={false} />
                    <XAxis
                      dataKey="month"
                      tick={{ fontSize: 10, fill: 'var(--text-mute)' }}
                      interval="preserveStartEnd"
                      minTickGap={25}
                      tickFormatter={(v) => v.slice(2).replace('-', '/')}
                      tickLine={false}
                      axisLine={{ stroke: 'var(--border-hair)' }}
                    />
                    <YAxis
                      tick={{ fontSize: 10, fill: 'var(--text-mute)' }}
                      tickFormatter={(v) => `${(v / 10000).toFixed(0)}만`}
                      width={50}
                      tickLine={false}
                      axisLine={false}
                    />
                    <RechartsTooltip
                      formatter={(v) => formatCurrency(Number(v))}
                      labelFormatter={(v) => `${v}월 손익`}
                      contentStyle={{ background: 'var(--bg-card)', border: '1px solid var(--border-hair)', borderRadius: 12, fontSize: 12 }}
                      cursor={{ fill: 'rgba(212,165,116,0.08)' }}
                    />
                    <Legend
                      wrapperStyle={{ fontSize: 11, paddingTop: 12 }}
                      iconType="circle"
                      verticalAlign="bottom"
                      height={32}
                    />
                    <Bar dataKey="total_revenue" name="매출" fill="#D4A574" radius={[4, 4, 0, 0]} maxBarSize={24} />
                    <Bar dataKey="gross_profit" name="매출총이익" fill="#5A9E6F" radius={[4, 4, 0, 0]} maxBarSize={24} />
                    <Bar dataKey="net_profit" name="순이익" fill="#2C1810" radius={[4, 4, 0, 0]} maxBarSize={24} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            )}

            {pnl.length > 1 && (
              <div className="bg-white dark:bg-gray-800 rounded-2xl p-4 border border-gray-100 dark:border-gray-700 shadow-sm">
                <h3 className="text-sm font-bold text-[#2C1810] dark:text-gray-100 mb-3">순이익 추이</h3>
                <ResponsiveContainer width="100%" height={200}>
                  <LineChart data={pnl} margin={{ top: 10, right: 12, bottom: 15, left: 0 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="var(--border-hair)" vertical={false} />
                    <XAxis
                      dataKey="month"
                      tick={{ fontSize: 10, fill: 'var(--text-mute)' }}
                      interval="preserveStartEnd"
                      minTickGap={30}
                      tickFormatter={(v) => v.slice(2).replace('-', '/')}
                      tickLine={false}
                      axisLine={{ stroke: 'var(--border-hair)' }}
                    />
                    <YAxis
                      tick={{ fontSize: 10, fill: 'var(--text-mute)' }}
                      tickFormatter={(v) => `${(v / 10000).toFixed(0)}만`}
                      width={50}
                      tickLine={false}
                      axisLine={false}
                    />
                    <RechartsTooltip
                      formatter={(v) => formatCurrency(Number(v))}
                      labelFormatter={(v) => `${v}월 순이익`}
                      contentStyle={{ background: 'var(--bg-card)', border: '1px solid var(--border-hair)', borderRadius: 12, fontSize: 12 }}
                    />
                    <Line type="monotone" dataKey="net_profit" stroke="#2C1810" strokeWidth={2}
                      dot={{ fill: '#D4A574', r: 4 }} activeDot={{ r: 6 }} />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            )}
          </>
        )}

        {/* ─── 고정비 관리 탭 ─── */}
        {!loading && tab === 'costs' && (
          <>
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-semibold text-[#2C1810] dark:text-gray-100">월 고정비 총액</p>
                <p className="text-2xl font-bold text-[#D4A574]">{formatCurrency(totalFixed)}</p>
              </div>
              {canEdit && (
                <button onClick={() => setShowAdd(true)}
                  className="flex items-center gap-1 px-3 py-1.5 bg-[#2C1810] text-white rounded-lg text-xs font-semibold">
                  <Plus size={12} /> 항목 추가
                </button>
              )}
            </div>

            {costs.length === 0 && (
              <div className="bg-white dark:bg-gray-800 rounded-2xl p-8 text-center text-gray-400 border border-gray-100 dark:border-gray-700">
                <p className="text-sm">고정비 항목을 추가하세요 (임대료, 공과금 등)</p>
              </div>
            )}

            <div className="space-y-2">
              {costs.map((c) =>
                editingId === c.id ? (
                  <FixedCostEditRow key={c.id} cost={c} onCancel={() => setEditingId(null)}
                    onSaved={() => { setEditingId(null); void loadData() }} />
                ) : (
                  <FixedCostRow key={c.id} cost={c} canEdit={canEdit} onEdit={() => setEditingId(c.id)} />
                )
              )}
            </div>
          </>
        )}
      </main>

      {showAdd && user && (
        <AddFixedCostModal storeId={user.id}
          onClose={() => setShowAdd(false)}
          onAdded={() => { setShowAdd(false); void loadData() }} />
      )}
    </div>
  )
}

function PnLCell({ label, value, sub }: { label: string; value: number; sub?: string }) {
  return (
    <div className="bg-[#FAFAF8] dark:bg-gray-900 rounded-xl p-3">
      <p className="text-xs text-gray-400">{label}</p>
      <p className={cn('text-base font-bold mt-0.5',
        value >= 0 ? 'text-[#2C1810] dark:text-gray-100' : 'text-red-600')}>
        {formatCurrency(value)}
      </p>
      {sub && <p className="text-[10px] text-gray-400 mt-0.5">{sub}</p>}
    </div>
  )
}

function FixedCostRow({ cost, canEdit, onEdit }: {
  cost: FixedCost; canEdit: boolean; onEdit: () => void
}) {
  const meta = CATEGORY_META[cost.category]
  return (
    <div className={cn('bg-white dark:bg-gray-800 rounded-xl p-3 border flex items-center gap-3',
      cost.active ? 'border-gray-100 dark:border-gray-700' : 'border-gray-100 opacity-60')}>
      <span className={cn('text-[10px] font-bold px-2 py-0.5 rounded-full', meta.bg, meta.color)}>
        {meta.label}
      </span>
      <div className="flex-1 min-w-0">
        <p className="font-semibold text-[#2C1810] dark:text-gray-100 text-sm">{cost.label}</p>
        {cost.notes && <p className="text-xs text-gray-400 mt-0.5">{cost.notes}</p>}
      </div>
      <p className="font-bold text-[#2C1810] dark:text-gray-100 text-sm">{formatCurrency(cost.monthly_amount)}</p>
      {canEdit && (
        <button onClick={onEdit} className="p-1.5 text-gray-400 hover:text-[#2C1810] rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700">
          <Edit3 size={13} />
        </button>
      )}
    </div>
  )
}

function FixedCostEditRow({ cost, onCancel, onSaved }: {
  cost: FixedCost; onCancel: () => void; onSaved: () => void
}) {
  const [label, setLabel] = useState(cost.label)
  const [amount, setAmount] = useState(cost.monthly_amount)
  const [category, setCategory] = useState(cost.category)
  const [active, setActive] = useState(cost.active)
  const [saving, setSaving] = useState(false)

  const handleSave = async () => {
    setSaving(true)
    const { error } = await supabase.from('accounting_fixed_costs').update({
      label, monthly_amount: amount, category, active,
      updated_at: new Date().toISOString(),
    }).eq('id', cost.id)
    if (error) toast.error(error.message)
    else { toast.success('저장됐어요'); onSaved() }
    setSaving(false)
  }

  const handleDelete = async () => {
    if (!confirm(`"${cost.label}" 삭제?`)) return
    const { error } = await supabase.from('accounting_fixed_costs').delete().eq('id', cost.id)
    if (error) toast.error(error.message)
    else { toast.success('삭제됨'); onSaved() }
  }

  return (
    <div className="bg-[#D4A574]/5 rounded-xl p-3 border-2 border-[#D4A574] space-y-2">
      <div className="grid grid-cols-12 gap-2">
        <select value={category} onChange={(e) => setCategory(e.target.value as FixedCost['category'])}
          className="col-span-3 px-2 py-1.5 rounded-lg border border-gray-200 text-xs">
          {Object.entries(CATEGORY_META).map(([k, v]) => <option key={k} value={k}>{v.label}</option>)}
        </select>
        <input value={label} onChange={(e) => setLabel(e.target.value)}
          className="col-span-5 px-2 py-1.5 rounded-lg border border-gray-200 text-sm" placeholder="항목명" />
        <input type="number" value={amount} onChange={(e) => setAmount(Number(e.target.value) || 0)}
          className="col-span-4 px-2 py-1.5 rounded-lg border border-gray-200 text-sm text-right" />
      </div>
      <div className="flex items-center gap-2">
        <label className="text-xs text-gray-600 flex items-center gap-1">
          <input type="checkbox" checked={active} onChange={(e) => setActive(e.target.checked)}
            className="accent-[#D4A574]" />
          활성
        </label>
        <button onClick={handleDelete} className="ml-auto px-3 py-1.5 text-xs text-red-500 border border-red-200 rounded-lg">삭제</button>
        <button onClick={onCancel} className="px-3 py-1.5 text-xs border border-gray-200 rounded-lg">취소</button>
        <button onClick={handleSave} disabled={saving}
          className="px-3 py-1.5 text-xs bg-[#2C1810] text-white rounded-lg disabled:opacity-50">
          {saving ? '저장...' : '저장'}
        </button>
      </div>
    </div>
  )
}

function AddFixedCostModal({ storeId, onClose, onAdded }: {
  storeId: string; onClose: () => void; onAdded: () => void
}) {
  const [category, setCategory] = useState<FixedCost['category']>('rent')
  const [label, setLabel] = useState('')
  const [amount, setAmount] = useState(0)
  const [notes, setNotes] = useState('')
  const [saving, setSaving] = useState(false)

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => { if (e.key === 'Escape') onClose() }
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [onClose])

  const handleAdd = async () => {
    if (!label.trim()) { toast.error('항목명 필수'); return }
    setSaving(true)
    const { error } = await supabase.from('accounting_fixed_costs').insert({
      store_id: storeId, category, label: label.trim(),
      monthly_amount: amount, notes: notes.trim() || null,
    })
    if (error) toast.error(error.message)
    else { toast.success('추가됐어요'); onAdded() }
    setSaving(false)
  }

  return (
    <div role="dialog" aria-modal="true"
      className="fixed inset-0 bg-black/50 flex items-end md:items-center justify-center z-50 md:p-4"
      onClick={(e) => { if (e.target === e.currentTarget) onClose() }}>
      <div className="bg-white dark:bg-gray-800 w-full md:max-w-md md:rounded-2xl rounded-t-3xl p-5 space-y-3">
        <div className="flex items-center justify-between">
          <h3 className="font-bold text-[#2C1810] dark:text-gray-100">고정비 항목 추가</h3>
          <button onClick={onClose}><X size={18} /></button>
        </div>
        <select value={category} onChange={(e) => setCategory(e.target.value as FixedCost['category'])}
          className="w-full px-3 py-2 rounded-xl border border-gray-200 dark:border-gray-700 dark:bg-gray-700 text-sm">
          {Object.entries(CATEGORY_META).map(([k, v]) => <option key={k} value={k}>{v.label}</option>)}
        </select>
        <input value={label} onChange={(e) => setLabel(e.target.value)}
          placeholder="항목 이름 (예: 임대료, KT 인터넷)"
          className="w-full px-3 py-2 rounded-xl border border-gray-200 dark:border-gray-700 dark:bg-gray-700 text-sm" />
        <input type="number" value={amount || ''} onChange={(e) => setAmount(Number(e.target.value) || 0)}
          placeholder="월 금액 (원)"
          className="w-full px-3 py-2 rounded-xl border border-gray-200 dark:border-gray-700 dark:bg-gray-700 text-sm" />
        <textarea value={notes} onChange={(e) => setNotes(e.target.value)} placeholder="메모 (선택)" rows={2}
          className="w-full px-3 py-2 rounded-xl border border-gray-200 dark:border-gray-700 dark:bg-gray-700 text-sm resize-none" />
        <div className="flex gap-2">
          <button onClick={onClose} className="flex-1 py-2 border border-gray-200 rounded-xl text-sm text-gray-600">취소</button>
          <button onClick={handleAdd} disabled={saving}
            className="flex-1 py-2 bg-[#2C1810] text-white rounded-xl text-sm font-semibold disabled:opacity-50">
            {saving ? '추가...' : '추가'}
          </button>
        </div>
      </div>
    </div>
  )
}
